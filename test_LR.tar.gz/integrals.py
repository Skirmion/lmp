# integrals.py
# ============
# FCIDUMP-writer, совместимый с integrals_core.write_two_e_fcidump.
# • Сортировка МО по иррепам (можно отключить), корректный ORBSYM.
# • Поддержка add_ops: имена PySCF интеграторов (1e/2e) и/или AO-массивы.
# • Профиль RSS (опционально).
# • Предобработки МО: NO в активе (только через method.cas_natorb) и полуканонизация closed/virtual.

import os
from contextlib import contextmanager
from typing import Dict, List, Optional, Sequence, Tuple, Union

import numpy as np
import psutil  # type: ignore
from pyscf import symm  # type: ignore

import integrals_core as core


# --------------------------------------------------------------------------- #
#   RSS-лог
# --------------------------------------------------------------------------- #

def _rss_mb() -> float:
    return psutil.Process(os.getpid()).memory_info().rss / 1024 ** 2


def _log_mem(tag: str, store: List[Tuple[str, float]], enable: bool):
    if enable:
        mb = _rss_mb()
        print(f"[MEM] {tag:<24}{mb:8.1f} MB")
        store.append((tag, mb))


# --------------------------------------------------------------------------- #
#   Вспомогательные — базовые утилиты
# --------------------------------------------------------------------------- #

def _is_unrestricted(mo_coeff):
    return isinstance(mo_coeff, (list, tuple))


def _as_list(x):
    return x if _is_unrestricted(x) else [x, x]


def _from_list(x_list, template):
    return x_list if _is_unrestricted(template) else x_list[0]


def _is_casscf_obj(x) -> bool:
    """Грубая проверка CASSCF/UCASSCF-объекта."""
    return all(hasattr(x, attr) for attr in ("ncore", "ncas", "ci", "fcisolver"))


def _guess_ncore_ncas(mol, method):
    """
    Для SCF-методов: ncore=nocc (число занятых орбиталей), ncas=0.
    Для CASSCF — берём из объекта.
    """
    if _is_casscf_obj(method):
        return int(method.ncore), int(method.ncas)
    # RHF/ROHF fallback
    nocc = None
    if hasattr(method, "mo_occ") and method.mo_occ is not None:
        occ = np.asarray(method.mo_occ)
        nocc = int((occ > 1e-8).sum())
    if nocc is None or nocc <= 0:
        nocc = int(mol.nelectron // 2)
    return nocc, 0


def _block_eigh_within_irreps(M, orbsym_block):
    """
    Диагонализует матрицу M по подблокам одинаковых иррепов.
    Возвращает собственные значения и блочно-собранные U.
    """
    n = M.shape[0]
    if n == 0:
        return np.array([]), np.eye(0)
    idxs = {}
    for i, s in enumerate(orbsym_block):
        idxs.setdefault(str(s), []).append(i)
    U = np.eye(n)
    evals = np.empty(n)
    for _, ii in idxs.items():
        ii = np.asarray(ii, dtype=int)
        if ii.size == 0:
            continue
        w, v = np.linalg.eigh(M[np.ix_(ii, ii)])
        U[np.ix_(ii, ii)] = v
        evals[ii] = w
    return evals, U


@contextmanager
def _temporary_mc_mos(mc, mo_tmp):
    """Временно подменяет mc.mo_coeff на mo_tmp и возвращает обратно."""
    mo_save = mc.mo_coeff
    try:
        mc.mo_coeff = mo_tmp
        yield
    finally:
        mc.mo_coeff = mo_save


def _dm_to_ao(mol, C, dm, *, prefer_mf=None):
    """
    Вернёт DM в AO-базисе.
    - Если dm уже (nao,nao), отдаём как есть.
    - Если (nmo,nmo), конвертируем: C @ dm @ C.T
    - Если dm=None и передан mean-field, берём mf.make_rdm1()
    """
    nao = mol.nao_nr()
    if dm is not None:
        arr = np.asarray(dm)
        if arr.ndim == 2 and arr.shape == (nao, nao):
            return arr
        # считаем, что это МО-база
        return C @ arr @ C.T
    if prefer_mf is not None and hasattr(prefer_mf, "make_rdm1"):
        return np.asarray(prefer_mf.make_rdm1())
    raise RuntimeError("Cannot obtain AO density matrix.")


def _ensure_ao_2d(x):
    """
    Приводит h/veff к 2D (nao,nao).
    Поддерживает варианты: (nao,nao), список/кортеж из двух матриц,
    а также тензоры с осью спина (2,nao,nao) или (nao,nao,2) — усредняем по спину.
    """
    if isinstance(x, (list, tuple)):
        mats = [np.asarray(m) for m in x]
        return sum(mats) / len(mats)
    arr = np.asarray(x)
    if arr.ndim == 2:
        return arr
    if arr.ndim == 3:
        for ax, dim in enumerate(arr.shape):
            if dim == 2:
                return arr.mean(axis=ax)
        if 1 in arr.shape:
            return np.squeeze(arr)
    raise RuntimeError(f"Cannot coerce AO matrix to 2D, got shape {arr.shape}")


def _label_orb_symm_safe(mol, mo, *, verbose=False):
    """
    Пытается разметить иррепы для текущих МО.
    1) label_orb_symm(mo); при неудаче:
    2) mo ← symm.symmetrize_space(mo); снова label_orb_symm;
    3) если всё ещё неудачно — возврат (labels=None, mo_sym=mo).
    """
    try:
        labels = symm.label_orb_symm(mol, mol.irrep_name, mol.symm_orb, mo)
        return mo, labels
    except Exception as e1:  # noqa: BLE001
        if verbose:
            print(f"[SYMM] relabel failed ({type(e1).__name__}): trying symmetrize_space")
        try:
            mo_sym = symm.symmetrize_space(mol, mo)
            labels = symm.label_orb_symm(mol, mol.irrep_name, mol.symm_orb, mo_sym)
            if verbose:
                print("[SYMM] symmetrize_space succeeded")
            return mo_sym, labels
        except Exception as e2:  # noqa: BLE001
            if verbose:
                print(f"[SYMM] symmetrize_space failed ({type(e2).__name__}); fallback to C1")
            return mo, None


# --------------------------------------------------------------------------- #
#   МО-предобработка
# --------------------------------------------------------------------------- #

def _call_cas_natorb_only(mc):
    """
    Получить (mo_no, occ_or_None) ТОЛЬКО через mc.cas_natorb().
    Поддерживает варианты возврата: mo; (mo, occ); (mo, occ, ...).
    Предполагается, что возвращается ПОЛНАЯ матрица МО (nao, nmo_full).
    """
    fn = getattr(mc, "cas_natorb", None)
    if not callable(fn):
        raise RuntimeError("prep_active_no=True требует mc.cas_natorb() в текущей сборке.")

    out = fn()
    if isinstance(out, (list, tuple)):
        if len(out) == 0:
            raise ValueError("cas_natorb() вернул пустой кортеж")
        mo = np.asarray(out[0])
        occ = np.asarray(out[1]).ravel() if len(out) > 1 else None
    else:
        mo = np.asarray(out)
        occ = None

    nao = mc.mol.nao_nr()
    if mo.ndim != 2 or mo.shape[0] != nao:
        raise ValueError(f"cas_natorb(): неожиданный размер МО {mo.shape} (nao={nao})")

    return mo, occ


def semicanonicalize_closed_virtual(mc, *, respect_irrep=True):
    """
    Работает для CASSCF/UCASSCF и RHF/ROHF/CCSD:
    - CASSCF: не трогаем актив; вращаем closed/virtual на F(dm_CAS).
    - SCF/CCSD: ncore=nocc, ncas=0; вращаем occupied/virtual на F(dm_ref в AO).

    Возвращает (mo_new, info).
    """
    C = mc.mo_coeff
    mol = mc.mol
    ncore, ncas = _guess_ncore_ncas(mol, mc)
    nocc = ncore + ncas

    mf = getattr(mc, "_scf", mc)

    dm_try = mc.make_rdm1() if hasattr(mc, "make_rdm1") else None
    dm1_ao = _dm_to_ao(mol, C, dm_try, prefer_mf=mf)

    h_ao    = _ensure_ao_2d(mf.get_hcore())
    veff_ao = _ensure_ao_2d(mf.get_veff(mol, dm1_ao))

    C_ab = _as_list(C)
    h_ab = _as_list(h_ao)
    veff_ab = _as_list(veff_ao)

    mo_new_ab = []
    info = {"alpha": {}, "beta": {}}

    for s, (Csp, hsp, veffsp) in enumerate(zip(C_ab, h_ab, veff_ab)):
        F_ao = hsp + veffsp
        F_mo = Csp.T @ F_ao @ Csp

        F_cc = F_mo[:ncore, :ncore]
        F_vv = F_mo[nocc:, nocc:]

        if respect_irrep:
            irrep_labels = symm.label_orb_symm(mol, mol.irrep_name, mol.symm_orb, Csp)
            sym_core = np.asarray(irrep_labels[:ncore])
            sym_virt = np.asarray(irrep_labels[nocc:])
            eps_c, Uc = _block_eigh_within_irreps(F_cc, sym_core)
            eps_v, Uv = _block_eigh_within_irreps(F_vv, sym_virt)
        else:
            eps_c, Uc = (np.linalg.eigh(F_cc) if F_cc.size else (np.array([]), np.eye(0)))
            eps_v, Uv = (np.linalg.eigh(F_vv) if F_vv.size else (np.array([]), np.eye(0)))

        C_new = Csp.copy()
        if ncore > 0 and Uc.size:
            C_new[:, :ncore] = C_new[:, :ncore] @ Uc
        if Csp.shape[1] > nocc and Uv.size:
            C_new[:, nocc:]  = C_new[:, nocc:]  @ Uv

        def _offdiag_norm(A):
            if A.size == 0:
                return 0.0
            B = A.copy(); np.fill_diagonal(B, 0.0)
            return float(np.linalg.norm(B))

        F_mo_new = C_new.T @ F_ao @ C_new
        key = "alpha" if s == 0 else "beta"
        info[key]["F_cc_off"] = _offdiag_norm(F_mo_new[:ncore, :ncore])
        info[key]["F_vv_off"] = _offdiag_norm(F_mo_new[nocc:, nocc:])
        info[key]["eps_c"] = eps_c
        info[key]["eps_v"] = eps_v

        mo_new_ab.append(C_new)

    mo_new = _from_list(mo_new_ab, C)
    return mo_new, info


# --------------------------------------------------------------------------- #
#   Классификация ndarray и сбор add_ops
# --------------------------------------------------------------------------- #

def _shape_tag(arr: np.ndarray) -> str | None:
    if arr.ndim == 2 and arr.shape[0] == arr.shape[1]:
        return "1e"
    if arr.ndim == 4 and len(set(arr.shape)) == 1:
        return "2e"
    return None


def _collect_add_ops(
    mol,
    add_ops: Sequence[Union[str, Tuple[str, np.ndarray]]] | None,
    *,
    verbose: bool = False,
):
    """
    Разбирает список «добавок»:
      • строки 'int1e_*' → AO-матрицы и суммируются к h_core;
      • строки 'int2e*'  → добавляются как отдельные 2e-операторы;
      • кортежи ('name', ndarray) → по форме: 1e (AO, суммировать), 2e (nao^4).
    """
    dh = None                      # Σ одноэлектронных (AO-матрица)
    intor2: List[str] = []         # список названий 2e-интеграторов
    extra2e: List[np.ndarray] = [] # дополнительные AO-ERI тензоры (nao^4)

    if not add_ops:
        return dh, intor2, extra2e

    for item in add_ops:
        if isinstance(item, str):
            if item.startswith("int1e_"):
                try:
                    arr = mol.intor(item)
                except Exception as err:  # noqa: BLE001
                    if verbose:
                        print(f"[WARN] skip {item}: {err}")
                    continue
                dh = arr if dh is None else dh + arr
            else:
                intor2.append(item)
            continue

        if isinstance(item, tuple) and len(item) == 2:
            name, arr = item
            tag = _shape_tag(arr)
            if tag == "1e":
                dh = arr if dh is None else dh + arr
            elif tag == "2e":
                extra2e.append(arr)
            else:
                if verbose:
                    print(f"[WARN] unknown ndarray shape for {name}: {arr.shape}")
            continue

        if verbose:
            print(f"[WARN] unknown add_ops item: {item!r}")

    return dh, intor2, extra2e


# --------------------------------------------------------------------------- #
#   Справочники MOLPRO id и БИТОВЫЕ КОДЫ иррепов (⊗ == XOR)
# --------------------------------------------------------------------------- #

_MOLPRO_ID: Dict[str, Dict[str, int]] = {
    "C1": {"A": 1},
    "Ci": {"Ag": 1, "Au": 2},
    "Cs": {"A'": 1, 'A"': 2},
    "C2": {"A": 1, "B": 2},
    "C2h": {"Ag": 1, "Bg": 4, "Au": 2, "Bu": 3},
    "C2v": {"A1": 1, "A2": 4, "B1": 2, "B2": 3},
    "D2": {"A": 1, "B1": 4, "B2": 3, "B3": 2},
    "D2h": {
        "Ag": 1, "B3u": 2, "B2u": 3, "B1g": 4, "B1u": 5, "B2g": 6, "B3g": 7, "Au": 8,
    },
}

_BITS: Dict[str, Dict[str, int]] = {
    "C1": {"A": 0},
    "Ci": {"Ag": 0b0, "Au": 0b1},
    "Cs": {"A'": 0b0, 'A"': 0b1},
    "C2": {"A": 0b0, "B": 0b1},
    "C2h": {"Ag": 0b00, "Bg": 0b01, "Au": 0b10, "Bu": 0b11},
    "C2v": {"A1": 0b00, "B1": 0b01, "B2": 0b10, "A2": 0b11},
    "D2":  {"A": 0b00, "B1": 0b01, "B2": 0b10, "B3": 0b11},
    "D2h": {
        "Ag": 0b000, "B1g": 0b100, "B2g": 0b010, "B3g": 0b110,
        "Au": 0b001, "B1u": 0b101, "B2u": 0b011, "B3u": 0b111,
    },
}


# --------------------------------------------------------------------------- #
#   Основной класс писателя FCIDUMP
# --------------------------------------------------------------------------- #

class IntegralsWriter:
    """Формирует FCIDUMP = (int2e + extras, h_core + extras)."""

    def __init__(
        self,
        mol,
        method,
        *,
        frozen_indices: Optional[Sequence[int]] = None,
        occupations: Optional[Sequence[float]] = None,
        granularity: int = 1,
        tol: float = 1e-20,
        mem_profile: bool = True,
        add_ops: Optional[Sequence[Union[str, Tuple[str, np.ndarray]]]] = None,
        verbose: bool = False,
        sort_by_symmetry: bool = True,
        small_last: bool = True,
        # --- предобработка МО ---
        prep_active_no: bool = True,
        prep_semicanonical: bool = False,
        prep_respect_irrep: bool = False,
        prep_log: bool = True,
    ) -> None:
        self._mem_on = mem_profile
        self._mem_log: List[Tuple[str, float]] = []
        _log_mem("init", self._mem_log, self._mem_on)

        self.mol, self.method, self.tol = mol, method, tol
        self.verbose = verbose
        self.small_last = bool(small_last)

        # Ограничение текущей версии писателя
        mo0 = method.mo_coeff
        if _is_unrestricted(mo0):
            raise NotImplementedError("Current writer assumes restricted (R) mo_coeff.")

        # --- подготовка МО (по желанию) ---
        mo_prep = mo0
        no_occ = None
        sc_info = None

        # 1) Натуральные орбитали в активе — ТОЛЬКО через method.cas_natorb()
        if prep_active_no:
            if not _is_casscf_obj(method):
                if self.verbose:
                    print("[PREP] Active NO skipped: method is not CASSCF/UCASSCF.")
            else:
                with _temporary_mc_mos(method, mo_prep):
                    mo_no, no_occ = _call_cas_natorb_only(method)
                    if self.verbose:
                        print("[PREP] Active NO via method.cas_natorb()")
                mo_prep = mo_no
                if prep_log and no_occ is not None:
                    print("[PREP][NO] active occupations (min..max) = "
                          f"[{float(no_occ.min()):.6f} .. {float(no_occ.max()):.6f}]")

        # 2) Полуканонизация closed/virtual — работает и для SCF, и для CASSCF
        if prep_semicanonical:
            with _temporary_mc_mos(method, mo_prep):
                mo_prep, sc_info = semicanonicalize_closed_virtual(
                    method, respect_irrep=prep_respect_irrep
                )
            if prep_log and self.verbose and sc_info is not None:
                a = sc_info.get("alpha", {})
                print(f"[PREP] Semicanonical: ||F_cc(off)||={a.get('F_cc_off', 0.0):.3e}, "
                      f"||F_vv(off)||={a.get('F_vv_off', 0.0):.3e}")

        # Сохраним «до сортировки» для 1e-стримера
        self.mo_prepared_full = mo_prep

        # --- исходные МО для дальнейших шагов — уже предобработанные ---
        mo = np.asarray(mo_prep)
        if mo.ndim != 2:
            if self.verbose:
                print(f"[PREP] Unexpected MO ndim={mo.ndim}; reverting to method.mo_coeff.")
            mo = np.asarray(method.mo_coeff)

        # --- попытка разметить иррепы и (при необходимости) симметризовать МО ---
        mo_sym, irreps_all = _label_orb_symm_safe(mol, mo, verbose=self.verbose)

        # Флаг «C1 fallback» если разметить не удалось
        force_c1 = irreps_all is None
        self._force_c1 = force_c1

        if force_c1:
            if self.verbose:
                print("[SYMM] Falling back to C1: no symmetry sorting and ORBSYM=1")
            perm = list(range(mo.shape[1]))
            self.perm = perm
            self.mo_sorted = mo  # не трогаем
            irreps_sorted = None
        else:
            mo = mo_sym
            self.mo_prepared_full = mo
            if sort_by_symmetry:
                perm = sorted(range(mo.shape[1]),
                              key=lambda i: _MOLPRO_ID[mol.groupname][irreps_all[i]])
            else:
                perm = list(range(mo.shape[1]))
            self.perm = perm
            self.mo_sorted = mo[:, perm]
            irreps_sorted = [irreps_all[i] for i in perm]

        # --- заморозка: внешние индексы → отсортированная нумерация ---
        frozen_indices = list(frozen_indices or [])
        self.frozen_idx = sorted([self.perm.index(i) for i in frozen_indices])

        # --- активные индексы в отсортированной нумерации ---
        self.active_idx = [i for i in range(self.mo_sorted.shape[1]) if i not in self.frozen_idx]

        # --- размеры и ORBSYM для АКТИВНОГО блока ---
        self.norb = len(self.active_idx)
        self.nelec = mol.nelectron - 2 * len(self.frozen_idx)
        self.ms2 = mol.spin

        # ORBSYM для ПЕЧАТИ/1e-стримера
        if force_c1:
            self.orbsym_ids_full_sorted = [1] * self.mo_sorted.shape[1]
            self.orbsym_ids_active = [1] * self.norb
        else:
            self.orbsym_ids_full_sorted = [
                _MOLPRO_ID[mol.groupname][lab] for lab in irreps_sorted
            ]
            self.orbsym_ids_active = [
                _MOLPRO_ID[mol.groupname][irreps_sorted[i]] for i in self.active_idx
            ]

        self.orbsym_str = ",".join(map(str, self.orbsym_ids_active))

        # Битовые коды иррепов для активных орбиталей (для 2e фильтрации)
        if force_c1:
            self.orbsym_bits_active = np.zeros(self.norb, dtype=np.int32)
        else:
            self.orbsym_bits_active = np.array([
                _BITS[mol.groupname][irreps_sorted[i]] for i in self.active_idx
            ], dtype=np.int32)

        # --- разбор add_ops ---
        dh, intor2, extra2e = _collect_add_ops(mol, add_ops, verbose=verbose)

        # --- frozen core c учётом 1e-добавок ---
        occ = occupations or [2.0] * len(self.frozen_idx)
        self.h_fc, self.E_const = core.build_frozen_core(
            mol, method, self.mo_sorted, self.frozen_idx, occ, extra1e=dh
        )

        # --- активные МО (в отсортированной нумерации) ---
        self.mo_act = self.mo_sorted[:, self.active_idx]

        # --- 2e настройки ---
        self.twoe_intor = ("int2e", *intor2)
        self.twoe_extra = extra2e
        self.granularity = int(granularity)

        _log_mem("setup-done", self._mem_log, self._mem_on)

    # ------------------------------------------------------------------ #
    #   Публичный API
    # ------------------------------------------------------------------ #

    def write(self, outfile: str = "FCIDUMP") -> None:
        # 2e сразу в итоговый файл (sparse → compact)
        core.write_two_e_fcidump(
            self.mol,
            self.mo_act,
            file_path=outfile,
            header=core.header_lines(self.norb, self.nelec, self.ms2, self.orbsym_str),
            tol=self.tol,
            log_fn=lambda t: _log_mem(t, self._mem_log, self._mem_on),
            granularity=self.granularity,
            intor=self.twoe_intor,
            ao2e_extra=self.twoe_extra,
            frozen=None,
            small_last=self.small_last,
            orbsym_bits=self.orbsym_bits_active,
        )

        # 1e + константа — дописываем в конец
        with open(outfile, "a", encoding="utf-8") as fh:
            for line in core.iter_one_e_lines_onfly(
                self.h_fc,
                self.mo_prepared_full,
                self.perm,
                self.frozen_idx,
                tol=self.tol,
                log_fn=lambda t: _log_mem(t, self._mem_log, self._mem_on),
                orbsym_sorted=self.orbsym_ids_full_sorted,
            ):
                fh.write(line)
            fh.writelines(core.const_line(self.E_const))

        if self._mem_on:
            self._summary()

    # ------------------------------------------------------------------ #
    #   Сводка по памяти
    # ------------------------------------------------------------------ #

    def _summary(self):
        print("\n=== RSS profile ===")
        for tag, mb in self._mem_log:
            print(f"{tag:<24}{mb:8.1f} MB")
        print("===================")
