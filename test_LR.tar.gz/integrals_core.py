# integrals_core.py
# =================
# • Формат FCIDUMP: старый _fmt и индексы шириной IND_WIDTH=4
# • header / const_line
# • build_frozen_core(extra1e)
# • 1e: iter_one_e_lines_onfly (стрим без сборки полной h^MO)
# • 2e: write_two_e_fcidump:
#     – granularity=0 → один S8 (compact=True) + фильтрация по иррепам;
#     – granularity>=1 → S4-плитки, покрывающие и «even», и «odd» пары;
#     – канонизация пар (code(ij) ≥ code(kl)), ранг и битовая маска (1 запись/строка);
#     – пост-компакт: удаление пустых строк (tol) и усечение файла.

import gc
import math
import os
import mmap
from functools import lru_cache
from typing import Iterable, List, Sequence, Tuple, Union, Optional

import numpy as np
from pyscf import ao2mo, scf
from pyscf.ao2mo import incore  # для extra2e

# --------------------------------------------------------------------------- #
#   Печать FCIDUMP (старый формат + IND_WIDTH=4)
# --------------------------------------------------------------------------- #

IND_WIDTH = 4  # ширина поля индексов

def _fmt(v: float) -> str:
    """Старый формат числа (как было у тебя ранее)."""
    if v == 0.0:
        return " 0.0000000000000000E+00"
    r = int(math.log10(abs(v)))
    m, e = (v / 10 ** (r + 1), r + 1) if abs(v) >= 1       else \
           (v / 10 ** (r + 1), abs(r + 1)) if abs(v) == .1 else \
           (v / 10 ** r, abs(r))
    return f"{'  ' if v > 0 else ' '}{m:0.16f}E{('+' if abs(v)>=.1 else '-')}{e:02d}"

def _line(v: float, i: int, j: int, k: int, l: int) -> bytes:
    """Строка FCIDUMP: число + четыре индекса шириной IND_WIDTH."""
    return (
        f"{_fmt(v)}"
        f"{i+1:{IND_WIDTH}d}{j+1:{IND_WIDTH}d}{k+1:{IND_WIDTH}d}{l+1:{IND_WIDTH}d}\n"
    ).encode()

LINE_LEN = 41

def header_lines(norb: int, nelec: int, ms2: int, orbsym: str) -> List[str]:
    return [
        f" &FCI NORB= {norb},NELEC= {nelec},MS2= {ms2},\n",
        f"  ORBSYM={orbsym},\n  ISYM=1,\n /\n",
    ]

def const_line(e0: float) -> List[str]:
    # индексы формируем тем же полем ширины
    return [f"{_fmt(e0)}{0:{IND_WIDTH}d}{0:{IND_WIDTH}d}{0:{IND_WIDTH}d}{0:{IND_WIDTH}d}\n"]


# --------------------------------------------------------------------------- #
#   Замороженное ядро: h_core + J − ½K  и E_const (учёт extra1e в AO)
# --------------------------------------------------------------------------- #

def build_frozen_core(
    mol,
    method,
    mo_sorted: np.ndarray,
    frozen_idx: Sequence[int],
    occ: Sequence[float],
    *,
    extra1e: np.ndarray | None = None,
) -> Tuple[np.ndarray, float]:
    """Вернёт матрицу h_ao (с extra1e) и константу энергии E_const."""
    h_ao = method.get_hcore(mol)
    if extra1e is not None:
        h_ao = h_ao + extra1e

    if not frozen_idx:
        return h_ao, float(mol.energy_nuc())

    dm = np.zeros_like(h_ao)
    for i, o in zip(frozen_idx, occ):
        c = mo_sorted[:, i]
        dm += o * np.outer(c, c)

    j, k = scf.hf.get_jk(mol, dm, hermi=1)
    h_fc = h_ao + j - 0.5 * k
    e0 = (
        mol.energy_nuc()
        + float(np.einsum("ij,ij->", dm, h_ao))
        + 0.5 * float(np.einsum("ij,ij->", dm, j - 0.5 * k))
    )
    return h_fc, e0


# --------------------------------------------------------------------------- #
#   1-электронные строки (стрим на лету)
# --------------------------------------------------------------------------- #

def _build_blocks_from_orbsym(orbsym_sorted: Sequence[int]) -> list[tuple[int, int]]:
    """Собирает непрерывные отрезки одинаковых меток ирреп в порядке МО.
    Возвращает список (start, end) с полуинтервалами [start, end)."""
    blocks = []
    if not orbsym_sorted:
        return blocks
    s = 0
    for i in range(1, len(orbsym_sorted)):
        if orbsym_sorted[i] != orbsym_sorted[i-1]:
            blocks.append((s, i))
            s = i
    blocks.append((s, len(orbsym_sorted)))
    return blocks


def iter_one_e_lines_onfly(
    h_ao_fc: np.ndarray,            # (nao, nao)
    mo_coeff: np.ndarray,           # (nao, norb)
    sorted_idx: Sequence[int],      # перестановка МО (сгруппирована по иррепам)
    frozen_idx: Sequence[int],      # индексы (в отсорт. нумерации), которые freeze
    *,
    tol: float,
    log_fn=None,
    # обязательно ПОЛНЫЙ orbsym (после сортировки), не только активные:
    orbsym_sorted: Sequence[int],
) -> Iterable[str]:
    """
    Стримит ⟨p|h|q⟩ с БЛОЧНОЙ сортировкой по иррепам (как обсуждали):
      — вывод только внутри симметрийных блоков;
      — в каждом блоке пары (i, j) идут по нижнему треугольнику: j от начала блока до i.

    Индексы в выводе нумеруются по активным МО (после freeze) последовательно,
    поэтому «старт» j во втором блоке будет равен 1 + числу активных МО в первом блоке.
    """
    Hp = h_ao_fc[np.ix_(sorted_idx, sorted_idx)]
    Cp = mo_coeff[sorted_idx][:, sorted_idx]  # (nao, norb_sorted)

    # активная маска (после фриза)
    mask = np.ones(Cp.shape[1], dtype=bool)
    if frozen_idx:
        mask[np.asarray(frozen_idx, dtype=int)] = False
    active_all = np.where(mask)[0]  # индексы в "отсортированной" системе
    n_act_total = active_all.size

    blocks = _build_blocks_from_orbsym(orbsym_sorted)

    # пересекаем блоки с активными МО
    printed_index_of_active = {}  # key: idx_in_sorted; val: 1-based printed idx
    act_running = 0
    active_blocks: list[list[int]] = []  # списки активных индексов (в sorted-нумерации) для каждого блока

    act_set = set(active_all.tolist())
    for s, e in blocks:
        blk_act = [i for i in range(s, e) if i in act_set]
        if blk_act:
            active_blocks.append(blk_act)
            for i in blk_act:
                act_running += 1
                printed_index_of_active[i] = act_running

    # основной вывод
    for bi, blk in enumerate(active_blocks, start=1):
        cols = [Cp[:, i] for i in blk]
        for a_loc, ia_sorted in enumerate(blk):
            col_i = cols[a_loc]
            i_print = printed_index_of_active[ia_sorted]
            for b_loc in range(0, a_loc + 1):  # j ≤ i  (j<i+1)
                ib_sorted = blk[b_loc]
                col_j = cols[b_loc]
                j_print = printed_index_of_active[ib_sorted]

                val = float(np.einsum("i,ij,j->", col_i, Hp, col_j, optimize=True))
                if abs(val) > tol:
                    yield f"{_fmt(val)}{i_print:{IND_WIDTH}d}{j_print:{IND_WIDTH}d}{0:{IND_WIDTH}d}{0:{IND_WIDTH}d}\n"

            if log_fn:
                log_fn(f"1e-row {i_print}/{n_act_total} (block {bi}/{len(active_blocks)})")

    del Hp, Cp
    gc.collect()


# --------------------------------------------------------------------------- #
#   Индексация пар, ранг и общий эмиттер (числовые записи)
# --------------------------------------------------------------------------- #

@lru_cache(None)
def _pair_arrays(n: int) -> tuple[np.ndarray, np.ndarray]:
    """Порядок пар (p, q) как в PySCF compact=True: нижний треугольник построчно."""
    pi = np.repeat(np.arange(n), np.arange(1, n + 1))
    pj = np.concatenate([np.arange(i + 1) for i in range(n)])
    return pi.astype(np.int32), pj.astype(np.int32)

def _rank(i: int, j: int, k: int, l: int) -> int:
    """Линейный индекс строки в S8-порядке (фиксированное место в файле)."""
    c_ij = i * (i + 1) // 2 + j
    c_kl = k * (k + 1) // 2 + l
    return c_ij * (c_ij + 1) // 2 + c_kl

def _emit_sorted_records(
    I: np.ndarray, J: np.ndarray,
    K: np.ndarray, L: np.ndarray,
    V: np.ndarray,
):
    """Сортирует по (I,J,K,L) и отдаёт (rank, i, j, k, l, v) — всё числа."""
    order = np.lexsort((L, K, J, I))
    for o in order:
        i, j, k, l = int(I[o]), int(J[o]), int(K[o]), int(L[o])
        yield _rank(i, j, k, l), i, j, k, l, float(V[o])


# --------------------------------------------------------------------------- #
#   Декодер S8 и поток S4 с фильтром по иррепам
# --------------------------------------------------------------------------- #

def _stream_s8_all(buf: np.ndarray, g: np.ndarray, tol: float, orbsym_bits: np.ndarray):
    """
    S8 для ao2mo.kernel(..., compact=True) по ВСЕМ парам: декодируем t→(m,q),
    распаковываем (i,j,k,l), далее фильтр по (γ_i⊕γ_j)==(γ_k⊕γ_l).
    """
    arr = buf[np.tril_indices(buf.shape[0])] if buf.ndim == 2 else buf
    flat = np.asarray(arr).ravel()
    nz = np.flatnonzero(np.abs(flat) > tol)
    if nz.size == 0:
        return

    n = g.size
    pi, pj = _pair_arrays(n)

    # t → (m, q) через треугольные числа
    m = ((np.sqrt(8 * nz + 1) - 1) // 2).astype(np.int64)
    q = nz - m * (m + 1) // 2

    I, J = g[pi[m]], g[pj[m]]
    K, L = g[pi[q]], g[pj[q]]
    V = flat[nz]

    # симметрийный фильтр по произведениям иррепов (абелева группа → XOR)
    mask = (orbsym_bits[I] ^ orbsym_bits[J]) == (orbsym_bits[K] ^ orbsym_bits[L])
    if not np.any(mask):
        return

    yield from _emit_sorted_records(I[mask], J[mask], K[mask], L[mask], V[mask])


def _stream_s4_general(
    buf: np.ndarray,
    gi: np.ndarray, gj: np.ndarray,
    gk: np.ndarray, gl: np.ndarray,
    tol: float,
    orbsym_bits: np.ndarray,
):
    """
    S4 (ao2mo.general(..., compact=False)):
      • нормализуем пары внутри половинок: i≥j и k≥l;
      • затем канонизируем половинки: code(ij) ≥ code(kl);
      • фильтр по симметрии (абелева группа → XOR).
    """
    ni, nj = int(gi.size), int(gj.size)
    nk, nl = int(gk.size), int(gl.size)

    arr = np.asarray(buf)
    if arr.ndim == 1:
        if arr.size != ni * nj * nk * nl:
            raise ValueError(f"S4 buffer size mismatch: got {arr.size}, expected {ni*nj*nk*nl}")
        arr = arr.reshape(ni * nj, nk * nl)
    elif arr.ndim == 2 and arr.shape != (ni * nj, nk * nl):
        arr = arr.reshape(ni * nj, nk * nl)

    mask_nz = np.abs(arr) > tol
    if not mask_nz.any():
        return
    rr, cc = np.nonzero(mask_nz)
    V = arr[rr, cc]

    # декодируем локальные индексы
    ii_loc, jj_loc = divmod(rr, nj)
    kk_loc, ll_loc = divmod(cc, nl)
    I, J = gi[ii_loc], gj[jj_loc]
    K, L = gk[kk_loc], gl[ll_loc]

    # --- (1) нормализация внутри пар: i≥j и k≥l ---
    swap_ij = I < J
    if np.any(swap_ij):
        I, J = np.where(swap_ij, J, I), np.where(swap_ij, I, J)

    swap_kl = K < L
    if np.any(swap_kl):
        K, L = np.where(swap_kl, L, K), np.where(swap_kl, K, L)

    # коды пар после нормализации
    cij = I * (I + 1) // 2 + J
    ckl = K * (K + 1) // 2 + L

    # --- (2) канонизация половинок: code(ij) ≥ code(kl) ---
    swap_halves = cij < ckl
    if np.any(swap_halves):
        I, J, K, L = (
            np.where(swap_halves, K, I),
            np.where(swap_halves, L, J),
            np.where(swap_halves, I, K),
            np.where(swap_halves, J, L),
        )
        cij, ckl = np.where(swap_halves, ckl, cij), np.where(swap_halves, cij, ckl)

    # --- (3) фильтр по симметрии (абелева группа → XOR) ---
    keep = (orbsym_bits[I] ^ orbsym_bits[J]) == (orbsym_bits[K] ^ orbsym_bits[L])
    if not np.any(keep):
        return

    yield from _emit_sorted_records(I[keep], J[keep], K[keep], L[keep], V[keep])



# --------------------------------------------------------------------------- #
#   Разбиение по ирреп-блокам/чанкам и главная запись 2e
# --------------------------------------------------------------------------- #

def _irrep_blocks_from_bits(orbsym_bits_full: np.ndarray) -> list[tuple[int, int]]:
    """Блоки непрерывных одинаковых меток (по уже отсортированным МО)."""
    blocks: list[tuple[int, int]] = []
    if orbsym_bits_full.size == 0:
        return blocks
    s = 0
    for i in range(1, orbsym_bits_full.size):
        if orbsym_bits_full[i] != orbsym_bits_full[i-1]:
            blocks.append((s, i))
            s = i
    blocks.append((s, orbsym_bits_full.size))
    return blocks


def _split_block_into_chunks(s: int, e: int, granularity: int, *, small_last: bool) -> list[np.ndarray]:
    """Разделить блок [s, e) на 'granularity' чанков, близких по размеру."""
    L = e - s
    if granularity <= 1 or L <= 0:
        return [np.arange(s, e, dtype=int)]
    g = int(granularity)
    S = (L + g - 1) // g  # ceil
    chunks: list[np.ndarray] = []
    start = s
    while start < e:
        stop = min(start + S, e)
        chunks.append(np.arange(start, stop, dtype=int))
        start = stop
    if not small_last and len(chunks) >= 2:
        # переносим «остаток» в последний-1 для более ровного вида (по желанию)
        pass
    return chunks


def write_two_e_fcidump(
    mol,
    mo: np.ndarray,
    *,
    file_path: str,
    header: Sequence[str],
    tol: float = 1e-20,
    log_fn=print,
    granularity: int = 1,
    intor: Union[str, Sequence[str]] = "int2e",
    ao2e_extra: Sequence[np.ndarray] | None = None,
    frozen: Optional[Sequence[int]] = None,
    small_last: bool = True,
    orbsym_bits: np.ndarray,
):
    # --- активные орбитали ---
    if frozen:
        mask = np.ones(mo.shape[1], bool)
        mask[list(frozen)] = False
        mo = mo[:, np.where(mask)[0]]
    norb = mo.shape[1]

    # --- шапка и sparse-заготовка ---
    n_pairs = norb * (norb + 1) // 2
    n_lines = n_pairs * (n_pairs + 1) // 2
    with open(file_path, "wb") as f:
        for ln in header:
            f.write((ln.rstrip("\n") + "\n").encode())
        hdr = f.tell()
        f.seek(hdr + n_lines * LINE_LEN - 1)
        f.write(b"\0")
    if log_fn:
        log_fn(f"[FILE] preallocated ≈{(hdr + n_lines * LINE_LEN)/1_048_576:.2f} MiB")

    fd = os.open(file_path, os.O_RDWR)
    written = bytearray((n_lines + 7) // 8)

    def _is_written(r: int) -> bool:
        return (written[r >> 3] >> (r & 7)) & 1

    def _set_written(r: int) -> None:
        written[r >> 3] |= (1 << (r & 7))

    # --- granularity=0: один S8 по всем орбиталям + фильтр по иррепам ---
    if granularity == 0:
        Ci = np.asfortranarray(mo, dtype=np.float64)
        parts: list[np.ndarray] = []
        intor_list = (intor,) if isinstance(intor, str) else tuple(intor)
        extra = tuple(ao2e_extra or ())

        for op in intor_list:
            parts.append(np.asarray(ao2mo.kernel(mol, Ci, intor=op, compact=True, max_memory=0.001),
                                    dtype=np.float64))
        for eri in extra:
            parts.append(np.asarray(incore.kernel(eri, Ci, compact=True), dtype=np.float64))

        if parts:
            buf = parts[0] if len(parts) == 1 else np.sum(parts, axis=0, dtype=np.float64)
            g = np.arange(norb, dtype=int)
            total_wrote = 0
            for rnk, i, j, k, l, v in _stream_s8_all(buf, g, tol, orbsym_bits):
                if not _is_written(rnk):
                    os.pwrite(fd, _line(v, i, j, k, l), hdr + rnk * LINE_LEN)
                    _set_written(rnk)
                    total_wrote += 1
            if log_fn:
                log_fn(f"[S8:all] wrote={total_wrote}")

        os.close(fd)
        # compact-проход
        with open(file_path, "r+b") as fh:
            mm = mmap.mmap(fh.fileno(), 0)
            blank = b" " * (LINE_LEN - 1) + b"\n"
            read = write = hdr
            while read < len(mm):
                chunk = mm[read:read + LINE_LEN]
                if chunk and chunk[0] != 0 and chunk.strip() and chunk != blank:
                    if read != write:
                        mm[write:write + LINE_LEN] = chunk
                    write += LINE_LEN
                read += LINE_LEN
            mm.flush()
            mm.close()
            fh.truncate(write)
            if log_fn:
                log_fn(f"[COMPACT] new size ≈{write/1_048_576:.2f} MiB")
        return

    # --- granularity>=1: плитки S4 для EVEN и ODD пар ---
    # орбитальные биты для построения блоков (в порядке текущих активных МО)
    blocks = _build_blocks_from_orbsym(orbsym_bits.tolist())
    if log_fn:
        blstr = " ".join(f"({s},{e})" for s, e in blocks)
        log_fn(f"[2e] active norb={norb}, irrep blocks=[{blstr}] (granularity={granularity})")

    # предразложение блоков на чанки по оси i (Gi)
    A_chunks: list[tuple[int, np.ndarray, int, int]] = []  # (block_id, Gi, s_block, e_block)
    for b_id, (s, e) in enumerate(blocks):
        for Gi in _split_block_into_chunks(s, e, granularity, small_last=small_last):
            A_chunks.append((b_id, Gi, s, e))

    # B-слои: even (диагональные) и odd (недиагональные) блоки
    B_even_blocks = [(b_id, np.arange(s, e, dtype=int)) for b_id, (s, e) in enumerate(blocks)]
    B_odd_pairs: list[tuple[int, np.ndarray, int, np.ndarray]] = []  # (bu, Gu, bv, Gv) с bu>bv
    for bu in range(len(blocks)):
        su, eu = blocks[bu]
        Gu = np.arange(su, eu, dtype=int)
        for bv in range(bu):
            sv, ev = blocks[bv]
            Gv = np.arange(sv, ev, dtype=int)
            B_odd_pairs.append((bu, Gu, bv, Gv))

    intor_list = (intor,) if isinstance(intor, str) else tuple(intor)
    extra = tuple(ao2e_extra or ())

    total_wrote = 0

    try:
        # предварительные числа чанков
        if log_fn:
            log_fn(f"[2e] A_chunks={len(A_chunks)}  B_even={len(B_even_blocks)}  B_odd_pairs={len(B_odd_pairs)}")

        for aidx, (ablock, Gi, s_block, e_block) in enumerate(A_chunks, start=1):
            Ci = np.asfortranarray(mo[:, Gi], dtype=np.float64)

            # --- EVEN pass: j внутри блока i; (k,l) внутри ОДНОГО блока (все диагональные) ---
            Gj_even = np.arange(s_block, Gi[-1] + 1, dtype=int)
            Cj_even = np.asfortranarray(mo[:, Gj_even], dtype=np.float64)
            for b_id, G in B_even_blocks:
                Ck = np.asfortranarray(mo[:, G], dtype=np.float64)
                Cl = Ck
                parts: list[np.ndarray] = []
                blk = (Ci, Cj_even, Ck, Cl)
                for op in intor_list:
                    parts.append(np.asarray(ao2mo.general(mol, blk, intor=op, compact=False, max_memory=0.001),
                                            dtype=np.float64))
                for eri in extra:
                    parts.append(np.asarray(incore.general(eri, blk, compact=False), dtype=np.float64))
                if not parts:
                    continue
                buf = parts[0] if len(parts) == 1 else np.sum(parts, axis=0, dtype=np.float64)

                wrote_here = 0
                for rnk, i, j, k, l, v in _stream_s4_general(buf, Gi, Gj_even, G, G, tol, orbsym_bits):
                    if not _is_written(rnk):
                        os.pwrite(fd, _line(v, i, j, k, l), hdr + rnk * LINE_LEN)
                        _set_written(rnk)
                        wrote_here += 1
                        total_wrote += 1
                if log_fn:
                    log_fn(f"[S4] A={aidx}/{len(A_chunks)}  EVEN  B blk={b_id+1}/{len(B_even_blocks)}  wrote={wrote_here}")

                del Ck, parts, buf
                gc.collect()

            # --- ODD pass (если блок не первый): j из предыдущих блоков; (k,l) из РАЗНЫХ блоков ---
            if s_block > 0:
                Gj_odd = np.arange(0, s_block, dtype=int)
                Cj_odd = np.asfortranarray(mo[:, Gj_odd], dtype=np.float64)
                for (bu, Gu, bv, Gv) in B_odd_pairs:
                    # (k,l) берём в порядке «больший блок» vs «меньший», канонизация в стримере всё выровняет
                    Ck = np.asfortranarray(mo[:, Gu], dtype=np.float64)
                    Cl = np.asfortranarray(mo[:, Gv], dtype=np.float64)
                    parts: list[np.ndarray] = []
                    blk = (Ci, Cj_odd, Ck, Cl)
                    for op in intor_list:
                        parts.append(np.asarray(ao2mo.general(mol, blk, intor=op, compact=False, max_memory=0.001),
                                                dtype=np.float64))
                    for eri in extra:
                        parts.append(np.asarray(incore.general(eri, blk, compact=False), dtype=np.float64))
                    if not parts:
                        continue
                    buf = parts[0] if len(parts) == 1 else np.sum(parts, axis=0, dtype=np.float64)

                    wrote_here = 0
                    for rnk, i, j, k, l, v in _stream_s4_general(buf, Gi, Gj_odd, Gu, Gv, tol, orbsym_bits):
                        if not _is_written(rnk):
                            os.pwrite(fd, _line(v, i, j, k, l), hdr + rnk * LINE_LEN)
                            _set_written(rnk)
                            wrote_here += 1
                            total_wrote += 1
                    if log_fn:
                        log_fn(f"[S4] A={aidx}/{len(A_chunks)}  ODD  B (u,v)=({bu+1},{bv+1}) wrote={wrote_here}")

                    del Ck, Cl, parts, buf
                    gc.collect()

            del Ci
            gc.collect()

        if log_fn:
            log_fn(f"[S4:all] total_wrote={total_wrote}")

    finally:
        os.close(fd)

    # --- compact-проход: удаляем «пустые» строки и укорачиваем файл ---
    with open(file_path, "r+b") as fh:
        mm = mmap.mmap(fh.fileno(), 0)
        blank = b" " * (LINE_LEN - 1) + b"\n"
        read = write = hdr
        while read < len(mm):
            chunk = mm[read:read + LINE_LEN]
            if chunk and chunk[0] != 0 and chunk.strip() and chunk != blank:
                if read != write:
                    mm[write:write + LINE_LEN] = chunk
                write += LINE_LEN
            read += LINE_LEN
        mm.flush()
        mm.close()
        fh.truncate(write)
        if log_fn:
            log_fn(f"[COMPACT] new size ≈{write/1_048_576:.2f} MiB")
    gc.collect()
