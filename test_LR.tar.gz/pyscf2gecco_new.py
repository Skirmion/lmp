# controller.py
"""
FCIDumpController
=================
Простой «дирижёр» над IntegralsWriter.

* Если n_nodes == 1  (по умолчанию) → обычный SEQ-запуск.
* Если n_nodes  > 1  и процесс НЕ содержит переменных NODE_ID /
  N_NODES → создаются n_nodes подпроцессов, каждому задаётся свой
  NODE_ID; родитель ждёт их завершения.
* Если переменные окружения уже заданы  (NODE_ID, N_NODES) → считаем,
  что нас запустил «лаунчер», и просто вызываем writer.write().
"""

from __future__ import annotations
import os, subprocess, sys
from pathlib import Path
from typing import Any, Dict

from integrals import IntegralsWriter


class FCIDumpController:
    """
    Parameters
    ----------
    mol, method : PySCF объекты (уже с рассчитанными mo_coeff)
    n_nodes     : int, сколько узлов запустить (≥1, по умолчанию 1)
    writer_kw   : остальные ключевые аргументы для IntegralsWriter
                  (granularity, tol, mem_debug, frozen_indices …)
    """

    def __init__(self, mol, method, *, n_nodes: int = 1, **writer_kw):
        if n_nodes < 1:
            raise ValueError("n_nodes должно быть ≥ 1")
        self.mol, self.method = mol, method
        self.n_nodes          = n_nodes
        self.writer_kw: Dict[str, Any] = writer_kw

    # ─────────────── публичный интерфейс ───────────────
    def run(self, outfile: str = "FCIDUMP"):
        """
        • Если переменные окружения NODE_ID / N_NODES присутствуют —
          запускаем IntegralsWriter в «узловом» режиме (доля блока).
        • Если их нет и n_nodes > 1 — порождаем нужное число
          подпроцессов, каждому задаём переменные окружения.
        • Если n_nodes == 1 — обычный SEQ.
        """
        env_node_id  = os.getenv("NODE_ID")
        env_n_nodes  = os.getenv("N_NODES")

        # ── ① Нас уже запустили как узел  ……………………………………
        if env_node_id is not None and env_n_nodes is not None:
            node_id = int(env_node_id)
            n_nodes = int(env_n_nodes)
            if not (0 <= node_id < n_nodes):
                raise RuntimeError("NODE_ID / N_NODES заданы некорректно")

            writer = IntegralsWriter(
                self.mol,
                self.method,
                **self.writer_kw,      # granularity, tol, mem_debug …
            )
            writer.write(outfile)
            return

        # ── ② Обычный SEQ (n_nodes == 1)  ……………………………………
        if self.n_nodes == 1:
            writer = IntegralsWriter(self.mol, self.method, **self.writer_kw)
            writer.write(outfile)
            return

        # ── ③ Родитель: запускаем подпроцессы узлов  …………………
        script = Path(sys.argv[0]).resolve()
        extra  = sys.argv[1:]                        # передаём те же агументы

        processes = []
        for k in range(self.n_nodes):
            env = os.environ.copy()
            env["NODE_ID"] = str(k)
            env["N_NODES"] = str(self.n_nodes)
            cmd = [sys.executable, str(script), *extra]

            print(f"[CTRL] Launch NODE_ID={k} / {self.n_nodes}  →  {cmd}")
            proc = subprocess.Popen(cmd, env=env)
            processes.append((k, proc))

        # ждём завершения
        errors = 0
        for k, p in processes:
            code = p.wait()
            if code == 0:
                print(f"[CTRL] node {k} finished OK")
            else:
                print(f"[CTRL] node {k} FAILED  (exit={code})")
                errors += 1

        if errors:
            raise RuntimeError(f"{errors} уз(л/лa) завершились с ошибкой")
        print("[CTRL] All nodes finished successfully")
