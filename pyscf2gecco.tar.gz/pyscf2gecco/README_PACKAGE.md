# pyscf2gecco

PySCF to GECCO Converter and Archiver for quantum chemistry calculations.

## Features

- **FCIDumpWriter**: Convert PySCF molecular integrals to FCIDUMP format optimized for GECCO
  - Support for multiple output formats (text, binary, compressed)
  - Custom molecular orbital handling
  - Frozen core approximation
  - Additional integral operators
  - Natural orbital support

- **GeCCoArchiver**: Compress, archive, and manage FCIDUMP files
  - Efficient binary compression with Zstandard
  - Parallel processing for large projects
  - Metadata preservation
  - Archive management utilities

## Installation

```bash
pip install pyscf2gecco
```

For archiver functionality with Cython extensions:

```bash
pip install pyscf2gecco[archiver]
cd archiver
python setup.py build_ext --inplace
```

## Quick Start

### Converting PySCF to FCIDUMP

```python
from pyscf import gto, scf
from pyscf2gecco import FCIDumpWriter

# Create molecule and run calculation
mol = gto.M(atom='H 0 0 0; H 0 0 0.74', basis='sto-3g')
mf = scf.RHF(mol).run()

# Generate FCIDUMP file
writer = FCIDumpWriter(
    mol=mol,
    method=mf,
    granularity=50,
    tol=1e-15,
    natorb=False
)
writer.run('FCIDUMP')
```

### Compressing FCIDUMP Files

```python
from pyscf2gecco import GeCCoArchiver

archiver = GeCCoArchiver()

# Compress FCIDUMP files in directory
archiver.compress_fcidump('project_dir', parallel=True)

# Create project archive
archiver.compress_all('project_dir', tag='v1.0')

# Decompress archive
archiver.decompress_all('project_archive_v1.0.tar.xz', output_dir='restored')
```

## API Reference

### FCIDumpWriter

Main class for generating FCIDUMP files from PySCF calculations.

**Parameters:**
- `mol`: PySCF Mole object
- `method`: PySCF method object (SCF, CASSCF, etc.)
- `granularity` (int): Block size for integral processing (default: 50)
- `tol` (float): Threshold for integral truncation (default: 1e-15)
- `natorb` (bool): Use natural orbitals from CASSCF (default: False)
- `frozen_indices` (list): Indices of frozen orbitals
- `mo_coeff` (array): Custom MO coefficients (overrides method MOs)
- `add_ops` (list): Additional operators to include

**Methods:**
- `run(fcidump_name, binary=False, compress=False, metadata=None)`: Generate FCIDUMP file

### GeCCoArchiver

High-level interface for archiving and compression.

**Methods:**
- `compress_fcidump(root_dir, parallel=True, ...)`: Compress FCIDUMP files
- `compress_all(root_dir, tag, ...)`: Create project archive
- `decompress_all(archive_path, output_dir, ...)`: Extract project archive
- `show_meta(archive_path)`: Display archive metadata
- `list_archives(root_dir)`: List available archives

## License

MIT License

## Authors

PySCF2GECCO Contributors
