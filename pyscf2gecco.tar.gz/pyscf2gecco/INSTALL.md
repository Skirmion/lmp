# Installation Guide for pyscf2gecco

## Prerequisites

- Python 3.8 or higher
- PySCF 2.0 or higher
- NumPy 1.20 or higher
- psutil 5.8 or higher
- For archiver: Cython 0.29 or higher, libzstd

## Installation Options

### Option 1: Install from source (recommended for development)

```bash
cd /path/to/p2g-18
pip install -e .
```

This will install the package in editable mode.

### Option 2: Install with archiver support

```bash
cd /path/to/p2g-18
pip install -e ".[archiver]"

# Build Cython extensions for archiver
cd archiver
python setup.py build_ext --inplace
cd ..
```

### Option 3: Build distribution package

```bash
cd /path/to/p2g-18
python setup.py sdist bdist_wheel
pip install dist/pyscf2gecco-1.0.0-*.whl
```

## Verify Installation

```python
import pyscf2gecco
print(pyscf2gecco.__version__)

from pyscf2gecco import FCIDumpWriter, GeCCoArchiver
print("Installation successful!")
```

## Quick Test

```bash
cd /path/to/p2g-18
python example.py
```

This will run several examples demonstrating the package functionality.

## Troubleshooting

### Missing dependencies

```bash
pip install numpy pyscf psutil
```

### Cython extensions not building

Make sure you have:
- GCC compiler installed
- libzstd development files: `sudo apt-get install libzstd-dev`
- Cython: `pip install Cython`

Then rebuild:
```bash
cd archiver
python setup.py build_ext --inplace --force
```

### Import errors

If you get import errors, make sure you're running Python from the correct directory or the package is properly installed:

```bash
# From package root directory
export PYTHONPATH="${PYTHONPATH}:$(pwd)"
python example.py
```

Or install the package:
```bash
pip install -e .
```

## Package Structure

```
p2g-18/
├── __init__.py              # Main package init
├── setup.py                 # Installation script
├── pyproject.toml           # Build configuration
├── LICENSE                  # MIT License
├── README_PACKAGE.md        # Package documentation
├── example.py               # Usage examples
├── fc_gen/                  # FCIDUMP generator module
│   ├── __init__.py
│   ├── fc_gen.py           # Main FCIDumpWriter class
│   ├── fc_utils.py         # Helper functions
│   ├── fmt.py              # Formatting utilities
│   ├── integrals_one_e.py  # One-electron integrals
│   ├── integrals_two_e.py  # Two-electron integrals
│   └── metadata_utils.py   # Metadata handling
└── archiver/                # FCIDUMP archiver module
    ├── __init__.py
    ├── gecco_archiver.py   # Main GeCCoArchiver class
    ├── archiver_core.py    # Core compression functions
    ├── fcidump_codec.pyx   # Cython codec
    ├── zstd_codec.pyx      # Zstandard compression
    └── ...
```

## Usage

See `example.py` and `README_PACKAGE.md` for detailed usage examples.
