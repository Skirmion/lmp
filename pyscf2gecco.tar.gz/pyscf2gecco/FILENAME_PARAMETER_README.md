# Параметр `filename` для работы с произвольными именами файлов FCIDUMP

## Описание изменений

Добавлен опциональный параметр `filename` в функции архиватора FCIDUMP, который позволяет работать с файлами, имеющими произвольные имена (не только стандартное "FCIDUMP").

## Ключевые особенности

### 1. Автоматическое определение формата по сигнатуре
Формат файла определяется **по содержимому**, а не по расширению:
- **`.bin`** - определяется по магической сигнатуре `FCD5` (4 байта)
- **`.bin.zst`** - определяется по магической сигнатуре zstd: `0x28 0xB5 0x2F 0xFD`
- **`.txt`** - текстовый формат (содержит `&FCI`, `NORB`, `NELEC` и т.д.)

Это означает, что файл может называться просто `data` без расширения, но внутри быть в формате `.bin.zst` - система автоматически это определит.

### 2. Обратная совместимость
Все изменения **полностью обратно совместимы**:
- Если параметр `filename` не указан (по умолчанию `None`), используются стандартные имена: `FCIDUMP`, `FCIDUMP.bin`, `FCIDUMP.bin.zst`
- Вся существующая логика работы остается неизменной

## Модифицированные функции

### 1. `compress_fcidump_dir()`

```python
def compress_fcidump_dir(
    *,
    dirpath: str,
    tag: str,
    compress: str = "zstd",
    zstd_level: int = 1,
    zstd_threads: Optional[int] = None,
    fc_workers: Optional[int] = None,
    user_meta: Optional[Dict] = None,
    filename: Optional[str] = None,  # НОВЫЙ ПАРАМЕТР
) -> Tuple[str, int, bool, str]:
```

**Параметр `filename`:**
- Если `None` (по умолчанию) - использует стандартные имена файлов
- Если указан - использует это имя как базовое для всех операций
- Формат автоматически определяется по сигнатуре файла

### 2. `restore_loose_fcidump()`

```python
def restore_loose_fcidump(
    *,
    dirpath: str,
    to_text: bool = True,
    fc_workers: Optional[int] = None,
    zstd_dthreads: int = 0,
    filename: Optional[str] = None,  # НОВЫЙ ПАРАМЕТР
) -> Tuple[str, int, bool, str]:
```

**Параметр `filename`:**
- Если `None` (по умолчанию) - ищет стандартные файлы
- Если указан - работает с файлом этого имени
- Автоматически определяет, является ли файл `.bin`, `.bin.zst` или `.txt`

## Примеры использования

### Пример 1: Сжатие файла с произвольным именем

```python
from pyscf2gecco.archiver.archiver_core import compress_fcidump_dir

# Файл может называться как угодно, например "my_data"
# И быть в любом формате (txt, bin, или bin.zst)
result = compress_fcidump_dir(
    dirpath="/path/to/dir",
    tag="my_tag",
    compress="zstd",
    fcidump_filename="my_data",  # произвольное имя
)

dirpath, saved, success, msg = result
print(f"Success: {success}, Saved: {saved} bytes")
```

### Пример 2: Восстановление файла с произвольным именем

```python
from pyscf2gecco.archiver.archiver_core import restore_loose_fcidump

# Файл "compressed_data" может быть на самом деле .bin.zst
# Формат определится автоматически по сигнатуре
result = restore_loose_fcidump(
    dirpath="/path/to/dir",
    to_text=True,
    fcidump_filename="compressed_data",  # произвольное имя
)

dirpath, delta, success, msg = result
print(f"Success: {success}, Delta: {delta} bytes")
```

### Пример 3: Стандартное использование (без изменений)

```python
# Старый код работает без изменений!
result = compress_fcidump_dir(
    dirpath="/path/to/dir",
    tag="my_tag",
    compress="zstd",
    # filename не указан - используются стандартные имена
)
```

## Внутренняя реализация

### Добавлена функция `_detect_fcidump_format()`

```python
def _detect_fcidump_format(filepath: str) -> Optional[str]:
    """
    Определить формат файла FCIDUMP по его содержимому.
    Возвращает: 'bin' для .bin, 'zst' для .bin.zst, 
                'txt' для текстового, None если не удалось определить.
    """
```

Функция проверяет:
1. Первые 4 байта на совпадение с `FCD5` (бинарный формат)
2. Первые 4 байта на совпадение с `0x28B52FFD` (zstd формат)
3. Пытается декодировать как UTF-8 текст и ищет ключевые слова FCIDUMP

### Логика работы в функциях

1. Если `fcidump_filename=None` → используются стандартные пути
2. Если `filename` указан → формируются пути с этим именем
3. Проверяется существование файла
4. Определяется реальный формат по сигнатуре
5. Пути перенаправляются на правильные файлы в зависимости от формата

## Тестирование

Созданы тесты:
- `test_filename_param.py` - тесты новой функциональности
- `test_backward_compat.py` - тесты обратной совместимости

Оба теста успешно пройдены ✓

## Изменения в коде

Файл: `pyscf2gecco/archiver/archiver_core.py`

1. Добавлена функция `_detect_fcidump_format()` (строки ~205-245)
2. Модифицирована `compress_fcidump_dir()` - добавлен параметр `filename`
3. Модифицирована `restore_loose_fcidump()` - добавлен параметр `filename`

Всего изменено: ~100 строк (добавлено ~80 новых, модифицировано ~20)

## Безопасность

- Все изменения **аккуратно интегрированы** в существующую логику
- **Не нарушена** работа существующего кода
- **Сохранена** полная обратная совместимость
- **Добавлена** защита от некорректных данных в `_detect_fcidump_format()`

## Заключение

Теперь функции архиватора могут работать с файлами FCIDUMP любых имен, автоматически определяя их формат по содержимому, а не по расширению. Это делает систему более гибкой и удобной в использовании, при этом полностью сохраняя совместимость со всем существующим кодом.
