# 🎉 Runner - Финальная версия (оптимизирована)

## Ключевое изменение

### Для текстовых файлов: ВСЕГДА симлинк!

```python
# fcidump_filename="my_file" (текстовый)

runner.run("job.inp", mode="ram", fcidump_filename="my_file")
runner.run("job.inp", mode="disk", fcidump_filename="my_file")

# Оба создают СИМЛИНК (не копию)
# → Экономия времени
# → Экономия места
# → Одинаковое поведение
```

## Простая матрица

| Файл | fcidump_filename | Что происходит |
|------|------------------|----------------|
| FCIDUMP (текст) | None | Используется как есть |
| FCIDUMP.bin | None | mode работает: ram/disk |
| my_file (текст) | "my_file" | **Симлинк** (оба mode) |
| my_file.bin | "my_file" | mode работает: ram/disk |

## Преимущества

✅ **Нет копирования** текстовых файлов  
✅ **Экономия времени** - создание симлинка мгновенное  
✅ **Экономия места** - нет дубликатов  
✅ **Простота** - один путь для текстовых  
✅ **Проверки** - mode всё ещё проверяет существование  

## Примеры

### Текстовый файл
```python
# mode не влияет на способ обработки
runner.run("job.inp", mode="ram", fcidump_filename="data.txt")
runner.run("job.inp", mode="disk", fcidump_filename="data.txt")
# Оба → симлинк
```

### Бинарный файл
```python
# mode влияет на место распаковки
runner.run("job.inp", mode="ram", fcidump_filename="data.bin")   # → RAM
runner.run("job.inp", mode="disk", fcidump_filename="data.bin")  # → disk
```

---

## ✅ ГОТОВО! ⚡ ОПТИМАЛЬНО!
