# sym.py  ───────────────────────────────────────────────────────────────────
"""
Lightweight helpers for symmetry and spin:

- molpro_irrep(obj, mol)  -> (molpro_id, label)
- spin_info(obj, mol)     -> (ms, mult)

Design goals
------------
- Robust when molecular symmetry is **disabled** (no wfnsym, no irrep tables).
- Works with HF/ROHF and CASSCF (incl. state-averaged).
- If wfnsym is missing/unknown, choose the group's **Molpro ID = 1** irrep
  (e.g., A1 in C2v, Ag in D2h, A in C1), which is widely accepted as a safe
  default. If symmetry is off or group is unknown, fall back to **C1 → (1,'A')**.

Spin
----
- ms   = obj.spin or mol.spin (PySCF stores 2*S_z)
- mult = 2*S+1 from <S^2> if available; otherwise |ms|+1
"""

from __future__ import annotations

import math
import numbers
from typing import Tuple, Optional, Any, Dict, List

import numpy as np
from pyscf import symm

# ── Molpro-ID tables (label -> ID) ─────────────────────────────────────────
ID: Dict[str, Dict[str, int]] = {
    "d2h": {"Ag": 1, "B1g": 4, "B2g": 6, "B3g": 7, "Au": 8, "B1u": 5, "B2u": 3, "B3u": 2},
    "c2v": {"A1": 1, "A2": 4, "B1": 2, "B2": 3},
    "c2h": {"Ag": 1, "Bg": 4, "Au": 2, "Bu": 3},
    "d2":  {"A": 1, "B1": 4, "B2": 3, "B3": 2},
    "cs":  {"A'": 1, 'A"': 2},
    "c2":  {"A": 1, "B": 2},
    "ci":  {"Ag": 1, "Au": 2},
    "c1":  {"A": 1},
}


def _group_key(mol) -> str:
    """Return normalized point group or 'c1' as a safe default."""
    g = getattr(mol, "groupname", None)
    if not g:
        return "c1"
    gkey = str(g).lower()
    return gkey if gkey in ID else "c1"


def _default_label_for_group(gkey: str) -> str:
    """Pick the label that has Molpro ID=1 for this group."""
    table = ID.get(gkey, ID["c1"])
    # Prefer the label explicitly mapped to 1; otherwise take the first key.
    for lab, mid in table.items():
        if mid == 1:
            return lab
    return next(iter(table.keys()))


def _normalize_label(obj: Any) -> str:
    """Convert bytes → str and strip whitespace."""
    if isinstance(obj, bytes):
        return obj.decode().strip()
    return str(obj).strip()


# ── 1) Molpro irrep of the wavefunction ────────────────────────────────────
def molpro_irrep(obj, mol) -> Tuple[int, str]:
    """
    Return (molpro_id, label) for HF/ROHF/CASSCF.

    Rules
    -----
    - If obj.wfnsym exists:
        * list/array → choose the state with minimal energy (obj.e_states) or 0
        * int        → map to label via mol.irrep_id/irrep_name or ID table
        * str/bytes  → validate/normalize within the group's table
    - If wfnsym is missing/invalid:
        * use group's default label with Molpro ID=1
    - If group is unknown → treat as C1.

    This function does NOT require symmetry to be enabled in PySCF.
    """
    gkey = _group_key(mol)
    table = ID[gkey]

    wfnsym: Optional[Any] = getattr(obj, "wfnsym", None)

    # State-averaged CASSCF may have a list/array of wfnsym
    if isinstance(wfnsym, (list, tuple, np.ndarray)):
        if hasattr(obj, "e_states") and isinstance(getattr(obj, "e_states"), (list, tuple, np.ndarray)):
            idx = int(np.argmin(np.asarray(obj.e_states)))
        else:
            idx = 0
        try:
            wfnsym = wfnsym[idx]
        except Exception:
            wfnsym = None

    label: Optional[str] = None

    if isinstance(wfnsym, numbers.Integral):
        # Try to map integer symmetry ID → label via PySCF molecule first
        names = getattr(mol, "irrep_name", None)
        ids = getattr(mol, "irrep_id", None)
        if names is not None and ids is not None:
            try:
                for lab, iid in zip(names, ids):
                    if int(iid) == int(wfnsym):
                        label = _normalize_label(lab)
                        break
            except Exception:
                label = None
        if label is None:
            # Fallback: invert our ID table for this group
            try:
                inv = {v: k for k, v in table.items()}
                label = inv.get(int(wfnsym))
            except Exception:
                label = None

    elif isinstance(wfnsym, (str, bytes)):
        lab = _normalize_label(wfnsym)
        label = lab if lab in table else None

    # If we still don't have a valid label → choose group's default (ID=1)
    if not label:
        label = _default_label_for_group(gkey)

    molpro_id = table[label]
    return molpro_id, label


# ── 2) ms and multiplicity ─────────────────────────────────────────────────
def spin_info(obj, mol) -> Tuple[int, int]:
    """
    Return (ms, mult) where:
      ms   = 2*M_S   (PySCF uses .spin = 2*S_z)
      mult = 2*S+1   (from <S^2> if available; otherwise |ms| + 1)
    """
    ms = int(getattr(obj, "spin", getattr(mol, "spin", 0)))

    # Try to read <S^2>
    s2 = None
    for attr in ("ssquare", "spin_square"):
        if hasattr(obj, attr):
            try:
                s2 = getattr(obj, attr)()[0]
                break
            except Exception:
                pass

    if s2 is not None:
        # Solve S(S+1) = <S^2>
        S = 0.5 * (-1.0 + math.sqrt(1.0 + 4.0 * float(s2)))
        mult = int(round(2 * S + 1))
    else:
        # Conservative fallback assuming S = |ms|/2
        mult = abs(ms) + 1

    return ms, mult
