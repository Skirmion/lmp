#!/usr/bin/env python3
# gecco_input_writer.py
"""
High-level builder for GECCo / IC-MRCC input files, driven by a template.

Key points
----------
- No public flags to choose method path for sym/ms/mult.
  The builder AUTO-detects the method family by scanning the template and user patches:
    • If 'method' contains CC-lines → CC family.
    • If it contains MR-like lines (MR, MRCC, MR_P, MRCC_new, ...) → MR family.
    • If BOTH CC and MR* are present → ValueError (families cannot be mixed).
    • If none found → MR family is assumed (a new 'MR' line may be created).

- Where parameters go:
    • sym/ms/mult           → to the selected path (CC or MR*; prefer exactly 'MR' if available).
    • method_MR_maxexc/minexc → to the selected path (works for CC and MR*).
    • method_MR_ciroot      → MR only; skipped with WARNING in CC mode. Target path: 'MR'
                               (created if absent).
    • method_MRCC_maxcom_*  → MRCC only; skipped with WARNING in CC mode. Target path: 'MRCC'
                               (created if absent).

- Unified patches with precedence:
    implicit autos → user patches → explicit builder args.
  Only explicit args warn on collision with patches (builder overrides).

- 'orb_space' is always replaced with 4 lines from shell_type.make_orb_lines(...).
- In non-orb_space blocks, params are `key=value` comma-separated with no spaces.

"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List, Sequence, Tuple, Union, Optional
import re
import warnings

from .shell_type import make_orb_lines
from .sym import molpro_irrep, spin_info
from .memory_utils import guess_mem_words
from .keyword_patch import apply_patches


# ------------------------------- Utilities -----------------------------------

BRACKET_SECTION = re.compile(r"^\s*\[\s*(?P<name>[\w\-]+)\s*\]\s*$", re.IGNORECASE)
BARE_HEADER = re.compile(r"^([A-Za-z_][\w]*)\s*$")  # e.g., "general", "method", "orb_space"
TOP_SKIP = re.compile(r"^\s*(?:#.*)?$")


def _leading_ws(s: str) -> str:
    m = re.match(r"^\s*", s)
    return m.group(0) if m else ""


def _default_indent(lines: List[str]) -> str:
    for ln in reversed(lines):
        if ln.strip():
            ws = _leading_ws(ln)
            return ws if ws else "  "
    return "  "


def _to_fortran_d(x: Any) -> str:
    """
    Convert a numeric value or an 'e/E' string to Fortran-D with compact exponent:
      1e-08  -> '1d-8'
      2.5e+07 -> '2.5d7'
      1.0     -> '1d0'
    Rules:
      - No leading zeros in the exponent.
      - No leading '+' sign for positive exponents.
      - Mantissa stripped from trailing zeros and trailing dot.
      - Preserve minus sign for negative exponents.
    """
    def _format_from_float(val: float) -> str:
        mant_str, exp_str = f"{float(val):.15e}".split("e")  # e.g. '1.000000000000000e-08'
        mant = mant_str.rstrip("0").rstrip(".") or "0"
        try:
            ed = int(exp_str)  # keeps sign and removes leading zeros automatically
        except ValueError:
            # extremely rare fallback: strip leading zeros and possible '+'
            exp_norm = exp_str.lstrip("+")
            exp_norm = exp_norm.lstrip("0") or "0"
            # restore sign if was negative
            if exp_str.startswith("-"):
                exp_norm = "-" + exp_norm
            return f"{mant}d{exp_norm}"
        return f"{mant}d{ed}"  # str(ed) has '-' for negatives, no '+' for positives

    # Numeric input
    if isinstance(x, (int, float)):
        return _format_from_float(float(x))

    # String input
    s = str(x).strip()
    if "e" in s.lower():
        try:
            return _format_from_float(float(s))
        except Exception:
            # last-resort fallback: just swap e/E→d (may keep '+', but only on unparsable inputs)
            return s.replace("E", "d").replace("e", "d")
    # Plain numeric string (e.g., '0.001')
    try:
        return _format_from_float(float(s))
    except Exception:
        return s  # non-numeric tokens unchanged



def _as_param_value(x: Any) -> str:
    """Compact formatting for values used in key=value."""
    if isinstance(x, bool):
        return "T" if x else "F"
    if isinstance(x, int):
        return str(x)
    if isinstance(x, float):
        return f"{x:g}"
    return str(x)


def _words_from_gib(mem_gib: Union[int, float]) -> int:
    """Convert GiB to the number of 8-byte words (floor)."""
    bytes_total = float(mem_gib) * (1024.0 ** 3)
    return int(bytes_total // 8.0)


def _path_words_only(tokens: Sequence[Any]) -> Tuple[str, ...]:
    """Normalize a 'path' (list of tokens) by keeping only bare words (drop 'k=v')."""
    words: List[str] = []
    for t in tokens:
        t = str(t).strip()
        if not t or "=" in t:
            continue
        words.append(t)
    return tuple(words)


def _param_key_of(patch: Dict[str, Any]) -> Tuple[str, Tuple[str, ...], str]:
    """
    Return a normalized key for conflict detection:
      (block_lower, tuple(path_words_only), key)
    """
    block = str(patch.get("block", "")).lower()
    path_words = _path_words_only(patch.get("path", []))
    param = str(patch.get("param", ""))
    key = param.split("=", 1)[0].strip() if "=" in param else ""
    return block, path_words, key


# --- minimal parsing for 'method' block words --------------------------------

def _split_words_params(body: str) -> Tuple[List[str], List[Tuple[str, str]]]:
    """Parse '<words> k=v,k2=v2' into (words, [(k,v),...])."""
    body = body.strip()
    if not body:
        return [], []
    parts = [p for p in body.split(",") if p != ""]
    first = parts[0]
    rest = parts[1:]
    words: List[str] = []
    items: List[Tuple[str, str]] = []
    for tok in first.split():
        if "=" in tok:
            k, v = tok.split("=", 1)
            if k:
                items.append((k.strip(), v.strip()))
        elif tok.strip():
            words.append(tok.strip())
    for frag in rest:
        frag = frag.strip()
        if frag and "=" in frag:
            k, v = frag.split("=", 1)
            items.append((k.strip(), v.strip()))
    return words, items


def _extract_block_lines(all_lines: List[str], block_name: str) -> List[str]:
    """Return lines inside a named block (bracket or bare header)."""
    out: List[str] = []
    i = 0
    block_name = block_name.lower()
    while i < len(all_lines):
        ln = all_lines[i]
        m = BRACKET_SECTION.match(ln)
        if m and m.group("name").strip().lower() == block_name:
            i += 1
            while i < len(all_lines) and not (BRACKET_SECTION.match(all_lines[i]) or BARE_HEADER.match(all_lines[i])):
                out.append(all_lines[i]); i += 1
            break
        m2 = BARE_HEADER.match(ln)
        if m2 and m2.group(1).strip().lower() == block_name:
            i += 1
            while i < len(all_lines) and not (BRACKET_SECTION.match(all_lines[i]) or BARE_HEADER.match(all_lines[i])):
                out.append(all_lines[i]); i += 1
            break
        i += 1
    return out


# ------------------------------ Core Builder ---------------------------------

class GeccoInputBuilder:
    """
    Orchestrates reading a template, building orb_space and keyword patches,
    applying them with ordering, and writing the final input file.

    Parameters
    ----------
    name : str
        Template name (without .inp extension). The builder will look for
        {name}.inp in templates_dir. Available templates: 'icMRCC', 'icMRCCpT'.
    mol : pyscf.gto.Mole
        PySCF molecule object.
    wf : pyscf.mcscf.CASSCF or similar
        PySCF wavefunction object (typically CASSCF).
    templates_dir : str or Path, optional
        Directory containing template .inp files. If None (default), uses
        the package's built-in templates directory.
    outfile : str, optional
        Output filename. If None, uses {name}_new.inp.
    mem_gib : float, optional
        Memory limit in GiB for GeCCo calculation.
    printlvl : int, optional
        Print level (0=minimal, 3=debug).
    group : str, optional
        Point group symmetry (e.g., 'd2h', 'c2v').
    core_idx : list of int, optional
        Indices of core orbitals.
    active_idx : list of int, optional
        Indices of active space orbitals.
    frozen_idx : list of int, optional
        Indices of frozen orbitals.
    deleted_idx : list of int, optional
        Indices of deleted virtual orbitals.
    method_MR_maxexc : int, optional
        Maximum excitation level for MR.
    method_MR_minexc : int, optional
        Minimum excitation level for MR.
    method_MR_ciroot : int, optional
        Number of CI roots.
    method_MRCC_maxcom_res : int, optional
        Max components in MRCC residuals.
    method_MRCC_maxcom_en : int, optional
        Max components in MRCC energy.
    calc_solve_maxiter : int, optional
        Maximum solver iterations.
    calc_solve_conv : float, optional
        Convergence threshold.
    calc_routes_sv_thresh : float, optional
        Singular value threshold.
    calc_solve_non_linear_optref : bool or int, optional
        Optimization reference flag.
    patches : list of dict, optional
        Additional keyword patches.
    debug_orb : bool, default=False
        Enable debug output for orbital spaces.
    verbose : bool, default=True
        Enable verbose output.

    Methods
    -------
    write()
        Execute the full pipeline and save the input file.

    Notes
    -----
    Call `write()` to execute the full pipeline and save the file.
    """

    def __init__(
        self,
        *,
        name: str,
        mol,
        wf,
        templates_dir: Union[str, Path] = None,
        outfile: Optional[str] = None,
        # Memory / printing (explicit only if not None)
        mem_gib: Optional[Union[int, float]] = None,
        printlvl: Optional[int] = None,
        # calculate / solve (explicit only if not None)
        calc_solve_maxiter: Any | None = None,
        calc_solve_conv: Any | None = None,
        # calculate / routes
        calc_routes_sv_thresh: Any | None = None,
        # calculate / solve non_linear
        calc_solve_non_linear_optref: Any | None = None,
        # method MR/MRCC knobs
        method_MR_maxexc: Any | None = None,
        method_MR_minexc: Any | None = None,
        method_MR_ciroot: Any | None = None,
        # method MRCC knobs
        method_MRCC_maxcom_res: Any | None = None,
        method_MRCC_maxcom_en: Any | None = None,
        # Extra patches from user
        patches: Sequence[Dict[str, Any]] | None = None,
        # orb_space options
        group: Optional[str] = None,
        core_idx: Sequence[int] | None = None,
        active_idx: Sequence[int] | None = None,
        frozen_idx: Sequence[int] | None = None,
        deleted_idx: Sequence[int] | None = None,
        debug_orb: bool = False,
        # verbosity
        verbose: bool = True,
    ):
        self.name = name
        self.mol = mol
        self.wf = wf
        # Default templates_dir to package's templates directory
        if templates_dir is None:
            self.templates_dir = Path(__file__).parent / "templates"
        else:
            self.templates_dir = Path(templates_dir)
        self.outfile = outfile
        # general
        self.mem_gib = mem_gib
        self.printlvl = printlvl
        # calculate/method knobs (explicit if not None)
        self.calc_solve_maxiter = calc_solve_maxiter
        self.calc_solve_conv = calc_solve_conv
        self.calc_routes_sv_thresh = calc_routes_sv_thresh
        self.calc_solve_non_linear_optref = calc_solve_non_linear_optref
        self.method_MR_maxexc = method_MR_maxexc
        self.method_MR_minexc = method_MR_minexc
        self.method_MR_ciroot = method_MR_ciroot
        self.method_MRCC_maxcom_res = method_MRCC_maxcom_res
        self.method_MRCC_maxcom_en = method_MRCC_maxcom_en
        self.user_patches = list(patches) if patches else []
        # orb space
        self.group = group
        self.core_idx = core_idx
        self.active_idx = active_idx
        self.frozen_idx = frozen_idx
        self.deleted_idx = deleted_idx
        self.debug_orb = debug_orb
        # verbosity
        self.verbose = verbose

        # Internal
        self._template_lines: List[str] = []
        self._orb_lines: List[str] = []
        self._mem_words: int = 0
        self._mem_explicit: bool = False
        self._sym_id: int = 1
        self._ms: int = 0
        self._mult: int = 1

        # detected family/path info
        self._method_path: List[str] = ["MR"]  # target for sym/ms/mult and generic knobs
        self._has_cc: bool = False
        self._mr_paths: List[List[str]] = []     # all MR* paths found
        self._mrcc_paths: List[List[str]] = []   # MRCC* subset

    # --------------------------- Pipeline steps -----------------------------

    def _read_template(self) -> None:
        tpl_path = self.templates_dir / f"{self.name}.inp"
        if not tpl_path.exists():
            raise FileNotFoundError(tpl_path)
        self._template_lines = tpl_path.read_text().splitlines()

    def _detect_memory(self) -> None:
        if self.mem_gib is not None:
            self._mem_words = _words_from_gib(self.mem_gib)
            self._mem_explicit = True
        else:
            self._mem_words = guess_mem_words()
            self._mem_explicit = False

    def _compute_sym_spin(self) -> None:
        self._sym_id, _ = molpro_irrep(self.wf, self.mol)
        self._ms, self._mult = spin_info(self.wf, self.mol)

    def _detect_method_path(self) -> None:
        """
        Scan template and user patches to decide method family and target path
        for sym/ms/mult and generic method knobs (maxexc/minexc).
        """
        method_lines = _extract_block_lines(self._template_lines, "method")

        cc_candidates: List[Tuple[int, List[str]]] = []
        mr_candidates: List[Tuple[int, List[str]]] = []
        mrcc_candidates: List[Tuple[int, List[str]]] = []

        # From template
        order = 0
        for ln in method_lines:
            words, _ = _split_words_params(ln.strip())
            if not words:
                continue
            u0 = words[0].upper()
            if u0 == "CC":
                cc_candidates.append((order, words))
            elif u0.startswith("MR"):
                mr_candidates.append((order, words))
                if u0.startswith("MRCC"):
                    mrcc_candidates.append((order, words))
            order += 1

        # From user patches (only method block)
        for idx, p in enumerate(self.user_patches):
            if str(p.get("block", "")).lower() != "method":
                continue
            path_words = [t for t in p.get("path", []) if isinstance(t, str) and "=" not in t]
            if not path_words:
                continue
            u0 = path_words[0].upper()
            if u0 == "CC":
                cc_candidates.append((order + idx, list(path_words)))
            elif u0.startswith("MR"):
                mr_candidates.append((order + idx, list(path_words)))
                if u0.startswith("MRCC"):
                    mrcc_candidates.append((order + idx, list(path_words)))

        self._has_cc = bool(cc_candidates)
        has_mr = bool(mr_candidates)

        if self._has_cc and has_mr:
            raise ValueError(
                "Method block mixes CC and MR-based inputs (found both CC and MR*). "
                "Please keep only one family: either CC, or MR/MRCC/MR_P/…"
            )

        def _choose_shortest_first(cands: List[Tuple[int, List[str]]]) -> List[str]:
            if not cands:
                return []
            cands_sorted = sorted(cands, key=lambda x: (len(x[1]), x[0]))
            return cands_sorted[0][1]

        if self._has_cc:
            self._method_path = _choose_shortest_first(cc_candidates) or ["CC"]
            self._mr_paths = []
            self._mrcc_paths = []
            return

        if has_mr:
            # prefer exactly ['MR'] if exists; else shortest MR*
            for _, words in mr_candidates:
                if [w.upper() for w in words] == ["MR"]:
                    self._method_path = words
                    break
            else:
                self._method_path = _choose_shortest_first(mr_candidates) or ["MR"]

            self._mr_paths = [w for _, w in mr_candidates]
            self._mrcc_paths = [w for _, w in mrcc_candidates]
            return

        # none found → default to MR (family)
        self._method_path = ["MR"]
        self._mr_paths = [["MR"]]
        self._mrcc_paths = []

    def _build_orb_space(self) -> None:
        nelec = getattr(self.mol, "nelectron")
        self._orb_lines = make_orb_lines(
            nelec,
            mol=self.mol,
            wf=self.wf,
            group=self.group,
            core_idx=self.core_idx,
            active_idx=self.active_idx,
            frozen_idx=self.frozen_idx,
            deleted_idx=self.deleted_idx,
            debug=self.debug_orb,
        )

    def _build_patches(self) -> List[Dict[str, Any]]:
        """
        Build a unified list of patches with correct precedence:
          implicit autos → user patches → explicit autos.
        Only explicit autos produce WARNINGs on collision with user patches.
        Also enforces family constraints for MR/MRCC-specific knobs with warnings.
        """
        implicit: List[Dict[str, Any]] = []
        explicit: List[Dict[str, Any]] = []

        # --- general ---
        if self._mem_explicit:
            explicit.append({"block": "general", "path": [], "param": f"memmax={self._mem_words}"})
        else:
            implicit.append({"block": "general", "path": [], "param": f"memmax={self._mem_words}"})
        if self.printlvl is not None:
            explicit.append({"block": "general", "path": [], "param": f"print={int(self.printlvl)}"})

        # --- sym/ms/mult go to selected path (CC or MR*)
        for k, v in (("sym", self._sym_id), ("ms", self._ms), ("mult", self._mult)):
            explicit.append({"block": "method", "path": self._method_path, "param": f"{k}={v}"})

        def add_exp(block: str, path: Sequence[str], key: str, val: Any, fortran_d: bool = False):
            if val is None:
                return
            v = _to_fortran_d(val) if fortran_d else _as_param_value(val)
            explicit.append({"block": block, "path": list(path), "param": f"{key}={v}"})

        # --- method generic knobs (work for both families) → selected path
        add_exp("method", self._method_path, "maxexc", self.method_MR_maxexc)
        add_exp("method", self._method_path, "minexc", self.method_MR_minexc)

        # --- MR-only: ciroot
        if self.method_MR_ciroot is not None:
            if self._has_cc:
                warnings.warn(
                    "Parameter 'ciroot' is MR-only but the method block is CC-family. "
                    "It will be ignored.",
                    stacklevel=1,
                )
            else:
                # choose MR target path: prefer exactly ['MR'], else first MR*, else create ['MR']
                mr_target = ["MR"]
                if self._mr_paths:
                    for w in self._mr_paths:
                        if [t.upper() for t in w] == ["MR"]:
                            mr_target = w
                            break
                    else:
                        mr_target = sorted(self._mr_paths, key=lambda ws: len(ws))[0]
                add_exp("method", mr_target, "ciroot", self.method_MR_ciroot)

        # --- MRCC-only: maxcom_res / maxcom_en
        for key, val in (("maxcom_res", self.method_MRCC_maxcom_res),
                         ("maxcom_en",  self.method_MRCC_maxcom_en)):
            if val is None:
                continue
            if self._has_cc:
                warnings.warn(
                    f"Parameter '{key}' is MRCC-only but the method block is CC-family. "
                    "It will be ignored.",
                    stacklevel=1,
                )
                continue
            # MR family: put into MRCC path; create 'MRCC' if absent
            if self._mrcc_paths:
                mrcc_target = sorted(self._mrcc_paths, key=lambda ws: len(ws))[0]
            else:
                mrcc_target = ["MRCC"]
            add_exp("method", mrcc_target, key, val)

        # --- calculate / solve
        add_exp("calculate", ["solve"], "maxiter", self.calc_solve_maxiter)
        add_exp("calculate", ["solve"], "conv", self.calc_solve_conv, fortran_d=True)
        # --- calculate / routes
        add_exp("calculate", ["routes"], "sv_thresh", self.calc_routes_sv_thresh, fortran_d=True)
        # --- calculate / solve non_linear
        add_exp("calculate", ["solve", "non_linear"], "optref", self.calc_solve_non_linear_optref)

        # --- WARNINGs only for collisions with explicit autos ---
        user_keys = {_param_key_of(p) for p in self.user_patches if "param" in p}
        for ap in explicit:
            akey = _param_key_of(ap)
            if akey[2] and akey in user_keys:
                block, pwords, key = akey
                path_str = " ".join(pwords) if pwords else "<root>"
                warnings.warn(
                    f"Parameter conflict for [{block}] path '{path_str}': '{key}' is set both "
                    f"in builder arguments and in 'patches'. The builder argument takes precedence.",
                    stacklevel=1,
                )

        # --- precedence: implicit → user → explicit ---
        return implicit + self.user_patches + explicit

    def _rewrite_with_orb_space(self, lines: List[str]) -> List[str]:
        """Replace the body of 'orb_space' with `self._orb_lines`."""
        out: List[str] = []
        i = 0

        def capture_until_next_header(start_idx: int) -> Tuple[List[str], int]:
            buf: List[str] = []
            j = start_idx
            while j < len(lines):
                if BRACKET_SECTION.match(lines[j]) or BARE_HEADER.match(lines[j]):
                    break
                buf.append(lines[j]); j += 1
            return buf, j

        while i < len(lines):
            ln = lines[i]

            if TOP_SKIP.match(ln):
                out.append(ln); i += 1; continue

            m = BRACKET_SECTION.match(ln)
            if m:
                block_name = m.group("name").strip().lower()
                out.append(ln); i += 1
                buf, i = capture_until_next_header(i)
                if block_name == "orb_space":
                    indent = _default_indent(buf) if buf else "  "
                    out.extend([indent + x if not x.startswith(" ") else indent + x.lstrip()
                                for x in self._orb_lines])
                else:
                    out.extend(buf)
                continue

            m2 = BARE_HEADER.match(ln)
            if m2:
                block_name = m2.group(1).strip().lower()
                out.append(ln); i += 1
                buf, i = capture_until_next_header(i)
                if block_name == "orb_space":
                    indent = _default_indent(buf) if buf else "  "
                    out.extend([indent + x if not x.startswith(" ") else indent + x.lstrip()
                                for x in self._orb_lines])
                else:
                    out.extend(buf)
                continue

            out.append(ln); i += 1

        return out

    def _apply_all(self) -> List[str]:
        """Replace orb_space and apply unified patches."""
        with_orb = self._rewrite_with_orb_space(self._template_lines)
        patched = apply_patches(with_orb, self._build_patches())
        return patched

    # ------------------------------ Public API ------------------------------

    def write(self) -> Path:
        """Execute the full pipeline and write the final input file to disk."""
        self._read_template()
        self._detect_memory()
        self._compute_sym_spin()
        self._detect_method_path()   # decide CC vs MR*, collect MR/MRCC paths
        self._build_orb_space()
        final_lines = self._apply_all()

        out_path = Path.cwd() / (self.outfile or f"{self.name}_new.inp")
        out_path.write_text("\n".join(final_lines) + "\n")
        if self.verbose:
            print(f"[GECCo] saved  →  {out_path}")
            print(f"        sym={self._sym_id}  ms={self._ms}  mult={self._mult}  memmax={self._mem_words}")
            print(f"        method path (generic knobs) → {' '.join(self._method_path)}")
        return out_path
