# shell_type.py
"""
Build the **orb_space** block (occ/closed/frozen/deleted) for GECCo / IC-MRCC
from actual molecular orbitals (MOs) using PySCF symmetry labels.

Key decisions
-------------
- We use a **single** MO→irrep labeling route (strict):
    pyscf.symm.label_orb_symm(mol, mol.irrep_name, mol.symm_orb, mo_coeff)

- No fallbacks to alternative APIs or projection. If labeling fails:
    • If requested group is 'c1' (or symmetry is off) → aggregate all MOs as 'A'.
    • Otherwise → raise a clear error instructing to enable symmetry or use 'c1'.

Active space rules
------------------
- If `wf` is CASSCF and you did NOT override indices:
    core = [0:ncore), active = [ncore:ncore+ncas), closed = core, occ = core ∪ active.
- Otherwise:
    • If `active_idx` is None → assume active=0 ⇒ occ = closed = all occupied MOs (by `mo_occ`).
    • If `active_idx` is set    → closed = core_idx (or []), occ = core ∪ active.

Validation
----------
- closed ⊆ occ
- frozen ⊆ closed
- deleted ⊆ closed
- Indices within [0, nmo).

Public API
----------
make_orb_lines(nelec, *,
               mol,
               wf=None,
               group=None,
               core_idx=None,
               active_idx=None,
               frozen_idx=None,
               deleted_idx=None,
               debug=False) -> list[str]

Returns four lines:
  "shell type = occ,def=(...)"
  "shell type = closed,def=(...)"
  "shell type = frozen,def=(...)"
  "shell type = deleted,def=(...)"
"""

from __future__ import annotations

from typing import Dict, Iterable, List, Optional, Sequence, Tuple
import warnings
import numpy as np
from pyscf import symm

# Irrep orders used for counting (Molpro/GECCo-style)
ORDERS: Dict[str, List[str]] = {
    "d2h": ["Ag", "B1g", "B2g", "B3g", "Au", "B1u", "B2u", "B3u"],
    "c2v": ["A1", "B1", "B2", "A2"],
    "cs": ["A'", 'A"'],
    "c1": ["A"],
}


def _order_for_group(mol, group: Optional[str]) -> Tuple[str, List[str]]:
    """Resolve point-group key and return (group_key, irrep_order)."""
    g = (group or getattr(mol, "groupname", "c1")).lower()
    if g not in ORDERS:
        raise ValueError(f"Unknown point group '{g}'. Add it to ORDERS if needed.")
    return g, ORDERS[g]


def _fmt(vec: Sequence[int]) -> str:
    return "(" + ",".join(str(int(x)) for x in vec) + ")"


def _count_by_irrep(ir_labels: Sequence[str],
                    order: Sequence[str],
                    indices: Iterable[int]) -> List[int]:
    """
    Count how many **spatial MOs** fall into each irrep bucket from `order`.
    """
    idx_set = set(int(i) for i in indices)
    vec = [0] * len(order)
    pos: Dict[str, int] = {lab: i for i, lab in enumerate(order)}
    unknown = 0

    for i in idx_set:
        if i < 0 or i >= len(ir_labels):
            continue
        lab = ir_labels[i]
        j = pos.get(lab)
        if j is not None:
            vec[j] += 1
        else:
            unknown += 1

    # If nothing matched and indices were non-empty → irrep names/order mismatch.
    if unknown and sum(vec) == 0 and idx_set:
        raise ValueError(
            "MO irreps could not be matched to the requested group's order. "
            "Check the molecule's point group and MO symmetry labeling."
        )
    return vec


def _cascade(space: Dict[str, List[int]]) -> None:
    """Enforce component-wise hierarchy: occ ≥ closed ≥ (frozen, deleted)."""
    def dom(ax: List[int], bx: List[int]) -> None:
        for i in range(len(ax)):
            if ax[i] < bx[i]:
                ax[i] = bx[i]

    dom(space["closed"], space["frozen"])
    dom(space["closed"], space["deleted"])
    dom(space["occ"],    space["closed"])


def _ensure_subset(big_name: str, big: Iterable[int],
                   small_name: str, small: Iterable[int]) -> None:
    """Validate `small ⊆ big`; raise with offending indices otherwise."""
    B = set(int(i) for i in big)
    S = set(int(i) for i in small)
    extra = sorted(S - B)
    if extra:
        raise ValueError(
            f"Validation failed: {small_name} ⊆ {big_name} violated. "
            f"Indices in {small_name} not contained in {big_name}: {extra}"
        )


def _ensure_in_bounds(name: str, idxs: Iterable[int], nmo: int) -> None:
    """Validate all indices are within [0, nmo-1]."""
    bad = sorted({i for i in (int(x) for x in idxs) if i < 0 or i >= nmo})
    if bad:
        raise ValueError(
            f"Index out of bounds in '{name}': {bad} (valid range: 0..{nmo-1})"
        )


# ---------- Strict MO → irrep labeling (single route) ----------

def _as_irrep_names(mol, ir_seq) -> List[str]:
    """
    Normalize output of pyscf.symm.label_orb_symm(...) to a list of names.
    Accepts list/tuple/ndarray of bytes/str/ints. Avoids ndarray truthiness.
    """
    arr = np.asarray(ir_seq, dtype=object).ravel()
    if arr.size == 0:
        return []
    first = arr.flat[0]
    if isinstance(first, (bytes, str)):
        out: List[str] = []
        for x in arr.tolist():
            out.append(x.decode() if isinstance(x, bytes) else str(x))
        return out
    # Assume integer irrep IDs; convert to names.
    return [symm.irrep_id2name(mol.groupname, int(x)) for x in arr.tolist()]


def _labels_strict(mol, mo_coeff: np.ndarray) -> List[str]:
    """
    Strict PySCF route:
        symm.label_orb_symm(mol, mol.irrep_name, mol.symm_orb, mo_coeff)
    Raises if `mol.symm_orb`/`mol.irrep_name` are not available or API fails.
    """
    if not getattr(mol, "symm_orb", None) or not getattr(mol, "irrep_name", None):
        raise RuntimeError("Molecule symmetry data (mol.symm_orb/irrep_name) are not available.")
    ir = symm.label_orb_symm(mol, mol.irrep_name, mol.symm_orb, mo_coeff)
    return _as_irrep_names(mol, ir)


# ---------- Public API ----------

def make_orb_lines(
    nelec: int,
    *,
    mol,
    wf=None,
    group: str | None = None,
    core_idx: Sequence[int] | None = None,
    active_idx: Sequence[int] | None = None,
    frozen_idx: Sequence[int] | None = None,
    deleted_idx: Sequence[int] | None = None,
    debug: bool = False,
) -> List[str]:
    """
    Return four `shell type = ...` lines for the **orb_space** block.
    """
    gkey, order = _order_for_group(mol, group)

    # --- MO coeffs
    if wf is None or getattr(wf, "mo_coeff", None) is None:
        raise ValueError("mo_coeff not found. Pass an HF/ROHF/CASSCF object as 'wf'.")
    mo_coeff = np.asarray(wf.mo_coeff)
    if mo_coeff.ndim != 2:
        raise ValueError(f"wf.mo_coeff must be 2D, got shape {mo_coeff.shape!r}")
    nmo = mo_coeff.shape[1]

    # --- Symmetry handling
    sym_available = bool(getattr(mol, "symm_orb", None) and getattr(mol, "irrep_name", None))
    if not sym_available:
        # Symmetry is effectively OFF → only C1 is meaningful
        if gkey != "c1":
            raise ValueError(
                "Molecule symmetry appears to be disabled (mol.symm_orb/irrep_name are missing). "
                "Either build the molecule with symmetry enabled (e.g., mol.build(symmetry=True, group='c2v')) "
                "or call the generator with group='c1' to aggregate all orbitals."
            )
        ir_labels = ["A"] * nmo
    else:
        # Symmetry available — try strict PySCF labeling
        try:
            ir_labels = _labels_strict(mol, mo_coeff)
        except Exception as e:
            if gkey == "c1":
                warnings.warn(
                    f"MO symmetry labeling failed ({e!r}); proceeding with C1 aggregation ('A')."
                )
                ir_labels = ["A"] * nmo
            else:
                raise ValueError(
                    "Failed to label MO irreps via PySCF and non-C1 group was requested.\n"
                    "Enable symmetry (mol.build(symmetry=True, group='...')) or set group='c1'.\n"
                    f"Original error: {e!r}"
                ) from e

    # --- Indices (user overrides win)
    core_given   = core_idx   is not None
    active_given = active_idx is not None
    frozen_given = frozen_idx is not None
    deleted_given= deleted_idx is not None

    core_idx   = [] if core_idx   is None else list(core_idx)
    active_idx = None if active_idx is None else list(active_idx)
    frozen_idx = [] if frozen_idx is None else list(frozen_idx)
    deleted_idx= [] if deleted_idx is None else list(deleted_idx)

    for nm, arr in (("core_idx", core_idx),
                    ("active_idx", active_idx or []),
                    ("frozen_idx", frozen_idx),
                    ("deleted_idx", deleted_idx)):
        _ensure_in_bounds(nm, arr, nmo)

    # Auto-split for CASSCF if not overridden
    is_casscf = hasattr(wf, "ncore") and hasattr(wf, "ncas")
    if is_casscf and not core_given and not active_given:
        ncore, ncas = int(wf.ncore), int(wf.ncas)
        core_idx = list(range(0, ncore))
        active_idx = list(range(ncore, ncore + ncas))
    else:
        if active_idx is None and not is_casscf:
            warnings.warn("Active space is not provided; assuming active=0 (occ = closed).")
        if not core_given:
            mo_occ = getattr(wf, "mo_occ", None)
            core_idx = [i for i, occ in enumerate(np.asarray(mo_occ).ravel()) if occ > 1.5] if mo_occ is not None else []

    # Build occ/closed sets
    if active_idx is not None:
        occ_idx = sorted(set(core_idx) | set(active_idx))
        closed_idx = list(core_idx)
    else:
        mo_occ = getattr(wf, "mo_occ", None)
        occ_all = [i for i, occ in enumerate(np.asarray(mo_occ).ravel()) if occ > 1e-3] if mo_occ is not None else list(core_idx)
        occ_idx = list(occ_all)
        closed_idx = list(occ_all)

    # Validate set inclusions
    _ensure_subset("occ",    occ_idx,    "closed",  closed_idx)
    _ensure_subset("closed", closed_idx, "frozen",  frozen_idx)
    _ensure_subset("closed", closed_idx, "deleted", deleted_idx)

    # Count per irrep
    occ_vec    = _count_by_irrep(ir_labels, order, occ_idx)
    closed_vec = _count_by_irrep(ir_labels, order, closed_idx)
    frozen_vec = _count_by_irrep(ir_labels, order, frozen_idx) if frozen_given else [0] * len(order)
    deleted_vec= _count_by_irrep(ir_labels, order, deleted_idx) if deleted_given else [0] * len(order)

    # Enforce hierarchy occ ≥ closed ≥ (frozen, deleted)
    space = {"occ": occ_vec, "closed": closed_vec, "frozen": frozen_vec, "deleted": deleted_vec}
    _cascade(space)

    lines = [
        f"shell type = occ,def={_fmt(space['occ'])}",
        f"shell type = closed,def={_fmt(space['closed'])}",
        f"shell type = frozen,def={_fmt(space['frozen'])}",
        f"shell type = deleted,def={_fmt(space['deleted'])}",
    ]
    if debug:
        print("[orb_space]")
        for ln in lines:
            print(ln)
    return lines
