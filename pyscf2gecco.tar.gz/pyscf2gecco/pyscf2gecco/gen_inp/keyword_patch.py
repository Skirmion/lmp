# keyword_patch.py
"""
Keyword patcher for simple, flat blocks.

Expected line format (except the special 'orb_space' block):
    <indent><bare words separated by spaces><optional space><k1=v1,k2=v2,...>

Where:
- "bare words" are path tokens (e.g., "non_linear" or "solver cg") placed at
  the beginning of the line and separated by single spaces.
- Parameters are `key=value` pairs joined by commas **without spaces**.

Path matching
-------------
- If `path` contains only bare words (e.g., ["non_linear"]):
  we match only lines whose bare words are **exactly equal** (same order).
  A line like "solve non_linear ..." does **not** match.

- If `path` contains at least one `key=value`:
    • all bare words from `path` must be a subset of the line's bare words;
    • all `key=value` pairs from `path` must be present among the line's params.

Behavior
--------
- If the target line is found:
    • if the key already exists: replace its value;
    • otherwise: append the new `key=value` to existing params (comma, no
      spaces).
- If no target line matches:
    • create a new line with inherited indentation (or "  " by default),
      write all `path` bare words first (space-separated), then (if any)
      parameters (comma-separated, no spaces). The new param is included.
    • multiple patches with the same `path` within a block merge into a single
      line.

Sorting
-------
- After applying patches to a block (except 'orb_space'), the lines in that
  block are **sorted by path**, primarily using a **per-block path order**
  declared at the top of this file. If two paths share a prefix that appears
  in the order but an exact path is not listed, the longer path is placed
  **right after** its longest matching prefix anchor.
- If no prefix from the order matches, lines are sorted alphabetically by
  their bare-word path (case-insensitive), with lines that have no bare words
  placed last. Sorting is stable.

Configuration
-------------
- The dictionary `PATH_ORDER` below declares the **default path order** per
  block. It lives **in this file by default** (as requested) and is applied
  whenever we patch a block that has an entry here.
"""

from __future__ import annotations

import re
from typing import Dict, Iterable, List, Sequence, Tuple

# =============================================================================
# Default path order per block (bare-word paths only, space-joined).
# Extend this dict with your real anchors as needed.
# =============================================================================
PATH_ORDER: Dict[str, List[str]] = {
    "calculate": [
        "solve",
        "solve linear",
        "solve non_linear",
        "routes",
    ],
    "method": [
        "MR",
        "MRCC",
    ],
}

# Precompute tokenized anchors for faster matching
_ORDER_ANCHORS: Dict[str, List[List[str]]] = {
    blk: [anchor.split() for anchor in order_list] for blk, order_list in PATH_ORDER.items()
}

_BLOCK_HEADER_RX = re.compile(r"^([A-Za-z_][\w]*)\s*$")


# ------------------------- Parsing utilities ---------------------------------

def _leading_ws(s: str) -> str:
    """Return leading whitespace of a string."""
    m = re.match(r"^\s*", s)
    return m.group(0) if m else ""


def _split_prefix_params(body: str) -> Tuple[List[str], List[str]]:
    """
    Split a body into (bare_words, params).

    The left part (before the first comma) may contain bare words and accidental
    `k=v` tokens (those are moved to params). Everything after the first comma
    is treated as comma-separated `k=v` parameters. Empty fragments are ignored.
    """
    body = body.strip()
    if not body:
        return [], []

    parts = [p for p in body.split(",") if p != ""]
    if not parts:
        return [], []

    first = parts[0]
    rest = parts[1:]

    words: List[str] = []
    params: List[str] = []

    for tok in first.split():
        if "=" in tok:
            params.append(tok.strip())
        elif tok.strip():
            words.append(tok.strip())

    for frag in rest:
        frag = frag.strip()
        if frag:
            params.append(frag)

    return words, params


def _parse_line(raw: str) -> Tuple[str, List[str], List[Tuple[str, str]]]:
    """
    Parse a line into (indent, words, items).

    - indent: leading whitespace.
    - words : list of bare words (e.g., ['non_linear', 'solver']).
    - items : ordered list of (key, value) for params; bare tokens are ignored.
    """
    indent = _leading_ws(raw)
    body = raw[len(indent):].strip()
    words, params = _split_prefix_params(body)

    items: List[Tuple[str, str]] = []
    for p in params:
        if "=" in p:
            k, v = p.split("=", 1)
            k = k.strip()
            v = v.strip()
            if k:
                items.append((k, v))
    return indent, words, items


def _serialize_line(indent: str, words: List[str], items: List[Tuple[str, str]]) -> str:
    """
    Serialize a line as:
        <indent><words joined by space>[ <params joined by comma>]
    """
    left = " ".join(w for w in words if w)
    right = ",".join(f"{k}={v}" for k, v in items if k and v != "")
    if left and right:
        return f"{indent}{left} {right}"
    if left:
        return f"{indent}{left}"
    if right:
        return f"{indent}{right}"
    return indent.rstrip()


def _ensure_indent_for_newline(block_lines: List[str]) -> str:
    """Infer indentation for a newly appended line from the last non-empty line."""
    for ln in reversed(block_lines):
        if ln.strip():
            ws = _leading_ws(ln)
            return ws if ws else "  "
    return "  "


# ------------------------- Matching utilities --------------------------------

def _path_split(tokens: Iterable[str]) -> Tuple[List[str], List[Tuple[str, str]]]:
    """Split `path` tokens into (path_words, path_items)."""
    path_words: List[str] = []
    path_items: List[Tuple[str, str]] = []
    for t in tokens:
        t = str(t).strip()
        if not t:
            continue
        if "=" in t:
            k, v = t.split("=", 1)
            k, v = k.strip(), v.strip()
            if k:
                path_items.append((k, v))
        else:
            path_words.append(t)
    return path_words, path_items


def _line_matches(
    path_words: List[str],
    path_items: List[Tuple[str, str]],
    words_i: List[str],
    items_i: List[Tuple[str, str]],
) -> bool:
    """
    Return True if a line matches the `path`:

    - If `path` has only words: match only when `words_i == path_words`.
    - If `path` has at least one `k=v`: `path_words` ⊆ `words_i` and
      all `k=v` present in params.
    """
    if not path_items:
        return words_i == path_words

    if not set(path_words).issubset(words_i):
        return False

    items_dict = {k: v for k, v in items_i if k}
    for k, v in path_items:
        if items_dict.get(k) != v:
            return False
    return True


def _merge_or_set(items: List[Tuple[str, str]], key: str, val: str) -> List[Tuple[str, str]]:
    """Replace value for `key` if it exists; otherwise append `key=val`."""
    out: List[Tuple[str, str]] = []
    replaced = False
    for k, v in items:
        if k == key:
            out.append((k, val))
            replaced = True
        else:
            out.append((k, v))
    if not replaced:
        out.append((key, val))
    return out


# -------------------------- Ordering utilities -------------------------------

def _longest_prefix_anchor_index(block: str, words: List[str]) -> Tuple[int, bool, int]:
    """
    Return (anchor_idx, is_exact, prefix_len) for the longest anchor that is a
    prefix of `words` in PATH_ORDER[block]. If no anchor, returns
    (len(anchors), False, 0).
    """
    anchors = _ORDER_ANCHORS.get(block.lower(), [])
    best_idx = len(anchors)
    best_len = 0
    is_exact = False

    for idx, anchor in enumerate(anchors):
        if len(words) >= len(anchor) and words[:len(anchor)] == anchor:
            if len(anchor) > best_len:
                best_len = len(anchor)
                best_idx = idx
                is_exact = (len(words) == len(anchor))

    return best_idx, is_exact, best_len


def _sort_block_lines(block: str, lines: List[str]) -> List[str]:
    """
    Sort lines by configured path order with longest-prefix anchoring.

    Key:
      1) anchor_idx (smaller first; no match → after all anchors)
      2) exact anchor before its extensions
      3) remainder words (lexicographic, case-insensitive)
      4) lines with words before lines without words
      5) original index (stability)
    """
    decorated: List[Tuple[Tuple[int, int, str, int, int], str]] = []
    for idx, ln in enumerate(lines):
        _, words, _ = _parse_line(ln)
        anchor_idx, is_exact, prefix_len = _longest_prefix_anchor_index(block, words)
        remainder = words[prefix_len:]
        remainder_key = " ".join(remainder).lower()
        has_words = 0 if words else 1  # words first
        exact_flag = 0 if is_exact else 1
        decorated.append(((anchor_idx, exact_flag, remainder_key, has_words, idx), ln))
    decorated.sort(key=lambda x: x[0])
    return [ln for _, ln in decorated]


# ------------------------------ Core patching --------------------------------

def _patch_block(block: str, lines: Sequence[str], plist: List[Dict]) -> List[str]:
    """
    Patch a single block using the given patch list.
    """
    out = list(lines)
    # Remember index of the created/used line per canonical path to avoid duplicates.
    created_for_path: Dict[Tuple[Tuple[str, ...], Tuple[Tuple[str, str], ...]], int] = {}

    for patch in plist:
        param = str(patch.get("param", "")).strip()
        if "=" not in param:
            continue
        p_key, p_val = param.split("=", 1)
        p_key, p_val = p_key.strip(), p_val.strip()

        path_tokens = patch.get("path", [])
        path_words, path_items = _path_split(path_tokens)
        path_key = (tuple(path_words), tuple(path_items))

        target_idx = None
        # Find the last line that matches under _line_matches.
        for i, ln in enumerate(out):
            _, words_i, items_i = _parse_line(ln)
            if _line_matches(path_words, path_items, words_i, items_i):
                target_idx = i

        if target_idx is None and path_key in created_for_path:
            target_idx = created_for_path[path_key]

        if target_idx is None:
            indent_new = _ensure_indent_for_newline(out)
            words_new = list(path_words)
            items_new = list(path_items)
            items_new = _merge_or_set(items_new, p_key, p_val)
            new_line = _serialize_line(indent_new, words_new, items_new)
            out.append(new_line)
            target_idx = len(out) - 1
            created_for_path[path_key] = target_idx
            continue

        indent, words_i, items_i = _parse_line(out[target_idx])
        existing = {k: v for k, v in items_i if k}
        for k, v in path_items:
            if existing.get(k) != v:
                items_i = _merge_or_set(items_i, k, v)
                existing[k] = v

        items_i = _merge_or_set(items_i, p_key, p_val)
        out[target_idx] = _serialize_line(indent, words_i, items_i)
        created_for_path[path_key] = target_idx

    # Sort the block lines by configured path order.
    out = _sort_block_lines(block, out)
    return out


def apply_patches(lines: List[str], patches: List[Dict]) -> List[str]:
    """
    Apply all patches to the whole file (list of lines, no trailing '\\n').
    """
    grouped: Dict[str, List[Dict]] = {}
    for p in patches:
        grouped.setdefault(str(p.get("block", "")).lower(), []).append(p)

    res: List[str] = []
    buf: List[str] = []
    cur_block: str | None = None

    for ln in lines + ["###_EOF###"]:
        m = _BLOCK_HEADER_RX.match(ln)
        is_eof = ln == "###_EOF###"
        if m or is_eof:
            if cur_block and cur_block.lower() in grouped and cur_block.lower() != "orb_space":
                buf = _patch_block(cur_block, buf, grouped[cur_block.lower()])
            res.extend(buf)
            buf = []
            cur_block = None if is_eof else m.group(1)
            if not is_eof:
                res.append(ln)
            continue
        buf.append(ln)

    return res
