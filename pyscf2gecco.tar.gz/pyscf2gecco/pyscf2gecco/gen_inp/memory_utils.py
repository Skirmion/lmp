"""memory_utils.py

Utility to estimate total available system RAM in 8‑byte words.

Main API
--------
guess_mem_words(verbose=True) -> int
    Return the total amount of physical memory as a count of 8‑byte words.
    When *verbose* is True (default) a human‑readable summary is printed.

Example
-------
>>> from memory_utils import guess_mem_words
>>> words = guess_mem_words()
[RAM] memmax = 8589934592   (~ 64.0 GiB)
>>> f'{words:,}'
'8,589,934,592'
"""

from __future__ import annotations

import os
import re
from typing import Final

_BYTES_IN_WORD: Final[int] = 8


def _words_from_bytes(n_bytes: int) -> int:
    """Convert *n_bytes* to a number of 8‑byte words.

    Parameters
    ----------
    n_bytes
        Size in bytes.

    Returns
    -------
    int
        Size expressed in 8‑byte words.

    Examples
    --------
    >>> _words_from_bytes(16)
    2
    """
    return n_bytes // _BYTES_IN_WORD


def _print_summary(words: int, verbose: bool = True) -> None:
    """Optionally print a formatted memory summary.

    Parameters
    ----------
    words
        Memory size in 8‑byte words.
    verbose
        Enable/disable printing.

    Examples
    --------
    >>> _print_summary(1_000_000, verbose=True)
    [RAM] memmax = 1000000   (~ 0.0 GiB)
    """
    if not verbose:
        return

    gib = words * _BYTES_IN_WORD / 1024**3
    print(f"[RAM] memmax = {words}   (~ {gib:.1f} GiB)")


def guess_mem_words(verbose: bool = True) -> int:
    """Guess the amount of physical RAM in 8‑byte words.

    The function tries several platform‑specific backends in order of
    preference:

    1. **psutil** – fast and portable (if installed);
    2. **/proc/meminfo** – Linux filesystems;
    3. **os.sysconf** – POSIX `SC_PHYS_PAGES`/`SC_PAGE_SIZE`;
    4. a conservative **64 GiB** fallback.

    Parameters
    ----------
    verbose
        Print the detected size as a friendly message.

    Returns
    -------
    int
        Total RAM size in 8‑byte words.

    Examples
    --------
    >>> guess_mem_words()
    [RAM] memmax = 8589934592   (~ 64.0 GiB)
    8589934592
    """
    # 1) psutil
    try:
        import psutil  # type: ignore

        words = _words_from_bytes(psutil.virtual_memory().total)
        _print_summary(words, verbose)
        return words
    except Exception:
        pass  # pragma: no cover

    # 2) /proc/meminfo (Linux)
    try:
        with open("/proc/meminfo", encoding="utf-8") as handle:
            for line in handle:
                if line.startswith("MemTotal:"):
                    kilobytes = int(re.search(r"\d+", line).group())  # type: ignore
                    words = _words_from_bytes(kilobytes * 1024)
                    _print_summary(words, verbose)
                    return words
    except Exception:
        pass  # pragma: no cover

    # 3) POSIX sysconf
    try:
        pages = os.sysconf("SC_PHYS_PAGES")
        page_size = os.sysconf("SC_PAGE_SIZE")
        words = _words_from_bytes(pages * page_size)
        _print_summary(words, verbose)
        return words
    except Exception:
        pass  # pragma: no cover

    # 4) Conservative fallback: 64 GiB
    fallback_words = _words_from_bytes(64 * 1024**3)
    _print_summary(fallback_words, verbose)
    return fallback_words
