"""
GeCCo Input Generator module for creating GeCCo/IC-MRCC calculation input files.

This module provides a high-level builder for generating GeCCo quantum chemistry
input files from PySCF calculations, with automatic symmetry detection, orbital
space construction, and flexible keyword patching.

Main Class:
    GeccoInputBuilder: High-level builder for GeCCo input files
    
Utility Functions:
    molpro_irrep: Get Molpro irrep ID and label from PySCF wavefunction
    spin_info: Extract spin and multiplicity information
    make_orb_lines: Generate orb_space block lines
    guess_mem_words: Estimate available system RAM
    apply_patches: Apply keyword patches to input file
"""

from .gecco_input_writer import GeccoInputBuilder
from .sym import molpro_irrep, spin_info
from .shell_type import make_orb_lines
from .memory_utils import guess_mem_words
from .keyword_patch import apply_patches

__all__ = [
    "GeccoInputBuilder",
    "molpro_irrep",
    "spin_info",
    "make_orb_lines",
    "guess_mem_words",
    "apply_patches",
]
