import numpy as np
from math import sin, cos, radians
from pyscf import gto, scf, cc

if __name__ == '__main__':
    # --- Геометрия: r = 1.85 bohr, угол HOH = 104°
    r = 1.85
    theta = radians(104.0)
    x = r * sin(theta/2.0)
    z = r * cos(theta/2.0)

    atoms = [
        ['O', ( 0.0, 0.0, 0.0)],
        ['H', ( x,   0.0, z  )],
        ['H', (-x,   0.0, z  )],
    ]

    mol = gto.M(
        atom=atoms,
        unit='B',
        basis = {
        'O': gto.basis.load('cc-pVDZ', 'O'),
        'H': gto.basis.load('cc-pVDZ', 'H')
        },
        symmetry=True,
        symmetry_subgroup='C2v',   # Molpro обычно C2v для H2O
        spin=0,                    # закрытая оболочка
        charge=0,
        cart=False,                # сферические гармоники (Molpro: spherical)
        max_memory=150,            # Molpro: memory,150,m  (МБ)
        verbose=3,
    )

    # --- SCF (закрытая оболочка HF)
    mf = scf.RHF(mol)
    mf.conv_tol = 1e-15
    mf.kernel()

    # # --- CCSD без заморозки коры (Molpro: {ccsd; core,0,0,0,0; thresh,energy=1e-12;})
    mycas = mf.CASSCF(ncas=3, nelecas=6, ncore = 2)
    mycas.conv_tol = 1e-20
    mycas.conv_tol_grad = 1e-20
    mycas.max_cycle_macro = 200
    #mycas.natorb = True
    mycas.kernel()

    from gecco_input_writer import GeccoInputBuilder

    patches = [
        {"block": "general",    "path": [],                   "param": "print=8"},
        {"block": "calculate",  "path": ["solve", "non_linear"],  "param": "maxiter=100"},
        {"block": "calculate",  "path": ["solve","linear"],  "param": "kRYa=100"}
    ]

    builder = GeccoInputBuilder(
        # template & output
        name="icMRCC",            # expects templates/icmrcc_template.inp
        templates_dir="templates",
        outfile="H2O_full.inp",

        # general
        mem_gib=32,                        # авто-конверсия в memmax (8-byte words)
        printlvl=4,

        # calculate / solve
        calc_solve_maxiter=200,
        calc_solve_conv=1e-8,              # авто → Fortran-D: 1d-8

        # calculate / routes
        calc_routes_sv_thresh=1e-12,       # авто → 1d-12

        # calculate / solve non_linear
        calc_solve_non_linear_optref=-1,

        # method / MR
        method_MR_maxexc=5,
        method_MR_minexc=1,
        method_MR_ciroot=2,

        # method / MRCC
        method_MRCC_maxcom_res=10,
        method_MRCC_maxcom_en=5,

        # extra patches (опционально)
        patches=patches,

        # orb_space controls
        mol=mol,
        wf=mycas,                          # можно поставить mf, если без CASSCF
        #group="cs",                       # 'c2v'|'d2h'|'cs'|'c1' ; при выключенной симметрии → 'c1'
        core_idx=None,                     # явные индексы core МО (если хочешь переопределить)
        active_idx=None,                   # явные индексы активных МО; если None и нет CASSCF → active=0
        frozen_idx=[],                     # индексы МО для заморозки (пересчитываются по иррепам)
        deleted_idx=[],                    # индексы МО для удаления (аналогично)
        debug_orb=False,                   # печать четырёх строк orb_space в stdout

        # logging
        verbose=True,
    )

    # --- 4) Write final input (полный конвейер внутри) ---
    builder.write()