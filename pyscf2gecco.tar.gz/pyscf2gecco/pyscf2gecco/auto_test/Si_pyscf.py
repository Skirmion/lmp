import numpy as np
from pyscf import gto, scf, mcscf, ao2mo, tools, symm

if __name__ == '__main__':
    mol = gto.M(
        atom='''
        Si  0.0  0.0  0.0
        ''',
        basis="ccpvtz",
        symmetry="D2h",
        unit='A',
        spin=2   # two unpaired electrons
    )

    mf = mol.ROHF(verbose=4)
    mf.max_cycle = 100
    mf.conv_tol = 1e-20
    mf.direct_scf_tol = 1e-20
    #mol.incore_anyway = False
    mf.kernel()

    mycas = mcscf.CASSCF(mf, 4, 4, ncore = 5)
    mycas.get_hcore = mf.get_hcore
    mycas.conv_tol = 1e-20  # Устанавливает порог сходимости энергии (точность)
    mycas.conv_tol_grad = 1e-20  # Устанавливает порог сходимости градиента
    mycas.max_cycle_macro = 100  # Устанавливает максимальное количество макроциклов SCF
    mycas.wfnsym= 'B1g'
    #mycas.state_average_([0, 0, 1])
    mycas.kernel()
    
    import pyscf2gecco_new

    ctrl = pyscf2gecco_new.FCIDumpController(
                                mol, mycas,
                                granularity=1,
                                frozen_indices=[],
                                tol=1e-15
                            )
    ctrl.run('FCIDUMP')
    

# from pathlib import Path
# from fcidump_tester import TestConfig, run_test, summarize

# # Сравнение с эталонным числом
# cfg_val = TestConfig(
#     test_fcidump_path=Path("/calc/FCIDUMP.anyname"),
#     inp_path=Path("/calc/gecco.inp"),
#     ref_energy_path=Path("/calc/ref_value.txt"),  # если не указать — /calc/ref_energy.txt
#     tolerance=1e-10,
# )
# r1 = run_test(cfg_val)

# Сравнение двух расчётов
# cfg_ref = TestConfig(
#     test_fcidump_path=Path("./FCIDUMPnew"),
#     ref_fcidump_path=Path("./FCIDUMP"),
#     inp_path=Path("./test_inp/H2.inp"),
#     tolerance=1e-15,
# )
# r2 = run_test(cfg_ref)

# code, summary = summarize([r2])
# print(summary)
