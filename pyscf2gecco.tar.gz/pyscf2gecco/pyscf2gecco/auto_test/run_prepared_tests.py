"""
Batch Test Runner for Pre-configured GeCCo Test Suites.

This module provides infrastructure for running comprehensive GeCCo test suites
with automatic test discovery, parallel execution, and formatted result reporting.
It integrates with fcidump_tester to execute individual tests and aggregates
results into human-readable tables with pass/fail statistics.

Test Suite Organization
-----------------------
The runner expects a specific directory structure:

    project_root/
    ├── gecco_inputs/          # GeCCo .inp files and reference energies
    │   ├── H2O_sto-3g_C2v_ccsd.inp
    │   ├── N2_cc-pvdz_D2h_ccsd.inp
    │   └── RESULTS            # Reference energy table
    ├── pyscf_inputs/          # PySCF scripts that generate FCIDUMPs
    │   ├── H2O_sto-3g_C2v_ccsd.py
    │   └── N2_cc-pvdz_D2h_ccsd.py
    └── run_test.py            # Test execution script

Naming Convention
-----------------
Test files must follow strict pairing by stem (filename without extension):
- GeCCo input: `gecco_inputs/<stem>.inp`
- PySCF script: `pyscf_inputs/<stem>.py`
- Both must have **identical stems** for pairing

Recommended stem format: `{molecule}_{basis}_{symmetry}_{method}`
Examples:
    - H2O_sto-3g_C2v_ccsd
    - N2_cc-pvdz_D2h_ccsd
    - NH3_cc-pvtz_C3v_fci

Reference Energy Table
----------------------
The RESULTS file maps test stems to reference energies:

    # Reference energies for test suite
    H2O_sto-3g_C2v_ccsd  -75.0129802245
    N2_cc-pvdz_D2h_ccsd  -109.2773486562
    # Comments and blank lines allowed

Format rules:
- One entry per line: `<stem> <energy>`
- Comments start with #
- Commas and semicolons treated as whitespace
- Blank lines ignored
- Non-numeric energies cause ValueError

PySCF Script Requirements
--------------------------
Each PySCF script must:
1. Accept execution as: `python3 <stem>.py`
2. Generate FCIDUMP in current working directory (./FCIDUMP)
3. Complete successfully (exit code 0)
4. Be self-contained (no external dependencies beyond pyscf and pyscf2gecco)

Example PySCF script structure:

    from pyscf import gto, scf, cc
    from pyscf2gecco import FCIDumpWriter
    
    mol = gto.M(atom='H 0 0 0; H 0 0 0.74', basis='sto-3g')
    mf = scf.RHF(mol).run()
    mycc = cc.CCSD(mf).run()
    
    writer = FCIDumpWriter(mol, mycc, granularity=50)
    writer.run('FCIDUMP')

GeCCo Output Parsing
--------------------
Energy is extracted from gecco.out using pattern:
    >>> final energy: <value>

The reference energy is read from RESULTS file and compared with tolerance.

Parallel Execution Strategy
----------------------------
Two-phase execution to avoid resource oversubscription:
1. **Serial Phase**: FCIDUMP generation for all tests (PySCF is already parallel)
2. **Parallel Phase**: GeCCo calculations in parallel worker pool

This prevents N × M threads (N tests × M PySCF threads) which would
thrash on most systems.

Output Format
-------------
Results are presented in a compact ASCII table:

    Results:
    PASS=15  FAIL=2  ERROR=1  TOTAL=18
    +----------+---------+-----------+-------+
    | Молекула | Базис   | Симметрия | Δ     |
    +----------+---------+-----------+-------+
    | H2O      | sto-3g  | C2v       | 2e-9  |
    | N2       | cc-pvdz | D2h       | 5e-8  |
    | NH3      | cc-pvtz | C3v       | error |
    +----------+---------+-----------+-------+

Δ column shows:
- Scientific notation for energy difference (PASS/FAIL)
- "error" for tests that could not complete
- "pyscf error" if FCIDUMP generation failed
- "gecco error" if GeCCo execution failed
- "runner error" for infrastructure failures

Error Handling
--------------
Detailed error information is saved to `./test_pyscf2gecco_errors`:
- Full stdout/stderr from failed PySCF scripts
- GeCCo error messages and diagnostics
- Exception tracebacks from runner
- Organized by test name and error origin

Classes
-------
RunnerConfig
    Configuration dataclass for batch runner, specifying directories,
    executables, tolerances, parallelism, and behavioral flags.

Functions
---------
run_all_tests(cfg: Optional[RunnerConfig] = None) -> Tuple[List[TestResult], str]
    Execute complete test suite with automatic discovery and parallel execution.
    If cfg is None, uses default RunnerConfig().

Private Functions
-----------------
_ensure_gecco_available : Validate gecco.x availability
_ensure_pyscf2gecco_available : Validate pyscf2gecco module
_parse_ref_table : Load reference energies from RESULTS file
_parse_stem : Extract molecule/basis/symmetry from test stem
_discover_tests : Find and pair all valid tests
_run_generator : Execute PySCF script to generate FCIDUMP
_print_table : Format and display ASCII result table

Examples
--------
Basic test suite execution with defaults:

    >>> from pyscf2gecco.auto_test import run_all_tests
    >>> 
    >>> # Run with all defaults (gecco_inputs, pyscf_inputs, etc.)
    >>> results, summary = run_all_tests()
    >>> print(summary)
    PASS=15  FAIL=0  ERROR=0  TOTAL=15

Basic test suite execution with custom config:

    >>> from pyscf2gecco.auto_test import RunnerConfig, run_all_tests
    >>> 
    >>> cfg = RunnerConfig(
    ...     gecco_inputs=Path("gecco_inputs"),
    ...     pyscf_inputs=Path("pyscf_inputs"),
    ...     tolerance=1e-8,
    ...     max_workers=8,
    ...     verbose=True
    ... )
    >>> results, summary = run_all_tests(cfg)
    >>> print(summary)
    PASS=15  FAIL=0  ERROR=0  TOTAL=15

Custom executables and paths:

    >>> cfg = RunnerConfig(
    ...     gecco_inputs=Path("tests/inputs"),
    ...     pyscf_inputs=Path("tests/pyscf"),
    ...     gecco_bin_path=Path("/opt/gecco/bin/gecco.x"),
    ...     pyscf2gecco_path=Path("../../pyscf2gecco/__init__.py"),
    ...     max_workers=4,
    ...     runner_mode="disk",  # Use disk mode for all tests
    ...     keep_workdirs=True   # Preserve for inspection
    ... )
    >>> results, summary = run_all_tests(cfg)

High-throughput configuration:

    >>> cfg = RunnerConfig(
    ...     gecco_inputs=Path("production_tests"),
    ...     pyscf_inputs=Path("production_pyscf"),
    ...     tolerance=1e-10,
    ...     max_workers=32,
    ...     verbose=False,  # Minimize output
    ...     runner_mode="ram",
    ...     grace=300.0  # Cleanup RAM after 5 minutes
    ... )
    >>> results, summary = run_all_tests(cfg)

Selective test execution:

    >>> # Only tests matching certain criteria
    >>> cfg = RunnerConfig(
    ...     gecco_inputs=Path("gecco_inputs"),
    ...     pyscf_inputs=Path("pyscf_inputs")
    ... )
    >>> results, summary = run_all_tests(cfg)
    >>> 
    >>> # Filter results
    >>> h2o_results = [r for r in results if "H2O" in r.name]
    >>> failed_results = [r for r in results if r.status == "FAIL"]

Notes
-----
- Test discovery requires exact stem matching between .inp and .py files
- Missing reference energies cause tests to be skipped silently
- PySCF scripts run with PYTHONPATH set to include pyscf2gecco if needed
- Working directories created with prefix `.suite_work_<stem>_`
- All temporary files cleaned unless keep_workdirs=True
- Error log appended to (not overwritten) for batch runs
- Results table sorted by molecule/basis/symmetry for readability

Performance Recommendations
---------------------------
- max_workers: Set to number of physical cores for best throughput
- runner_mode='ram': Faster but requires RAM for largest FCIDUMP
- grace period: Enables memory reclamation during long calculations
- verbose=False: Reduces output overhead for large test suites

System Requirements
-------------------
- Linux with /proc filesystem (for grace period monitoring)
- Sufficient RAM for mode='ram' (largest FCIDUMP × max_workers)
- gecco.x executable in PATH or specified via gecco_bin_path
- pyscf2gecco module installed or path provided via pyscf2gecco_path

See Also
--------
fcidump_tester : Underlying single-test runner
RunnerConfig : Configuration dataclass
TestResult : Individual test result structure
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import concurrent.futures as cf
import os
import shutil
import subprocess
import tempfile

from .fcidump_tester import TestConfig, TestResult, run_test


@dataclass
class RunnerConfig:
    """
    Configuration for batch test suite execution.

    This dataclass encapsulates all settings for running a complete test suite,
    including directory paths, executable locations, execution parameters,
    comparison criteria, and behavioral flags.

    Parameters
    ----------
    gecco_inputs : Path, optional
        Directory containing GeCCo .inp files and RESULTS reference table.
        All .inp files in this directory are potential tests (if paired).
        Default: None (uses module_dir/gecco_inputs where module_dir is the
        directory containing this module)
    pyscf_inputs : Path, optional
        Directory containing PySCF scripts that generate FCIDUMPs.
        Each script must match a .inp file by stem for test pairing.
        Default: None (uses module_dir/pyscf_inputs where module_dir is the
        directory containing this module)
    gecco_bin_path : Path, optional
        Path to gecco.x executable. If None, searches in system PATH.
        Raises error if gecco.x not found or not executable.
        Default: None
    pyscf2gecco_path : Path, optional
        Path to pyscf2gecco module (typically __init__.py). If None,
        assumes module is installed and importable. If provided, adds
        parent directory to PYTHONPATH for PySCF script execution.
        Default: None
    tolerance : float, optional
        Maximum absolute energy difference for PASS status. Test passes
        if |E_test - E_ref| <= tolerance, otherwise FAIL.
        Default: 1e-8
    keep_workdirs : bool, optional
        Preserve working directories after test completion. When False,
        all temporary directories are removed automatically. Useful for
        debugging when True.
        Default: False
    ref_table_name : str, optional
        Filename of reference energy table in gecco_inputs directory.
        File format: "<stem> <energy>" per line, comments with #.
        Default: "RESULTS"
    verbose : bool, optional
        Enable detailed per-test progress logging. When True, prints
        test discovery, FCIDUMP generation, GeCCo execution, and cleanup
        messages. When False, only summary table is shown.
        Default: True
    max_workers : int, optional
        Maximum number of parallel GeCCo workers for phase 2. If None,
        defaults to os.cpu_count(). Set to 1 for fully serial execution.
        FCIDUMP generation (phase 1) is always serial to avoid thread
        oversubscription in PySCF.
        Default: None
    runner_mode : str, optional
        FCIDUMPRunner execution mode for all tests: 'ram' or 'disk'.
        - 'ram': Use RAM-backed FCIDUMP (faster, requires memory)
        - 'disk': Use disk-based FCIDUMP (slower, lower memory)
        Default: "ram"
    grace : float, optional
        Grace period in seconds for RAM cleanup monitoring. Only effective
        when runner_mode='ram'. If set, FCIDUMPs are deleted from RAM as
        soon as they've been closed for this duration. Useful for long
        calculations with early FCIDUMP access.
        Default: None (no monitoring)

    Attributes
    ----------
    All parameters are exposed as attributes with the same names.

    Examples
    --------
    Minimal configuration (uses defaults):

        >>> from pyscf2gecco.auto_test import RunnerConfig
        >>> cfg = RunnerConfig()

    Custom directories and executables:

        >>> cfg = RunnerConfig(
        ...     gecco_inputs=Path("my_tests/gecco"),
        ...     pyscf_inputs=Path("my_tests/pyscf"),
        ...     gecco_bin_path=Path("/opt/gecco/bin/gecco.x"),
        ...     pyscf2gecco_path=Path("../pyscf2gecco/__init__.py")
        ... )

    High-performance configuration:

        >>> cfg = RunnerConfig(
        ...     max_workers=16,
        ...     runner_mode="ram",
        ...     grace=300.0,  # 5-minute grace
        ...     tolerance=1e-10,
        ...     verbose=False  # Minimal output
        ... )

    Debugging configuration:

        >>> cfg = RunnerConfig(
        ...     max_workers=1,  # Serial execution
        ...     keep_workdirs=True,  # Preserve files
        ...     runner_mode="disk",  # Easier inspection
        ...     verbose=True  # Detailed logs
        ... )

    Production test suite:

        >>> cfg = RunnerConfig(
        ...     gecco_inputs=Path("production/gecco_inputs"),
        ...     pyscf_inputs=Path("production/pyscf_inputs"),
        ...     ref_table_name="PRODUCTION_REFERENCES",
        ...     tolerance=1e-9,
        ...     max_workers=32,
        ...     runner_mode="ram",
        ...     grace=600.0,
        ...     keep_workdirs=False,
        ...     verbose=False
        ... )

    Notes
    -----
    - gecco_inputs and pyscf_inputs must exist and be readable
    - RESULTS file must exist in gecco_inputs directory
    - max_workers=None defaults to os.cpu_count() at runtime
    - grace monitoring requires Linux /proc filesystem
    - Phase 1 (FCIDUMP generation) is always serial regardless of max_workers
    - Phase 2 (GeCCo execution) parallelism controlled by max_workers

    See Also
    --------
    run_all_tests : Function that uses this configuration
    TestConfig : Per-test configuration (created automatically)
    """

    gecco_inputs: Optional[Path] = None
    pyscf_inputs: Optional[Path] = None
    gecco_bin_path: Optional[Path] = None
    pyscf2gecco_path: Optional[Path] = None
    tolerance: float = 1e-8
    keep_workdirs: bool = False
    ref_table_name: str = "RESULTS"
    verbose: bool = True
    max_workers: Optional[int] = None  # None -> os.cpu_count()
    runner_mode: str = "ram"  # 'ram' or 'disk' for FCIDUMPRunner
    grace: Optional[float] = None  # Grace period for RAM monitoring


# ---------------------------------------------------------------------------
# Preconditions
# ---------------------------------------------------------------------------

def _ensure_gecco_available(gecco_bin_path: Optional[Path]) -> Optional[Path]:
    if gecco_bin_path:
        exe = Path(gecco_bin_path).expanduser().resolve()
        if not exe.exists():
            raise RuntimeError(f"gecco.x not found at '{exe}'.")
        if not os.access(exe, os.X_OK):
            raise RuntimeError(f"gecco.x at '{exe}' is not executable.")
        return exe

    from shutil import which

    if which("gecco.x") is None:
        raise RuntimeError("'gecco.x' not found in PATH. Provide gecco_bin_path or add it to PATH.")
    return None


def _ensure_pyscf2gecco_available(pyscf2gecco_path: Optional[Path]) -> Optional[Path]:
    if pyscf2gecco_path:
        p = Path(pyscf2gecco_path).expanduser().resolve()
        if not p.exists():
            raise RuntimeError(f"pyscf2gecco path not found at '{p}'. Provide a valid path or install the module.")
        return p.parent

    try:
        import importlib.util
        if importlib.util.find_spec("pyscf2gecco") is None:
            raise ImportError
    except Exception as exc:  # noqa: BLE001
        raise RuntimeError("Python module 'pyscf2gecco' is not importable. Install it or pass pyscf2gecco_path.") from exc
    return None


# ---------------------------------------------------------------------------
# IO helpers
# ---------------------------------------------------------------------------

def _parse_ref_table(path: Path) -> Dict[str, float]:
    if not path.exists():
        raise FileNotFoundError(f"Reference table not found: {path}")
    out: Dict[str, float] = {}
    text = path.read_text(encoding="utf-8", errors="ignore")
    for i, line in enumerate(text.splitlines(), 1):
        s = line.strip()
        if not s or s.startswith("#"):
            continue
        s = s.replace(",", " ").replace(";", " ")
        parts = s.split()
        if len(parts) < 2:
            continue
        stem, val = parts[0], parts[1]
        try:
            out[stem] = float(val)
        except Exception as exc:  # noqa: BLE001
            raise ValueError(f"Non-numeric energy in {path} at line {i}: {line!r}") from exc
    return out


def _parse_stem(stem: str) -> Tuple[str, str, str]:
    parts = stem.split("_")
    if len(parts) >= 3:
        return parts[0], parts[1], parts[2]
    if len(parts) == 2:
        return parts[0], parts[1], ""
    if len(parts) == 1:
        return parts[0], "", ""
    return "", "", ""


def _discover_tests(
    gecco_dir: Path, pyscf_dir: Path, ref_map: Dict[str, float]
) -> List[Tuple[str, Path, Path, float]]:
    gecco_dir = gecco_dir.resolve()
    pyscf_dir = pyscf_dir.resolve()

    tests: List[Tuple[str, Path, Path, float]] = []
    for g_inp in gecco_dir.glob("*.inp"):
        stem = g_inp.stem
        if stem not in ref_map:
            continue
        py = pyscf_dir / f"{stem}.py"  # strict exact-stem match
        if not py.exists():
            continue
        tests.append((stem, g_inp.resolve(), py.resolve(), ref_map[stem]))

    tests.sort(key=lambda t: _parse_stem(t[0]))
    return tests


def _run_generator(pyscf_input: Path, workdir: Path, extra_py_path: Optional[Path]) -> Tuple[str, str]:
    cmd = ["python3", str(pyscf_input)]
    env = os.environ.copy()
    if extra_py_path is not None:
        current = env.get("PYTHONPATH", "")
        env["PYTHONPATH"] = str(extra_py_path) + (os.pathsep + current if current else "")
    proc = subprocess.run(cmd, cwd=str(workdir), env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    return proc.stdout, proc.stderr


# ---------------------------------------------------------------------------
# Runner
# ---------------------------------------------------------------------------

def _print_table(rows: List[List[str]]) -> None:
    widths = [len(col) for col in rows[0]]
    for row in rows[1:]:
        for i, val in enumerate(row):
            widths[i] = max(widths[i], len(val))

    def hline(char: str = "-") -> str:
        return "+" + "+".join(char * (w + 2) for w in widths) + "+"

    def fmt(row: List[str]) -> str:
        return "|" + "|".join(" " + val.ljust(w) + " " for val, w in zip(row, widths)) + "|"

    print(hline())
    print(fmt(rows[0]))
    print(hline())
    for row in rows[1:]:
        print(fmt(row))
    print(hline())


def run_all_tests(cfg: Optional[RunnerConfig] = None) -> Tuple[List[TestResult], str]:
    if cfg is None:
        cfg = RunnerConfig()
    
    # Set default paths relative to this module if not specified
    module_dir = Path(__file__).resolve().parent
    if cfg.gecco_inputs is None:
        cfg.gecco_inputs = module_dir / "gecco_inputs"
    if cfg.pyscf_inputs is None:
        cfg.pyscf_inputs = module_dir / "pyscf_inputs"
    
    gecco_bin_resolved = _ensure_gecco_available(cfg.gecco_bin_path)
    extra_py_path = _ensure_pyscf2gecco_available(cfg.pyscf2gecco_path)

    ref_table_path = cfg.gecco_inputs / cfg.ref_table_name
    ref_map = _parse_ref_table(ref_table_path)

    items = _discover_tests(cfg.gecco_inputs, cfg.pyscf_inputs, ref_map)

    results: List[TestResult] = []
    table_rows: List[List[object]] = []
    error_log_path = Path.cwd() / "test_pyscf2gecco_errors"

    def fmt_delta(x: object) -> str:
        if isinstance(x, (int, float)):
            s = f"{float(x):.0e}"
            return s.replace("e-0", "e-").replace("e+0", "e+")
        return str(x)

    def log_error(stem: str, origin: str, detail: str) -> None:
        with error_log_path.open("a", encoding="utf-8") as f:
            f.write("=" * 80 + "\n")
            f.write(f"TEST: {stem}\nORIGIN: {origin}\n\n{detail}\n\n")

    def generate_once(stem: str, g_inp: Path, p_inp: Path, ref_val: float):
        if cfg.verbose:
            print(f"[{stem}] matched PySCF: {p_inp.name}")
            print(f"[{stem}] preparing workdir...")
        workdir = Path(tempfile.mkdtemp(prefix=f".suite_work_{stem}_", dir=os.getcwd()))
        try:
            # GeCCo input
            dst_inp = workdir / "gecco.inp"
            shutil.copy2(g_inp, dst_inp)
            if cfg.verbose:
                print(f"[{stem}] copied gecco.inp")

            # Reference file for VALUE mode
            (workdir / "ref_energy.txt").write_text(f"{ref_val:.15f}\n", encoding="utf-8")
            if cfg.verbose:
                print(f"[{stem}] reference set to {ref_val:.15f}")

            # Generate FCIDUMP
            if cfg.verbose:
                print(f"[{stem}] generating FCIDUMP with python3 {p_inp.name} ...")
            out, err = _run_generator(p_inp, workdir, extra_py_path)
            fc = workdir / "FCIDUMP"
            if not fc.exists():
                detail = f"STDOUT:\n{out}\n\nSTDERR:\n{err}"
                log_error(stem, "pyscf", detail)
                if cfg.verbose:
                    print(f"[{stem}] ERROR (pyscf): see {error_log_path}")
                results.append(TestResult(stem, "ERROR", "pyscf: FCIDUMP not produced"))
                mol, basis, sym = _parse_stem(stem)
                table_rows.append([mol, basis, sym, "pyscf error"])
                # cleanup
                if not cfg.keep_workdirs and workdir.exists():
                    shutil.rmtree(workdir, ignore_errors=True)
                    if cfg.verbose:
                        print(f"[{stem}] cleaned workdir")
                return None  # signal error
            if cfg.verbose:
                print(f"[{stem}] FCIDUMP generated")
            return workdir, dst_inp, fc
        except Exception as exc:  # noqa: BLE001
            log_error(stem, "runner(generation)", f"DETAIL:\n{type(exc).__name__}: {exc}")
            if cfg.verbose:
                print(f"[{stem}] ERROR (runner): see {error_log_path}")
            results.append(TestResult(stem, "ERROR", f"runner: {type(exc).__name__}: {exc}"))
            mol, basis, sym = _parse_stem(stem)
            table_rows.append([mol, basis, sym, "runner error"])
            if not cfg.keep_workdirs and workdir.exists():
                shutil.rmtree(workdir, ignore_errors=True)
                if cfg.verbose:
                    print(f"[{stem}] cleaned workdir")
            return None

    def gecco_worker(stem: str, workdir: Path, dst_inp: Path, fc: Path):
        # buffer logs to avoid interleaving
        logs = []
        if cfg.verbose:
            logs.append(f"[{stem}] running gecco.x ...")
        tc = TestConfig(
            gecco_bin_path=gecco_bin_resolved,
            test_fcidump_path=fc,
            inp_path=dst_inp,
            ref_energy_path=workdir / "ref_energy.txt",
            parse_file="gecco.out",
            tolerance=cfg.tolerance,
            keep_workdirs=cfg.keep_workdirs,
            test_name=stem,
            runner_mode=cfg.runner_mode,
            grace=cfg.grace,
        )
        tr = run_test(tc)
        mol, basis, sym = _parse_stem(stem)
        if tr.status in ("PASS", "FAIL"):
            if cfg.verbose:
                logs.append(f"[{stem}] gecco done: E_test={tr.test_energy:.15f} |Δ|={tr.diff:.3g} → {tr.status}")
            row = [mol, basis, sym, tr.diff if tr.diff is not None else ""]
        else:
            log_error(stem, "gecco", f"DETAIL:\n{tr.detail}")
            if cfg.verbose:
                logs.append(f"[{stem}] ERROR (gecco): see {error_log_path}")
            row = [mol, basis, sym, "gecco error"]
        # Clean outer workdir after gecco if requested
        if not cfg.keep_workdirs and Path(workdir).exists():
            shutil.rmtree(workdir, ignore_errors=True)
            if cfg.verbose:
                logs.append(f"[{stem}] cleaned workdir")
        # return logs as a single block
        log_text = ("\n".join(logs) + "\n") if logs else ""
        return tr, row, log_text

    workers = cfg.max_workers or os.cpu_count() or 1
    workers = max(1, int(workers))

    if workers == 1:
        # Fully sequential: generate -> gecco -> cleanup for each test
        for stem, g_inp, p_inp, ref_val in items:
            gen = generate_once(stem, g_inp, p_inp, ref_val)
            if gen is None:
                continue
            workdir, dst_inp, fc = gen
            tr, row, log_text = gecco_worker(stem, workdir, dst_inp, fc)
            results.append(tr)
            table_rows.append(row)
            if cfg.verbose and log_text:
                print(log_text, end="")
    else:
        # Two-pass: serial generation, then parallel gecco runs; print logs per-test upon completion
        prepared = []
        for stem, g_inp, p_inp, ref_val in items:
            gen = generate_once(stem, g_inp, p_inp, ref_val)
            if gen is None:
                continue
            prepared.append((stem, *gen))

        with cf.ThreadPoolExecutor(max_workers=workers) as ex:
            future_map = {ex.submit(gecco_worker, stem, wd, inp, fc): stem for (stem, wd, inp, fc) in prepared}
            for fut in cf.as_completed(future_map):
                tr, row, log_text = fut.result()
                results.append(tr)
                table_rows.append(row)
                if cfg.verbose and log_text:
                    print(log_text, end="")

    # -------- Render compact output --------
    n_pass = sum(1 for r in results if r.status == "PASS")
    n_fail = sum(1 for r in results if r.status == "FAIL")
    n_err = sum(1 for r in results if r.status == "ERROR")
    total = len(results)
    metrics_line = f"PASS={n_pass}  FAIL={n_fail}  ERROR={n_err}  TOTAL={total}"

    header = ["Молекула", "Базис", "Симметрия", "Δ"]
    # Ensure rows are sorted even after parallel execution
    table_rows = sorted(table_rows, key=lambda r: (str(r[0]), str(r[1]), str(r[2])))
    table = [header] + [[str(m), str(b), str(s), fmt_delta(d)] for m, b, s, d in table_rows]

    print("Results:")
    print(metrics_line)
    _print_table(table)

    if n_err > 0:
        print(f"Error details are saved to: {error_log_path}")

    return results, metrics_line


__all__ = ["RunnerConfig", "run_all_tests"]
