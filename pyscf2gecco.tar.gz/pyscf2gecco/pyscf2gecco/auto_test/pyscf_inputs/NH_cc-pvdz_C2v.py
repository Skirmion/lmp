import numpy as np
from pyscf import gto, scf, mcscf, ao2mo, tools, symm

if __name__ == '__main__':
    mol = gto.M(atom=f'N 0 0 -0.132247047; H 0 0 1.837752953', unit = "B")
    mol.build(
        basis="ccpvdz",
        charge = 0,
        symmetry = True,
        symmetry_subgroup = "C2v",
        cart=False,
        spin=2
    )
 
    mf = mol.ROHF(verbose=4)
    mf.max_cycle = 100
    mf.conv_tol = 1e-20
    mf.direct_scf_tol = 1e-20
    mf.kernel()

    mycas = mf.CASSCF(4, 4) # Число активных орбиталей # Число электронов в активном пространстве (8 всего - 2 в остовной = 6)
    #mycas.frozen = [0]
    mycas.ncore = 2
    mo = mcscf.sort_mo_by_irrep(mycas, mf.mo_coeff, cas_irrep_nocc = {"A1":2, "A2":0, "B1":1, "B2":1}, cas_irrep_ncore = {"A1":2, "A2":0, "B1":0, "B2":0})
    mycas.conv_tol = 1e-20
    mycas.conv_tol_grad = 1e-20
    mycas.max_cycle_macro = 100
    mycas.wfnsym= 'A2'
    mycas.kernel(mo)


    import pyscf2gecco_new

    ctrl = pyscf2gecco_new.FCIDumpController(
                                mol, mycas,
                                granularity=1,
                                frozen_indices=[0],
                                tol=0
                            )
    ctrl.run('FCIDUMP')
