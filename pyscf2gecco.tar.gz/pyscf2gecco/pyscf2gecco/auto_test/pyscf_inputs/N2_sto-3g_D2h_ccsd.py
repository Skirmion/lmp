import numpy as np
from pyscf import gto,mcscf



basis_txt_nwchem = """
N  S
   99.10616896    0.1543289673
   18.05231239    0.5353281423
    4.885660238   0.4446345422
N  S
    3.780455879  -0.09996722919
    0.8784966449  0.3995128261
    0.2857143744  0.7001154689
N  P
    3.780455879   0.1559162750
    0.8784966449  0.6076837186
    0.2857143744  0.3919573931
"""

mol = gto.M(
    atom='N 0 0 0; N 0 0 2.118',
    unit='B',
    basis={'N': gto.basis.parse(basis_txt_nwchem, optimize=False)},  # ВАЖНО: parse (не parse_gaussian)
    #basis="sto-3g",
    charge=0,
    spin=0,
    symmetry=True,
    symmetry_subgroup='D2h',
    cart=False,  # сферические гармоники
    verbose=4,
)


mf = mol.ROHF(verbose=4)
mf.max_cycle = 100
mf.conv_tol = 1e-15
mf.direct_scf_tol = 1e-15
mf.kernel()

mycas = mf.CASSCF(ncas=1, nelecas=0)
mycas.ncore = 7
mycas.conv_tol = 1e-15
mycas.conv_tol_grad = 1e-15
mycas.max_cycle_macro = 100
mycas.kernel()

import pyscf2gecco_new

ctrl = pyscf2gecco_new.FCIDumpController(
                            mol, mycas,
                            granularity=1,
                            frozen_indices=[],
                            tol=1e-15
                        )
ctrl.run('FCIDUMP')
