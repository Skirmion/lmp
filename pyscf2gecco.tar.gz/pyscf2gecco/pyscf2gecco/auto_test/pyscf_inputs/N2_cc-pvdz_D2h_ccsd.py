import numpy as np
from pyscf import gto,mcscf


mol = gto.M(
    atom='N 0 0 0; N 0 0 2.118',
    unit='B',
    basis="ccpvdz",  # ВАЖНО: parse (не parse_gaussian)
    #basis="sto-3g",
    charge=0,
    spin=0,
    symmetry=True,
    symmetry_subgroup='D2h',
    cart=False,  # сферические гармоники
    verbose=4,
)


mf = mol.ROHF(verbose=4)
mf.max_cycle = 100
mf.conv_tol = 1e-15
mf.direct_scf_tol = 1e-15
mf.kernel()

mycas = mf.CASSCF(ncas=1, nelecas=0)
mycas.ncore = 7
mycas.conv_tol = 1e-15
mycas.conv_tol_grad = 1e-15
mycas.max_cycle_macro = 100
mycas.kernel()

import pyscf2gecco_new

ctrl = pyscf2gecco_new.FCIDumpController(
                            mol, mycas,
                            granularity=1,
                            frozen_indices=[],
                            tol=1e-15
                        )
ctrl.run('FCIDUMP')
