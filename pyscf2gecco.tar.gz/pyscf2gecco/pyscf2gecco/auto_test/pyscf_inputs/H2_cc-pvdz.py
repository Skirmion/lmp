import numpy as np
from pyscf import gto,mcscf

if __name__ == '__main__':
    mol = gto.M(atom='H 0 0 0; H 0 0 1', unit = "Ang")
    mol.build(
        basis="ccpvdz",
        charge = 0,
        symmetry = True,
        symmetry_subgroup = mol.groupname,
        spin=0 
    )
 
    mf = mol.RHF(verbose=4)
    #mf.max_cycle = 100
    mf.conv_tol = 1e-15
    mf.direct_scf_tol = 1e-15
    mf.kernel()

    import pyscf2gecco_new

    ctrl = pyscf2gecco_new.FCIDumpController(
                                mol, mf,
                                granularity=5,
                                frozen_indices=[],
                            )
    ctrl.run('FCIDUMP')
