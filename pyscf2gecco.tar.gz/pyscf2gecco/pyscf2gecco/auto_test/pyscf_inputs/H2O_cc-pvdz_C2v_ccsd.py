import numpy as np
from pyscf import gto,mcscf

if __name__ == '__main__':
    from math import sin, cos, radians
    from pyscf import gto, scf, cc

    # --- Геометрия: r = 1.85 bohr, угол HOH = 104°
    r = 1.85
    theta = radians(104.0)
    x = r * sin(theta/2.0)
    z = r * cos(theta/2.0)

    atoms = [
        ['O', ( 0.0, 0.0, 0.0)],
        ['H', ( x,   0.0, z  )],
        ['H', (-x,   0.0, z  )],
    ]

    mol = gto.M(
        atom=atoms,
        unit='Bohr',
        basis='cc-pvdz',           # Molpro: basis=vdz
        symmetry=True,
        symmetry_subgroup='C2v',   # Molpro обычно C2v для H2O
        spin=0,                    # закрытая оболочка
        charge=0,
        cart=False,                # сферические гармоники (Molpro: spherical)
        max_memory=150,            # Molpro: memory,150,m  (МБ)
        verbose=4,
    )

    mf = scf.RHF(mol)
    mf.max_cycle = 100
    mf.conv_tol = 1e-15
    mf.direct_scf_tol = 1e-15
    mf.kernel()

    mycas = mf.CASSCF(ncas=1, nelecas=0)
    mycas.conv_tol = 1e-15
    mycas.conv_tol_grad = 1e-15
    mycas.max_cycle_macro = 100
    mycas.kernel()

    import pyscf2gecco_new

    ctrl = pyscf2gecco_new.FCIDumpController(
                                mol, mycas,
                                granularity=1,
                                frozen_indices=[],
                                tol=1e-12
                            )
    ctrl.run('FCIDUMP')

