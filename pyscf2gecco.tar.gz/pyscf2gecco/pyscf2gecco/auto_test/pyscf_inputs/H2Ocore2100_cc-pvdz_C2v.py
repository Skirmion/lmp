import numpy as np
from pyscf import gto,mcscf

basis_txt_H = """
H  S
   13.01000   0.01968500
    1.96200   0.13797700
    0.44460   0.47814800
    0.12200   0.50124000
H  S
    0.12200   1.00000000
H  P
    0.72700   1.00000000
"""

basis_txt_O = """
O  S
 11720.0000   0.0007100000
  1759.0000   0.0054700000
   400.8000   0.0278370000
   113.7000   0.1048000000
    37.0300   0.2830620000
    13.2700   0.4487190000
     5.0250   0.2709520000
     1.0130   0.0154580000
     0.3023  -0.0025850000
O  S
 11720.0000  -0.0001600000
  1759.0000  -0.0012630000
   400.8000  -0.0062670000
   113.7000  -0.0257160000
    37.0300  -0.0709240000
    13.2700  -0.1654110000
     5.0250  -0.1169550000
     1.0130   0.5573680000
     0.3023   0.5727590000
O  S
     0.3023   1.00000000
O  P
    17.7000   0.0430180000
     3.8540   0.2289130000
     1.0460   0.5087280000
     0.2753   0.4605310000
O  P
     0.2753   1.00000000
O  D
     1.1850   1.00000000
"""


if __name__ == '__main__':
    from math import sin, cos, radians
    from pyscf import gto, scf, cc

    # --- Геометрия: r = 1.85 bohr, угол HOH = 104°
    r = 1.85
    theta = radians(104.0)
    x = r * sin(theta/2.0)
    z = r * cos(theta/2.0)

    atoms = [
        ['O', ( 0.0, 0.0, 0.0)],
        ['H', ( x,   0.0, z  )],
        ['H', (-x,   0.0, z  )],
    ]

    mol = gto.M(
        atom=atoms,
        unit='Bohr',
        basis = {
            'H': gto.basis.parse(basis_txt_H, optimize=False),
            'O': gto.basis.parse(basis_txt_O, optimize=False),
        },
        symmetry=True,
        symmetry_subgroup='C2v',   # Molpro обычно C2v для H2O
        spin=0,                    # закрытая оболочка
        charge=0,
        cart=False,                # сферические гармоники (Molpro: spherical)
        max_memory=150,            # Molpro: memory,150,m  (МБ)
        verbose=4,
    )

    mf = scf.RHF(mol)
    mf.max_cycle = 100
    mf.conv_tol = 1e-15
    mf.direct_scf_tol = 1e-15
    mf.kernel()

    mycas = mf.CASSCF(ncas=2, nelecas=4, ncore=3)
    mycas.conv_tol = 1e-15
    mycas.conv_tol_grad = 1e-15
    mycas.max_cycle_macro = 100
    mycas.kernel()

    import pyscf2gecco_new

    ctrl = pyscf2gecco_new.FCIDumpController(
                                mol, mycas,
                                granularity=1,
                                frozen_indices=[0, 1, 2],
                                tol=1e-12
                            )
    ctrl.run('FCIDUMP')

