import numpy as np
from math import sin, cos, radians
from pyscf import gto, scf

if __name__ == '__main__':
    from math import sin, cos, radians
    from pyscf import gto, scf, cc

    basis_txt_H = """
    H  S
    3.4252509140     0.1543289673
    0.6239137298     0.5353281423
    0.1688554040     0.4446345422
    """

    basis_txt_O = """
    O  S
    130.7093214        0.1543289673
    23.80886605       0.5353281423
    6.443608313      0.4446345422
    O  S
    5.033151319     -0.09996722919
    1.169596125      0.3995128261
    0.38038896       0.7001154689
    O  P
    5.033151319      0.1559162750
    1.169596125      0.6076837186
    0.38038896       0.3919573931
    """

    # --- Геометрия: r = 1.85 bohr, угол HOH = 104°
    r = 1.85
    theta = radians(104.0)
    x = r * sin(theta/2.0)
    z = r * cos(theta/2.0)

    atoms = [
        ['O', ( 0.0, 0.0, 0.0)],
        ['H', ( x,   0.0, z  )],
        ['H', (-x,   0.0, z  )],
    ]

    mol = gto.M(
        atom=atoms,
        unit='Bohr',
        basis = {
            'H': gto.basis.parse(basis_txt_H, optimize=False),
            'O': gto.basis.parse(basis_txt_O, optimize=False),
        },
        symmetry=True,
        symmetry_subgroup='C2v',   # Molpro обычно C2v для H2O
        spin=0,                    # закрытая оболочка
        charge=0,
        cart=False,                # сферические гармоники (Molpro: spherical)
        max_memory=150,            # Molpro: memory,150,m  (МБ)
        verbose=4,
    )

    # --- SCF (закрытая оболочка HF)
    mf = scf.RHF(mol)
    mf.conv_tol = 1e-15
    mf.kernel()

    # --- CCSD без заморозки коры (Molpro: {ccsd; core,0,0,0,0; thresh,energy=1e-12;})
    mycas = mf.CASSCF(ncas=1, nelecas=0)
    mycas.conv_tol = 1e-15
    mycas.conv_tol_grad = 1e-15
    mycas.max_cycle_macro = 100
    mycas.kernel()

    import pyscf2gecco_new

    ctrl = pyscf2gecco_new.FCIDumpController(
                                mol, mycas,
                                granularity=1,
                                frozen_indices=[],
                                tol=1e-12
                            )
    ctrl.run('FCIDUMP')

