"""
GeCCo Test Harness with Multi-Format FCIDUMP Support.

This module provides a comprehensive testing framework for GeCCo quantum chemistry
calculations. It integrates with FCIDUMPRunner to support multiple FCIDUMP formats
and provides flexible test configuration with automatic energy extraction and
comparison.

The test harness can operate in two modes:

1. **REF Mode**: Compare energies from two different FCIDUMP files (test vs reference)
2. **VALUE Mode**: Compare test FCIDUMP energy against a known reference value

Key Features
------------
- Automatic FCIDUMP format detection (text, .bin, .bin.zst) by file signature
- Configurable execution mode (RAM or disk) via FCIDUMPRunner
- Flexible FCIDUMP filename support for non-standard naming
- Robust energy parsing from GeCCo output with multiple pattern matching
- Automatic temporary directory management with optional preservation
- Comprehensive error handling and detailed diagnostics

Workflow
--------
1. Prepare test environment (working directory, input files)
2. Detect FCIDUMP format and configure runner appropriately
3. Execute GeCCo calculation(s) using FCIDUMPRunner
4. Parse energy from output file using pattern matching
5. Compare against reference (file or value) within tolerance
6. Clean up temporary files (unless keep_workdirs=True)
7. Return structured TestResult with status and diagnostics

Energy Parsing
--------------
The module attempts multiple regex patterns to extract energy values from
GeCCo output, ensuring compatibility with different output formats:
- ">>> final energy:" pattern (primary)
- User-provided custom regex
- Standard patterns: CC, FCI, E(tot), Total energy, Energy

Output Patterns
---------------
Recognized energy output formats include:
    >>> final energy: -76.0123456789
    CC  -76.012345678901
    Total energy = -7.60123456789E+01

Test Results
------------
Each test returns a TestResult object containing:
- Status: 'PASS', 'FAIL', or 'ERROR'
- Test and reference energies (when available)
- Energy difference (when computed)
- Detailed error/diagnostic messages
- Working directory paths (when preserved)

Classes
-------
TestConfig
    Configuration dataclass for a single test run, specifying all input
    parameters, file paths, tolerances, and behavioral flags.

TestResult
    Result dataclass containing test outcome, computed energies, comparison
    results, and diagnostic information.

Functions
---------
run_test(cfg: TestConfig) -> TestResult
    Execute a GeCCo test with the provided configuration and return results.

summarize(results: List[TestResult]) -> str
    Generate a concise summary string from a list of test results.

Examples
--------
Value mode test (compare against known reference):

    >>> config = TestConfig(
    ...     gecco_bin_path=Path("gecco.x"),
    ...     test_fcidump_path=Path("FCIDUMP"),
    ...     ref_energy_path=Path("ref_energy.txt"),
    ...     inp_path=Path("gecco.inp"),
    ...     tolerance=1e-8,
    ...     runner_mode="ram"
    ... )
    >>> result = run_test(config)
    >>> print(f"Status: {result.status}, Diff: {result.diff}")

REF mode test (compare two FCIDUMP calculations):

    >>> config = TestConfig(
    ...     gecco_bin_path=Path("gecco.x"),
    ...     test_fcidump_path=Path("FCIDUMP.test"),
    ...     ref_fcidump_path=Path("FCIDUMP.ref"),
    ...     inp_path=Path("gecco.inp"),
    ...     tolerance=1e-8,
    ...     keep_workdirs=True  # Preserve for debugging
    ... )
    >>> result = run_test(config)
    >>> if result.status == "PASS":
    ...     print(f"Test passed with diff={result.diff:.2e}")

Batch testing with summary:

    >>> results = []
    >>> for test_file in test_files:
    ...     cfg = TestConfig(test_fcidump_path=test_file, ...)
    ...     results.append(run_test(cfg))
    >>> print(summarize(results))
    PASS=15  FAIL=2  ERROR=1  TOTAL=18

Notes
-----
- Requires Linux system with /proc filesystem for process monitoring
- Working directories created in parent directory of test_fcidump_path
- Energy parsing is format-agnostic, supporting various GeCCo output styles
- Temporary files are always cleaned up on exception (unless keep_workdirs=True)

See Also
--------
pyscf2gecco.runner.FCIDUMPRunner : Underlying execution engine
run_prepared_tests : Batch runner for multiple pre-configured tests
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import os
import re
import shutil
import subprocess
import sys
import tempfile


DEFAULT_ENERGY_REGEX = (
    r"Total\s+energy\s*=\s*([-+]?\d+(?:\.\d*)?(?:[eE][-+]?\d+)?)"
)


@dataclass
class TestConfig:
    """
    Configuration for a single GeCCo test run.

    This dataclass encapsulates all parameters required to execute and validate
    a GeCCo quantum chemistry calculation test, including file paths, execution
    settings, comparison criteria, and behavioral flags.

    The configuration supports two testing modes:
    1. REF mode: Compare test FCIDUMP against reference FCIDUMP (ref_fcidump_path set)
    2. VALUE mode: Compare test result against reference value (ref_energy_path set)

    Parameters
    ----------
    gecco_bin_path : Path, optional
        Path to gecco.x executable. If None, searches in system PATH.
        Default: None
    timeout : int, optional
        Maximum execution time in seconds before test is terminated.
        Default: 3600
    env : Dict[str, str], optional
        Additional environment variables to set for GeCCo execution.
        Default: empty dict
    test_fcidump_path : Path, optional
        Path to the test FCIDUMP file (text, .bin, or .bin.zst format).
        Format is auto-detected by file signature.
        Default: Path("FCIDUMP")
    ref_fcidump_path : Path, optional
        Path to reference FCIDUMP for REF mode testing. When set, enables
        comparison between two FCIDUMP calculations instead of against
        a fixed reference value. Format auto-detected.
        Default: None
    inp_path : Path, optional
        Path to GeCCo input file (gecco.inp). If None, test runs with
        default GeCCo settings (not recommended).
        Default: None
    runner_mode : str, optional
        Execution mode for FCIDUMPRunner: 'ram' or 'disk'.
        - 'ram': Use RAM-backed FCIDUMP (faster, requires memory)
        - 'disk': Use disk-based FCIDUMP (slower, lower memory)
        Default: 'ram'
    grace : float, optional
        Grace period in seconds for RAM cleanup monitoring. Only effective
        when runner_mode='ram'. If set, FCIDUMP is deleted from RAM as soon
        as it's been closed for this duration. Useful for long calculations.
        Default: None (no monitoring)
    ref_energy_path : Path, optional
        Path to file containing reference energy value for VALUE mode testing.
        File should contain a single numeric value (one per line, comments
        allowed with # prefix). Required for VALUE mode.
        Default: None
    parse_file : str, optional
        Name of GeCCo output file to parse for energy extraction.
        Default: 'gecco.out'
    energy_regex : str, optional
        Custom regex pattern for energy extraction. Should contain one capture
        group for the energy value. If default patterns fail, this is tried.
        Default: DEFAULT_ENERGY_REGEX
    tolerance : float, optional
        Maximum absolute energy difference for PASS status.
        Test PASS if |E_test - E_ref| <= tolerance, otherwise FAIL.
        Default: 1e-8
    keep_workdirs : bool, optional
        Preserve working directories after test completion. Useful for
        debugging failed tests. When False, all temporary directories and
        files are removed automatically.
        Default: False
    test_name : str, optional
        Human-readable test identifier for logging and result tracking.
        Default: 'test'
    inp_dst_name : str, optional
        Destination filename for GeCCo input in working directory.
        Default: 'gecco.inp'

    Attributes
    ----------
    All parameters are exposed as attributes with the same names.

    Examples
    --------
    VALUE mode test configuration:

        >>> config = TestConfig(
        ...     gecco_bin_path=Path("/opt/gecco/gecco.x"),
        ...     test_fcidump_path=Path("H2O_test.bin.zst"),
        ...     ref_energy_path=Path("H2O_reference.txt"),
        ...     inp_path=Path("ccsd.inp"),
        ...     tolerance=1e-10,
        ...     runner_mode="ram",
        ...     test_name="H2O_CCSD"
        ... )

    REF mode test configuration with grace period:

        >>> config = TestConfig(
        ...     test_fcidump_path=Path("FCIDUMP.test"),
        ...     ref_fcidump_path=Path("FCIDUMP.pyscf"),
        ...     inp_path=Path("gecco.inp"),
        ...     runner_mode="ram",
        ...     grace=300.0,  # 5-minute grace period
        ...     keep_workdirs=True,  # Keep for inspection
        ...     test_name="comparison_test"
        ... )

    Minimal configuration (uses defaults):

        >>> config = TestConfig(
        ...     test_fcidump_path=Path("FCIDUMP"),
        ...     ref_energy_path=Path("ref.txt")
        ... )

    Notes
    -----
    - Either ref_energy_path or ref_fcidump_path should be set (not both)
    - When both are None, test fails with configuration error
    - FCIDUMP format is auto-detected, no need to specify
    - Working directories are created in test_fcidump_path parent directory

    See Also
    --------
    TestResult : Output data structure for test results
    run_test : Function that executes test with this configuration
    """

    # Program & environment
    gecco_bin_path: Optional[Path] = None  # Path to gecco.x or None for PATH lookup
    timeout: int = 3600
    env: Dict[str, str] = field(default_factory=dict)

    # Inputs
    test_fcidump_path: Path = Path("FCIDUMP")
    ref_fcidump_path: Optional[Path] = None
    inp_path: Optional[Path] = None

    # FCIDUMPRunner settings
    runner_mode: str = "ram"  # 'ram' or 'disk'
    grace: Optional[float] = None  # RAM monitoring grace period

    # VALUE-mode reference
    ref_energy_path: Optional[Path] = None

    # Parsing
    parse_file: Optional[str] = None  # default: 'gecco.out'
    energy_regex: str = DEFAULT_ENERGY_REGEX

    # Behavior
    tolerance: float = 1e-8
    keep_workdirs: bool = False

    # Naming
    test_name: str = "test"
    inp_dst_name: str = "gecco.inp"


@dataclass
class TestResult:
    """
    Result of a single GeCCo test calculation.

    This dataclass encapsulates the complete outcome of a test run, including
    status, computed energies, comparison metrics, and diagnostic information.
    It provides a structured format for result analysis, logging, and aggregation.

    Parameters
    ----------
    name : str
        Test identifier matching the test_name from TestConfig.
    status : str
        Test outcome: 'PASS', 'FAIL', or 'ERROR'.
        - 'PASS': Energy difference within tolerance
        - 'FAIL': Energy difference exceeds tolerance
        - 'ERROR': Test could not complete (configuration, execution, or parsing error)
    detail : str
        Human-readable description of the test outcome. For PASS/FAIL, contains
        energy difference and tolerance. For ERROR, contains exception details
        and diagnostic information.
    test_energy : float, optional
        Energy computed from test FCIDUMP calculation. None if calculation
        failed or energy could not be parsed.
        Default: None
    ref_energy : float, optional
        Reference energy value. Either from ref_energy_path (VALUE mode) or
        from ref_fcidump_path calculation (REF mode). None if not available
        or calculation failed.
        Default: None
    diff : float, optional
        Absolute energy difference |test_energy - ref_energy|. None if either
        energy is unavailable or test status is ERROR.
        Default: None
    workdir_test : Path, optional
        Path to test calculation working directory. Preserved when
        keep_workdirs=True in TestConfig, otherwise None.
        Default: None
    workdir_ref : Path, optional
        Path to reference calculation working directory (REF mode only).
        Preserved when keep_workdirs=True, otherwise None. Always None
        for VALUE mode.
        Default: None

    Attributes
    ----------
    All parameters are exposed as attributes with the same names.

    Examples
    --------
    Successful test result:

        >>> result = TestResult(
        ...     name="H2O_CCSD",
        ...     status="PASS",
        ...     detail="|E_test - E_ref| = 3.5e-10 (tol 1e-8)",
        ...     test_energy=-76.0123456789,
        ...     ref_energy=-76.0123456792,
        ...     diff=3.5e-10
        ... )

    Failed test result:

        >>> result = TestResult(
        ...     name="N2_FCI",
        ...     status="FAIL",
        ...     detail="|E_test - E_ref| = 1.2e-6 (tol 1e-8)",
        ...     test_energy=-108.9876543210,
        ...     ref_energy=-108.9876531098,
        ...     diff=1.2e-6
        ... )

    Error result:

        >>> result = TestResult(
        ...     name="broken_test",
        ...     status="ERROR",
        ...     detail="FileNotFoundError: FCIDUMP not found",
        ...     test_energy=None,
        ...     ref_energy=None,
        ...     diff=None
        ... )

    Accessing results:

        >>> for result in test_results:
        ...     if result.status == "PASS":
        ...         print(f"{result.name}: {result.diff:.2e}")
        ...     elif result.status == "ERROR":
        ...         print(f"{result.name}: {result.detail}")

    Notes
    -----
    - diff is always computed as absolute difference, not relative
    - workdir paths are only available when keep_workdirs=True
    - For ERROR status, test_energy and ref_energy may be partially available
    - detail field is essential for ERROR diagnostics and debugging

    See Also
    --------
    TestConfig : Configuration dataclass for test setup
    run_test : Function that produces TestResult
    summarize : Aggregate multiple TestResults into summary
    """

    name: str
    status: str  # 'PASS' | 'FAIL' | 'ERROR'
    detail: str
    test_energy: Optional[float] = None
    ref_energy: Optional[float] = None
    diff: Optional[float] = None
    workdir_test: Optional[Path] = None
    workdir_ref: Optional[Path] = None


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _detect_fcidump_format(fcidump_path: Path) -> str:
    """
    Detect FCIDUMP format by file signature.
    Returns: 'txt', 'bin', or 'zst'
    """
    if not fcidump_path.exists():
        raise FileNotFoundError(f"FCIDUMP not found: {fcidump_path}")
    
    with open(fcidump_path, 'rb') as f:
        header = f.read(16)
    
    # Check for zstd magic (0x28B52FFD)
    if len(header) >= 4 and header[:4] == b'\x28\xB5\x2F\xFD':
        return 'zst'
    
    # Check for FCD5 signature (binary v5)
    if len(header) >= 4 and header[:4] == b'FCD5':
        return 'bin'
    
    # Assume text if starts with printable ASCII
    try:
        # Try to decode as text
        header_str = header.decode('utf-8', errors='strict')
        if '&FCI' in header_str or 'NORB' in header_str:
            return 'txt'
    except:
        pass
    
    # Default to text if can't determine
    return 'txt'


def _ensure_gecco_available(gecco_bin_path: Optional[Path]) -> str:
    """
    Ensure gecco.x is available and return the path or 'gecco.x'.
    """
    if gecco_bin_path:
        exe = Path(gecco_bin_path).expanduser().resolve()
        if not exe.exists():
            raise RuntimeError(f"gecco.x not found at '{exe}'.")
        if not os.access(exe, os.X_OK):
            raise RuntimeError(f"gecco.x at '{exe}' is not executable.")
        return str(exe)

    from shutil import which
    if which("gecco.x") is None:
        raise RuntimeError("'gecco.x' not found in PATH. Provide gecco_bin_path or add it to PATH.")
    return "gecco.x"


def _mk_workdir(base_dir: Path, prefix: str) -> Path:
    base_dir.mkdir(parents=True, exist_ok=True)
    return Path(tempfile.mkdtemp(prefix=prefix, dir=str(base_dir)))


def _copy(src: Path, dst: Path) -> None:
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)


def _read_ref_value(path: Path) -> float:
    text = path.read_text(encoding="utf-8", errors="ignore")
    for line in text.splitlines():
        s = line.strip()
        if not s or s.startswith("#"):
            continue
        try:
            return float(s.split()[0])
        except Exception:
            continue
    raise ValueError(f"No numeric value found in {path}")


def _parse_energy_from_text(text: str, user_regex: str) -> float:
    """Extract energy from text using known patterns."""
    patterns = [
        r">>\>\s*final\s+energy:\s*([-+]?\d+(?:\.\d*)?(?:[eE][-+]?\d+)?)",
        user_regex,
        r"^\s*CC\s+([-+]?\d+(?:\.\d*)?(?:[eE][-+]?\d+)?)\s*$",
        r"^\s*FCI\s+([-+]?[\d\.]+(?:[eE][-+]?\d+)?)\s*$",
        r"E\s*\(tot\)\s*=\s*([-+]?\d+(?:\.\d*)?(?:[eE][-+]?\d+)?)",
        r"Total\s+energy\s*=\s*([-+]?\d+(?:\.\d*)?(?:[eE][-+]?\d+)?)",
        r"Energy\s*=\s*([-+]?\d+(?:\.\d*)?(?:[eE][-+]?\d+)?)",
    ]
    for pat in patterns:
        m = re.search(pat, text, flags=re.MULTILINE)
        if m:
            return float(m.group(1))
    raise ValueError("Energy not found in the provided results file using known patterns.")


def _run_single(
    calc_name: str,
    base_dir: Path,
    cfg: TestConfig,
    gecco_bin: str,
    fcidump_src: Path,
) -> Tuple[float, Path]:
    """Run one GeCCo calculation using FCIDUMPRunner and return (energy, workdir)."""
    workdir = _mk_workdir(base_dir, prefix=f".fcidump_work_{cfg.test_name}_{calc_name}_")

    # Copy gecco.inp
    if cfg.inp_path is not None:
        if not cfg.inp_path.exists():
            raise FileNotFoundError(f"GeCCo input not found: {cfg.inp_path}")
        _copy(cfg.inp_path, workdir / cfg.inp_dst_name)
    
    # Detect FCIDUMP format
    fcidump_format = _detect_fcidump_format(fcidump_src)
    fcidump_filename = fcidump_src.name
    
    # Copy FCIDUMP to workdir with original name
    _copy(fcidump_src, workdir / fcidump_filename)
    
    # Import FCIDUMPRunner
    try:
        sys.path.insert(0, str(Path(__file__).parent.parent))
        from runner.fcidump_runner import FCIDUMPRunner
    except ImportError as e:
        raise ImportError(
            f"Cannot import FCIDUMPRunner: {e}\n"
            "Make sure pyscf2gecco is installed or in PYTHONPATH"
        )
    
    # Create runner
    runner = FCIDUMPRunner(gecco_bin=gecco_bin, verbose=False)
    
    # Run GeCCo with FCIDUMPRunner
    try:
        exit_code = runner.run(
            gecco_inp=cfg.inp_dst_name,
            mode=cfg.runner_mode,
            fcidump_filename=fcidump_filename,
            out_name="gecco.out",
            grace=cfg.grace,
        )
        
        if exit_code != 0:
            raise RuntimeError(f"GeCCo exited with code {exit_code}")
    
    except Exception as e:
        # Check if gecco.out exists for diagnostics
        gecco_out = workdir / "gecco.out"
        if gecco_out.exists():
            tail = gecco_out.read_text()[-2000:]
            raise RuntimeError(
                f"FCIDUMPRunner failed in {workdir}: {e}\n"
                f"gecco.out tail:\n{tail}"
            )
        else:
            raise RuntimeError(f"FCIDUMPRunner failed in {workdir}: {e}")
    
    # Parse energy from gecco.out
    parse_path = workdir / (cfg.parse_file if cfg.parse_file else "gecco.out")
    if not parse_path.exists():
        raise FileNotFoundError(
            f"Results file not found: {parse_path}"
        )
    
    text = parse_path.read_text(encoding="utf-8", errors="ignore")
    energy = _parse_energy_from_text(text, cfg.energy_regex)
    
    return energy, workdir


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def run_test(cfg: TestConfig) -> TestResult:
    """
    Execute a GeCCo test with automatic FCIDUMP handling and energy comparison.

    This function orchestrates a complete test workflow: prepares the execution
    environment, runs GeCCo calculation(s) using FCIDUMPRunner with the specified
    configuration, extracts energies from output, compares results against reference,
    and returns a structured TestResult.

    The function supports two testing modes:
    1. **VALUE mode**: Compare test result against a reference energy value from file
    2. **REF mode**: Run two calculations (test and reference FCIDUMPs) and compare

    All temporary files and working directories are automatically managed and cleaned
    up unless keep_workdirs=True is specified in the configuration.

    Parameters
    ----------
    cfg : TestConfig
        Complete test configuration including file paths, execution settings,
        comparison criteria, and behavioral flags. See TestConfig documentation
        for detailed parameter descriptions.

    Returns
    -------
    TestResult
        Structured test outcome containing:
        - status: 'PASS' (within tolerance), 'FAIL' (exceeds tolerance), or 'ERROR'
        - test_energy: Energy from test calculation (if successful)
        - ref_energy: Reference energy (from file or calculation)
        - diff: Absolute energy difference (if both energies available)
        - detail: Human-readable description and diagnostics
        - workdir_test, workdir_ref: Paths to working directories (if preserved)

    Raises
    ------
    This function does not raise exceptions. All errors are caught and returned
    as TestResult with status='ERROR' and detailed diagnostic information in
    the detail field.

    Common error conditions:
        - FileNotFoundError: Missing FCIDUMP, input, or reference files
        - RuntimeError: GeCCo execution failures, binary decompression errors
        - ValueError: Energy parsing failures, invalid configuration
        - OSError: File system operation failures, permission errors

    Notes
    -----
    Execution Workflow:
        1. Validate configuration and resolve file paths
        2. Create temporary working directory in test_fcidump_path parent
        3. Copy GeCCo input file to working directory
        4. Detect FCIDUMP format and prepare for execution
        5. Run GeCCo via FCIDUMPRunner (RAM or disk mode)
        6. Parse energy from GeCCo output using multiple patterns
        7. Compare with reference (value or calculation)
        8. Clean up temporary files (unless keep_workdirs=True)
        9. Return TestResult with status and metrics

    FCIDUMP Handling:
        - Format detected automatically by file signature
        - Text FCIDUMPs used directly via symlink
        - Binary .bin files decoded in parallel (Cython when available)
        - Compressed .bin.zst files decompressed then decoded
        - All formats converted to text for GeCCo consumption

    Energy Parsing:
        Multiple regex patterns attempted in priority order:
        1. ">>> final energy:" (primary GeCCo pattern)
        2. User-provided custom regex from cfg.energy_regex
        3. Standard patterns: CC, FCI, E(tot), Total energy, Energy
        First successful match is used; parsing failure triggers ERROR status

    Performance:
        - RAM mode: Faster for large FCIDUMPs, requires sufficient memory
        - Disk mode: Lower memory footprint, may be I/O bound
        - Grace period monitoring: Minimal overhead, enables early cleanup
        - Parallel decompression: Significant speedup for binary formats

    Examples
    --------
    VALUE mode test (most common):

        >>> cfg = TestConfig(
        ...     test_fcidump_path=Path("FCIDUMP.test"),
        ...     ref_energy_path=Path("reference.txt"),
        ...     inp_path=Path("ccsd.inp"),
        ...     tolerance=1e-8,
        ...     runner_mode="ram",
        ...     test_name="H2O_test"
        ... )
        >>> result = run_test(cfg)
        >>> print(f"{result.status}: diff={result.diff:.2e}")
        PASS: diff=3.45e-10

    REF mode test with preserved workdirs:

        >>> cfg = TestConfig(
        ...     test_fcidump_path=Path("FCIDUMP.new"),
        ...     ref_fcidump_path=Path("FCIDUMP.verified"),
        ...     inp_path=Path("gecco.inp"),
        ...     keep_workdirs=True,  # Keep for inspection
        ...     test_name="regression_test"
        ... )
        >>> result = run_test(cfg)
        >>> if result.status == "PASS":
        ...     print(f"Test passed: {result.workdir_test}")
        ... else:
        ...     print(f"Check workdirs: {result.workdir_test}, {result.workdir_ref}")

    Batch testing:

        >>> results = []
        >>> for fcidump_file in fcidump_files:
        ...     cfg = TestConfig(
        ...         test_fcidump_path=fcidump_file,
        ...         ref_energy_path=ref_file,
        ...         inp_path=inp_file,
        ...         tolerance=1e-8
        ...     )
        ...     results.append(run_test(cfg))
        >>> 
        >>> passed = sum(1 for r in results if r.status == "PASS")
        >>> print(f"Passed: {passed}/{len(results)}")

    Error handling:

        >>> result = run_test(cfg)
        >>> if result.status == "ERROR":
        ...     print(f"Test failed: {result.detail}")
        ...     if "FCIDUMP not found" in result.detail:
        ...         print("Check FCIDUMP file path")
        ...     elif "Energy not found" in result.detail:
        ...         print("Check GeCCo output format")

    See Also
    --------
    TestConfig : Configuration dataclass with all parameters
    TestResult : Return value structure
    summarize : Aggregate results from multiple tests
    FCIDUMPRunner : Underlying execution engine
    """
    name = cfg.test_name
    try:
        test_fci = cfg.test_fcidump_path.expanduser().resolve()
        if not test_fci.exists():
            raise FileNotFoundError(f"test_fcidump_path does not exist: {test_fci}")

        base_dir = test_fci.parent.resolve()
        gecco_bin = _ensure_gecco_available(cfg.gecco_bin_path)

        # REF mode: compare two calculations
        if cfg.ref_fcidump_path is not None:
            ref_fci = cfg.ref_fcidump_path.expanduser().resolve()
            if not ref_fci.exists():
                raise FileNotFoundError(f"ref_fcidump_path does not exist: {ref_fci}")

            e_ref, wd_ref = _run_single("ref", base_dir, cfg, gecco_bin, ref_fci)
            e_test, wd_test = _run_single("test", base_dir, cfg, gecco_bin, test_fci)
            diff = abs(e_test - e_ref)
            status = "PASS" if diff <= cfg.tolerance else "FAIL"
            detail = f"|E_test - E_refcalc| = {diff:.12g} (tol {cfg.tolerance})"

            if not cfg.keep_workdirs:
                shutil.rmtree(wd_ref, ignore_errors=True)
                shutil.rmtree(wd_test, ignore_errors=True)
                wd_ref_ret = None
                wd_test_ret = None
            else:
                wd_ref_ret = wd_ref
                wd_test_ret = wd_test

            return TestResult(
                name,
                status,
                detail,
                test_energy=e_test,
                ref_energy=e_ref,
                diff=diff,
                workdir_test=wd_test_ret,
                workdir_ref=wd_ref_ret,
            )

        # VALUE mode: compare with numeric value
        ref_path = (
            cfg.ref_energy_path.expanduser().resolve()
            if cfg.ref_energy_path is not None
            else (base_dir / "ref_energy.txt").resolve()
        )
        if not ref_path.exists():
            raise FileNotFoundError(f"Reference energy file not found: {ref_path}")

        e_test, wd_test = _run_single("test", base_dir, cfg, gecco_bin, test_fci)
        e_ref = _read_ref_value(ref_path)
        diff = abs(e_test - e_ref)
        status = "PASS" if diff <= cfg.tolerance else "FAIL"
        detail = f"|E_test - E_ref| = {diff:.12g} (tol {cfg.tolerance})"

        if not cfg.keep_workdirs:
            shutil.rmtree(wd_test, ignore_errors=True)
            wd_test_ret = None
        else:
            wd_test_ret = wd_test

        return TestResult(
            name,
            status,
            detail,
            test_energy=e_test,
            ref_energy=e_ref,
            diff=diff,
            workdir_test=wd_test_ret,
            workdir_ref=None,
        )

    except Exception as exc:
        return TestResult(
            name,
            "ERROR",
            f"{type(exc).__name__}: {exc}",
            None,
            None,
            None,
            None,
            None,
        )



def summarize(results: List[TestResult]) -> str:
    """
    Generate a concise summary string from a list of test results.

    Creates a single-line summary showing the count of tests by status
    (PASS, FAIL, ERROR) and the total number of tests. Useful for
    batch testing reports and continuous integration output.

    Parameters
    ----------
    results : List[TestResult]
        List of test results to summarize. Can be from multiple test runs,
        different molecules, basis sets, or calculation types. Empty list
        is valid and returns all zeros.

    Returns
    -------
    str
        Formatted summary string in the format:
        "PASS=X  FAIL=Y  ERROR=Z  TOTAL=N"
        where X, Y, Z are counts of each status and N is the total.

    Examples
    --------
    Basic usage:

        >>> results = [run_test(cfg1), run_test(cfg2), run_test(cfg3)]
        >>> print(summarize(results))
        PASS=2  FAIL=1  ERROR=0  TOTAL=3

    Empty results:

        >>> print(summarize([]))
        PASS=0  FAIL=0  ERROR=0  TOTAL=0

    Integration with batch runner:

        >>> results = []
        >>> for test_config in test_configs:
        ...     results.append(run_test(test_config))
        >>> summary = summarize(results)
        >>> print(f"Test suite: {summary}")
        >>> if "FAIL=0" in summary and "ERROR=0" in summary:
        ...     print("All tests passed!")

    Conditional processing:

        >>> summary = summarize(results)
        >>> n_pass = int(summary.split("PASS=")[1].split()[0])
        >>> n_total = int(summary.split("TOTAL=")[1])
        >>> success_rate = 100.0 * n_pass / n_total if n_total > 0 else 0.0
        >>> print(f"Success rate: {success_rate:.1f}%")

    Notes
    -----
    - The summary format is designed for easy parsing and human readability
    - Status counts are computed by iterating through results list
    - Each status is counted exactly once per result
    - The function is safe for empty input (returns all zeros)

    See Also
    --------
    run_test : Function that produces TestResult objects
    TestResult : Data structure containing test status
    """
    n_pass = sum(1 for r in results if r.status == "PASS")
    n_fail = sum(1 for r in results if r.status == "FAIL")
    n_err = sum(1 for r in results if r.status == "ERROR")
    total = len(results)
    return f"PASS={n_pass}  FAIL={n_fail}  ERROR={n_err}  TOTAL={total}"


__all__ = ["TestConfig", "TestResult", "run_test", "summarize"]
