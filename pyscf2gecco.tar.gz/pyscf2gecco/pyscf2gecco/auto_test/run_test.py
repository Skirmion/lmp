from pathlib import Path
from run_prepared_tests import RunnerConfig, run_all_tests

cfg = RunnerConfig(
    gecco_inputs=Path("gecco_inputs"),
    pyscf_inputs=Path("pyscf_inputs"),
    gecco_bin_path=None,          # or Path("/abs/path/to/.../gecco.x")
    pyscf2gecco_path=None,        # or Path("/abs/path/to/pyscf2gecco/__init__.py")
    tolerance=1e-8,
    keep_workdirs=False,
    verbose=True,
    max_workers=16,               # default: os.cpu_count(); can set to 4, etc.
    runner_mode="ram",            # 'ram' or 'disk' for FCIDUMPRunner
    grace=None,                   # Grace period for RAM monitoring (e.g., 30.0)
)

results, metrics = run_all_tests(cfg)
