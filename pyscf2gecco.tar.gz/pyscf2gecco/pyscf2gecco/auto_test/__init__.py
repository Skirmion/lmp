"""
Automated Testing Framework for GeCCo Calculations.

This module provides comprehensive infrastructure for testing GeCCo quantum
chemistry calculations with automatic test discovery, parallel execution,
and formatted result reporting.

Key Features
------------
- Automatic FCIDUMP format detection and handling (text, .bin, .bin.zst)
- Flexible test configuration with VALUE or REF comparison modes
- Parallel test execution with resource management
- Energy extraction with multiple pattern matching
- Formatted result tables with pass/fail statistics
- Detailed error logging and diagnostics

Main Components
---------------
Single Test Execution:
    - TestConfig: Configuration for individual test
    - TestResult: Structured test outcome
    - run_test: Execute single test with configuration

Batch Test Suite:
    - RunnerConfig: Configuration for test suite
    - run_all_tests: Execute complete test suite with discovery

Test Organization
-----------------
Tests are organized with strict directory structure and naming:

    project_root/
    ├── gecco_inputs/          # GeCCo .inp files and RESULTS
    │   ├── <stem>.inp
    │   └── RESULTS            # Reference energies
    ├── pyscf_inputs/          # PySCF FCIDUMP generators
    │   └── <stem>.py          # Must match .inp stem
    └── test_runner.py         # Execution script

Classes
-------
TestConfig
    Per-test configuration with file paths, execution settings, and tolerances.
TestResult
    Test outcome with status, energies, differences, and diagnostics.
RunnerConfig
    Batch runner configuration with directories, parallelism, and behavior.

Functions
---------
run_test(cfg: TestConfig) -> TestResult
    Execute single GeCCo test and return structured result.
run_all_tests(cfg: RunnerConfig) -> Tuple[List[TestResult], str]
    Execute complete test suite with automatic discovery and reporting.
summarize(results: List[TestResult]) -> str
    Generate concise summary from list of results.

Examples
--------
Single test execution:

    >>> from pyscf2gecco.auto_test import TestConfig, run_test
    >>> 
    >>> cfg = TestConfig(
    ...     test_fcidump_path=Path("FCIDUMP"),
    ...     ref_energy_path=Path("ref.txt"),
    ...     inp_path=Path("gecco.inp"),
    ...     tolerance=1e-8,
    ...     runner_mode="ram"
    ... )
    >>> result = run_test(cfg)
    >>> print(f"Status: {result.status}, Diff: {result.diff:.2e}")

Batch test suite:

    >>> from pyscf2gecco.auto_test import RunnerConfig, run_all_tests
    >>> 
    >>> cfg = RunnerConfig(
    ...     gecco_inputs=Path("gecco_inputs"),
    ...     pyscf_inputs=Path("pyscf_inputs"),
    ...     max_workers=8,
    ...     tolerance=1e-8,
    ...     verbose=True
    ... )
    >>> results, summary = run_all_tests(cfg)
    >>> print(summary)
    PASS=15  FAIL=0  ERROR=0  TOTAL=15

Custom configuration:

    >>> cfg = RunnerConfig(
    ...     gecco_bin_path=Path("/opt/gecco/gecco.x"),
    ...     runner_mode="disk",
    ...     keep_workdirs=True,
    ...     max_workers=4
    ... )
    >>> results, summary = run_all_tests(cfg)

Notes
-----
- Requires gecco.x executable (in PATH or specified)
- PySCF scripts must generate ./FCIDUMP in working directory
- Reference energies in RESULTS file: "<stem> <energy>"
- Test pairing by exact stem match between .inp and .py
- Parallel execution: serial FCIDUMP generation, parallel GeCCo runs
- Error details saved to ./test_pyscf2gecco_errors

See Also
--------
pyscf2gecco.runner : FCIDUMPRunner for GeCCo execution
"""

from .fcidump_tester import TestConfig, TestResult, run_test, summarize
from .run_prepared_tests import RunnerConfig, run_all_tests

__all__ = [
    "TestConfig",
    "TestResult",
    "run_test",
    "summarize",
    "RunnerConfig",
    "run_all_tests",
]
