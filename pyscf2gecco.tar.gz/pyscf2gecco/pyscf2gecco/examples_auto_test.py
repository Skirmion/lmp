"""
Examples for pyscf2gecco.auto_test module.

This file demonstrates usage of the automated testing framework for GeCCo
calculations, including single test execution and batch test suites.
"""

from pathlib import Path
from pyscf2gecco.auto_test import (
    TestConfig, TestResult, run_test, summarize,
    RunnerConfig, run_all_tests
)


def example_default_test_suite():
    """
    Example 0: Default automated test suite (RECOMMENDED).
    
    This is the main way to run automated tests with pyscf2gecco.
    Executes all tests from gecco_inputs/ and pyscf_inputs/ directories
    with automatic FCIDUMP generation and GeCCo verification using default settings.
    
    Directory structure required:
        project_root/
        ├── gecco_inputs/       # GeCCo .inp files
        │   ├── test1.inp
        │   └── RESULTS         # Reference energies
        ├── pyscf_inputs/       # PySCF scripts
        │   └── test1.py
        
    Usage:
        Just run this function with properly organized test directories.
        No configuration needed - uses optimal defaults.
    """
    print("=" * 70)
    print("Example 0: Default automated test suite")
    print("=" * 70)
    
    # Run all tests with default configuration
    # Default settings:
    #   - gecco_inputs: Path("gecco_inputs")
    #   - pyscf_inputs: Path("pyscf_inputs")
    #   - tolerance: 1e-8
    #   - runner_mode: "ram"
    #   - max_workers: os.cpu_count()
    #   - verbose: True
    results, summary = run_all_tests()
    
    # Print summary
    print("\n" + "=" * 70)
    print("Test Suite Summary")
    print("=" * 70)
    print(summary)
    
    # Count results
    passed = sum(1 for r in results if r.status == "PASS")
    failed = sum(1 for r in results if r.status == "FAIL")
    errors = sum(1 for r in results if r.status == "ERROR")
    
    print(f"\nTotal tests: {len(results)}")
    print(f"  PASS:  {passed}")
    print(f"  FAIL:  {failed}")
    print(f"  ERROR: {errors}")
    print()


def example_single_test_value_mode():
    """
    Single test in VALUE mode (compare against reference energy value).
    
    Most common test mode: runs one FCIDUMP calculation and compares
    the energy against a known reference value from file.
    """
    print("=" * 70)
    print("Example 1: Single test - VALUE mode")
    print("=" * 70)
    
    config = TestConfig(
        gecco_bin_path=None,  # Use gecco.x from PATH
        test_fcidump_path=Path("FCIDUMP"),
        ref_energy_path=Path("reference_energy.txt"),
        inp_path=Path("gecco.inp"),
        tolerance=1e-8,
        runner_mode="ram",
        test_name="H2O_test"
    )
    
    result = run_test(config)
    
    print(f"Test: {result.name}")
    print(f"Status: {result.status}")
    print(f"Test energy: {result.test_energy}")
    print(f"Ref energy: {result.ref_energy}")
    print(f"Difference: {result.diff}")
    print(f"Detail: {result.detail}")
    print()


def example_single_test_ref_mode():
    """
    Single test in REF mode (compare two FCIDUMP calculations).
    
    Runs GeCCo with both test and reference FCIDUMPs, compares energies.
    Useful for regression testing or method comparison.
    """
    print("=" * 70)
    print("Example 2: Single test - REF mode")
    print("=" * 70)
    
    config = TestConfig(
        test_fcidump_path=Path("FCIDUMP.test"),
        ref_fcidump_path=Path("FCIDUMP.reference"),
        inp_path=Path("gecco.inp"),
        tolerance=1e-8,
        runner_mode="ram",
        test_name="method_comparison"
    )
    
    result = run_test(config)
    
    print(f"Status: {result.status}")
    if result.status != "ERROR":
        print(f"|E_test - E_ref| = {result.diff:.3e}")
    else:
        print(f"Error: {result.detail}")
    print()


def example_single_test_with_grace():
    """
    Single test with RAM grace period monitoring.
    
    Enables automatic FCIDUMP cleanup from RAM after grace period,
    useful for long calculations with early FCIDUMP access.
    """
    print("=" * 70)
    print("Example 3: Single test with grace period")
    print("=" * 70)
    
    config = TestConfig(
        test_fcidump_path=Path("FCIDUMP.bin.zst"),
        ref_energy_path=Path("ref.txt"),
        inp_path=Path("long_calculation.inp"),
        runner_mode="ram",
        grace=300.0,  # 5-minute grace period
        tolerance=1e-10,
        test_name="long_test"
    )
    
    result = run_test(config)
    print(f"Result: {result.status}")
    print()


def example_single_test_keep_workdirs():
    """
    Single test with preserved working directories.
    
    Keeps temporary directories for inspection and debugging.
    Useful when tests fail or for detailed analysis.
    """
    print("=" * 70)
    print("Example 4: Single test with preserved workdirs")
    print("=" * 70)
    
    config = TestConfig(
        test_fcidump_path=Path("FCIDUMP"),
        ref_energy_path=Path("ref.txt"),
        inp_path=Path("gecco.inp"),
        keep_workdirs=True,  # Preserve directories
        test_name="debug_test"
    )
    
    result = run_test(config)
    
    print(f"Status: {result.status}")
    if result.workdir_test:
        print(f"Test workdir: {result.workdir_test}")
    if result.workdir_ref:
        print(f"Ref workdir: {result.workdir_ref}")
    print()


def example_batch_tests_basic():
    """
    Basic batch test suite execution.
    
    Automatically discovers tests by pairing .inp files with .py scripts,
    runs FCIDUMP generation serially, then GeCCo calculations in parallel.
    """
    print("=" * 70)
    print("Example 5: Basic batch test suite")
    print("=" * 70)
    
    cfg = RunnerConfig(
        gecco_inputs=Path("gecco_inputs"),
        pyscf_inputs=Path("pyscf_inputs"),
        tolerance=1e-8,
        verbose=True,
        max_workers=8
    )
    
    results, summary = run_all_tests(cfg)
    
    print(f"\nSummary: {summary}")
    
    # Show failed tests
    failed = [r for r in results if r.status == "FAIL"]
    if failed:
        print(f"\nFailed tests ({len(failed)}):")
        for r in failed:
            print(f"  - {r.name}: diff={r.diff:.2e}")
    print()


def example_batch_tests_custom_paths():
    """
    Batch tests with custom executable paths.
    
    Specifies custom paths for gecco.x and pyscf2gecco module,
    useful for testing specific versions or non-standard installations.
    """
    print("=" * 70)
    print("Example 6: Batch tests with custom paths")
    print("=" * 70)
    
    cfg = RunnerConfig(
        gecco_inputs=Path("tests/gecco"),
        pyscf_inputs=Path("tests/pyscf"),
        gecco_bin_path=Path("/opt/gecco/bin/gecco.x"),
        pyscf2gecco_path=Path("../../pyscf2gecco/__init__.py"),
        tolerance=1e-9,
        max_workers=4
    )
    
    results, summary = run_all_tests(cfg)
    print(f"Summary: {summary}")
    print()


def example_batch_tests_production():
    """
    Production test suite configuration.
    
    Optimized for high-throughput testing with minimal output,
    RAM mode with grace period, and appropriate parallelism.
    """
    print("=" * 70)
    print("Example 7: Production test suite")
    print("=" * 70)
    
    cfg = RunnerConfig(
        gecco_inputs=Path("production_tests/gecco_inputs"),
        pyscf_inputs=Path("production_tests/pyscf_inputs"),
        tolerance=1e-10,
        max_workers=32,
        runner_mode="ram",
        grace=600.0,  # 10-minute grace
        verbose=False,  # Minimal output
        keep_workdirs=False
    )
    
    results, summary = run_all_tests(cfg)
    
    print(f"Production run: {summary}")
    
    # Report errors
    errors = [r for r in results if r.status == "ERROR"]
    if errors:
        print(f"\nErrors encountered ({len(errors)}):")
        for r in errors:
            print(f"  - {r.name}")
    print()


def example_batch_tests_debugging():
    """
    Debug configuration for troubleshooting.
    
    Serial execution with preserved workdirs, disk mode for easier
    inspection, and verbose logging.
    """
    print("=" * 70)
    print("Example 8: Debug configuration")
    print("=" * 70)
    
    cfg = RunnerConfig(
        gecco_inputs=Path("gecco_inputs"),
        pyscf_inputs=Path("pyscf_inputs"),
        max_workers=1,  # Serial execution
        runner_mode="disk",  # Easier to inspect
        keep_workdirs=True,  # Keep all files
        verbose=True  # Detailed logs
    )
    
    results, summary = run_all_tests(cfg)
    print(f"Debug run: {summary}")
    print()


def example_batch_tests_selective():
    """
    Selective test execution with filtering.
    
    Runs all discovered tests but filters results for specific analysis.
    """
    print("=" * 70)
    print("Example 9: Selective test execution")
    print("=" * 70)
    
    cfg = RunnerConfig(
        gecco_inputs=Path("gecco_inputs"),
        pyscf_inputs=Path("pyscf_inputs"),
        max_workers=8
    )
    
    results, summary = run_all_tests(cfg)
    
    # Filter by molecule
    h2o_results = [r for r in results if "H2O" in r.name]
    print(f"H2O tests: {summarize(h2o_results)}")
    
    # Filter by basis
    pvdz_results = [r for r in results if "cc-pvdz" in r.name]
    print(f"cc-pVDZ tests: {summarize(pvdz_results)}")
    
    # Check tolerance
    high_accuracy = [r for r in results 
                     if r.diff is not None and r.diff < 1e-10]
    print(f"High accuracy (< 1e-10): {len(high_accuracy)}")
    print()


def example_summarize_results():
    """
    Using summarize() function for result aggregation.
    
    Demonstrates creating summary strings from test result lists.
    """
    print("=" * 70)
    print("Example 10: Result summarization")
    print("=" * 70)
    
    # Simulate test results
    results = []
    
    # Run hypothetical tests
    for i in range(10):
        config = TestConfig(
            test_fcidump_path=Path(f"test{i}/FCIDUMP"),
            ref_energy_path=Path(f"test{i}/ref.txt"),
            inp_path=Path("gecco.inp"),
            test_name=f"test_{i}"
        )
        # results.append(run_test(config))  # Would run actual test
    
    # Create mock results for demonstration
    from dataclasses import dataclass
    
    # (In real usage, run_test() returns TestResult objects)
    print("Mock results for demonstration:")
    print("Total: 10, PASS: 8, FAIL: 1, ERROR: 1")
    print()


def main():
    """Run all examples."""
    print("\n" + "=" * 70)
    print("pyscf2gecco.auto_test - Testing Framework Examples")
    print("=" * 70 + "\n")
    
    print("These examples demonstrate the automated testing framework")
    print("for GeCCo calculations.\n")
    
    print("NOTE: The default test suite requires only test directories:")
    print("      gecco_inputs/ and pyscf_inputs/ with RESULTS file.")
    print("      No configuration needed!\n")
    
    # DEFAULT AUTOMATED TEST SUITE (recommended usage - no config needed!)
    # Uncomment to run the full test suite with defaults:
    # example_default_test_suite()
    
    # Single test examples (require manual setup)
    # example_single_test_value_mode()
    # example_single_test_ref_mode()
    # example_single_test_with_grace()
    # example_single_test_keep_workdirs()
    
    # Batch test examples (customization options)
    # example_batch_tests_basic()
    # example_batch_tests_custom_paths()
    # example_batch_tests_production()
    # example_batch_tests_debugging()
    # example_batch_tests_selective()
    # example_summarize_results()
    
    print("To run the default automated test suite (EASIEST):")
    print("  1. Organize tests in gecco_inputs/ and pyscf_inputs/")
    print("  2. Call: run_all_tests()  # No config needed!")
    print("  3. Or uncomment example_default_test_suite() above\n")
    
    print("For custom tests, uncomment other examples and set up:")
    print("  gecco_inputs/    - GeCCo .inp files and RESULTS")
    print("  pyscf_inputs/    - PySCF scripts to generate FCIDUMPs")


if __name__ == "__main__":
    main()
