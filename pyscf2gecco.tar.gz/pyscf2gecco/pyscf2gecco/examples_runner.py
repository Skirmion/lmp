"""
Examples for pyscf2gecco.runner module.

This file demonstrates usage of FCIDUMPRunner for executing GeCCo calculations
with intelligent FCIDUMP handling, supporting multiple formats and execution modes.
"""

from pathlib import Path
from pyscf2gecco.runner import FCIDUMPRunner


def example_basic_ram_mode():
    """
    Basic usage with RAM mode (default).
    
    Automatically detects FCIDUMP format (text, .bin, .bin.zst) and expands
    to RAM-backed text file with symlink as ./FCIDUMP.
    """
    print("=" * 70)
    print("Example 1: Basic RAM mode execution")
    print("=" * 70)
    
    runner = FCIDUMPRunner(gecco_bin="gecco.x", verbose=True)
    
    # Run with auto-detected FCIDUMP (tries FCIDUMP, FCIDUMP.bin, FCIDUMP.bin.zst)
    exit_code = runner.run(
        gecco_inp="calculation.inp",
        mode="ram"
    )
    
    if exit_code == 0:
        print("✓ Calculation completed successfully")
    else:
        print(f"✗ Calculation failed with exit code {exit_code}")
    
    print()


def example_ram_mode_with_grace():
    """
    RAM mode with grace period for early cleanup.
    
    Monitors /proc/<pid>/fd and automatically deletes RAM FCIDUMP after it's
    been closed continuously for the specified grace period. Useful for long
    calculations where FCIDUMP is read early and kept closed.
    """
    print("=" * 70)
    print("Example 2: RAM mode with grace period monitoring")
    print("=" * 70)
    
    runner = FCIDUMPRunner(gecco_bin="gecco.x", verbose=True)
    
    exit_code = runner.run(
        gecco_inp="large_calculation.inp",
        mode="ram",
        grace=600.0,   # Delete after 10 minutes of being closed
        interval=5.0   # Check every 5 seconds
    )
    
    print(f"Exit code: {exit_code}")
    print()


def example_disk_mode():
    """
    Disk mode for memory-constrained systems.
    
    Creates ./FCIDUMP directly in current working directory instead of using
    RAM. Slower but requires less memory.
    """
    print("=" * 70)
    print("Example 3: Disk mode execution")
    print("=" * 70)
    
    runner = FCIDUMPRunner(gecco_bin="gecco.x", verbose=True)
    
    exit_code = runner.run(
        gecco_inp="calculation.inp",
        mode="disk"
    )
    
    print(f"Exit code: {exit_code}")
    print()


def example_custom_fcidump_file():
    """
    Custom FCIDUMP filename with format auto-detection.
    
    Uses specified file instead of default search. Format is auto-detected
    by file signature (supports text, .bin, .bin.zst).
    """
    print("=" * 70)
    print("Example 4: Custom FCIDUMP filename")
    print("=" * 70)
    
    runner = FCIDUMPRunner(gecco_bin="gecco.x", verbose=True)
    
    # Use archived compressed FCIDUMP
    exit_code = runner.run(
        gecco_inp="job.inp",
        mode="ram",
        fcidump_filename="archived_integrals.bin.zst"
    )
    
    print(f"Exit code: {exit_code}")
    print()


def example_custom_output_file():
    """
    Custom output filename for GeCCo stdout.
    
    By default, stdout goes to <stem>.out. This example shows how to
    specify a custom output filename.
    """
    print("=" * 70)
    print("Example 5: Custom output filename")
    print("=" * 70)
    
    runner = FCIDUMPRunner(verbose=True)
    
    exit_code = runner.run(
        gecco_inp="calculation.inp",
        mode="ram",
        out_name="custom_output.log"
    )
    
    print(f"Exit code: {exit_code}")
    print()


def example_custom_binary_path():
    """
    Custom gecco.x executable path.
    
    Useful when gecco.x is not in PATH or when testing different versions.
    """
    print("=" * 70)
    print("Example 6: Custom GeCCo binary path")
    print("=" * 70)
    
    runner = FCIDUMPRunner(
        gecco_bin="/opt/gecco/bin/gecco.x",
        verbose=True
    )
    
    exit_code = runner.run(
        gecco_inp="test.inp",
        mode="ram"
    )
    
    print(f"Exit code: {exit_code}")
    print()


def example_quiet_execution():
    """
    Quiet execution (minimal output).
    
    Only essential information and errors are shown. Useful for batch
    processing or when logs are captured externally.
    """
    print("=" * 70)
    print("Example 7: Quiet execution")
    print("=" * 70)
    
    runner = FCIDUMPRunner(gecco_bin="gecco.x", verbose=False)
    
    exit_code = runner.run(
        gecco_inp="calculation.inp",
        mode="ram"
    )
    
    if exit_code == 0:
        print("Calculation completed")
    
    print()


def example_binary_fcidump():
    """
    Working with binary FCIDUMP files.
    
    Binary .bin files (FCIDUMP v5 format) are decoded in parallel using
    Cython/OpenMP when available, or pure Python fallback.
    """
    print("=" * 70)
    print("Example 8: Binary FCIDUMP handling")
    print("=" * 70)
    
    runner = FCIDUMPRunner(verbose=True)
    
    # Binary file will be auto-detected and decoded
    exit_code = runner.run(
        gecco_inp="calculation.inp",
        mode="ram",
        fcidump_filename="FCIDUMP.bin"
    )
    
    print(f"Exit code: {exit_code}")
    print()


def example_compressed_fcidump():
    """
    Working with compressed FCIDUMP files.
    
    Compressed .bin.zst files are decompressed and decoded automatically.
    Optimal for archival storage and network transfer.
    """
    print("=" * 70)
    print("Example 9: Compressed FCIDUMP handling")
    print("=" * 70)
    
    runner = FCIDUMPRunner(verbose=True)
    
    exit_code = runner.run(
        gecco_inp="calculation.inp",
        mode="ram",
        fcidump_filename="FCIDUMP.bin.zst"
    )
    
    print(f"Exit code: {exit_code}")
    print()


def example_production_workflow():
    """
    Production workflow with optimal settings.
    
    Combines RAM mode with grace period for memory efficiency in long
    calculations, verbose logging for monitoring, and custom paths.
    """
    print("=" * 70)
    print("Example 10: Production workflow")
    print("=" * 70)
    
    runner = FCIDUMPRunner(
        gecco_bin="gecco.x",
        verbose=True
    )
    
    # Production settings: RAM mode with grace, custom output
    exit_code = runner.run(
        gecco_inp="production_job.inp",
        mode="ram",
        grace=300.0,        # 5-minute grace period
        interval=2.0,       # Check every 2 seconds
        out_name="production.out"
    )
    
    if exit_code == 0:
        print("✓ Production run completed successfully")
        print("Check production.out for detailed results")
    else:
        print(f"✗ Production run failed with exit code {exit_code}")
        print("Check stderr output for error details")
    
    print()


def main():
    """Run all examples."""
    print("\n" + "=" * 70)
    print("pyscf2gecco.runner - FCIDUMPRunner Examples")
    print("=" * 70 + "\n")
    
    print("These examples demonstrate FCIDUMPRunner usage for executing")
    print("GeCCo calculations with intelligent FCIDUMP handling.\n")
    
    print("NOTE: Examples are for demonstration only. Actual execution")
    print("      requires valid input files and gecco.x executable.\n")
    
    # Uncomment examples to run (requires valid input files)
    
    # example_basic_ram_mode()
    # example_ram_mode_with_grace()
    # example_disk_mode()
    # example_custom_fcidump_file()
    # example_custom_output_file()
    # example_custom_binary_path()
    # example_quiet_execution()
    # example_binary_fcidump()
    # example_compressed_fcidump()
    # example_production_workflow()
    
    print("To run examples, uncomment function calls in main() and")
    print("ensure required input files exist in the working directory.")


if __name__ == "__main__":
    main()
