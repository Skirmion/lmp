#!/usr/bin/env python3
"""
Examples demonstrating GeccoInputBuilder and gen_inp utilities after pip installation.

This file shows comprehensive usage of all features available for generating
GeCCo/IC-MRCC input files from PySCF calculations.
"""

from pyscf import gto, scf, mcscf
from pyscf2gecco import GeccoInputBuilder
from pyscf2gecco import gen_inp
import os


def example_basic_input():
    """
    Example 1: Basic GeCCo input file generation.
    
    Demonstrates:
    - Creating simple molecule
    - Running CASSCF calculation
    - Generating basic GeCCo input file
    """
    print("=" * 70)
    print("Example 1: Basic GeCCo input generation")
    print("=" * 70)
    
    # Create H2 molecule
    mol = gto.M(
        atom='H 0 0 0; H 0 0 0.74',
        basis='6-31g',
        symmetry='D2h'
    )
    
    # Run CASSCF
    mf = scf.RHF(mol).run()
    mc = mcscf.CASSCF(mf, 2, 2)  # (2e, 2o) active space
    mc.run()
    
    # Generate GeCCo input using icMRCC template
    builder = GeccoInputBuilder(
        name="icMRCC",
        mol=mol,
        wf=mc,
        group="d2h"
    )
    
    builder.write()
    print("✓ icMRCC.inp generated successfully\n")


def example_with_symmetry():
    """
    Example 2: Input file with custom symmetry group.
    
    Demonstrates:
    - Specifying point group symmetry
    - Using symmetry-adapted orbitals
    - Automatic irrep detection
    """
    print("=" * 70)
    print("Example 2: GeCCo input with symmetry")
    print("=" * 70)
    
    # Create H2O with C2v symmetry
    mol = gto.M(
        atom='''
        O  0.0000  0.0000  0.0000
        H  0.7572  0.5865  0.0000
        H -0.7572  0.5865  0.0000
        ''',
        basis='cc-pvdz',
        symmetry='C2v'
    )
    
    mf = scf.RHF(mol).run()
    mc = mcscf.CASSCF(mf, 4, 4)  # (4e, 4o) active space
    mc.run()
    
    # Generate with explicit symmetry group
    builder = GeccoInputBuilder(
        name="icMRCC",
        mol=mol,
        wf=mc,
        group="c2v",  # C2v point group
        verbose=True
    )
    
    builder.write()
    print("✓ icMRCC.inp generated with C2v symmetry\n")


def example_orbital_spaces():
    """
    Example 3: Customizing orbital spaces.
    
    Demonstrates:
    - Defining core, active, virtual orbitals
    - Freezing orbitals
    - Deleting high-energy virtuals
    """
    print("=" * 70)
    print("Example 3: Custom orbital spaces")
    print("=" * 70)
    
    # Create NH3 molecule
    mol = gto.M(
        atom='''
        N  0.0000  0.0000  0.0000
        H  0.0000  0.9377  0.3816
        H  0.8121 -0.4689  0.3816
        H -0.8121 -0.4689  0.3816
        ''',
        basis='cc-pvdz',
        symmetry='Cs'
    )
    
    mf = scf.RHF(mol).run()
    mc = mcscf.CASSCF(mf, 6, 6)  # (6e, 6o) active space
    mc.run()
    
    # Define orbital spaces
    builder = GeccoInputBuilder(
        name="icMRCC",
        mol=mol,
        wf=mc,
        group="Cs",
        core_idx=[0],  # Freeze 1s of N as core
        active_idx=[1, 2, 3, 4, 5, 6],  # Active space orbitals
        frozen_idx=[0],  # Frozen core
        deleted_idx=None,  # Keep all virtuals
        debug_orb=False
    )
    
    builder.write()
    print("✓ icMRCC.inp generated with custom orbital spaces\n")


def example_method_parameters():
    """
    Example 4: Setting method-specific parameters.
    
    Demonstrates:
    - Configuring MR/MRCC parameters
    - Setting excitation levels
    - Controlling CI roots
    """
    print("=" * 70)
    print("Example 4: Method parameters")
    print("=" * 70)
    
    mol = gto.M(
        atom='Be 0 0 0',
        basis='6-31g',
        symmetry='D2h'
    )
    
    mf = scf.RHF(mol).run()
    mc = mcscf.CASSCF(mf, 2, 4)  # (2e, 4o) active space
    mc.run()
    
    # Set method parameters
    builder = GeccoInputBuilder(
        name="icMRCC",
        mol=mol,
        wf=mc,
        group="d2h",
        method_MR_maxexc=2,  # Maximum excitation level
        method_MR_minexc=0,  # Minimum excitation level
        method_MR_ciroot=1,  # Number of CI roots
        method_MRCC_maxcom_res=50,  # Max components in residuals
        method_MRCC_maxcom_en=50,   # Max components in energy
    )
    
    builder.write()
    print("✓ icMRCC.inp generated with method parameters\n")


def example_calculation_settings():
    """
    Example 5: Configuring calculation settings.
    
    Demonstrates:
    - Setting convergence criteria
    - Controlling iterations
    - Adjusting thresholds
    """
    print("=" * 70)
    print("Example 5: Calculation settings")
    print("=" * 70)
    
    mol = gto.M(
        atom='H 0 0 0; H 0 0 0.74',
        basis='cc-pvtz',
        symmetry='D2h'
    )
    
    mf = scf.RHF(mol).run()
    mc = mcscf.CASSCF(mf, 2, 2)
    mc.run()
    
    # Configure calculation settings
    builder = GeccoInputBuilder(
        name="icMRCC",
        mol=mol,
        wf=mc,
        group="d2h",
        calc_solve_maxiter=100,  # Maximum iterations
        calc_solve_conv=1e-8,  # Convergence threshold
        calc_routes_sv_thresh=1e-10,  # Singular value threshold
        calc_solve_non_linear_optref=True,  # Optimization reference
    )
    
    builder.write()
    print("✓ icMRCC.inp generated with calculation settings\n")


def example_memory_settings():
    """
    Example 6: Memory and output control.
    
    Demonstrates:
    - Setting memory limits
    - Controlling print level
    - Adjusting verbosity
    """
    print("=" * 70)
    print("Example 6: Memory and output settings")
    print("=" * 70)
    
    mol = gto.M(
        atom='Ne 0 0 0',
        basis='cc-pvdz'
    )
    
    mf = scf.RHF(mol).run()
    mc = mcscf.CASSCF(mf, 8, 10)  # (8e, 10o) active space
    mc.run()
    
    # Set memory and print level
    builder = GeccoInputBuilder(
        name="icMRCC",
        mol=mol,
        wf=mc,
        mem_gib=4.0,  # 4 GB memory limit
        printlvl=2,  # Print level (0=minimal, 3=debug)
        verbose=True
    )
    
    builder.write()
    print("✓ icMRCC.inp generated with memory settings\n")


def example_keyword_patches():
    """
    Example 7: Using keyword patches for advanced customization.
    
    Demonstrates:
    - Applying custom keyword patches
    - Overriding default parameters
    - Fine-tuning calculation parameters
    """
    print("=" * 70)
    print("Example 7: Keyword patches")
    print("=" * 70)
    
    mol = gto.M(
        atom='Li 0 0 0',
        basis='6-31g',
        spin = 1,
        charge=0
    )
    
    mf = scf.RHF(mol).run()
    mc = mcscf.CASSCF(mf, 4, 3)
    mc.run()
    
    # Define custom patches
    custom_patches = [
        {
            "block": "calculate",
            "subblock": "solve",
            "params": {"maxiter": 200, "conv": "1d-10"}
        },
        {
            "block": "method",
            "line": "MR",
            "params": {"maxexc": 3}
        }
    ]
    
    builder = GeccoInputBuilder(
        name="icMRCC",
        mol=mol,
        wf=mc,
        patches=custom_patches,  # Apply custom patches
        verbose=True
    )
    
    builder.write()
    print("✓ icMRCC.inp generated with keyword patches\n")


def example_custom_output_file():
    """
    Example 8: Specifying custom output filename.
    
    Demonstrates:
    - Setting custom output path
    - Organizing output files
    - Naming conventions
    """
    print("=" * 70)
    print("Example 8: Custom output filename")
    print("=" * 70)
    
    mol = gto.M(atom='He 0 0 0', basis='cc-pvqz')
    mf = scf.RHF(mol).run()
    mc = mcscf.CASSCF(mf, 2, 2)
    mc.run()
    
    # Specify custom output file
    builder = GeccoInputBuilder(
        name="icMRCC",
        mol=mol,
        wf=mc,
        outfile="custom_output/he_calculation.inp"  # Custom path
    )
    
    # Create directory if needed
    os.makedirs("custom_output", exist_ok=True)
    
    builder.write()
    print("✓ Custom output file: custom_output/he_calculation.inp\n")


def example_utility_functions():
    """
    Example 9: Using utility functions from gen_inp module.
    
    Demonstrates:
    - molpro_irrep: Get irrep information
    - spin_info: Extract spin/multiplicity
    - make_orb_lines: Generate orbital space lines
    - guess_mem_words: Estimate memory
    """
    print("=" * 70)
    print("Example 9: Utility functions")
    print("=" * 70)
    
    # Create test molecule
    mol = gto.M(
        atom='O 0 0 0',
        basis='6-31g',
        symmetry='D2h',
        spin=2  # Triplet
    )
    
    mf = scf.ROHF(mol).run()
    
    # Use molpro_irrep
    irrep_id, irrep_label = gen_inp.molpro_irrep(mf, mol)
    print(f"Molpro irrep: ID={irrep_id}, Label={irrep_label}")
    
    # Use spin_info
    ms2, mult = gen_inp.spin_info(mf, mol)
    print(f"Spin info: ms2={ms2}, multiplicity={mult}")
    
    # Use make_orb_lines
    orb_lines = gen_inp.make_orb_lines(
        nelec=mol.nelectron,
        mol=mol,
        wf=mf,
        group="d2h",
        core_idx=[0],
        active_idx=[1, 2, 3],
        frozen_idx=[0]
    )
    print(f"\nOrbital space lines:")
    for line in orb_lines:
        print(f"  {line}")
    
    # Use guess_mem_words
    mem_words = gen_inp.guess_mem_words()
    print(f"\nEstimated memory: {mem_words} words (~{mem_words*8/1e9:.2f} GB)")
    
    print("\n✓ Utility functions demonstrated\n")


def example_complete_workflow():
    """
    Example 10: Complete workflow with all features.
    
    Demonstrates:
    - Full production setup
    - Combining all options
    - Best practices
    """
    print("=" * 70)
    print("Example 10: Complete workflow")
    print("=" * 70)
    
    # Create CO molecule
    mol = gto.M(
        atom='''
        C  0.0  0.0  0.0
        O  0.0  0.0  1.128
        ''',
        basis='cc-pvtz',
        symmetry='C2v'
    )
    
    # Run calculations
    mf = scf.RHF(mol).run()
    mc = mcscf.CASSCF(mf, 6, 8)  # (6e, 8o) active space
    mc.run()
    
    # Define comprehensive setup
    custom_patches = [
        {
            "block": "calculate",
            "subblock": "solve",
            "params": {"conv": "1d-10"}
        }
    ]
    
    # Build complete input
    builder = GeccoInputBuilder(
        name="icMRCC",
        mol=mol,
        wf=mc,
        group="c2v",
        # Memory
        mem_gib=8.0,
        printlvl=2,
        # Calculation settings
        calc_solve_maxiter=150,
        calc_solve_conv=1e-10,
        calc_routes_sv_thresh=1e-12,
        # Method parameters
        method_MR_maxexc=2,
        method_MR_minexc=0,
        method_MR_ciroot=1,
        method_MRCC_maxcom_res=100,
        method_MRCC_maxcom_en=100,
        # Orbital spaces
        core_idx=[0, 1],  # 1s of C and O
        frozen_idx=[0, 1],  # Freeze core
        # Patches
        patches=custom_patches,
        # Output
        outfile="production/co_mrcc.inp",
        verbose=True
    )
    
    os.makedirs("production", exist_ok=True)
    builder.write()
    
    print("✓ Complete production input generated\n")


if __name__ == '__main__':
    print("\n")
    print("=" * 70)
    print("GeccoInputBuilder Examples - Complete Usage Guide")
    print("=" * 70)
    print("\n")
    
    # Run all examples
    example_basic_input()
    example_with_symmetry()
    example_orbital_spaces()
    example_method_parameters()
    example_calculation_settings()
    example_memory_settings()
    example_keyword_patches()
    example_custom_output_file()
    example_utility_functions()
    example_complete_workflow()
    
    print("=" * 70)
    print("All GeccoInputBuilder examples completed successfully!")
    print("=" * 70)
