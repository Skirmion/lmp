"""
Helper functions and preprocessing for FCIDUMP generation.

This module contains utility functions, dataclasses, and MO processing
routines used by FCIDumpWriter. It handles:
- PySCF object inspection and validation
- Molecular orbital preparation and sorting
- Symmetry labeling and bit operations
- Active space construction
- Additional operator collection and parsing
- Metadata preparation for binary format

All functions use explicit parameter passing (no kwargs).

Functions
---------
is_casscf_obj : Check if object is CASSCF
call_cas_natorb_only : Extract natural orbitals from CASSCF
label_orb_symm_safe : Safely label orbital symmetries with fallbacks
shape_tag : Determine operator type from array shape
collect_add_ops : Parse and collect additional operators
is_unrestricted : Check if MO coefficients are unrestricted
prepare_initial_mo : Extract and validate initial MO coefficients
prepare_mo_stage : Prepare and sort MOs by symmetry
build_active_space : Build active space after removing frozen orbitals
build_integral_components : Collect and prepare integral operators
prepare_user_metadata : Prepare metadata dictionary for binary format
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import List, Optional, Sequence, Tuple, Union

import numpy as np


# ============================================================================ #
#   PYSCF HELPER FUNCTIONS
# ============================================================================ #

def is_casscf_obj(x) -> bool:
    """
    Check if object is a CASSCF object.
    
    Parameters:
        x: Object to check
    
    Returns:
        True if x has CASSCF attributes
    """
    return all(hasattr(x, attr) for attr in ("ncore", "ncas", "ci", "fcisolver"))


def call_cas_natorb_only(mc):
    """
    Call mc.cas_natorb() and extract MO and occupations.
    
    Parameters:
        mc: CASSCF object
    
    Returns:
        (mo, occ) tuple where:
        - mo: natural orbitals
        - occ: occupations (or None)
    
    Raises:
        RuntimeError: if cas_natorb is not available
        ValueError: if output format is unexpected
    """
    fn = getattr(mc, "cas_natorb", None)
    if not callable(fn):
        raise RuntimeError("natorb=True requires mc.cas_natorb()")

    out = fn()
    if isinstance(out, (list, tuple)):
        if len(out) == 0:
            raise ValueError("cas_natorb() returned empty tuple")
        mo = np.asarray(out[0])
        occ = np.asarray(out[1]).ravel() if len(out) > 1 else None
    else:
        mo = np.asarray(out)
        occ = None

    nao = mc.mol.nao_nr()
    if mo.ndim != 2 or mo.shape[0] != nao:
        raise ValueError(f"cas_natorb(): unexpected MO shape {mo.shape} (nao={nao})")

    return mo, occ


def label_orb_symm_safe(mol, mo, *, verbose: bool = False):
    """
    Safely label orbital symmetries, with fallbacks.
    
    Tries:
    1. Direct label_orb_symm
    2. symmetrize_space then label_orb_symm
    3. Fallback to C1 (returns None for labels)
    
    Parameters:
        mol: PySCF molecule object
        mo: MO coefficients
        verbose: Print diagnostic messages
    
    Returns:
        (mo_result, labels) where:
        - mo_result: possibly symmetrized MO
        - labels: symmetry labels list or None (for C1)
    """
    from pyscf import symm
    
    try:
        labels = symm.label_orb_symm(mol, mol.irrep_name, mol.symm_orb, mo)
        return mo, labels
    except Exception as e1:  # noqa: BLE001
        if verbose:
            print(f"[SYMM] relabel failed ({type(e1).__name__}): trying symmetrize_space")
        try:
            mo_sym = symm.symmetrize_space(mol, mo)
            labels = symm.label_orb_symm(mol, mol.irrep_name, mol.symm_orb, mo_sym)
            if verbose:
                print("[SYMM] symmetrize_space succeeded")
            return mo_sym, labels
        except Exception as e2:  # noqa: BLE001
            if verbose:
                print(f"[SYMM] symmetrize_space failed ({type(e2).__name__}); fallback to C1")
            return mo, None


# ============================================================================ #
#   DATACLASSES
# ============================================================================ #

@dataclass(slots=True)
class MOSortResult:
    """Result of MO sorting and preparation."""
    mo_prepared: np.ndarray
    mo_sorted: np.ndarray
    perm: List[int]
    irreps_sorted: Optional[List[str]]
    force_c1: bool


@dataclass(slots=True)
class ActiveSpaceData:
    """Active space configuration."""
    frozen_idx: List[int]
    norb: int
    nelec: int
    ms2: int
    orbsym_ids_full_sorted: List[int]
    orbsym_ids_active: List[int]
    orbsym_bits_active: np.ndarray


# ============================================================================ #
#   UTILITY FUNCTIONS
# ============================================================================ #

def shape_tag(arr: np.ndarray) -> Optional[str]:
    """
    Determine if array is 1e or 2e.
    
    Parameters:
        arr: numpy array
    
    Returns:
        "1e" for square 2D arrays
        "2e" for 4D arrays with all dimensions equal
        None otherwise
    """
    if arr.ndim == 2 and arr.shape[0] == arr.shape[1]:
        return "1e"
    if arr.ndim == 4 and len({arr.shape[0], arr.shape[1], arr.shape[2], arr.shape[3]}) == 1:
        return "2e"
    return None


def collect_add_ops(
    mol,
    add_ops: Sequence[Union[str, Tuple[str, np.ndarray]]] | None,
    *,
    verbose: bool = False,
) -> Tuple[Optional[np.ndarray], List[str], List[np.ndarray], Optional[List[str]]]:
    """
    Parse and collect additional integral operators.
    
    This function processes the add_ops parameter from FCIDumpWriter and
    separates operators into 1e and 2e categories. It supports:
    - PySCF integral names (e.g., "int1e_kin", "int2e_ip1")
    - Custom operators as (name, array) tuples
    
    Parameters
    ----------
    mol : pyscf.gto.Mole
        PySCF molecule object (for computing integrals from names).
    add_ops : Sequence[str | Tuple[str, np.ndarray]], optional
        Additional operators to include. Each element can be:
        
        - str starting with "int1e_": PySCF 1e integral name
          (computed via mol.intor(), then added to h_core)
        - str starting with "int2e_": PySCF 2e integral name
          (added to 2e integrals list)
        - Tuple[str, np.ndarray]: Custom operator with name and array
          * Shape (n,n) → 1e operator (added to h_core)
          * Shape (n,n,n,n) → 2e operator (added to 2e section)
    verbose : bool, optional
        Print warning messages for failed operations. Default is False.
    
    Returns
    -------
    dh : np.ndarray or None
        Accumulated 1e operator matrix (sum of all 1e contributions).
        None if no 1e operators provided.
    intor2 : List[str]
        List of PySCF 2e integral names to compute.
    extra2e : List[np.ndarray]
        List of explicit 2e operator arrays.
    meta : List[str] or None
        List of operator names for metadata (None if add_ops is None).
    
    Notes
    -----
    - All 1e operators are summed into a single matrix dh.
    - 2e operators are kept separate (to be added after MO transformation).
    - Invalid operators are skipped with warnings (if verbose=True).
    
    Examples
    --------
    >>> dh, intor2, extra2e, meta = collect_add_ops(
    ...     mol,
    ...     ["int1e_kin", "int2e_ip1", ("my_op", my_1e_array)],
    ...     verbose=True
    ... )
    >>> print(meta)
    ['int1e_kin', 'int2e_ip1', 'my_op']
    """
    dh: Optional[np.ndarray] = None
    intor2: List[str] = []
    extra2e: List[np.ndarray] = []
    meta: Optional[List[str]] = None if add_ops is None else []

    if not add_ops:
        return dh, intor2, extra2e, meta

    for item in add_ops:
        if isinstance(item, str):
            if meta is not None:
                meta.append(item)
            if item.startswith("int1e_"):
                try:
                    arr = mol.intor(item)
                except Exception as err:  # noqa: BLE001
                    if verbose:
                        print(f"[WARN] skip {item}: {err}")
                    continue
                dh = arr if dh is None else dh + arr
            else:
                intor2.append(item)
            continue

        if isinstance(item, tuple) and len(item) == 2:
            name, arr = item
            if meta is not None:
                meta.append(name)
            tag = shape_tag(arr)
            if tag == "1e":
                dh = arr if dh is None else dh + arr
            elif tag == "2e":
                extra2e.append(arr)
            else:
                if verbose:
                    print(f"[WARN] unknown ndarray shape for {name}: {arr.shape}")
            continue

        if verbose:
            print(f"[WARN] unknown add_ops item: {item!r}")

    return dh, intor2, extra2e, meta


def is_unrestricted(mo_coeff) -> bool:
    """
    Check if MO coefficients are unrestricted.
    
    Parameters:
        mo_coeff: MO coefficients from PySCF
    
    Returns:
        True if unrestricted (tuple/list), False otherwise
    """
    return isinstance(mo_coeff, (list, tuple))


# ============================================================================ #
#   MO PREPARATION
# ============================================================================ #

def prepare_initial_mo(
    method,
    *,
    natorb: bool,
    verbose: bool,
    extended_debug: bool,
    mo_coeff_custom: Optional[np.ndarray] = None,
) -> np.ndarray:
    """
    Prepare initial MO coefficients.
    
    Extracts MO from method, optionally applies natural orbital transformation.
    
    Parameters:
        method: PySCF method object with mo_coeff
        natorb: Apply natural orbital transformation if CASSCF
        verbose: Print detailed messages
        extended_debug: Print NO occupations
        mo_coeff_custom: Custom MO coefficients (overrides method.mo_coeff)
    
    Returns:
        MO coefficient matrix (nao × nmo)
    
    Raises:
        RuntimeError: if method.mo_coeff is not available and mo_coeff_custom is None
        NotImplementedError: if unrestricted MO coefficients
    """
    # If custom MO provided, use it and warn if natorb is True
    if mo_coeff_custom is not None:
        if natorb and verbose:
            print("[PREP] Warning: natorb=True ignored because custom mo_coeff provided")
        mo = np.asarray(mo_coeff_custom)
        if mo.ndim != 2:
            raise ValueError(f"Custom mo_coeff must be 2D, got shape {mo.shape}")
        return mo
    
    mo0 = getattr(method, "mo_coeff", None)
    if mo0 is None:
        raise RuntimeError("method.mo_coeff is required when mo_coeff_custom is not provided")
    if is_unrestricted(mo0):
        raise NotImplementedError("Current workflow assumes restricted (R) mo_coeff.")

    mo_prep = mo0
    no_occ = None
    if natorb:
        if not is_casscf_obj(method):
            if verbose:
                print("[PREP] Active NO skipped: method is not CASSCF/UCASSCF.")
        else:
            # Inline temporary_mc_mos functionality
            old_mo = method.mo_coeff
            method.mo_coeff = mo_prep
            try:
                mo_no, no_occ = call_cas_natorb_only(method)
                if verbose:
                    print("[PREP] Active NO via method.cas_natorb()")
            finally:
                method.mo_coeff = old_mo
            mo_prep = mo_no
            if extended_debug and no_occ is not None:
                print(
                    "[PREP][NO] active occupations (min..max) = "
                    f"[{float(no_occ.min()):.6f} .. {float(no_occ.max()):.6f}]"
                )

    mo = np.asarray(mo_prep)
    if mo.ndim != 2:
        if verbose:
            print(f"[PREP] Unexpected MO ndim={mo.ndim}; reverting to method.mo_coeff.")
        mo = np.asarray(method.mo_coeff)
    return mo


def prepare_mo_stage(
    mol,
    method,
    *,
    natorb: bool,
    sort_by_symmetry: bool,
    verbose: bool,
    extended_debug: bool,
    mo_coeff_custom: Optional[np.ndarray] = None,
) -> MOSortResult:
    """
    Prepare and sort MO coefficients with symmetry labeling.
    
    Steps:
    1. Get initial MO (with optional NO transformation or custom MO)
    2. Label orbital symmetries
    3. Sort by symmetry if requested
    
    Parameters:
        mol: PySCF molecule object
        method: PySCF method object
        natorb: Apply natural orbitals (ignored if mo_coeff_custom provided)
        sort_by_symmetry: Sort MOs by symmetry
        verbose: Print messages
        extended_debug: Extended debug output
        mo_coeff_custom: Custom MO coefficients array
    
    Returns:
        MOSortResult with prepared and sorted MOs
    """
    from .fmt import MOLPRO_ID
    
    mo_initial = prepare_initial_mo(
        method,
        natorb=natorb,
        verbose=verbose,
        extended_debug=extended_debug,
        mo_coeff_custom=mo_coeff_custom,
    )
    
    mo_sym, irreps_all = label_orb_symm_safe(
        mol,
        mo_initial,
        verbose=verbose,
    )

    if irreps_all is None:
        if verbose:
            print("[SYMM] Falling back to C1: no symmetry sorting and ORBSYM=1")
        perm = list(range(mo_initial.shape[1]))
        return MOSortResult(
            mo_prepared=mo_initial,
            mo_sorted=mo_initial,
            perm=perm,
            irreps_sorted=None,
            force_c1=True,
        )

    mo_work = mo_sym
    if sort_by_symmetry:
        perm = sorted(
            range(mo_work.shape[1]),
            key=lambda i: MOLPRO_ID[mol.groupname][irreps_all[i]],
        )
    else:
        perm = list(range(mo_work.shape[1]))

    irreps_sorted = [irreps_all[i] for i in perm]
    mo_sorted = mo_work[:, perm]

    return MOSortResult(
        mo_prepared=mo_work,
        mo_sorted=mo_sorted,
        perm=perm,
        irreps_sorted=irreps_sorted,
        force_c1=False,
    )


# ============================================================================ #
#   ACTIVE SPACE CONSTRUCTION
# ============================================================================ #

def build_active_space(
    mol,
    stage: MOSortResult,
    frozen_indices: Sequence[int],
) -> ActiveSpaceData:
    """
    Build active space configuration.
    
    Determines:
    - Frozen orbital indices (in sorted MO basis)
    - Active orbital indices
    - Number of active orbitals and electrons
    - Orbital symmetry IDs and bits
    
    Parameters:
        mol: PySCF molecule object
        stage: MO sorting result
        frozen_indices: Original frozen orbital indices
    
    Returns:
        ActiveSpaceData with complete active space information
    """
    from .fmt import MOLPRO_ID, ORBSYM_BITS
    
    frozen_idx = sorted(stage.perm.index(i) for i in frozen_indices)
    active_idx = [i for i in range(stage.mo_sorted.shape[1]) if i not in frozen_idx]

    norb = len(active_idx)
    nelec = mol.nelectron - 2 * len(frozen_idx)
    ms2 = mol.spin

    if stage.force_c1 or stage.irreps_sorted is None:
        orbsym_ids_full_sorted = [1] * stage.mo_sorted.shape[1]
        orbsym_ids_active = [1] * norb
        orbsym_bits_active = np.zeros(norb, dtype=np.int32)
    else:
        irrep_map = MOLPRO_ID[mol.groupname]
        bit_map = ORBSYM_BITS[mol.groupname]
        orbsym_ids_full_sorted = [irrep_map[label] for label in stage.irreps_sorted]
        orbsym_ids_active = [irrep_map[stage.irreps_sorted[i]] for i in active_idx]
        orbsym_bits_active = np.array(
            [bit_map[stage.irreps_sorted[i]] for i in active_idx],
            dtype=np.int32,
        )

    return ActiveSpaceData(
        frozen_idx=list(frozen_idx),
        norb=norb,
        nelec=nelec,
        ms2=ms2,
        orbsym_ids_full_sorted=list(orbsym_ids_full_sorted),
        orbsym_ids_active=list(orbsym_ids_active),
        orbsym_bits_active=orbsym_bits_active,
    )


# ============================================================================ #
#   INTEGRAL COMPONENTS
# ============================================================================ #

def build_integral_components(
    mol,
    stage: MOSortResult,
    active: ActiveSpaceData,
    add_ops: Optional[Sequence],
    verbose: bool,
) -> Tuple[np.ndarray, Optional[np.ndarray], Tuple[str, ...], List[np.ndarray], Optional[List[str]]]:
    """
    Build integral components from additional operators.
    
    Processes add_ops to extract:
    - 1e operator corrections (dh)
    - 2e integral names (intor2)
    - Explicit 2e arrays (extra2e)
    - Metadata list
    
    Also computes active MO coefficients.
    
    Parameters:
        mol: PySCF molecule
        stage: MO sorting result
        active: Active space data
        add_ops: Additional operators list
        verbose: Print warnings
    
    Returns:
        Tuple of:
        - mo_active: active MO coefficients
        - dh: 1e operator correction (or None)
        - twoe_intor: tuple of 2e integral names
        - twoe_extra: list of explicit 2e arrays
        - add_ops_meta: metadata list (or None)
    """
    dh, intor2, extra2e, add_ops_meta = collect_add_ops(
        mol,
        add_ops,
        verbose=verbose,
    )

    # Compute active_idx dynamically
    frozen_idx_set = set(active.frozen_idx)
    active_idx = [i for i in range(stage.mo_sorted.shape[1]) if i not in frozen_idx_set]
    
    mo_active = stage.mo_sorted[:, active_idx]
    twoe_intor = ("int2e", *intor2)
    twoe_extra = list(extra2e)

    return mo_active, dh, twoe_intor, twoe_extra, add_ops_meta


# ============================================================================ #
#   METADATA PREPARATION
# ============================================================================ #

def prepare_user_metadata(
    mol,
    *,
    tol: float,
    granularity: int,
    natorb: bool,
    sort_by_symmetry: bool,
    frozen_idx: Sequence[int],
    source_file: Optional[str],
    add_ops_meta: Optional[List[str]],
    twoe_extra: Sequence[np.ndarray],
) -> dict:
    """
    Prepare user metadata for binary format.
    
    Collects:
    - Computation parameters (tol, granularity, etc.)
    - Molecular geometry
    - Basis and ECP information
    - Additional integrals metadata
    
    Parameters:
        mol: PySCF molecule
        tol: Integral threshold
        granularity: Chunking granularity
        natorb: Natural orbitals flag
        sort_by_symmetry: Symmetry sorting flag
        frozen_idx: Frozen orbital indices
        source_file: Source file path for basis/ECP
        add_ops_meta: Additional operators metadata
        twoe_extra: Additional 2e integral arrays
    
    Returns:
        Dictionary with user metadata
    """
    from .metadata_utils import get_atom_geometry, get_basis_ecp_blocks_from_file
    
    user_meta = {
        "tol": tol,
        "granularity": granularity,
        "natorb": natorb,
        "sort_by_symmetry": sort_by_symmetry,
    }
    
    # Add frozen_idx only if non-empty
    if frozen_idx:
        user_meta["frozen_idx"] = list(frozen_idx)
    
    # Add geometry
    try:
        geometry_unit = mol.unit
        geometry = get_atom_geometry(mol, unit=geometry_unit)
        if geometry:
            user_meta["geometry"] = {
                "unit": geometry_unit,
                "atoms": geometry,
            }
    except Exception:
        pass
    
    # Add basis and ECP information
    if source_file:
        try:
            info = get_basis_ecp_blocks_from_file(mol, source_file)
            user_meta["source_file"] = str(source_file)
            
            # For basis: write hint if available, otherwise block
            basis_hint = info.get("basis_hint")
            basis_block = info.get("basis_block")
            if basis_hint:
                user_meta["basis"] = basis_hint
            elif basis_block:
                user_meta["basis"] = basis_block
            
            # For ECP: write hint if available, otherwise block
            ecp_hint = info.get("ecp_hint")
            ecp_block = info.get("ecp_block")
            if ecp_hint:
                user_meta["ecp"] = ecp_hint
            elif ecp_block:
                user_meta["ecp"] = ecp_block
        except Exception:
            pass
    
    # Separate additional integrals into 1e and 2e
    if add_ops_meta:
        add_1e = []
        add_2e = []
        for op in add_ops_meta:
            # Determine operator type by name
            if "1e" in str(op).lower() or op.startswith("h_"):
                add_1e.append(op)
            else:
                add_2e.append(op)
        
        if add_1e:
            user_meta["add_1e_integrals"] = add_1e
        if add_2e:
            user_meta["add_2e_integrals"] = add_2e
    
    # Add dimensions of additional 2e integrals if present
    twoe_shapes = [tuple(arr.shape) for arr in twoe_extra]
    if twoe_shapes:
        user_meta["twoe_extra_shapes"] = [list(s) for s in twoe_shapes]
    
    return user_meta
