"""
PySCF to GECCO Converter.

Main module for converting PySCF molecular integrals to FCIDUMP format
optimized for GECCO quantum chemistry software.

This module provides a high-level interface for generating FCIDUMP files
from PySCF calculations with support for multiple output formats (text,
binary, compressed), custom molecular orbitals, frozen core approximation,
and additional integral operators.

Public API:
    FCIDumpWriter: High-level class for automated FCIDUMP generation.

Example:
    >>> from pyscf2gecco import FCIDumpWriter
    >>> writer = FCIDumpWriter(mol, method, granularity=50, tol=1e-15)
    >>> writer.run('FCIDUMP')
"""

from __future__ import annotations

import gc
import os
import sys
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Tuple

import numpy as np
import psutil  # type: ignore

from .fmt import header_lines
from .integrals_one_e import build_frozen_core, append_one_e_section, append_constant
from .integrals_two_e import write_two_e_fcidump
from .metadata_utils import write_metadata

# Import zstd_codec with fallback for different import contexts
try:
    from ..archiver.zstd_codec import compress_zstd_file
except (ImportError, ValueError):
    # Fallback for when fc_gen is imported directly
    try:
        import sys
        from pathlib import Path
        parent_dir = Path(__file__).parent.parent
        if str(parent_dir) not in sys.path:
            sys.path.insert(0, str(parent_dir))
        from archiver.zstd_codec import compress_zstd_file
    except ImportError:
        # Zstd codec not available
        compress_zstd_file = None

# Import symmetry utilities
try:
    from ..gen_inp.sym import molpro_irrep, spin_info
except (ImportError, ValueError):
    # Fallback for when fc_gen is imported directly
    try:
        import sys
        from pathlib import Path
        parent_dir = Path(__file__).parent.parent
        if str(parent_dir) not in sys.path:
            sys.path.insert(0, str(parent_dir))
        from gen_inp.sym import molpro_irrep, spin_info
    except ImportError:
        # Symmetry utilities not available - use default
        def molpro_irrep(obj, mol):
            return 1, "A"
        def spin_info(obj, mol):
            ms = int(getattr(obj, "spin", getattr(mol, "spin", 0)))
            return ms, abs(ms) + 1

from .fc_utils import (
    prepare_mo_stage,
    build_active_space,
    build_integral_components,
    prepare_user_metadata,
)

__all__ = ["FCIDumpWriter"]
__version__ = "1.0.0"




# ============================================================================ #
#   UTILITY FUNCTIONS
# ============================================================================ #


def _rss_mb() -> float:
    """
    Get current resident set size (RSS) memory usage.

    Returns
    -------
    float
        Current RSS memory in megabytes.
    """
    return psutil.Process(os.getpid()).memory_info().rss / 1024 ** 2


def _log_mem(tag: str, store: List[Tuple[str, float]], enable: bool) -> None:
    """
    Log current memory usage with a descriptive tag.

    Parameters
    ----------
    tag : str
        Description of the checkpoint.
    store : List[Tuple[str, float]]
        List to store (tag, memory) tuples.
    enable : bool
        If False, logging is skipped.
    """
    if enable:
        mb = _rss_mb()
        print(f"[MEM] {tag:<40}{mb:8.1f} MB")
        store.append((tag, mb))


def _log_time(
    tag: str,
    store: List[Tuple[str, float]],
    enable: bool,
    start_time: float
) -> None:
    """
    Log elapsed time since start_time with a descriptive tag.

    Parameters
    ----------
    tag : str
        Description of the checkpoint.
    store : List[Tuple[str, float]]
        List to store (tag, elapsed_time) tuples.
    enable : bool
        If False, logging is skipped.
    start_time : float
        Reference start time (from time.time()).
    """
    if enable:
        elapsed = time.time() - start_time
        print(f"[TIME] {tag:<40}{elapsed:8.3f} s")
        store.append((tag, elapsed))


# ============================================================================ #
#   FCIDUMPWRITER - Main Public API
# ============================================================================ #


class FCIDumpWriter:
    """
    High-level interface for generating FCIDUMP files from PySCF calculations.

    This class handles the complete workflow of converting PySCF molecular
    integrals to FCIDUMP format, including:
    - Molecular orbital preparation and sorting by symmetry
    - Frozen core approximation
    - Natural orbital transformation (for CASSCF)
    - Custom MO coefficient input
    - Additional integral operators
    - Multiple output formats (text, binary, compressed)
    - Memory profiling and performance monitoring

    Parameters
    ----------
    mol : pyscf.gto.Mole
        PySCF molecule object containing geometry, basis, and symmetry info.
    method : pyscf.scf.RHF or pyscf.mcscf.CASSCF
        PySCF calculation object with computed mo_coeff attribute.
    format : str, optional
        Output format: "txt" (plain text), "bin" (binary), or "zst" (compressed).
        Default is "bin".
    tol : float, optional
        Integral threshold; integrals with |value| <= tol are discarded.
        Default is 1e-20.
    granularity : int, optional
        Chunking granularity for parallel processing. If 0, uses fully parallel
        mode. If >0, processes integrals in chunks of this size. The remainder
        is always distributed uniformly across all chunks. Default is 0.
    extended_debug : bool, optional
        Enable detailed memory and time profiling. Default is True.
    verbose : bool, optional
        Print diagnostic messages during MO preparation. Default is False.
    sort_by_symmetry : bool, optional
        Sort molecular orbitals by irreducible representation. Default is True.
    natorb : bool, optional
        For CASSCF objects, transform to natural orbitals before FCIDUMP generation.
        Ignored if mo_coeff is provided. Default is True.
    frozen_indices : Sequence[int], optional
        Indices of orbitals to freeze (0-based, in original MO order).
        These orbitals are integrated out using frozen core approximation.
        Default is empty (no frozen orbitals).
    add_ops : Sequence[str | Tuple[str, np.ndarray]], optional
        Additional integral operators to include. Each element can be:
        
        - str starting with "int1e_": PySCF 1-electron integral name
          (added to h_core, e.g., "int1e_kin", "int1e_nuc").
        - str starting with "int2e_": PySCF 2-electron integral name
          (added to 2e section, e.g., "int2e_ip1").
        - Tuple[str, np.ndarray]: Custom operator with name and array.
          * Shape (n,n) → 1e operator (added to h_core).
          * Shape (n,n,n,n) → 2e operator (added to 2e section).
        
        Default is None (no additional operators).
    mo_coeff : np.ndarray, optional
        Custom MO coefficient matrix with shape (n_ao, n_mo). If provided,
        this overrides method.mo_coeff and natorb is ignored with a warning.
        Default is None (use method.mo_coeff).

    Attributes
    ----------
    norb : int
        Number of active orbitals (after frozen core removal).
    nelec : int
        Number of active electrons (after frozen core removal).
    ms2 : int
        Spin multiplicity (2S).
    isym : int
        Molpro symmetry ID for the wavefunction irreducible representation.
    isym_label : str
        Symmetry label corresponding to isym (e.g., "A1", "Ag").
    frozen_idx : List[int]
        Frozen orbital indices in sorted MO basis.
    orbsym_ids_active : List[int]
        Molpro symmetry IDs for active orbitals.

    Methods
    -------
    run(outfile, info_file=None)
        Generate FCIDUMP file(s) and metadata.

    Notes
    -----
    - When granularity > 0, the remainder from dividing n_orbitals by granularity
      is distributed uniformly: the first (remainder) chunks get +1 orbital each.
    - For "zst" format, a binary file is created first, then compressed with zstd,
      and the intermediate .bin file is removed.
    - The source file (basis/ECP definitions) is auto-detected from sys.argv[0].
    - Metadata is written to FCIDUMP_info.txt in the same directory as outfile.

    Examples
    --------
    Basic usage with CASSCF natural orbitals:

    >>> from pyscf import gto, scf, mcscf
    >>> from pyscf2gecco import FCIDumpWriter
    >>> mol = gto.M(atom='H 0 0 0; H 0 0 0.74', basis='cc-pvdz')
    >>> mf = scf.RHF(mol).run()
    >>> mc = mcscf.CASSCF(mf, 2, 2).run()
    >>> writer = FCIDumpWriter(mol, mc, natorb=True, tol=1e-15)
    >>> writer.run('FCIDUMP')

    Frozen core with custom MO and additional operators:

    >>> import numpy as np
    >>> mo_custom = np.loadtxt('my_mos.txt')
    >>> writer = FCIDumpWriter(
    ...     mol, mf,
    ...     mo_coeff=mo_custom,
    ...     frozen_indices=[0, 1],
    ...     add_ops=["int1e_kin", ("my_2e_op", my_2e_array)],
    ...     format="zst",
    ...     granularity=50
    ... )
    >>> writer.run('FCIDUMP.bin.zst')
    """

    def __init__(
        self,
        mol,
        method,
        format: str = "bin",
        tol: float = 1e-20,
        granularity: int = 0,
        extended_debug: bool = True,
        verbose: bool = False,
        sort_by_symmetry: bool = True,
        natorb: bool = True,
        frozen_indices: Sequence[int] = (),
        add_ops: Optional[Sequence[Any]] = None,
        mo_coeff: Optional[np.ndarray] = None,
    ):
        self.mol = mol
        self.method = method
        self.format = format
        self.tol = float(tol)
        self.granularity = int(granularity)
        self.extended_debug = bool(extended_debug)
        self.verbose = bool(verbose)
        self.sort_by_symmetry = bool(sort_by_symmetry)
        self.natorb = bool(natorb)
        self.frozen_indices = list(frozen_indices)
        self.add_ops = add_ops
        self.mo_coeff = mo_coeff

        # Basic PySCF attributes
        self.ms2 = getattr(mol, "spin", None)
        self.nelec_total = getattr(mol, "nelectron", None)

        # Auto-detect source file for basis/ECP metadata
        argv0 = sys.argv[0] if sys.argv else None
        if argv0 and argv0 not in {"", "-c", "-m"}:
            try:
                self.source_file = Path(argv0).resolve()
            except Exception:  # noqa: BLE001
                self.source_file = None
        else:
            self.source_file = None

        # Profiling attributes
        self._mem_on = bool(extended_debug)
        self._mem_log: List[Tuple[str, float]] = []
        self._time_log: List[Tuple[str, float]] = []
        self._time_pyscf = 0.0
        self._time_processing = 0.0

        # Prepare all parameters at initialization
        self._prepare_parameters()

    # ──────────────────────────────────────────────────────────────────────── #
    #   Internal methods
    # ──────────────────────────────────────────────────────────────────────── #

    def _build_header(self) -> Sequence[str]:
        """
        Generate FCIDUMP header lines.

        Returns
        -------
        Sequence[str]
            List of header strings for the FCIDUMP file.
        """
        orbsym_str = ",".join(map(str, self.orbsym_ids_active)) if self.orbsym_ids_active else ""
        return header_lines(self.norb, self.nelec, self.ms2, orbsym_str, self.isym)

    def _write_two_e(
        self,
        outfile: str,
        header: Sequence[str],
        writer_mode: str,
        h_fc=None,
        e_const=None
    ) -> None:
        """
        Write two-electron integrals to FCIDUMP file.

        For binary format, also writes 1e integrals and constant if provided.

        Parameters
        ----------
        outfile : str
            Output file path.
        header : Sequence[str]
            FCIDUMP header lines.
        writer_mode : str
            Writer mode: "txt" or "bin".
        h_fc : np.ndarray, optional
            Frozen-core Hamiltonian (for binary format only).
        e_const : float, optional
            Energy constant (for binary format only).
        """
        # Prepare metadata for binary format
        user_meta = self._prepare_user_metadata() if writer_mode == 'bin' else None

        pyscf_time, processing_time = write_two_e_fcidump(
            mol=self.mol,
            mo=self.mo_active,
            file_path=outfile,
            writer_mode=writer_mode,
            header=header,
            norb=self.norb,
            nelec=self.nelec,
            ms2=self.ms2,
            orbsym_ids=self.orbsym_ids_active,
            isym=self.isym,
            tol=self.tol,
            log_fn=lambda t: _log_mem(t, self._mem_log, self._mem_on),
            granularity=self.granularity,
            intor=self.twoe_intor,
            ao2e_extra=self.twoe_extra,
            frozen=None,
            orbsym_bits=self.orbsym_bits_active,
            # Additional parameters for binary format
            h_fc=h_fc,
            e_const=e_const,
            mo_prepared_full=self.mo_prepared_full if writer_mode == 'bin' else None,
            perm=self.perm if writer_mode == 'bin' else None,
            frozen_idx=self.frozen_idx if writer_mode == 'bin' else None,
            orbsym_sorted=self.orbsym_ids_full_sorted if writer_mode == 'bin' else None,
            user_meta=user_meta,
            extended_debug=self._mem_on,
        )

        # Accumulate timing
        self._time_pyscf += pyscf_time
        self._time_processing += processing_time

    def _build_frozen_core(self) -> Tuple[np.ndarray, float]:
        """
        Compute frozen-core Hamiltonian and energy constant.

        Returns
        -------
        Tuple[np.ndarray, float]
            - h_fc: Frozen-core effective Hamiltonian matrix.
            - e_const: Nuclear + frozen orbital energy constant.
        """
        # Compute occupations based on frozen_idx
        occ = [2.0] * len(self.frozen_idx)

        h_fc, e_const, pyscf_time = build_frozen_core(
            mol=self.mol,
            method=self.method,
            mo_sorted=self.mo_sorted,
            frozen_idx=self.frozen_idx,
            occ=occ,
            extra1e=self.extra_one_e,
        )

        # Accumulate PySCF time
        if self._mem_on:
            self._time_pyscf += pyscf_time

        return h_fc, e_const

    def _write_one_e(self, outfile: str, h_fc: np.ndarray) -> None:
        """
        Append one-electron integrals to FCIDUMP file.

        Parameters
        ----------
        outfile : str
            Output file path.
        h_fc : np.ndarray
            Frozen-core Hamiltonian matrix.
        """
        append_one_e_section(
            file_path=outfile,
            h_fc=h_fc,
            mo_prepared_full=self.mo_prepared_full,
            perm=self.perm,
            frozen_idx=self.frozen_idx,
            tol=self.tol,
            log_fn=lambda t: _log_mem(t, self._mem_log, self._mem_on),
            orbsym_sorted=self.orbsym_ids_full_sorted,
        )

    def _write_constant(self, outfile: str, e_const: float) -> None:
        """
        Append energy constant to FCIDUMP file.

        Parameters
        ----------
        outfile : str
            Output file path.
        e_const : float
            Energy constant (nuclear + frozen orbital contributions).
        """
        append_constant(outfile, e_const)

    def _prepare_user_metadata(self) -> dict:
        """
        Prepare complete user metadata for binary format.

        Returns
        -------
        dict
            Dictionary containing metadata (geometry, basis, ECP, parameters).
        """
        return prepare_user_metadata(
            self.mol,
            tol=self.tol,
            granularity=self.granularity,
            natorb=self.natorb,
            sort_by_symmetry=self.sort_by_symmetry,
            frozen_idx=self.frozen_idx,
            source_file=self.source_file,
            add_ops_meta=self.add_ops_meta,
            twoe_extra=self.twoe_extra,
        )

    def _write_metadata(self, info_file: str) -> None:
        """
        Write metadata file (FCIDUMP_info.txt).

        Parameters
        ----------
        info_file : str
            Path to metadata file.
        """
        # Compute active_idx dynamically
        active_idx = [i for i in range(self.mo_sorted.shape[1]) if i not in self.frozen_idx]

        # Compute orbsym_str dynamically
        orbsym_str = ",".join(map(str, self.orbsym_ids_active)) if self.orbsym_ids_active else ""

        twoe_shapes = [tuple(arr.shape) for arr in self.twoe_extra]
        write_metadata(
            self.mol,
            info_file,
            norb=self.norb,
            nelec=self.nelec,
            ms2=self.ms2,
            force_c1=self.force_c1,
            natorb=self.natorb,
            sort_by_symmetry=self.sort_by_symmetry,
            granularity=self.granularity,
            tol=self.tol,
            frozen_idx=self.frozen_idx,
            active_idx=active_idx,
            orbsym_ids_active=self.orbsym_ids_active,
            orbsym_bits_active=self.orbsym_bits_active,
            orbsym_str=orbsym_str,
            perm=self.perm,
            add_ops=self.add_ops_meta,
            twoe_intor=self.twoe_intor,
            twoe_extra_shapes=twoe_shapes,
            source_file=self.source_file,
        )

    def _summary(self) -> None:
        """
        Print memory and time profiling summary.

        Displays:
        - Memory usage at each checkpoint
        - Time elapsed at each checkpoint
        - Breakdown by operation type (PySCF, processing, other)
        """
        print("\n" + "=" * 70)
        print("=== MEMORY PROFILE ===")
        print("=" * 70)
        for tag, mb in self._mem_log:
            print(f"{tag:<45}{mb:10.1f} MB")

        print("\n" + "=" * 70)
        print("=== TIME PROFILE ===")
        print("=" * 70)
        for tag, seconds in self._time_log:
            print(f"{tag:<45}{seconds:10.3f} s")

        # Compute breakdown by operation type
        if self._time_log:
            total_time = next((t for tag, t in self._time_log if "TOTAL" in tag), 0.0)
            pyscf_time = self._time_pyscf
            processing_time = self._time_processing

            # Other time = total - pyscf - processing
            other_time = total_time - pyscf_time - processing_time

            print("\n" + "=" * 70)
            print("=== TIME BREAKDOWN ===")
            print("=" * 70)
            if pyscf_time > 0:
                pct = 100 * pyscf_time / total_time if total_time > 0 else 0
                print(f"{'PySCF integral calculation':<45}{pyscf_time:10.3f} s  ({pct:.1f}%)")
            if processing_time > 0:
                pct = 100 * processing_time / total_time if total_time > 0 else 0
                print(f"{'Post-processing and writing':<45}{processing_time:10.3f} s  ({pct:.1f}%)")
            if other_time > 0.001:
                pct = 100 * other_time / total_time if total_time > 0 else 0
                print(f"{'Other operations':<45}{other_time:10.3f} s  ({pct:.1f}%)")
            if total_time > 0:
                print(f"{'Total':<45}{total_time:10.3f} s")

        print("=" * 70)

    # ──────────────────────────────────────────────────────────────────────── #
    #   Public methods
    # ──────────────────────────────────────────────────────────────────────── #

    def run(self, outfile: str = "FCIDUMP", *, info_file: Optional[str] = None) -> int:
        """
        Generate FCIDUMP file and metadata.

        This method orchestrates the complete FCIDUMP generation process:
        1. Build FCIDUMP header
        2. Compute frozen-core Hamiltonian (if needed)
        3. Write two-electron integrals
        4. Write one-electron integrals (text format only)
        5. Write energy constant (text format only)
        6. Compress file (zst format only)
        7. Write metadata file

        Parameters
        ----------
        outfile : str, optional
            Output file path. Default is "FCIDUMP".
            - For "txt" format: creates <outfile>
            - For "bin" format: creates <outfile> (or <outfile>.bin)
            - For "zst" format: creates <outfile>.bin.zst (temporary .bin removed)
        info_file : str, optional
            Metadata file path. If None (default), creates "FCIDUMP_info.txt"
            in the same directory as outfile.

        Returns
        -------
        int
            Exit code (0 on success).

        Notes
        -----
        For binary and zst formats, 1e integrals and constant are written
        together with 2e integrals in a single pass. For text format, they
        are appended sequentially.

        Examples
        --------
        >>> writer = FCIDumpWriter(mol, method)
        >>> writer.run('FCIDUMP')  # Creates FCIDUMP and FCIDUMP_info.txt
        >>> writer.run('output/integrals.bin', info_file='output/meta.txt')
        """
        t_start_total = time.time()

        if self._mem_on:
            _log_mem("run: start", self._mem_log, True)

        header = self._build_header()

        # Determine output file paths based on format
        if self.format == 'zst':
            # For zst format: create .bin file, then compress to .bin.zst
            bin_file = outfile if outfile.endswith('.bin') else outfile + ".bin"
            zst_file = bin_file + ".zst"
            output_file = bin_file
            writer_mode = 'bin'
        else:
            output_file = outfile
            writer_mode = self.format
            bin_file = None
            zst_file = None

        # For binary format: compute h_fc and e_const BEFORE writing 2e
        # For text format: compute AFTER writing 2e
        h_fc, e_const = None, None
        if writer_mode == 'bin':
            t_start = time.time()
            h_fc, e_const = self._build_frozen_core()
            self._time_log.append(("frozen_core computed", time.time() - t_start))
            if self._mem_on:
                _log_mem("frozen_core computed", self._mem_log, True)

        # Write 2e integrals
        t_start_2e = time.time()
        if writer_mode == 'bin':
            self._write_two_e(output_file, header, writer_mode, h_fc=h_fc, e_const=e_const)
            # Free memory after writing
            del h_fc, e_const
            gc.collect()
        else:
            self._write_two_e(output_file, header, writer_mode)
        self._time_log.append(("2e integrals written", time.time() - t_start_2e))

        if self._mem_on:
            _log_mem("2e integrals written", self._mem_log, True)

        # Compress to zst format if requested
        if self.format == 'zst':
            # Clear memory before compression
            if self._mem_on:
                _log_mem("before gc.collect()", self._mem_log, True)
            gc.collect()
            if self._mem_on:
                _log_mem("after gc.collect()", self._mem_log, True)

            t_start_compress = time.time()
            compress_zstd_file(bin_file, zst_file)
            os.remove(bin_file)
            self._time_log.append(("compressed to zst", time.time() - t_start_compress))
            if self._mem_on:
                _log_mem("compressed to zst", self._mem_log, True)

        # Write 1e integrals and constant (text format only)
        if self.format == 'txt':
            # Compute h_fc and e_const only for text format
            t_start = time.time()
            h_fc, e_const = self._build_frozen_core()
            self._time_log.append(("frozen_core computed", time.time() - t_start))
            if self._mem_on:
                _log_mem("frozen_core computed", self._mem_log, True)

            t_start_1e = time.time()
            self._write_one_e(outfile, h_fc)
            self._time_log.append(("1e integrals written", time.time() - t_start_1e))
            if self._mem_on:
                _log_mem("1e integrals written", self._mem_log, True)

            t_start_const = time.time()
            self._write_constant(outfile, e_const)
            self._time_log.append(("constant written", time.time() - t_start_const))
            if self._mem_on:
                _log_mem("constant written", self._mem_log, True)

            # Free memory
            del h_fc, e_const
            gc.collect()

        # Write metadata (only for text format)
        if self.format == 'txt':
            if info_file is None:
                out_dir = os.path.dirname(os.path.abspath(outfile)) or "."
                info_file = os.path.join(out_dir, "FCIDUMP_info.txt")
            
            t_start_meta = time.time()
            self._write_metadata(info_file)
            self._time_log.append(("metadata written", time.time() - t_start_meta))

        if self._mem_on:
            _log_mem("metadata written", self._mem_log, True)
            _log_time("total time", self._time_log, True, t_start_total)
            self._summary()

        return 0

    # ──────────────────────────────────────────────────────────────────────── #
    #   Parameter preparation
    # ──────────────────────────────────────────────────────────────────────── #

    def _prepare_parameters(self) -> None:
        """
        Prepare all internal parameters for FCIDUMP generation.

        This method is called during __init__ to compute:
        - Sorted MO coefficients with symmetry labels
        - Active space configuration (frozen/active orbitals)
        - Integral components (1e corrections, 2e operators)
        - Symmetry IDs and bits for active orbitals
        
        All computed parameters are stored as instance attributes.
        """
        mo_stage = prepare_mo_stage(
            self.mol,
            self.method,
            natorb=self.natorb,
            sort_by_symmetry=self.sort_by_symmetry,
            verbose=self.verbose,
            extended_debug=self.extended_debug,
            mo_coeff_custom=self.mo_coeff,
        )
        active_space = build_active_space(
            self.mol,
            mo_stage,
            self.frozen_indices,
        )
        (
            mo_active,
            dh_extra,
            twoe_intor,
            twoe_extra,
            add_ops_meta,
        ) = build_integral_components(
            self.mol,
            mo_stage,
            active_space,
            self.add_ops,
            self.verbose,
        )

        self.mo_prepared_full = mo_stage.mo_prepared
        self.mo_sorted = mo_stage.mo_sorted
        self.perm = list(mo_stage.perm)
        self.frozen_idx = list(active_space.frozen_idx)
        self.norb = active_space.norb
        self.nelec = active_space.nelec
        self.ms2 = active_space.ms2
        self.orbsym_ids_full_sorted = list(active_space.orbsym_ids_full_sorted)
        self.orbsym_ids_active = list(active_space.orbsym_ids_active)
        self.orbsym_bits_active = active_space.orbsym_bits_active.copy()
        self.mo_active = mo_active
        self.extra_one_e = dh_extra
        self.twoe_intor = tuple(twoe_intor)
        self.twoe_extra = list(twoe_extra)
        self.add_ops_meta = add_ops_meta
        self.force_c1 = mo_stage.force_c1
        self.metadata_source_file = str(self.source_file) if self.source_file else None
        self.metadata_geometry_unit = "Ang"

        # Compute wavefunction symmetry (ISYM) using gen_inp.sym
        try:
            self.isym, self.isym_label = molpro_irrep(self.method, self.mol)
        except Exception:  # noqa: BLE001
            # Fallback to default C1 symmetry
            self.isym = 1
            self.isym_label = "A"

