"""
Two-electron integrals processing module.

This module handles the computation and writing of two-electron integrals
for FCIDUMP files, including:
- Two-electron ERI calculation via PySCF ao2mo
- Additional 2e operators (e.g., spin-orbit, dipole moments)
- Efficient streaming and parallel processing
- Symmetry screening using orbital symmetry bits
- Support for both text and binary output formats
- Memory-optimized chunked processing (granular mode)

The module implements two processing modes:
1. Parallel mode (granularity=0): Full ERI buffer in memory, parallel sorting
2. Sequential mode (granularity>0): Streaming chunks to minimize memory usage

Functions
---------
write_two_e_fcidump : Main entry point for writing 2e integrals
"""

import gc
import os
import mmap
import time
import concurrent.futures
from functools import lru_cache
from typing import Iterable, List, Optional, Sequence, Tuple

import numpy as np
from pyscf import ao2mo
from pyscf.ao2mo import incore

from ..archiver.stream_writer import FCIDumpTextStreamWriter
from .fmt import _line, _fmt, LINE_LEN, IND_WIDTH
from .integrals_one_e import iter_one_e_lines_onfly

# --------------------------------------------------------------------------- #
#   Helper functions for two-electron integrals
# --------------------------------------------------------------------------- #

@lru_cache(None)
def _pair_arrays(n: int) -> tuple[np.ndarray, np.ndarray]:
    """
    Generate pair indices for compact ERI storage (PySCF convention).
    
    Creates arrays of (i, j) pairs following PySCF's compact=True ordering:
    lower triangular matrix read row-by-row.
    
    Parameters
    ----------
    n : int
        Number of orbitals.
    
    Returns
    -------
    pi : np.ndarray
        First indices of pairs, shape (n*(n+1)/2,), dtype int32.
    pj : np.ndarray
        Second indices of pairs, shape (n*(n+1)/2,), dtype int32.
    
    Notes
    -----
    - Result is cached for repeated calls with the same n.
    - Ordering: (0,0), (1,0), (1,1), (2,0), (2,1), (2,2), ...
    
    Examples
    --------
    >>> pi, pj = _pair_arrays(3)
    >>> list(zip(pi, pj))
    [(0,0), (1,0), (1,1), (2,0), (2,1), (2,2)]
    """
    pi = np.repeat(np.arange(n), np.arange(1, n + 1))
    pj = np.concatenate([np.arange(i + 1) for i in range(n)])
    return pi.astype(np.int32), pj.astype(np.int32)

def _rank(i: int, j: int, k: int, l: int) -> int:
    """
    Compute linear rank for S8-ordered 2e integral record.
    
    Calculates a unique index for the integral (i,j|k,l) following
    8-fold permutation symmetry (S8) ordering. This rank determines
    the position of the integral in a fixed-size FCIDUMP file.
    
    Parameters
    ----------
    i, j, k, l : int
        Orbital indices (0-based), must satisfy i≥j and k≥l,
        and code(i,j) ≥ code(k,l) where code(p,q) = p*(p+1)/2 + q.
    
    Returns
    -------
    int
        Linear rank (0-based) in S8 ordering.
    
    Notes
    -----
    - Assumes input indices are already canonicalized.
    - Used for random-access writes to pre-allocated FCIDUMP files.
    
    Examples
    --------
    >>> _rank(0, 0, 0, 0)  # First integral
    0
    >>> _rank(1, 1, 0, 0)  # (1,1|0,0)
    3
    """
    c_ij = i * (i + 1) // 2 + j
    c_kl = k * (k + 1) // 2 + l
    return c_ij * (c_ij + 1) // 2 + c_kl

# --------------------------------------------------------------------------- #
#   Stream functions for S8 and S4 integrals
# --------------------------------------------------------------------------- #

def _stream_s8_records_from_chunk(buf_chunk: np.ndarray, offset: int, norb: int, tol: float, orbsym_bits: np.ndarray):
    """
    Generate sorted S8 integral records from a chunk of the ERI buffer.
    
    Processes a chunk of the compact S8 ERI buffer (from PySCF ao2mo.kernel
    with compact=True), decodes triangular indices, applies symmetry screening,
    and yields records in sorted order.
    
    Parameters
    ----------
    buf_chunk : np.ndarray
        Chunk of the compact ERI buffer.
    offset : int
        Global offset of this chunk in the full buffer (linear index).
    norb : int
        Number of orbitals.
    tol : float
        Integral threshold; |value| <= tol are discarded.
    orbsym_bits : np.ndarray
        Binary symmetry labels for orbitals (for screening).
    
    Yields
    ------
    tuple
        (rank, i, j, k, l, value) for each non-zero integral passing
        symmetry screening, sorted in S8 order.
    
    Notes
    -----
    - Only integrals satisfying (sym_i ^ sym_j) == (sym_k ^ sym_l) are yielded.
    - Records are sorted lexicographically by (i, j, k, l).
    - Memory is explicitly freed via del statements.
    - Batched yielding (5000 records/batch) to control memory.
    """
    g = np.arange(norb, dtype=int)
    
    flat = np.asarray(buf_chunk).ravel()
    nz_local = np.flatnonzero(np.abs(flat) > tol)
    if nz_local.size == 0:
        return

    nz = nz_local + offset
    n = g.size
    pi, pj = _pair_arrays(n)
    max_idx = len(pi) - 1  # Maximum valid index

    m = ((np.sqrt(8 * nz + 1) - 1) // 2).astype(np.int64)
    q = nz - m * (m + 1) // 2

    # Bounds check to prevent IndexError
    valid_mask = (m <= max_idx) & (q <= max_idx)
    if not np.any(valid_mask):
        return
    
    m = m[valid_mask]
    q = q[valid_mask]
    nz_local_valid = nz_local[valid_mask]

    I, J = g[pi[m]], g[pj[m]]
    K, L = g[pi[q]], g[pj[q]]
    V = flat[nz_local_valid]

    mask = (orbsym_bits[I] ^ orbsym_bits[J]) == (orbsym_bits[K] ^ orbsym_bits[L])
    if not np.any(mask):
        return

    I_f, J_f, K_f, L_f, V_f = I[mask], J[mask], K[mask], L[mask], V[mask]
    del I, J, K, L, V, mask
    
    # CRITICAL OPTIMIZATION: sort and yield directly
    n_rec = len(I_f)
    if n_rec > 0:
        order = np.lexsort((L_f, K_f, J_f, I_f))
        
        batch_size = min(5000, n_rec)
        for batch_start in range(0, n_rec, batch_size):
            batch_end = min(batch_start + batch_size, n_rec)
            batch_order = order[batch_start:batch_end]
            
            for o in batch_order:
                i, j, k, l = int(I_f[o]), int(J_f[o]), int(K_f[o]), int(L_f[o])
                yield _rank(i, j, k, l), i, j, k, l, float(V_f[o])
            
            batch_order = None
            del batch_order
        
        order = None
        del order
    
    del I_f, J_f, K_f, L_f, V_f


def _parallel_worker_g0(args):
    """
    Parallel worker for processing ERI buffer chunks (granularity=0).
    
    Processes a chunk of the full ERI buffer in a separate process,
    extracting and sorting integral records.
    
    Parameters
    ----------
    args : tuple
        (buf_chunk, offset, norb, tol, orbsym_bits, writer_mode)
        - buf_chunk: Chunk of ERI buffer
        - offset: Global offset in full buffer
        - norb: Number of orbitals
        - tol: Integral threshold
        - orbsym_bits: Symmetry labels
        - writer_mode: 'txt' or 'bin'
    
    Returns
    -------
    list[tuple]
        List of (rank, line_bytes) tuples for writing.
    
    Notes
    -----
    - Used with ProcessPoolExecutor for parallel processing.
    - Returns pre-formatted lines ready for random-access writes.
    """
    buf_chunk, offset, norb, tol, orbsym_bits, writer_mode = args
    
    results = []
    for rnk, i, j, k, l, v in _stream_s8_records_from_chunk(buf_chunk, offset, norb, tol, orbsym_bits):
        line = _line(v, i, j, k, l)
        if writer_mode == 'txt':
            results.append((rnk, line))
        elif writer_mode == 'bin':
            # For binary mode, return rank (for sorting) and line
            results.append((rnk, line))
    return results


def _parallel_write_g0(
    buf: np.ndarray,
    file_path: str,
    writer_mode: str,
    norb_active: int,
    tol: float,
    orbsym_bits: np.ndarray,
    header: Optional[Sequence[str]],
    norb: Optional[int],
    nelec: Optional[int],
    ms2: Optional[int],
    orbsym_ids: Optional[Sequence[int]],
    isym: Optional[int],
    h_fc: Optional[np.ndarray],
    e_const: Optional[float],
    mo_prepared_full: Optional[np.ndarray],
    perm: Optional[Sequence[int]],
    frozen_idx: Optional[Sequence[int]],
    orbsym_sorted: Optional[Sequence[int]],
    user_meta: Optional[dict],
    extended_debug: bool,
):
    """
    Orchestrate parallel writing of 2e integrals for granularity=0 mode.
    
    Splits the full ERI buffer into chunks, processes them in parallel using
    multiple worker processes, then writes results to file using random-access I/O.
    
    Parameters
    ----------
    buf : np.ndarray
        Full ERI buffer (compact S8 format).
    file_path : str
        Output file path.
    writer_mode : str
        Output format: 'txt' or 'bin'.
    norb_active : int
        Number of active orbitals.
    tol : float
        Integral threshold.
    orbsym_bits : np.ndarray
        Binary symmetry labels for orbitals.
    header : Sequence[str], optional
        FCIDUMP header lines (for text format).
    norb, nelec, ms2 : int, optional
        Parameters for binary format.
    orbsym_ids : Sequence[int], optional
        Molpro symmetry IDs (for binary format).
    h_fc, e_const, mo_prepared_full, perm, frozen_idx, orbsym_sorted : optional
        Parameters for writing 1e integrals and constant (binary format only).
    user_meta : dict, optional
        User metadata (for binary format).
    extended_debug : bool
        Enable detailed profiling.
    
    Notes
    -----
    - Uses ProcessPoolExecutor with os.cpu_count() workers.
    - Pre-allocates file with null bytes, then random-access writes.
    - For text format: compacts file after writing (removes null bytes).
    - For binary format: writes 2e, 1e, and constant in a single pass.
    """
    n_workers = os.cpu_count() or 1
    tasks = []
    if buf.size > 0:
        chunk_size = (buf.size + n_workers - 1) // n_workers
        for i in range(n_workers):
            offset = i * chunk_size
            if offset >= buf.size: break
            chunk = buf[offset : offset + chunk_size]
            tasks.append((chunk, offset, norb_active, tol, orbsym_bits, writer_mode))

    all_results = []
    with concurrent.futures.ProcessPoolExecutor(max_workers=n_workers) as executor:
        for result_chunk in executor.map(_parallel_worker_g0, tasks):
            all_results.extend(result_chunk)

    if writer_mode == 'txt':
        if header is None: raise ValueError("Header is required for 'txt' writer mode.")
        n_pairs = norb_active * (norb_active + 1) // 2
        n_lines = n_pairs * (n_pairs + 1) // 2
        
        with open(file_path, "wb") as f:
            for ln in header: f.write((ln.rstrip("\n") + "\n").encode())
            hdr = f.tell()
            if n_lines > 0:
                f.seek(hdr + n_lines * LINE_LEN - 1)
                f.write(b"\0")

        fd = os.open(file_path, os.O_RDWR)
        try:
            for rnk, line_bytes in all_results:
                os.pwrite(fd, line_bytes, hdr + rnk * LINE_LEN)
        finally:
            os.close(fd)

        with open(file_path, "r+b") as fh:
            mm = mmap.mmap(fh.fileno(), 0)
            read = write = hdr
            while read < len(mm):
                chunk = mm[read:read + LINE_LEN]
                if chunk and chunk[0] != 0 and chunk.strip():
                    if read != write: mm[write:write + LINE_LEN] = chunk
                    write += LINE_LEN
                read += LINE_LEN
            fh.truncate(write)

    elif writer_mode == 'bin':
        if any(p is None for p in [norb, nelec, ms2, orbsym_ids, isym]):
            raise ValueError("norb, nelec, ms2, orbsym_ids, and isym are required for 'bin' writer mode.")
        
        # Sort by rank and convert to sequential offsets
        sorted_results = sorted(all_results, key=lambda x: x[0])
        
        # Use provided metadata or create base metadata
        final_user_meta = user_meta if user_meta is not None else {"tol": tol}
        
        with FCIDumpTextStreamWriter(file_path, norb, nelec, ms2, orbsym_ids, isym=isym) as writer:
            # Write 2e integrals with sequential offsets
            text_offset = 0
            for rnk, line_bytes in sorted_results:
                writer.write_text_partition(text_offset, line_bytes)
                text_offset += len(line_bytes)
            
            # Write 1e integrals if provided
            if h_fc is not None and mo_prepared_full is not None and perm is not None:
                for line in iter_one_e_lines_onfly(
                    h_fc, mo_prepared_full, perm, frozen_idx or [],
                    tol, None, orbsym_sorted or []
                ):
                    line_bytes = line.encode() if isinstance(line, str) else line
                    writer.write_text_partition(text_offset, line_bytes)
                    text_offset += len(line_bytes)
                
                # Write constant
                if e_const is not None:
                    from .fmt import const_line
                    const_lines = const_line(e_const)
                    for line in const_lines:
                        line_bytes = line.encode() if isinstance(line, str) else line
                        writer.write_text_partition(text_offset, line_bytes)
                        text_offset += len(line_bytes)
            
            writer.finalize(user_meta=final_user_meta)

# --------------------------------------------------------------------------- #
#   S8 decoder and S4 stream with symmetry filter
# --------------------------------------------------------------------------- #

def _stream_s8_all(buf: np.ndarray, g: np.ndarray, tol: float, orbsym_bits: np.ndarray):
    """
    Stream all S8 integral records from compact ERI buffer.
    
    Processes the complete compact S8 ERI buffer (from PySCF ao2mo.kernel
    with compact=True), decodes all triangular indices, applies symmetry
    screening, and yields records in sorted order.
    
    Parameters
    ----------
    buf : np.ndarray
        Full compact ERI buffer (1D or 2D).
    g : np.ndarray
        Orbital index array (0-based).
    tol : float
        Integral threshold; |value| <= tol are discarded.
    orbsym_bits : np.ndarray
        Binary symmetry labels for orbitals.
    
    Yields
    ------
    tuple
        (rank, i, j, k, l, value) for each non-zero integral passing
        symmetry screening (sym_i ^ sym_j == sym_k ^ sym_l).
    
    Notes
    -----
    - Optimized for minimal memory consumption.
    - Intermediate arrays are explicitly deleted after use.
    - Records are sorted lexicographically by (i, j, k, l).
    - Batched yielding (5000 records/batch) to control memory.
    """
    arr = buf[np.tril_indices(buf.shape[0])] if buf.ndim == 2 else buf
    flat = np.asarray(arr).ravel()
    del arr  # Free intermediate array
    
    nz = np.flatnonzero(np.abs(flat) > tol)
    if nz.size == 0:
        del flat, nz
        return

    n = g.size
    pi, pj = _pair_arrays(n)

    # Decode triangular indices: t → (m, q)
    m = ((np.sqrt(8 * nz + 1) - 1) // 2).astype(np.int64)
    q = nz - m * (m + 1) // 2
    V = flat[nz]  # Save values before deleting nz
    del flat, nz  # Free memory

    I, J = g[pi[m]], g[pj[m]]
    K, L = g[pi[q]], g[pj[q]]
    del m, q  # Free memory

    # Symmetry filter: XOR of irrep bits (Abelian group)
    mask = (orbsym_bits[I] ^ orbsym_bits[J]) == (orbsym_bits[K] ^ orbsym_bits[L])
    if not np.any(mask):
        del I, J, K, L, V, mask
        return

    I_f, J_f, K_f, L_f, V_f = I[mask], J[mask], K[mask], L[mask], V[mask]
    del I, J, K, L, V, mask
    
    # CRITICAL OPTIMIZATION: sort and yield directly, no nested generator
    n_rec = len(I_f)
    if n_rec > 0:
        order = np.lexsort((L_f, K_f, J_f, I_f))
        
        batch_size = min(5000, n_rec)
        for batch_start in range(0, n_rec, batch_size):
            batch_end = min(batch_start + batch_size, n_rec)
            batch_order = order[batch_start:batch_end]
            
            for o in batch_order:
                i, j, k, l = int(I_f[o]), int(J_f[o]), int(K_f[o]), int(L_f[o])
                yield _rank(i, j, k, l), i, j, k, l, float(V_f[o])
            
            batch_order = None
            del batch_order
        
        order = None
        del order
    
    del I_f, J_f, K_f, L_f, V_f


def _stream_s4_general(
    buf: np.ndarray,
    gi: np.ndarray, gj: np.ndarray,
    gk: np.ndarray, gl: np.ndarray,
    tol: float,
    orbsym_bits: np.ndarray,
):
    """
    Stream S4 integral records from general ERI buffer.
    
    Processes ERI buffer from PySCF ao2mo.general(..., compact=False),
    normalizes index pairs, canonicalizes half-transformations,
    applies symmetry screening, and yields sorted records.
    
    The canonicalization follows these steps:
    1. Normalize pairs: i≥j and k≥l
    2. Canonicalize half-transforms: code(i,j) ≥ code(k,l)
    3. Apply symmetry filter: (sym_i ^ sym_j) == (sym_k ^ sym_l)
    
    Parameters
    ----------
    buf : np.ndarray
        ERI buffer from ao2mo.general, shape (ni*nj, nk*nl) or 1D.
    gi, gj, gk, gl : np.ndarray
        Orbital index arrays for each index position.
    tol : float
        Integral threshold; |value| <= tol are discarded.
    orbsym_bits : np.ndarray
        Binary symmetry labels for orbitals.
    
    Yields
    ------
    tuple
        (rank, i, j, k, l, value) for each non-zero integral passing
        symmetry screening, sorted in S8 order.
    
    Notes
    -----
    - Optimized for minimal memory consumption.
    - All intermediate arrays are explicitly deleted.
    - Records are sorted lexicographically by (i, j, k, l).
    - Batched yielding (5000 records/batch) to control memory.
    """
    ni, nj = int(gi.size), int(gj.size)
    nk, nl = int(gk.size), int(gl.size)

    arr = np.asarray(buf)
    if arr.ndim == 1:
        if arr.size != ni * nj * nk * nl:
            raise ValueError(f"S4 buffer size mismatch: got {arr.size}, expected {ni*nj*nk*nl}")
        arr = arr.reshape(ni * nj, nk * nl)
    elif arr.ndim == 2 and arr.shape != (ni * nj, nk * nl):
        arr = arr.reshape(ni * nj, nk * nl)

    mask_nz = np.abs(arr) > tol
    if not mask_nz.any():
        del arr, mask_nz
        return
    
    rr, cc = np.nonzero(mask_nz)
    del mask_nz  # Free immediately
    
    V = arr[rr, cc].copy()  # CRITICAL: copy() to break reference to arr
    arr = None  # Nullify reference
    del arr  # Free large array
    
    # Decode local indices
    ii_loc, jj_loc = divmod(rr, nj)
    kk_loc, ll_loc = divmod(cc, nl)
    rr = None; cc = None
    del rr, cc
    
    I, J = gi[ii_loc], gj[jj_loc]
    K, L = gk[kk_loc], gl[ll_loc]
    ii_loc = None; jj_loc = None; kk_loc = None; ll_loc = None
    del ii_loc, jj_loc, kk_loc, ll_loc

    # --- (1) Normalize within pairs: i≥j and k≥l ---
    swap_ij = I < J
    if np.any(swap_ij):
        # CRITICAL: use temporary variables and explicit deletion
        tmp_I, tmp_J = I.copy(), J.copy()
        I = np.where(swap_ij, tmp_J, tmp_I)
        J = np.where(swap_ij, tmp_I, tmp_J)
        tmp_I = None; tmp_J = None
        del tmp_I, tmp_J
    swap_ij = None
    del swap_ij

    swap_kl = K < L
    if np.any(swap_kl):
        tmp_K, tmp_L = K.copy(), L.copy()
        K = np.where(swap_kl, tmp_L, tmp_K)
        L = np.where(swap_kl, tmp_K, tmp_L)
        tmp_K = None; tmp_L = None
        del tmp_K, tmp_L
    swap_kl = None
    del swap_kl

    # Pair codes after normalization
    cij = I * (I + 1) // 2 + J
    ckl = K * (K + 1) // 2 + L

    # --- (2) Canonicalize half-transforms: code(ij) ≥ code(kl) ---
    swap_halves = cij < ckl
    if np.any(swap_halves):
        tmp_I, tmp_J, tmp_K, tmp_L = I.copy(), J.copy(), K.copy(), L.copy()
        tmp_cij, tmp_ckl = cij.copy(), ckl.copy()
        I = np.where(swap_halves, tmp_K, tmp_I)
        J = np.where(swap_halves, tmp_L, tmp_J)
        K = np.where(swap_halves, tmp_I, tmp_K)
        L = np.where(swap_halves, tmp_J, tmp_L)
        cij = np.where(swap_halves, tmp_ckl, tmp_cij)
        ckl = np.where(swap_halves, tmp_cij, tmp_ckl)
        tmp_I = None; tmp_J = None; tmp_K = None; tmp_L = None
        tmp_cij = None; tmp_ckl = None
        del tmp_I, tmp_J, tmp_K, tmp_L, tmp_cij, tmp_ckl
    swap_halves = None; cij = None; ckl = None
    del swap_halves, cij, ckl

    # --- (3) Symmetry filter (Abelian group → XOR) ---
    keep = (orbsym_bits[I] ^ orbsym_bits[J]) == (orbsym_bits[K] ^ orbsym_bits[L])
    if not np.any(keep):
        I = None; J = None; K = None; L = None; V = None; keep = None
        del I, J, K, L, V, keep
        return

    I_f, J_f, K_f, L_f, V_f = I[keep], J[keep], K[keep], L[keep], V[keep]
    I = None; J = None; K = None; L = None; V = None; keep = None
    del I, J, K, L, V, keep
    
    # CRITICAL OPTIMIZATION: sort and yield directly, no nested generator
    # This allows freeing arrays immediately after completion, rather than
    # waiting for the outer generator to finish
    n = len(I_f)
    if n > 0:
        order = np.lexsort((L_f, K_f, J_f, I_f))
        
        # Batch yield for memory control
        batch_size = min(5000, n)
        for batch_start in range(0, n, batch_size):
            batch_end = min(batch_start + batch_size, n)
            batch_order = order[batch_start:batch_end]
            
            for o in batch_order:
                i, j, k, l = int(I_f[o]), int(J_f[o]), int(K_f[o]), int(L_f[o])
                yield _rank(i, j, k, l), i, j, k, l, float(V_f[o])
            
            batch_order = None
            del batch_order
        
        order = None
        del order
    
    # Final cleanup
    I_f = None; J_f = None; K_f = None; L_f = None; V_f = None
    del I_f, J_f, K_f, L_f, V_f


# --------------------------------------------------------------------------- #
#   Block splitting and integral gathering
# --------------------------------------------------------------------------- #

def _irrep_blocks_from_bits(orbsym_bits_full: np.ndarray) -> list[tuple[int, int]]:
    """
    Build contiguous blocks of orbitals with the same symmetry bit pattern.
    
    Groups consecutive orbitals that share the same binary symmetry label
    into blocks. Used for block-wise processing to optimize memory access.
    
    Parameters
    ----------
    orbsym_bits_full : np.ndarray
        Binary symmetry labels for sorted MOs.
    
    Returns
    -------
    list[tuple[int, int]]
        List of (start, end) index pairs for each symmetry block.
        Empty list if orbsym_bits_full is empty.
    
    Notes
    -----
    - Assumes orbitals are already sorted by symmetry.
    - Used internally for chunking in granular mode.
    
    Examples
    --------
    >>> _irrep_blocks_from_bits(np.array([1, 1, 1, 2, 2, 4]))
    [(0, 3), (3, 5), (5, 6)]
    """
    blocks: list[tuple[int, int]] = []
    if orbsym_bits_full.size == 0:
        return blocks
    s = 0
    for i in range(1, orbsym_bits_full.size):
        if orbsym_bits_full[i] != orbsym_bits_full[i-1]:
            blocks.append((s, i))
            s = i
    blocks.append((s, orbsym_bits_full.size))
    return blocks


# Функция _split_block_into_chunks удалена, так как не используется.
# Вместо неё используется равномерное распределение остатка непосредственно
# в _get_two_e_integrals() (строки 520-530)


def _get_two_e_integrals(
    mol,
    mo: np.ndarray,
    tol: float,
    log_fn,
    granularity: int,
    intor: str | Sequence[str],
    ao2e_extra: Optional[Sequence[np.ndarray]],
    frozen: Optional[Sequence[int]],
    orbsym_bits: np.ndarray,
    extended_debug: bool,
):
    """
    Unified function to compute 2e integrals with flexible chunking.
    
    Computes two-electron integrals using PySCF's ao2mo module with
    optional additional operators. Supports two processing modes:
    
    - granularity=0: Computes full ERI buffer in parallel (ao2mo.kernel).
      Returns numpy array for subsequent parallel processing.
    
    - granularity≥1: Streams integrals in chunks (ao2mo.general).
      Returns generator yielding (rank, i, j, k, l, value) records.
      The remainder from dividing norb by granularity is distributed
      uniformly across chunks (first remainder chunks get +1 orbital).
    
    Parameters
    ----------
    mol : pyscf.gto.Mole
        PySCF molecule object.
    mo : np.ndarray
        MO coefficient matrix, shape (n_ao, n_mo).
    tol : float
        Integral threshold; |value| <= tol are discarded.
    log_fn : Callable[[str], None]
        Logging function for progress messages.
    granularity : int
        Chunking granularity:
        - 0: Full parallel mode (entire ERI in memory)
        - ≥1: Sequential chunked mode (process orbitals in chunks)
    intor : str or Sequence[str]
        PySCF integral name(s), e.g., 'int2e' or ['int2e', 'int2e_ip1'].
        Multiple integrals are summed element-wise.
    ao2e_extra : Sequence[np.ndarray], optional
        Additional 2e operators in AO basis to add to ERI.
        Each array has shape (n_ao, n_ao, n_ao, n_ao).
    frozen : Sequence[int], optional
        Frozen orbital indices to exclude from active space.
    orbsym_bits : np.ndarray
        Binary symmetry labels for orbitals (for screening).
    extended_debug : bool
        Enable detailed memory profiling output.
    
    Returns
    -------
    np.ndarray or generator
        - For granularity=0: Full ERI buffer as numpy array.
        - For granularity≥1: Generator yielding (rank, i, j, k, l, value) tuples.
    
    Notes
    -----
    - For granularity≥1, intermediate arrays are freed via gc.collect().
    - Generator mode yields sentinel tuple (7 elements with last=True) at chunk end.
    - Memory optimization: uses max_memory=0.001 to minimize PySCF caching.
    """
    active_mo = mo
    if frozen:
        mask = np.ones(mo.shape[1], bool)
        mask[list(frozen)] = False
        active_mo = mo[:, np.where(mask)[0]]
    norb = active_mo.shape[1]

    intor_list = (intor,) if isinstance(intor, str) else tuple(intor)
    extra = tuple(ao2e_extra or ())

    if granularity == 0:
        # granularity=0: ONLY for parallel mode (ao2mo.kernel - multi-threaded)
        Ci = np.asfortranarray(active_mo, dtype=np.float64)
        parts: list[np.ndarray] = []
        for op in intor_list:
            parts.append(np.asarray(ao2mo.kernel(mol, Ci, intor=op, compact=True, max_memory=0.001), dtype=np.float64))
        for eri in extra:
            parts.append(np.asarray(incore.kernel(eri, Ci, compact=True), dtype=np.float64))
        
        if not parts:
            return np.array([], dtype=np.float64)
        
        # Sum accumulatively to save memory
        result = parts[0]
        for i in range(1, len(parts)):
            result += parts[i]
            parts[i] = None  # Free immediately
        return result

    # --- Generator for granularity >= 1 ---
    
    def _compute_records_g_ge_1():
        # For memory profiling
        _rss_mb = None
        if extended_debug:
            import os, psutil
            _rss_mb = lambda: psutil.Process(os.getpid()).memory_info().rss / 1024 ** 2
        
        if log_fn:
            log_fn(f"[2e] active norb={norb} (granularity={granularity}, uniform chunking)")

        # Uniform division with remainder distribution
        # g=1 → entire array as 1 chunk
        # g>1 → divide uniformly
        if granularity == 1:
            A_chunks = [(0, norb)]
        else:
            base_size = norb // granularity
            remainder = norb % granularity
            
            A_chunks: list[tuple[int, int]] = []
            current = 0
            
            for i in range(granularity):
                # First 'remainder' chunks get +1 orbital
                chunk_size = base_size + (1 if i < remainder else 0)
                A_chunks.append((current, current + chunk_size))
                current += chunk_size
        
        if log_fn:
            sizes = [e - s for s, e in A_chunks]
            log_fn(f"[2e] A_chunks={len(A_chunks)}, sizes={sizes} (max_diff={max(sizes)-min(sizes)})")

        for aidx, (s_i, e_i) in enumerate(A_chunks, start=1):
            if _rss_mb is not None:
                mem_before = _rss_mb()
            
            # Indices i for this chunk
            Gi = np.arange(s_i, e_i, dtype=int)
            Ci = np.asfortranarray(active_mo[:, Gi], dtype=np.float64)
            
            # j from 0 to last i in this chunk (inclusive)
            Gj = np.arange(0, e_i, dtype=int)
            Cj = np.asfortranarray(active_mo[:, Gj], dtype=np.float64)
            
            # k, l - all orbitals
            Gk = np.arange(0, norb, dtype=int)
            Ck = np.asfortranarray(active_mo[:, Gk], dtype=np.float64)
            Cl = Ck  # k and l are identical
            
            blk = (Ci, Cj, Ck, Cl)
            
            # OPTIMIZATION: sum accumulatively with aggressive memory release
            buf = None
            for idx, op in enumerate(intor_list):
                arr = np.asarray(ao2mo.general(mol, blk, intor=op, compact=False, max_memory=0.001), dtype=np.float64)
                if buf is None:
                    buf = arr
                    arr = None  # buf now owns the data
                else:
                    buf += arr
                    arr.fill(0)  # Zero before deletion
                    arr = None
                    del arr
                # CRITICAL: full GC immediately after each ao2mo to free its internal buffers
                gc.collect(2)
                
            for idx, eri in enumerate(extra):
                arr = np.asarray(incore.general(eri, blk, compact=False), dtype=np.float64)
                if buf is None:
                    buf = arr
                    arr = None
                else:
                    buf += arr
                    arr.fill(0)
                    arr = None
                    del arr
                gc.collect(2)
            
            if buf is not None:
                # CRITICAL OPTIMIZATION: yield records directly from _stream_s4_general
                # DO NOT accumulate in a list to avoid memory leak
                record_count = 0
                for record in _stream_s4_general(buf, Gi, Gj, Gk, Gk, tol, orbsym_bits):
                    yield record
                    record_count += 1
                    # Periodic GC every 1000 records for more frequent cleanup
                    if record_count % 1000 == 0:
                        gc.collect(0)
                
                # CRITICAL OPTIMIZATION: completely destroy buf
                buf.fill(0)  # Zero before deletion
                buf = None
                del buf
            
            # CRITICAL OPTIMIZATION: free coefficient arrays
            Ci = None; Cj = None; Ck = None; Cl = None
            Gi = None; Gj = None; Gk = None
            del Ci, Cj, Ck, Cl, Gi, Gj, Gk
            
            # CRITICAL OPTIMIZATION: full garbage collection after each chunk
            # This guarantees freeing all temporary objects from generators
            gc.collect(2)
            
            # ADDITIONAL OPTIMIZATION: force C-memory release
            try:
                import ctypes
                libc = ctypes.CDLL("libc.so.6")
                libc.malloc_trim(0)
            except:
                pass
            
            # IMPORTANT: Yield sentinel to signal end of chunk to consumer
            # Sentinel = tuple of 7 elements instead of 6 to distinguish from regular record
            yield (-1, -1, -1, -1, -1, -1.0, True)  # last element = True means "end of chunk"
            
            if _rss_mb is not None:
                print(f"[MEM] chunk {aidx}/{len(A_chunks):<30}{_rss_mb():8.1f} MB")
    
    return _compute_records_g_ge_1()


def _sequential_write_from_iterator(
    iterator: Iterable[Tuple[int, int, int, int, int, float]],
    file_path: str,
    writer_mode: str,
    norb_active: int,
    header: Optional[Sequence[str]],
    norb: Optional[int],
    nelec: Optional[int],
    ms2: Optional[int],
    orbsym_ids: Optional[Sequence[int]],
    isym: Optional[int],
    tol: float,
    h_fc: Optional[np.ndarray],
    e_const: Optional[float],
    mo_prepared_full: Optional[np.ndarray],
    perm: Optional[Sequence[int]],
    frozen_idx: Optional[Sequence[int]],
    orbsym_sorted: Optional[Sequence[int]],
    user_meta: Optional[dict],
    extended_debug: bool,
):
    """
    Write integral records from an iterator sequentially to file.
    
    Processes records from a generator, writing them to file using
    random-access I/O to avoid sorting large datasets in memory.
    
    For text format:
    - Pre-allocates file with null bytes (fixed FCIDUMP format)
    - Writes records at their canonical positions (determined by rank)
    - Compacts file at the end by removing null bytes
    
    For binary format:
    - Writes records in small batches to minimize memory usage
    - Uses FCIDumpTextStreamWriter for efficient binary output
    
    Parameters
    ----------
    iterator : Iterable[Tuple[int, int, int, int, int, float]]
        Generator yielding (rank, i, j, k, l, value) tuples.
        May include sentinel tuples (7 elements, last=True) for chunk boundaries.
    file_path : str
        Output file path.
    writer_mode : str
        Output format: 'txt' or 'bin'.
    norb_active : int
        Number of active orbitals.
    header : Sequence[str], optional
        FCIDUMP header lines (for text format).
    norb, nelec, ms2 : int, optional
        Parameters for binary format.
    orbsym_ids : Sequence[int], optional
        Molpro symmetry IDs (for binary format).
    tol : float
        Integral threshold.
    h_fc, e_const, mo_prepared_full, perm, frozen_idx, orbsym_sorted : optional
        Parameters for writing 1e integrals and constant (not yet supported for bin).
    user_meta : dict, optional
        User metadata (for binary format).
    extended_debug : bool
        Enable detailed profiling.
    
    Notes
    -----
    - For text format: uses bitmap to track written records and avoid duplicates.
    - For binary format: batch size is 4096 records to balance memory/I/O.
    - Periodic garbage collection prevents memory leaks during long iterations.
    - File synchronization every 50000 records to free OS buffers.
    """
    if writer_mode == 'txt':
        if header is None:
            raise ValueError("Header is required for 'txt' writer mode.")
        
        n_pairs = norb_active * (norb_active + 1) // 2
        n_lines = n_pairs * (n_pairs + 1) // 2
        
        with open(file_path, "wb") as f:
            for ln in header: f.write((ln.rstrip("\n") + "\n").encode())
            hdr = f.tell()
            if n_lines > 0:
                f.seek(hdr + n_lines * LINE_LEN - 1)
                f.write(b"\0")

        fd = os.open(file_path, os.O_RDWR)
        written = bytearray((n_lines + 7) // 8)
        def _is_written(r): return (written[r >> 3] >> (r & 7)) & 1
        def _set_written(r): written[r >> 3] |= (1 << (r & 7))

        try:
            # CRITICAL OPTIMIZATION: periodic GC to prevent leak
            record_count = 0
            last_gc_at = 0
            chunk_record_count = 0
            for item in iterator:
                # Check sentinel (7 elements instead of 6)
                if len(item) == 7 and item[6] is True:
                    # End of chunk - aggressive GC
                    gc.collect(2)
                    continue
                
                rnk, i, j, k, l, v = item
                if not _is_written(rnk):
                    os.pwrite(fd, _line(v, i, j, k, l), hdr + rnk * LINE_LEN)
                    _set_written(rnk)
                
                record_count += 1
                chunk_record_count += 1
                
                # Aggressive garbage collection every 5000 records
                if record_count - last_gc_at >= 5000:
                    gc.collect(0)
                    last_gc_at = record_count
                    
                    # Additionally: file sync every 50000 records
                    # to free OS buffers
                    if chunk_record_count >= 50000:
                        try:
                            os.fsync(fd)
                        except:
                            pass
                        chunk_record_count = 0
        finally:
            os.close(fd)

        with open(file_path, "r+b") as fh:
            mm = mmap.mmap(fh.fileno(), 0)
            read = write = hdr
            while read < len(mm):
                chunk = mm[read:read + LINE_LEN]
                if chunk and chunk[0] != 0 and chunk.strip():
                    if read != write: mm[write:write + LINE_LEN] = chunk
                    write += LINE_LEN
                read += LINE_LEN
            fh.truncate(write)

    elif writer_mode == 'bin':
        if any(p is None for p in [norb, nelec, ms2, orbsym_ids, isym]):
            raise ValueError("norb, nelec, ms2, orbsym_ids, and isym are required for 'bin' writer mode.")
        
        # For streaming write in bin format, accumulate records in minimal batches
        # to reduce memory consumption
        final_user_meta = user_meta if user_meta is not None else {"tol": tol}
        
        # CRITICAL OPTIMIZATION: small block_recs for frequent disk flush
        writer = FCIDumpTextStreamWriter(file_path, norb, nelec, ms2, orbsym_ids, isym=isym, block_recs=4096)
        try:
            # CRITICAL OPTIMIZATION: direct record write without text conversion
            # This saves memory as we don't need to create strings and parse them back
            for item in iterator:
                # Check sentinel (7 elements instead of 6)
                if len(item) == 7 and item[6] is True:
                    # End of chunk - aggressive GC
                    gc.collect(2)
                    continue
                
                rnk, i, j, k, l, v = item
                writer.write_record_direct(v, i, j, k, l)
            
            # Finalize 2e integrals
            writer.finalize(user_meta=final_user_meta)
            
            # IMPORTANT: 1e integrals and constant are written in txt mode after finalize
            # For bin format this is not yet supported - need to either write separate file
            # or add write_record_direct for 1e at the end
            # TODO: add support for 1e/const for bin via append after finalize
            
        finally:
            # Ensure writer is closed even if error occurs
            if hasattr(writer, '_fd') and not writer._finalized:
                try:
                    os.close(writer._fd)
                except:
                    pass

def write_two_e_fcidump(
    mol,
    mo: np.ndarray,
    file_path: str,
    writer_mode: str,
    header: Optional[Sequence[str]],
    norb: Optional[int],
    nelec: Optional[int],
    ms2: Optional[int],
    orbsym_ids: Optional[Sequence[int]],
    isym: Optional[int],
    tol: float,
    log_fn,
    granularity: int,
    intor: str | Sequence[str],
    ao2e_extra: Optional[Sequence[np.ndarray]],
    frozen: Optional[Sequence[int]],
    orbsym_bits: np.ndarray,
    h_fc: Optional[np.ndarray],
    e_const: Optional[float],
    mo_prepared_full: Optional[np.ndarray],
    perm: Optional[Sequence[int]],
    frozen_idx: Optional[Sequence[int]],
    orbsym_sorted: Optional[Sequence[int]],
    user_meta: Optional[dict],
    extended_debug: bool,
) -> Tuple[float, float]:
    """
    Write two-electron integrals to FCIDUMP file (text or binary).
    
    This is the main entry point for 2e integral processing. It handles:
    - Computing 2e integrals via PySCF ao2mo
    - Adding additional 2e operators (if provided)
    - Symmetry screening using orbital symmetry bits
    - Writing in text or binary format
    - For binary format: also writes 1e integrals and constant
    
    The function supports two processing modes:
    - Parallel mode (granularity=0): Computes full ERI buffer, then processes
      chunks in parallel for maximum speed.
    - Sequential mode (granularity>0): Streams integrals in chunks to minimize
      memory usage. The remainder is distributed uniformly across chunks.
    
    Parameters
    ----------
    mol : pyscf.gto.Mole
        PySCF molecule object.
    mo : np.ndarray
        Active MO coefficient matrix, shape (n_ao, n_active).
    file_path : str
        Output file path.
    writer_mode : str
        Output format: "txt" or "bin".
    header : Sequence[str], optional
        FCIDUMP header lines (for text format).
    norb : int, optional
        Number of active orbitals (for binary format).
    nelec : int, optional
        Number of active electrons (for binary format).
    ms2 : int, optional
        Spin multiplicity 2S (for binary format).
    orbsym_ids : Sequence[int], optional
        Molpro symmetry IDs for active orbitals (for binary format).
    isym : int, optional
        Molpro symmetry ID for the wavefunction (for binary format).
    tol : float
        Integral threshold; |value| <= tol are discarded.
    log_fn : Callable[[str], None]
        Logging function for memory checkpoints.
    granularity : int
        Chunking granularity:
        - 0: Full parallel mode (all integrals in memory).
        - >0: Sequential chunked mode (process granularity orbitals per chunk).
    intor : str or Sequence[str]
        PySCF integral name(s), e.g., "int2e" or ["int2e", "int2e_ip1"].
        The first entry is the main ERI; subsequent entries are additional operators.
    ao2e_extra : Sequence[np.ndarray], optional
        Additional 2e operators in AO basis, shape (n_ao, n_ao, n_ao, n_ao).
        These are added to the ERI after MO transformation.
    frozen : Sequence[int], optional
        Frozen orbital indices (currently unused; frozen orbitals excluded earlier).
    orbsym_bits : np.ndarray
        Binary symmetry labels for active orbitals (for screening).
    h_fc : np.ndarray, optional
        Frozen-core Hamiltonian (for binary format only).
    e_const : float, optional
        Energy constant (for binary format only).
    mo_prepared_full : np.ndarray, optional
        Full MO coefficient matrix (for binary format 1e integrals).
    perm : Sequence[int], optional
        Permutation indices (for binary format 1e integrals).
    frozen_idx : Sequence[int], optional
        Frozen orbital indices (for binary format 1e integrals).
    orbsym_sorted : Sequence[int], optional
        Sorted Molpro symmetry IDs (for binary format 1e integrals).
    user_meta : dict, optional
        User metadata for binary format (written to metadata section).
    extended_debug : bool
        Enable detailed profiling output.
    
    Returns
    -------
    pyscf_time : float
        Time spent in PySCF integral calculation (seconds).
    processing_time : float
        Time spent in post-processing and writing (seconds).
    
    Notes
    -----
    - For granularity>0, the remainder from dividing norb by granularity is
      distributed uniformly: the first (remainder) chunks get +1 orbital each.
    - Symmetry screening: only integrals with (sym_i ^ sym_j) == (sym_k ^ sym_l)
      are written (bitwise XOR of symmetry labels).
    - Binary format writes 2e, 1e, and constant in a single pass.
    - Text format writes 2e here; 1e and constant appended later.
    
    Examples
    --------
    >>> pyscf_time, proc_time = write_two_e_fcidump(
    ...     mol, mo_active, 'FCIDUMP', 'txt',
    ...     header=header_lines, norb=None, nelec=None, ms2=None, orbsym_ids=None,
    ...     tol=1e-15, log_fn=print, granularity=50,
    ...     intor='int2e', ao2e_extra=None, frozen=None,
    ...     orbsym_bits=orbsym_bits,
    ...     h_fc=None, e_const=None, mo_prepared_full=None,
    ...     perm=None, frozen_idx=None, orbsym_sorted=None,
    ...     user_meta=None, extended_debug=True
    ... )
    """
    t_start_total = time.time()
    t_pyscf = 0.0
    t_processing = 0.0
    
    t_start_integrals = time.time()
    integrals = _get_two_e_integrals(
        mol, mo, tol, log_fn, granularity, intor, ao2e_extra, frozen, orbsym_bits, extended_debug
    )
    t_pyscf += time.time() - t_start_integrals
    
    norb_active = mo.shape[1] - len(frozen or [])

    t_start_write = time.time()
    
    if granularity == 0:
        # granularity=0: integrals is a numpy array (full ERI buffer, parallel mode)
        buf = integrals
        if buf.size == 0:
            if writer_mode == 'txt' and header:
                with open(file_path, "wb") as f:
                    for ln in header: f.write((ln.rstrip("\n") + "\n").encode())
            elif writer_mode == 'bin' and all(p is not None for p in [norb, nelec, ms2, orbsym_ids, isym]):
                 with FCIDumpTextStreamWriter(file_path, norb, nelec, ms2, orbsym_ids, isym=isym) as writer:
                    writer.finalize(user_meta=user_meta or {"tol": tol})
            t_processing = time.time() - t_start_write
            return t_pyscf, t_processing
        
        _parallel_write_g0(
            buf, file_path, writer_mode, norb_active, tol, orbsym_bits,
            header, norb, nelec, ms2, orbsym_ids, isym,
            h_fc, e_const, mo_prepared_full,
            perm, frozen_idx, orbsym_sorted,
            user_meta,
            extended_debug,
        )
    else:
        # granularity >= 1: integrals is an iterator
        _sequential_write_from_iterator(
            integrals, file_path, writer_mode, norb_active,
            header, norb, nelec, ms2, orbsym_ids, isym, tol,
            h_fc, e_const, mo_prepared_full,
            perm, frozen_idx, orbsym_sorted,
            user_meta,
            extended_debug,
        )
    
    t_processing = time.time() - t_start_write
    
    return t_pyscf, t_processing
