# fmt.py
# =======
# Unified formatting module for FCIDUMP files
# Contains format functions and symmetry mappings

import math
from typing import Dict, List

# --------------------------------------------------------------------------- #
#   FCIDUMP format constants
# --------------------------------------------------------------------------- #

IND_WIDTH = 4
LINE_LEN = 41
TOKEN_WIDTH = 24  # for archiver compatibility

# --------------------------------------------------------------------------- #
#   Symmetry mappings (MOLPRO IDs and bit representations)
# --------------------------------------------------------------------------- #

MOLPRO_ID: Dict[str, Dict[str, int]] = {
    "C1": {"A": 1},
    "Ci": {"Ag": 1, "Au": 2},
    "Cs": {"A'": 1, 'A"': 2},
    "C2": {"A": 1, "B": 2},
    "C2h": {"Ag": 1, "Bg": 4, "Au": 2, "Bu": 3},
    "C2v": {"A1": 1, "A2": 4, "B1": 2, "B2": 3},
    "D2": {"A": 1, "B1": 4, "B2": 3, "B3": 2},
    "D2h": {
        "Ag": 1, "B3u": 2, "B2u": 3, "B1g": 4, "B1u": 5, "B2g": 6, "B3g": 7, "Au": 8,
    },
}

ORBSYM_BITS: Dict[str, Dict[str, int]] = {
    "C1": {"A": 0},
    "Ci": {"Ag": 0b0, "Au": 0b1},
    "Cs": {"A'": 0b0, 'A"': 0b1},
    "C2": {"A": 0b0, "B": 0b1},
    "C2h": {"Ag": 0b00, "Bg": 0b01, "Au": 0b10, "Bu": 0b11},
    "C2v": {"A1": 0b00, "B1": 0b01, "B2": 0b10, "A2": 0b11},
    "D2":  {"A": 0b00, "B1": 0b01, "B2": 0b10, "B3": 0b11},
    "D2h": {
        "Ag": 0b000, "B1g": 0b100, "B2g": 0b010, "B3g": 0b110,
        "Au": 0b001, "B1u": 0b101, "B2u": 0b011, "B3u": 0b111,
    },
}

# --------------------------------------------------------------------------- #
#   Formatting functions
# --------------------------------------------------------------------------- #

def _fmt(v: float) -> str:
    """Format float for FCIDUMP (16 decimal places, exponential notation)."""
    if v == 0.0: 
        return " 0.0000000000000000E+00"
    r = int(math.log10(abs(v)))
    m, e = (v / 10**(r + 1), r + 1) if abs(v) >= 1 else (v / 10**r, r)
    return f"{ '  ' if v > 0 else ' '}{m:0.16f}E{'+' if e >= 0 else '-'}{abs(e):02d}"


def _normalize_exp(s: str) -> str:
    """Normalize exponential notation (archiver compatibility)."""
    s = s.strip().replace("e", "E")
    if "E" not in s:
        return s
    base, exp = s.split("E", 1)
    sign = "+" if not exp.startswith(("-", "+")) else exp[0]
    try:
        val = int(exp[1:] if exp and exp[0] in "+-" else exp)
    except ValueError:
        return s
    return f"{base}E{sign}{abs(val):02d}"


def _fmt_archiver(val: float) -> str:
    """Format float for archiver (10 decimal places)."""
    return _normalize_exp(f"{val: .10E}")


def _line(v: float, i: int, j: int, k: int, l: int) -> bytes:
    """Format integral line (1-indexed)."""
    return (f"{_fmt(v)}{i+1:{IND_WIDTH}d}{j+1:{IND_WIDTH}d}"
            f"{k+1:{IND_WIDTH}d}{l+1:{IND_WIDTH}d}\n").encode()


def _line_from_token(token: str, i: int, j: int, k: int, l: int) -> bytes:
    """Format integral line from pre-formatted token (archiver compatibility)."""
    s = (
        f"{token:>{TOKEN_WIDTH}s}"
        f"{i:>{IND_WIDTH}d}{j:>{IND_WIDTH}d}{k:>{IND_WIDTH}d}{l:>{IND_WIDTH}d}\n"
    )
    return s.encode("ascii")


def header_lines(norb: int, nelec: int, ms2: int, orbsym: str, isym: int = 1) -> List[str]:
    """
    Generate FCIDUMP header lines.

    Parameters
    ----------
    norb : int
        Number of orbitals.
    nelec : int
        Number of electrons.
    ms2 : int
        2*M_S (twice the z-component of spin).
    orbsym : str
        Comma-separated orbital symmetry IDs.
    isym : int, optional
        Molpro symmetry ID for the wavefunction. Default is 1.

    Returns
    -------
    List[str]
        FCIDUMP header lines.
    """
    return [
        f" &FCI NORB= {norb},NELEC= {nelec},MS2= {ms2},\n",
        f"  ORBSYM={orbsym},\n  ISYM={isym},\n /\n"
    ]


def const_line(e0: float) -> List[str]:
    """Format energy constant line."""
    return [f"{_fmt(e0)}{0:{IND_WIDTH}d}{0:{IND_WIDTH}d}{0:{IND_WIDTH}d}{0:{IND_WIDTH}d}\n"]


# Aliases for backward compatibility
_MOLPRO_ID = MOLPRO_ID
_BITS = ORBSYM_BITS
