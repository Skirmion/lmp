"""
One-electron integrals processing module.

This module handles the computation and writing of one-electron integrals
for FCIDUMP files, including:
- Frozen-core Hamiltonian construction
- Effective 1e integrals in the active space
- Energy constant calculation (nuclear + frozen orbitals)
- Writing 1e sections to text FCIDUMP files

Functions
---------
build_frozen_core : Compute frozen-core effective Hamiltonian
append_one_e_section : Write 1e integrals to FCIDUMP file
append_constant : Write energy constant to FCIDUMP file
"""

import gc
import time
from typing import Callable, Iterable, Optional, Sequence, Tuple

import numpy as np
from pyscf import scf

from .fmt import _fmt, IND_WIDTH, const_line


def build_frozen_core(
    mol, method, mo_sorted: np.ndarray, frozen_idx: Sequence[int],
    occ: Sequence[float], extra1e: Optional[np.ndarray] = None
) -> Tuple[np.ndarray, float, float]:
    """
    Construct frozen-core effective Hamiltonian for active space.
    
    This function computes the effective one-electron Hamiltonian that includes
    the Coulomb and exchange interactions with frozen (doubly occupied) orbitals.
    
    The frozen-core energy is computed as:
        E_frozen = E_nuc + Tr(D * h_core) + 0.5 * Tr(D * (J - 0.5*K))
    
    The effective Hamiltonian is:
        h_eff = h_core + J - 0.5*K
    
    where D is the density matrix of frozen orbitals, J is the Coulomb matrix,
    and K is the exchange matrix.
    
    Parameters
    ----------
    mol : pyscf.gto.Mole
        PySCF molecule object.
    method : pyscf.scf.RHF or similar
        PySCF method object with get_hcore().
    mo_sorted : np.ndarray
        Sorted MO coefficient matrix, shape (n_ao, n_mo).
    frozen_idx : Sequence[int]
        Indices of frozen orbitals (in sorted MO basis).
    occ : Sequence[float]
        Occupations of frozen orbitals (typically 2.0 for closed-shell).
    extra1e : np.ndarray, optional
        Additional 1e operator in AO basis to add to h_core.
        Shape (n_ao, n_ao).
    
    Returns
    -------
    h_fc : np.ndarray
        Frozen-core effective Hamiltonian in AO basis, shape (n_ao, n_ao).
    e_const : float
        Energy constant (nuclear + frozen orbital contribution).
    pyscf_time : float
        Time spent in PySCF integral calculation (seconds).
    
    Notes
    -----
    - If frozen_idx is empty, returns h_core + extra1e and E_nuc.
    - The returned h_fc must be transformed to MO basis by the caller.
    - This function measures and returns time spent in PySCF get_hcore() and get_jk().
    """
    t_pyscf = 0.0
    
    t_start = time.time()
    h_ao = method.get_hcore(mol)
    t_pyscf += time.time() - t_start
    
    if extra1e is not None: 
        h_ao = h_ao + extra1e
    
    if not frozen_idx: 
        return h_ao, float(mol.energy_nuc()), t_pyscf
    
    dm = np.zeros_like(h_ao)
    for i, o in zip(frozen_idx, occ):
        c = mo_sorted[:, i]
        dm += o * np.outer(c, c)
    
    t_start = time.time()
    j, k = scf.hf.get_jk(mol, dm, hermi=1)
    t_pyscf += time.time() - t_start
    
    h_fc = h_ao + j - 0.5 * k
    e0 = (
        mol.energy_nuc() + float(np.einsum("ij,ij->", dm, h_ao))
        + 0.5 * float(np.einsum("ij,ij->", dm, j - 0.5 * k))
    )
    
    return h_fc, e0, t_pyscf

# --------------------------------------------------------------------------- #
#   One-electron integral iteration
# --------------------------------------------------------------------------- #

def _build_blocks_from_orbsym(orbsym_sorted: Sequence[int]) -> list[tuple[int, int]]:
    """
    Build contiguous blocks of orbitals with the same symmetry label.
    
    Groups consecutive orbitals that share the same symmetry ID into blocks.
    Used for block-wise processing of 1e integrals to optimize memory access.
    
    Parameters
    ----------
    orbsym_sorted : Sequence[int]
        Sorted orbital symmetry IDs (Molpro convention).
    
    Returns
    -------
    list[tuple[int, int]]
        List of (start, end) index pairs for each symmetry block.
        Empty list if orbsym_sorted is empty.
    
    Examples
    --------
    >>> _build_blocks_from_orbsym([1, 1, 1, 2, 2, 3])
    [(0, 3), (3, 5), (5, 6)]
    """
    blocks = []
    if not orbsym_sorted: return blocks
    s = 0
    for i in range(1, len(orbsym_sorted)):
        if orbsym_sorted[i] != orbsym_sorted[i-1]:
            blocks.append((s, i))
            s = i
    blocks.append((s, len(orbsym_sorted)))
    return blocks

def iter_one_e_lines_onfly(
    h_ao_fc: np.ndarray, mo_coeff: np.ndarray, sorted_idx: Sequence[int],
    frozen_idx: Sequence[int], tol: float, log_fn: Optional[Callable[[str], None]],
    orbsym_sorted: Sequence[int]
) -> Iterable[str]:
    """
    Generate one-electron integral lines in FCIDUMP format on-the-fly.
    
    This function transforms the frozen-core Hamiltonian to the active MO basis
    and yields FCIDUMP-formatted lines (upper triangular only). It processes
    integrals block-by-block according to orbital symmetry to optimize memory.
    
    Parameters
    ----------
    h_ao_fc : np.ndarray
        Frozen-core effective Hamiltonian in AO basis, shape (n_ao, n_ao).
    mo_coeff : np.ndarray
        Full MO coefficient matrix, shape (n_ao, n_mo).
    sorted_idx : Sequence[int]
        Permutation indices for symmetry sorting.
    frozen_idx : Sequence[int]
        Indices of frozen orbitals in sorted MO basis.
    tol : float
        Integral threshold; |h_ij| <= tol are discarded.
    log_fn : Callable[[str], None], optional
        Logging function for progress messages.
    orbsym_sorted : Sequence[int]
        Molpro symmetry IDs for sorted MOs (for block structure).
    
    Yields
    ------
    str
        FCIDUMP-formatted lines: "value i j 0 0\n"
        where i >= j (upper triangular only).
    
    Notes
    -----
    - Frozen orbitals are excluded from output.
    - Active orbital indices are remapped to 1-based contiguous integers.
    - Symmetry blocks are processed separately to optimize memory access.
    - Memory is explicitly freed after processing via gc.collect().
    """
    Hp = h_ao_fc[np.ix_(sorted_idx, sorted_idx)]
    Cp = mo_coeff[sorted_idx][:, sorted_idx]  # (nao, norb_sorted)

    # Active orbital mask (after freezing)
    mask = np.ones(Cp.shape[1], dtype=bool)
    if frozen_idx:
        mask[np.asarray(frozen_idx, dtype=int)] = False
    active_all = np.where(mask)[0]  # Indices in sorted system
    n_act_total = active_all.size

    blocks = _build_blocks_from_orbsym(orbsym_sorted)

    # Intersect blocks with active MOs
    printed_index_of_active = {}  # key: idx_in_sorted; val: 1-based printed idx
    act_running = 0
    active_blocks: list[list[int]] = []  # Lists of active indices (in sorted numbering) for each block

    act_set = set(active_all.tolist())
    for s, e in blocks:
        blk_act = [i for i in range(s, e) if i in act_set]
        if blk_act:
            active_blocks.append(blk_act)
            for i in blk_act:
                act_running += 1
                printed_index_of_active[i] = act_running

    # Main output
    for bi, blk in enumerate(active_blocks, start=1):
        cols = [Cp[:, i] for i in blk]
        for a_loc, ia_sorted in enumerate(blk):
            col_i = cols[a_loc]
            i_print = printed_index_of_active[ia_sorted]
            for b_loc in range(0, a_loc + 1):  # j ≤ i  (j<i+1)
                ib_sorted = blk[b_loc]
                col_j = cols[b_loc]
                j_print = printed_index_of_active[ib_sorted]

                val = float(np.einsum("i,ij,j->", col_i, Hp, col_j, optimize=True))
                if abs(val) > tol:
                    yield f"{_fmt(val)}{i_print:{IND_WIDTH}d}{j_print:{IND_WIDTH}d}{0:{IND_WIDTH}d}{0:{IND_WIDTH}d}\n"

            if log_fn:
                log_fn(f"1e-row {i_print}/{n_act_total} (block {bi}/{len(active_blocks)})")

    del Hp, Cp
    gc.collect()

def append_one_e_section(
    file_path: str,
    h_fc: np.ndarray,
    mo_prepared_full: np.ndarray,
    perm: Sequence[int],
    frozen_idx: Sequence[int],
    tol: float,
    log_fn: Optional[Callable[[str], None]],
    orbsym_sorted: Sequence[int],
) -> None:
    """
    Append one-electron integral section to FCIDUMP file (text format).
    
    This function transforms the frozen-core Hamiltonian to the active MO basis
    and writes the integrals in FCIDUMP format (upper triangular only).
    
    Parameters
    ----------
    file_path : str
        Path to FCIDUMP file (opened in append mode).
    h_fc : np.ndarray
        Frozen-core effective Hamiltonian in AO basis, shape (n_ao, n_ao).
    mo_prepared_full : np.ndarray
        Full MO coefficient matrix (original basis), shape (n_ao, n_mo).
    perm : Sequence[int]
        Permutation indices for symmetry sorting.
    frozen_idx : Sequence[int]
        Indices of frozen orbitals in sorted MO basis.
    tol : float
        Integral threshold; |h_ij| <= tol are discarded.
    log_fn : Callable[[str], None], optional
        Logging function for memory checkpoints.
    orbsym_sorted : Sequence[int]
        Molpro symmetry IDs for sorted MOs (for block structure).
    
    Notes
    -----
    - Integrals are written in Molpro FCIDUMP format: value i j 0 0
    - Only upper triangle (i >= j) is written.
    - Frozen orbitals are excluded from output.
    - Symmetry blocks are processed separately to optimize memory.
    """
    with open(file_path, "a", encoding="utf-8") as fh:
        for line in iter_one_e_lines_onfly(
            h_fc,
            mo_prepared_full,
            perm,
            frozen_idx,
            tol,
            log_fn,
            orbsym_sorted,
        ):
            fh.write(line)


def append_constant(file_path: str, e0: float) -> None:
    """
    Append energy constant to FCIDUMP file (text format).
    
    Parameters
    ----------
    file_path : str
        Path to FCIDUMP file (opened in append mode).
    e0 : float
        Energy constant (nuclear + frozen orbital contribution).
    
    Notes
    -----
    Written in FCIDUMP format: value 0 0 0 0
    """
    with open(file_path, "a", encoding="utf-8") as fh:
        fh.writelines(const_line(e0))
