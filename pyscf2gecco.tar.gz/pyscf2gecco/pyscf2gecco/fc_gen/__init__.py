"""
fc_gen - PySCF to FCIDUMP converter module.

This module provides functionality for converting PySCF molecular integrals
to FCIDUMP format optimized for GECCO quantum chemistry software.
"""

from .fc_gen import FCIDumpWriter

__all__ = ["FCIDumpWriter"]
__version__ = "1.0.0"
