"""
Metadata utilities for FCIDUMP generation.

This module provides functions for extracting and writing metadata related to
FCIDUMP files, including:
- Molecular geometry extraction from PySCF molecule objects
- Basis set and ECP definition extraction from source files
- Metadata file generation (FCIDUMP_info.txt) with complete calculation parameters

The metadata file includes:
- System parameters (orbitals, electrons, spin, symmetry)
- Molecular geometry
- Basis set and ECP definitions
- Processing parameters (tolerance, granularity, frozen orbitals)
- Source file information

Functions
---------
get_atom_geometry : Extract molecular geometry from PySCF Mole object
get_basis_ecp_blocks_from_file : Extract basis/ECP definitions from source file
print_basis_ecp_blocks_from_file : Print extracted basis/ECP blocks
write_metadata : Write comprehensive metadata file for FCIDUMP
"""

from __future__ import annotations

import re
from pathlib import Path
from typing import Dict, List, Mapping, Optional, Sequence, Tuple, Union

import numpy as np

__all__ = [
    "get_atom_geometry",
    "get_basis_ecp_blocks_from_file",
    "print_basis_ecp_blocks_from_file",
    "write_metadata",
]


def get_atom_geometry(mol, unit: str = "Ang") -> List[str]:
    """
    Extract molecular geometry from PySCF Mole object.
    
    Parameters
    ----------
    mol : pyscf.gto.Mole
        PySCF molecule object.
    unit : str, optional
        Coordinate units: "Ang" (Angstrom) or "Bohr". Default is "Ang".
    
    Returns
    -------
    List[str]
        List of geometry strings in format "Element x y z" with 10 decimal places.
    
    Examples
    --------
    >>> from pyscf import gto
    >>> mol = gto.M(atom='H 0 0 0; H 0 0 0.74', basis='sto-3g')
    >>> geom = get_atom_geometry(mol)
    >>> print(geom[0])
    H 0.0000000000 0.0000000000 0.0000000000
    """
    coords = mol.atom_coords(unit=unit)
    lines: List[str] = []
    for i in range(mol.natm):
        sym = mol.atom_symbol(i)
        x, y, z = coords[i]
        lines.append(f"{sym} {x:.10f} {y:.10f} {z:.10f}")
    return lines


def get_basis_ecp_blocks_from_file(
    mol,
    source_file: Union[str, Path],
    *_args,
    **_kwargs,
) -> Dict[str, Optional[str]]:
    """
    Extract basis set and ECP definitions from source file.
    
    This function parses the source Python file to find the last assignments
    to 'basis' and 'ecp' variables (e.g., mol.basis = ... or M(basis=...)).
    
    Parameters
    ----------
    mol : pyscf.gto.Mole
        PySCF molecule object (for signature compatibility; not used).
    source_file : str or Path
        Path to the source Python file containing basis/ECP definitions.
    
    Returns
    -------
    dict
        Dictionary with keys:
        - "basis_block": str or None - Extracted basis definition
        - "basis_hint": str or None - Brief basis hint (e.g., "cc-pvdz")
        - "ecp_block": str or None - Extracted ECP definition
        - "ecp_hint": str or None - Brief ECP hint
        - "source_file": str - Resolved absolute path to source file
        - "matched_var": None - (reserved for future use)
        - "matched_lineno": int or None - Line number of last match
    
    Notes
    -----
    - If source_file does not exist, returns all None values.
    - Only the LAST assignment to basis/ecp in the file is extracted.
    - Supports various assignment patterns: mol.basis = ..., M(basis=...), etc.
    
    Examples
    --------
    >>> info = get_basis_ecp_blocks_from_file(mol, 'my_calc.py')
    >>> print(info['basis_block'])
    'cc-pvdz'
    """
    path = Path(source_file).expanduser().resolve()
    if not path.exists():
        return {
            "basis_block": None,
            "basis_hint": None,
            "ecp_block": None,
            "ecp_hint": None,
            "source_file": str(path),
            "matched_var": None,
            "matched_lineno": None,
        }

    text = path.read_text(encoding="utf-8", errors="replace")
    basis_block, basis_hint, basis_line = _extract_last_assignment(text, "basis")
    ecp_block, ecp_hint, ecp_line = _extract_last_assignment(text, "ecp")

    return {
        "basis_block": basis_block,
        "basis_hint": basis_hint,
        "ecp_block": ecp_block,
        "ecp_hint": ecp_hint,
        "source_file": str(path),
        "matched_var": None,
        "matched_lineno": basis_line or ecp_line,
    }


def print_basis_ecp_blocks_from_file(
    mol, source_file: Union[str, Path], *_args, **_kwargs
) -> None:
    """
    Print extracted basis set and ECP definitions to stdout.
    
    Convenience function that calls get_basis_ecp_blocks_from_file() and
    formats the output for display.
    
    Parameters
    ----------
    mol : pyscf.gto.Mole
        PySCF molecule object (for signature compatibility).
    source_file : str or Path
        Path to the source Python file.
    
    Examples
    --------
    >>> print_basis_ecp_blocks_from_file(mol, 'my_calc.py')
    # source: /path/to/my_calc.py
    # matched_var: None  at line: 42
    
    # BASIS (last):
    cc-pvdz
    # basis_hint: cc-pvdz
    """
    info = get_basis_ecp_blocks_from_file(mol, source_file, *_args, **_kwargs)
    print(f"# source: {info['source_file']}")
    print(f"# matched_var: {info['matched_var']}  at line: {info['matched_lineno']}")
    if info["basis_block"]:
        print("\n# BASIS (last):")
        print(info["basis_block"])
        if info["basis_hint"]:
            print(f"# basis_hint: {info['basis_hint']}")
    else:
        print("\n# BASIS assignment not found")

    if info["ecp_block"]:
        print("\n# ECP (last):")
        print(info["ecp_block"])
        if info["ecp_hint"]:
            print(f"# ecp_hint: {info['ecp_hint']}")
    else:
        print("\n# ECP assignment not found")


def write_metadata(
    mol,
    file_path: Union[str, Path],
    *,
    norb: int,
    nelec: int,
    ms2: int,
    force_c1: bool,
    natorb: bool,
    sort_by_symmetry: bool,
    granularity: int,
    tol: float,
    frozen_idx: Sequence[int],
    active_idx: Sequence[int],
    orbsym_ids_active: Sequence[int],
    orbsym_bits_active: Sequence[int] | np.ndarray,
    orbsym_str: str,
    perm: Sequence[int],
    add_ops: Optional[Sequence[str]],
    twoe_intor: Sequence[str],
    twoe_extra_shapes: Sequence[Sequence[int]],
    source_file: Optional[Union[str, Path]] = None,
) -> None:
    """
    Write comprehensive metadata file for FCIDUMP generation.
    
    Creates a text file (typically FCIDUMP_info.txt) containing all parameters
    used for FCIDUMP generation, including molecular geometry, basis set/ECP
    definitions, processing parameters, and orbital information.
    
    Parameters
    ----------
    mol : pyscf.gto.Mole
        PySCF molecule object.
    file_path : str or Path
        Output path for metadata file.
    norb : int
        Number of active orbitals.
    nelec : int
        Number of active electrons.
    ms2 : int
        Spin multiplicity (2S).
    force_c1 : bool
        Whether C1 symmetry was forced.
    natorb : bool
        Whether natural orbitals were used.
    sort_by_symmetry : bool
        Whether orbitals were sorted by symmetry.
    granularity : int
        Chunking granularity used.
    tol : float
        Integral threshold.
    frozen_idx : Sequence[int]
        Frozen orbital indices.
    active_idx : Sequence[int]
        Active orbital indices.
    orbsym_ids_active : Sequence[int]
        Molpro symmetry IDs for active orbitals.
    orbsym_bits_active : Sequence[int] or np.ndarray
        Binary symmetry labels for active orbitals.
    orbsym_str : str
        Comma-separated orbital symmetry string.
    perm : Sequence[int]
        Permutation indices for symmetry sorting.
    add_ops : Sequence[str], optional
        Additional operators that were included.
    twoe_intor : Sequence[str]
        PySCF 2e integral names used.
    twoe_extra_shapes : Sequence[Sequence[int]]
        Shapes of additional 2e operators.
    source_file : str or Path, optional
        Path to source file for basis/ECP extraction.
    
    Notes
    -----
    The metadata file includes:
    - System parameters (norb, nelec, ms2, etc.)
    - Processing parameters (tol, granularity, frozen/active indices)
    - Orbital symmetry information
    - Molecular geometry
    - Basis set and ECP definitions (if source_file provided)
    - Additional operator information
    
    Examples
    --------
    >>> write_metadata(
    ...     mol, 'FCIDUMP_info.txt',
    ...     norb=10, nelec=8, ms2=0,
    ...     force_c1=False, natorb=True, sort_by_symmetry=True,
    ...     granularity=50, tol=1e-15,
    ...     frozen_idx=[0, 1], active_idx=list(range(2, 12)),
    ...     orbsym_ids_active=[1]*10, orbsym_bits_active=[0]*10,
    ...     orbsym_str="1,1,1,1,1,1,1,1,1,1", perm=list(range(12)),
    ...     add_ops=["int1e_kin"], twoe_intor=["int2e"],
    ...     twoe_extra_shapes=[], source_file='my_calc.py'
    ... )
    """
    path = Path(file_path)
    with path.open("w", encoding="utf-8") as fh:
        fh.write("# FCIDUMP metadata\n")
        fh.write(f"norb = {norb}\n")
        fh.write(f"nelec = {nelec}\n")
        fh.write(f"ms2 = {ms2}\n")
        fh.write(f"force_c1 = {force_c1}\n")
        fh.write(f"natorb = {natorb}\n")
        fh.write(f"sort_by_symmetry = {sort_by_symmetry}\n")
        fh.write(f"granularity = {granularity}\n")
        fh.write(f"tol = {tol}\n")
        fh.write(f"frozen_idx = {list(frozen_idx)}\n")
        fh.write(f"active_idx = {list(active_idx)}\n")
        fh.write(f"orbsym_ids_active = {list(orbsym_ids_active)}\n")
        bits = np.asarray(orbsym_bits_active).tolist()
        fh.write(f"orbsym_bits_active = {bits}\n")
        fh.write(f"orbsym_str = {orbsym_str}\n")
        fh.write(f"perm = {list(perm)}\n")

        if add_ops is None:
            fh.write("add_ops = None\n")
        else:
            fh.write(f"add_ops = {list(add_ops)}\n")

        fh.write(f"twoe_intor = {list(twoe_intor)}\n")
        fh.write(f"twoe_extra_shapes = {list(map(tuple, twoe_extra_shapes))}\n")

        if source_file is not None:
            fh.write(f"source_file = {Path(source_file)}\n")

        fh.write("\n")
        try:
            geometry_unit = mol.unit
            fh.write(f"# Geometry ({geometry_unit})\n")
            for line in get_atom_geometry(mol, unit=geometry_unit):
                fh.write(f"{line}\n")
        except Exception as exc:  # noqa: BLE001
            fh.write(f"# geometry_error: {exc}\n")

        fh.write("\n")
        if source_file is not None:
            try:
                info = get_basis_ecp_blocks_from_file(mol, source_file)
                fh.write("# BASIS block\n")
                basis_block = info.get("basis_block")
                fh.write((basis_block if basis_block else "<not found>") + "\n")
                basis_hint = info.get("basis_hint")
                if basis_hint:
                    fh.write(f"# basis_hint: {basis_hint}\n")

                fh.write("\n# ECP block\n")
                ecp_block = info.get("ecp_block")
                fh.write((ecp_block if ecp_block else "<not found>") + "\n")
                ecp_hint = info.get("ecp_hint")
                if ecp_hint:
                    fh.write(f"# ecp_hint: {ecp_hint}\n")
            except Exception as exc:  # noqa: BLE001
                fh.write(f"# basis_ecp_error: {exc}\n")


# --------------------------------------------------------------------------- #
#   Вспомогательные функции
# --------------------------------------------------------------------------- #


def _ensure_path(p: Union[str, Path]) -> Path:
    return Path(p).expanduser().resolve()


def _extract_last_assignment(text: str, keyword: str) -> Tuple[Optional[str], Optional[str], Optional[int]]:
    pattern = re.compile(rf"^\s*(?:\w+\.)?{keyword}\s*=\s*(.+)$", re.MULTILINE)
    matches = list(pattern.finditer(text))
    if not matches:
        return None, None, None

    match = matches[-1]
    rhs = match.group(1).rstrip()
    block = match.group(0).strip()
    hint = _first_string_literal(rhs)

    # Попытка захватить тройные кавычки (многострочные литералы)
    if rhs.startswith("'''") or rhs.startswith('"""'):
        quote = rhs[:3]
        start = match.end(1) - len(rhs)
        rest = text[start:]
        end = rest.find(quote, 3)
        if end != -1:
            block = text[match.start(): start + end + 3].strip()
    
    # Попытка захватить словарь {...} или список [...]
    elif rhs.startswith('{') or rhs.startswith('['):
        opening = rhs[0]
        closing = '}' if opening == '{' else ']'
        start_pos = match.end(1) - len(rhs)
        rest = text[start_pos:]
        
        # Поиск соответствующей закрывающей скобки с учётом вложенности
        depth = 0
        end_pos = -1
        for i, char in enumerate(rest):
            if char == opening:
                depth += 1
            elif char == closing:
                depth -= 1
                if depth == 0:
                    end_pos = i
                    break
        
        if end_pos != -1:
            block = text[match.start(): start_pos + end_pos + 1].strip()
            # Для словаря/списка hint берём как есть, без обработки
            hint = None

    return block, hint, match.start()


def _first_string_literal(rhs: str) -> Optional[str]:
    string_pattern = re.compile(r"('''.*?'''|\"\"\".*?\"\"\"|'[^']*'|\"[^\"]*\")", re.DOTALL)
    match = string_pattern.search(rhs)
    if not match:
        return None
    literal = match.group(0)
    cleaned = literal.strip("'\"")
    return cleaned if cleaned else None
