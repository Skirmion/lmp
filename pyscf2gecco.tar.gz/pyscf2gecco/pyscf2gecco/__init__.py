"""
pyscf2gecco - PySCF to GeCCo Converter and Utilities.

This package provides comprehensive tools for working with GeCCo quantum chemistry
software, including integral conversion, file compression, pseudopotential handling,
input generation, test automation, and execution management.

Main Classes
------------
FCIDumpWriter
    Convert PySCF molecular calculations to FCIDUMP format with configurable
    granularity, symmetry handling, and orbital transformations.

GeCCoArchiver
    Compress, archive, and restore FCIDUMP files using binary and compressed
    formats with parallel processing support.

GeccoInputBuilder
    Generate GeCCo/IC-MRCC input files from PySCF calculations with automatic
    parameter extraction and formatting.

FCIDUMPRunner
    Execute GeCCo calculations with intelligent FCIDUMP handling, supporting
    RAM and disk modes with automatic format conversion.

Submodules
----------
ecp
    Pseudopotential (GRECP/QED) loading, validation, and diagnostics.
    Functions: load_pseudopotential, load_qed, print_ecp_diagnostics, etc.

gen_inp
    GeCCo input file generation utilities with template system.
    Main class: GeccoInputBuilder

runner
    GeCCo execution management with FCIDUMP format handling.
    Main class: FCIDUMPRunner

auto_test
    Automated testing framework for GeCCo calculations with batch execution.
    Main classes: TestConfig, TestResult, RunnerConfig
    Main functions: run_test, run_all_tests

Quick Start Examples
--------------------
Generate FCIDUMP from PySCF calculation:

    >>> from pyscf import gto, scf
    >>> from pyscf2gecco import FCIDumpWriter
    >>> 
    >>> mol = gto.M(atom='H 0 0 0; H 0 0 0.74', basis='sto-3g')
    >>> mf = scf.RHF(mol).run()
    >>> 
    >>> writer = FCIDumpWriter(mol, mf, granularity=50)
    >>> writer.run('FCIDUMP')

Compress FCIDUMP files:

    >>> from pyscf2gecco import GeCCoArchiver
    >>> 
    >>> archiver = GeCCoArchiver()
    >>> archiver.compress_fcidump('project_dir')

Load pseudopotential:

    >>> from pyscf2gecco import ecp
    >>> 
    >>> pseudo_text = ecp.load_pseudopotential("U60")
    >>> ecp.print_ecp_diagnostics("U60")

Generate GeCCo input file:

    >>> from pyscf2gecco import GeccoInputBuilder
    >>> 
    >>> builder = GeccoInputBuilder(
    ...     name="h2o_casscf",
    ...     mol=mol,
    ...     wf=casscf,
    ...     group="c2v"
    ... )
    >>> builder.write()

Run GeCCo calculation:

    >>> from pyscf2gecco.runner import FCIDUMPRunner
    >>> 
    >>> runner = FCIDUMPRunner(gecco_bin="gecco.x", verbose=True)
    >>> exit_code = runner.run("job.inp", mode="ram", grace=600.0)

Automated testing:

    >>> from pyscf2gecco.auto_test import RunnerConfig, run_all_tests
    >>> 
    >>> cfg = RunnerConfig(
    ...     gecco_inputs=Path("gecco_inputs"),
    ...     pyscf_inputs=Path("pyscf_inputs"),
    ...     max_workers=8,
    ...     tolerance=1e-8
    ... )
    >>> results, summary = run_all_tests(cfg)

Module Organization
-------------------
pyscf2gecco/
├── fc_gen/          # FCIDUMP generation from PySCF
├── archiver/        # FCIDUMP compression and archiving
├── ecp/             # Pseudopotential utilities
├── gen_inp/         # GeCCo input file generation
├── runner/          # GeCCo execution management
└── auto_test/       # Automated testing framework

Version and License
-------------------
Version: 1.0.0
License: MIT
Python: >= 3.8

Dependencies
------------
Required:
- numpy >= 1.20.0
- pyscf >= 2.0.0
- psutil >= 5.8.0

Optional (for archiver):
- Cython >= 0.29.0 (for binary codec acceleration)
- zstd library (for compression)

Installation
------------
Basic installation:
    pip install pyscf2gecco

With archiver support:
    pip install pyscf2gecco[archiver]

Development installation:
    pip install -e .[archiver]

See Also
--------
Documentation: README.md, QUICKSTART.md
Examples: examples_*.py files in package directory
"""

from .fc_gen.fc_gen import FCIDumpWriter
from .archiver.gecco_archiver import GeCCoArchiver
from .gen_inp.gecco_input_writer import GeccoInputBuilder
from .runner.fcidump_runner import FCIDUMPRunner

# Submodules available as: pyscf2gecco.{ecp, gen_inp, runner, auto_test}
from . import ecp
from . import gen_inp
from . import runner
from . import auto_test

__version__ = "1.0.0"
__all__ = [
    "FCIDumpWriter",
    "GeCCoArchiver",
    "GeccoInputBuilder",
    "FCIDUMPRunner",
    "ecp",
    "gen_inp",
    "runner",
    "auto_test",
    "__version__"
]
