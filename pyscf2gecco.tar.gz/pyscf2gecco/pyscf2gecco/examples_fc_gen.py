#!/usr/bin/env python3
"""
Examples demonstrating FCIDumpWriter usage after pip installation.

This file shows comprehensive usage of all features available in the fc_gen
module for converting PySCF calculations to FCIDUMP format.
"""

from pyscf import gto, scf, mcscf
from pyscf2gecco import FCIDumpWriter
import numpy as np


def example_basic_rhf():
    """
    Example 1: Basic FCIDUMP generation from RHF calculation.
    
    Demonstrates:
    - Creating a simple molecule
    - Running RHF calculation
    - Generating FCIDUMP file
    """
    print("=" * 70)
    print("Example 1: Basic RHF to FCIDUMP")
    print("=" * 70)
    
    # Create H2 molecule
    mol = gto.M(
        atom='H 0 0 0; H 0 0 0.74',
        basis='sto-3g',
        symmetry=True
    )
    
    # Run RHF calculation
    mf = scf.RHF(mol).run()
    
    # Generate FCIDUMP file
    writer = FCIDumpWriter(
        mol=mol,
        method=mf,
        granularity=50,
        tol=1e-15
    )
    writer.run('FCIDUMP_H2_rhf')
    print("✓ FCIDUMP_H2_rhf generated successfully\n")


def example_with_symmetry():
    """
    Example 2: FCIDUMP with molecular symmetry.
    
    Demonstrates:
    - Using symmetry-adapted calculations
    - Preserving orbital symmetry labels in FCIDUMP
    """
    print("=" * 70)
    print("Example 2: FCIDUMP with symmetry")
    print("=" * 70)
    
    # Create H2O molecule with C2v symmetry
    mol = gto.M(
        atom='''
        O  0.0000  0.0000  0.0000
        H  0.7572  0.5865  0.0000
        H -0.7572  0.5865  0.0000
        ''',
        basis='6-31g',
        symmetry='C2v'
    )
    
    mf = scf.RHF(mol).run()
    
    writer = FCIDumpWriter(
        mol=mol,
        method=mf,
        granularity=100,
        tol=1e-14
    )
    writer.run('FCIDUMP_H2O_sym')
    print("✓ FCIDUMP_H2O_sym generated with C2v symmetry\n")


def example_frozen_core():
    """
    Example 3: FCIDUMP with frozen core orbitals.
    
    Demonstrates:
    - Freezing core orbitals for correlated calculations
    - Using frozen_indices parameter
    """
    print("=" * 70)
    print("Example 3: FCIDUMP with frozen core")
    print("=" * 70)
    
    # Create CH4 molecule
    mol = gto.M(
        atom='''
        C  0.0000  0.0000  0.0000
        H  0.6276  0.6276  0.6276
        H -0.6276 -0.6276  0.6276
        H -0.6276  0.6276 -0.6276
        H  0.6276 -0.6276 -0.6276
        ''',
        basis='cc-pvdz'
    )
    
    mf = scf.RHF(mol).run()
    
    # Freeze core orbitals (1s orbital of carbon)
    writer = FCIDumpWriter(
        mol=mol,
        method=mf,
        frozen_indices=[0],  # Freeze first orbital
        granularity=50,
        tol=1e-15
    )
    writer.run('FCIDUMP_CH4_frozen')
    print("✓ FCIDUMP_CH4_frozen generated with frozen core\n")


def example_custom_mo_coefficients():
    """
    Example 4: FCIDUMP with custom MO coefficients.
    
    Demonstrates:
    - Providing custom orbital coefficients
    - Bypassing automatic MO extraction from method
    """
    print("=" * 70)
    print("Example 4: FCIDUMP with custom MO coefficients")
    print("=" * 70)
    
    mol = gto.M(
        atom='He 0 0 0',
        basis='sto-3g'
    )
    
    mf = scf.RHF(mol).run()
    
    # Create custom MO coefficients (e.g., rotated orbitals)
    custom_mo = mf.mo_coeff.copy()
    # Apply some rotation (example: identity for simplicity)
    
    writer = FCIDumpWriter(
        mol=mol,
        method=mf,
        mo_coeff=custom_mo,  # Use custom MO coefficients
        granularity=50,
        tol=1e-15
    )
    writer.run('FCIDUMP_He_custom_mo')
    print("✓ FCIDUMP_He_custom_mo generated with custom MO\n")


def example_natural_orbitals():
    """
    Example 5: FCIDUMP with natural orbitals from CASSCF.
    
    Demonstrates:
    - Using natorb=True to generate natural orbitals
    - Working with CASSCF calculations
    """
    print("=" * 70)
    print("Example 5: FCIDUMP with natural orbitals")
    print("=" * 70)
    
    mol = gto.M(
        atom='H 0 0 0; H 0 0 0.74',
        basis='6-31g'
    )
    
    # Run CASSCF calculation
    mf = scf.RHF(mol).run()
    mc = mcscf.CASSCF(mf, 2, 2)  # (2e, 2o) active space
    mc.run()
    
    # Generate FCIDUMP with natural orbitals
    writer = FCIDumpWriter(
        mol=mol,
        method=mc,
        natorb=True,  # Use natural orbitals
        granularity=50,
        tol=1e-15
    )
    writer.run('FCIDUMP_H2_natorb')
    print("✓ FCIDUMP_H2_natorb generated with natural orbitals\n")


def example_additional_operators():
    """
    Example 6: FCIDUMP with additional one-electron operators.
    
    Demonstrates:
    - Adding custom one-electron operators (e.g., dipole moments)
    - Format: add_ops = [("name", matrix), ...]
    """
    print("=" * 70)
    print("Example 6: FCIDUMP with additional operators")
    print("=" * 70)
    
    mol = gto.M(
        atom='H 0 0 0; H 0 0 0.74',
        basis='sto-3g'
    )
    
    mf = scf.RHF(mol).run()
    
    # Calculate dipole moment integrals
    dipole_ints = mol.intor('int1e_r')  # Shape: (3, nao, nao)
    
    # Add dipole operators
    add_ops = [
        ("DMX", dipole_ints[0]),  # x-component
        ("DMY", dipole_ints[1]),  # y-component
        ("DMZ", dipole_ints[2]),  # z-component
    ]
    
    writer = FCIDumpWriter(
        mol=mol,
        method=mf,
        add_ops=add_ops,  # List of (name, matrix) tuples
        granularity=50,
        tol=1e-15
    )
    writer.run('FCIDUMP_H2_dipole')
    print("✓ FCIDUMP_H2_dipole generated with dipole operators\n")


def example_binary_compressed():
    """
    Example 7: Generate compressed binary FCIDUMP.
    
    Demonstrates:
    - Creating binary FCIDUMP format
    - Applying zstd compression
    """
    print("=" * 70)
    print("Example 7: Compressed binary FCIDUMP")
    print("=" * 70)
    
    mol = gto.M(
        atom='''
        N 0 0 0
        N 0 0 1.09
        ''',
        basis='6-31g**',
        symmetry=True
    )
    
    mf = scf.RHF(mol).run()
    
    writer = FCIDumpWriter(
        mol=mol,
        method=mf,
        granularity=100,
        tol=1e-14
    )
    
    # Generate compressed binary format
    writer.run('FCIDUMP_N2', binary=True, compress=True)
    print("✓ FCIDUMP_N2.bin.zst generated (compressed binary)\n")


def example_metadata():
    """
    Example 8: FCIDUMP with custom metadata.
    
    Demonstrates:
    - Adding user metadata to FCIDUMP file
    - Metadata format and usage
    """
    print("=" * 70)
    print("Example 8: FCIDUMP with custom metadata")
    print("=" * 70)
    
    mol = gto.M(
        atom='Li 0 0 0',
        basis='6-31g'
    )
    
    mf = scf.RHF(mol).run()
    
    # Define custom metadata
    metadata = {
        "author": "John Doe",
        "date": "2025-01-18",
        "project": "Li atom test",
        "notes": "Single atom RHF calculation"
    }
    
    writer = FCIDumpWriter(
        mol=mol,
        method=mf,
        user_meta=metadata,  # Custom metadata dictionary
        granularity=50,
        tol=1e-15
    )
    writer.run('FCIDUMP_Li_meta')
    print("✓ FCIDUMP_Li_meta generated with metadata\n")


def example_uhf():
    """
    Example 9: FCIDUMP from unrestricted (UHF) calculation.
    
    Demonstrates:
    - Working with UHF calculations
    - Handling spin-polarized orbitals
    """
    print("=" * 70)
    print("Example 9: UHF to FCIDUMP")
    print("=" * 70)
    
    # Create radical system (H atom)
    mol = gto.M(
        atom='H 0 0 0',
        basis='6-31g',
        spin=1  # One unpaired electron
    )
    
    # Run UHF calculation
    mf = scf.UHF(mol).run()
    
    writer = FCIDumpWriter(
        mol=mol,
        method=mf,
        granularity=50,
        tol=1e-15
    )
    writer.run('FCIDUMP_H_uhf')
    print("✓ FCIDUMP_H_uhf generated from UHF\n")


def example_combined_features():
    """
    Example 10: Combining multiple features.
    
    Demonstrates:
    - Frozen core + natural orbitals + custom metadata
    - Complete workflow for production calculations
    """
    print("=" * 70)
    print("Example 10: Combined features")
    print("=" * 70)
    
    mol = gto.M(
        atom='''
        O 0.0 0.0 0.0
        O 0.0 0.0 1.2
        ''',
        basis='cc-pvdz',
        symmetry='D2h'
    )
    
    # RHF + CASSCF
    mf = scf.RHF(mol).run()
    mc = mcscf.CASSCF(mf, 6, 8)  # (6e, 8o) active space
    mc.run()
    
    # Custom metadata
    metadata = {
        "molecule": "O2",
        "method": "CASSCF(6,8)",
        "basis": "cc-pvdz",
        "symmetry": "D2h"
    }
    
    writer = FCIDumpWriter(
        mol=mol,
        method=mc,
        frozen_indices=[0, 1],  # Freeze 1s orbitals on both O atoms
        natorb=True,  # Use natural orbitals
        user_meta=metadata,
        granularity=100,
        tol=1e-14
    )
    
    # Generate compressed binary
    writer.run('FCIDUMP_O2_full', binary=True, compress=True)
    print("✓ FCIDUMP_O2_full.bin.zst generated with all features\n")


if __name__ == '__main__':
    print("\n")
    print("=" * 70)
    print("FCIDumpWriter Examples - Complete Usage Guide")
    print("=" * 70)
    print("\n")
    
    # Run all examples
    example_basic_rhf()
    example_with_symmetry()
    example_frozen_core()
    example_custom_mo_coefficients()
    example_natural_orbitals()
    example_additional_operators()
    example_binary_compressed()
    example_metadata()
    example_uhf()
    example_combined_features()
    
    print("=" * 70)
    print("All FCIDumpWriter examples completed successfully!")
    print("=" * 70)
