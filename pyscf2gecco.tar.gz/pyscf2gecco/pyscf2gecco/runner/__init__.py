"""
GeCCo Execution Runner Module.

This module provides FCIDUMPRunner for executing GeCCo quantum chemistry
calculations with intelligent FCIDUMP file handling, supporting multiple
formats and execution modes.

Classes
-------
FCIDUMPRunner
    Execute GeCCo with automatic FCIDUMP format handling and resource management.

Example
-------
    >>> from pyscf2gecco.runner import FCIDUMPRunner
    >>> 
    >>> runner = FCIDUMPRunner(gecco_bin="gecco.x", verbose=True)
    >>> exit_code = runner.run("calculation.inp", mode="ram", grace=600.0)
"""

from .fcidump_runner import FCIDUMPRunner

__all__ = ["FCIDUMPRunner"]
