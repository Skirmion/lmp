# FCIDUMP Runner для GeCCo

Обновленный runner для запуска GeCCo с поддержкой произвольных имен FCIDUMP файлов и автоопределением формата.

## Основные изменения

### 1. Упрощенные режимы работы
- **`mode="ram"`** - распаковка в RAM (/dev/shm)
- **`mode="disk"`** - распаковка на диск
- **Автоматика**: если найден текстовый FCIDUMP и не указан fcidump_filename, mode игнорируется и используется существующий файл

### 2. Параметр `fcidump_filename`
Позволяет указать произвольное имя FCIDUMP файла:
```python
runner.run(
    gecco_inp="job.inp",
    mode="ram",
    fcidump_filename="my_integrals"  # вместо FCIDUMP
)
```

### 3. Автоопределение формата
Формат файла определяется по сигнатуре (не по расширению):
- `FCD5` (4 байта) → .bin формат
- `0x28B52FFD` → .bin.zst формат  
- Текст с `&FCI` → текстовый FCIDUMP

### 4. Приоритет файлов
Если `fcidump_filename` не указан:
1. `FCIDUMP` (текст)
2. `FCIDUMP.bin`
3. `FCIDUMP.bin.zst`

### 5. Проверка существования
- **disk mode**: ошибка если `./FCIDUMP` уже существует
- **ram mode**: ошибка если `./FCIDUMP` уже существует

### 6. Всегда текстовый формат
- Любой входной формат → распаковывается в `./FCIDUMP` (текст)
- Не создается `FCIDUMP_info.txt`

## Логика работы

### Случай 1: Текстовый FCIDUMP существует, fcidump_filename не указан
```python
# Файл ./FCIDUMP уже существует в текстовом виде
runner.run("job.inp", mode="ram")  # mode игнорируется!
```
**Поведение:**
- mode игнорируется (ram/disk не важно)
- gecco.x запускается с существующим ./FCIDUMP
- Файл НЕ удаляется после завершения
- Никакой обработки не происходит

### Случай 2: Указан fcidump_filename, файл текстовый
```python
# Файл my_data - текстовый FCIDUMP
runner.run("job.inp", mode="ram", fcidump_filename="my_data")
runner.run("job.inp", mode="disk", fcidump_filename="my_data")
```
**Поведение (одинаково для ram и disk):**
- Проверка: ./FCIDUMP не должен существовать
- Создается **симлинк**: ./FCIDUMP → my_data
- gecco.x запускается
- Симлинк удаляется, исходный файл остается

**Примечание:** Для текстовых файлов mode не влияет на способ обработки - всегда создается симлинк, чтобы избежать лишнего копирования.

### Случай 3: Бинарный/сжатый FCIDUMP
```python
# Файл FCIDUMP.bin.zst нужно распаковать
runner.run("job.inp", mode="ram")  # mode работает!
```
**Поведение для mode="ram":**
- Распаковка в /dev/shm (RAM)
- Создается симлинк: ./FCIDUMP → /dev/shm/FCIDUMP_xxx.txt
- gecco.x запускается
- После завершения: удаляются симлинк и файл в RAM

**Поведение для mode="disk":**
- Проверка: ./FCIDUMP не должен существовать (иначе ошибка)
- Распаковка на диск: ./FCIDUMP
- gecco.x запускается
- После завершения: ./FCIDUMP удаляется

### Случай 4: fcidump_filename указывает на бинарный файл
```python
runner.run("job.inp", mode="ram", fcidump_filename="integrals.bin.zst")
```
**Поведение:**
- Формат определяется автоматически по сигнатуре
- mode работает (ram или disk)
- Распаковка в текст → ./FCIDUMP
- После завершения удаляется

## Примеры использования

### Базовый пример
```python
from pyscf2gecco.runner.fcidump_runner import FCIDUMPRunner

runner = FCIDUMPRunner(verbose=True)

# Запуск с FCIDUMP.bin.zst в RAM
exit_code = runner.run(
    gecco_inp="job.inp",
    mode="ram"
)
```

### Произвольное имя файла
```python
runner = FCIDUMPRunner()

# Файл "custom_integrals" может быть .txt, .bin или .bin.zst
# Формат определяется автоматически
exit_code = runner.run(
    gecco_inp="job.inp",
    mode="disk",
    fcidump_filename="custom_integrals"
)
```

### RAM mode с мониторингом
```python
runner = FCIDUMPRunner(verbose=True)

# Удаление из RAM после закрытия файла (grace period = 30 sec)
exit_code = runner.run(
    gecco_inp="job.inp",
    mode="ram",
    grace=30.0,  # Удалить через 30 сек после закрытия
    interval=2.0  # Проверять каждые 2 сек
)
```

### Disk mode с проверкой
```python
runner = FCIDUMPRunner()

# Ошибка если ./FCIDUMP уже существует
try:
    exit_code = runner.run(
        gecco_inp="job.inp",
        mode="disk",
        fcidump_filename="data.bin.zst"  # .bin.zst файл с любым именем
    )
except FileExistsError as e:
    print(f"Error: {e}")
```

## Сигнатура метода run()

```python
def run(
    self,
    gecco_inp: str,              # Путь к GeCCo input файлу
    mode: str = "ram",           # "ram" или "disk"
    fcidump_filename: Optional[str] = None,  # Имя FCIDUMP файла
    out_name: Optional[str] = None,          # Имя output файла
    grace: Optional[float] = None,           # Grace period для RAM mode
    interval: float = 2.0,                   # Интервал мониторинга
    chunk_records: int = 500_000,           # Устаревший параметр
) -> int:  # Возвращает exit code GeCCo
```

## Поддерживаемые форматы

| Формат | Расширение | Сигнатура | Поддержка |
|--------|-----------|-----------|-----------|
| Текст | .txt, без расширения | `&FCI` | ✅ |
| Бинарный v5 | .bin | `FCD5` | ✅ |
| Сжатый | .bin.zst | `0x28B52FFD` | ✅ |

## Workflow

```
┌─────────────────────────────────────────┐
│ Входной файл (любое имя)               │
│ • my_data                               │
│ • integrals.bin                        │  
│ • custom.bin.zst                       │
└─────────────────────────────────────────┘
              │
              ▼
    ┌──────────────────┐
    │ Автоопределение  │
    │ формата по       │
    │ сигнатуре        │
    └──────────────────┘
              │
              ▼
    ┌──────────────────┐
    │ Распаковка в     │
    │ RAM или на диск  │
    └──────────────────┘
              │
              ▼
    ┌──────────────────┐
    │ ./FCIDUMP        │
    │ (текстовый)      │
    └──────────────────┘
              │
              ▼
    ┌──────────────────┐
    │ Запуск GeCCo     │
    └──────────────────┘
              │
              ▼
    ┌──────────────────┐
    │ Автоудаление     │
    │ ./FCIDUMP        │
    └──────────────────┘
```

## Обратная совместимость

Старый код продолжает работать:
```python
# Устаревший API (все еще работает)
runner.run("job.inp", mode="ram")

# Новый API (рекомендуется)
runner.run("job.inp", mode="ram", fcidump_filename="custom")
```

## Требования

- Python 3.7+
- pyscf2gecco с обновленным архиватором
- Опционально: libzstd для .bin.zst файлов
- Опционально: Cython расширения для ускорения

## Ограничения

1. **Имя выходного файла**: всегда `./FCIDUMP` (текст)
2. **Удаление info файлов**: `FCIDUMP_info.txt` автоматически удаляется
3. **Мониторинг**: только для RAM mode с `grace` parameter
4. **Platform**: /proc monitoring работает только на Linux

## См. также

- `FILENAME_PARAMETER_README.md` - документация по fcidump_filename
- `API_FILENAME_EXAMPLES.md` - примеры использования архиватора
- `fcidump_runner.py` - исходный код
