# Поведение FCIDUMPRunner - Полное описание

## Матрица поведения

| fcidump_filename | Файл найден | Формат | mode | Поведение |
|------------------|-------------|--------|------|-----------|
| **None** | FCIDUMP | текст | любой | ✓ mode **игнорируется**, используется как есть, **не удаляется** |
| **None** | FCIDUMP.bin | bin | ram | ✓ Распаковка в RAM → симлинк, **удаляется** |
| **None** | FCIDUMP.bin | bin | disk | ✓ Распаковка на диск, **удаляется** |
| **None** | FCIDUMP.bin.zst | zst | ram | ✓ Распаковка в RAM → симлинк, **удаляется** |
| **None** | FCIDUMP.bin.zst | zst | disk | ✓ Распаковка на диск, **удаляется** |
| **"my_file"** | my_file | текст | ram | ✓ **СИМЛИНК** ./FCIDUMP → my_file, **симлинк удаляется** |
| **"my_file"** | my_file | текст | disk | ✓ **СИМЛИНК** ./FCIDUMP → my_file, **симлинк удаляется** |
| **"my_file"** | my_file | bin | ram | ✓ Распаковка в RAM → симлинк, **удаляется** |
| **"my_file"** | my_file | bin | disk | ✓ Распаковка на диск, **удаляется** |
| **"my_file"** | my_file | zst | ram | ✓ Распаковка в RAM → симлинк, **удаляется** |
| **"my_file"** | my_file | zst | disk | ✓ Распаковка на диск, **удаляется** |

## Детальные сценарии

### Сценарий 1: Текстовый FCIDUMP уже есть

**Команда:**
```python
runner.run("job.inp", mode="ram")  # или mode="disk"
```

**Условия:**
- `./FCIDUMP` существует
- Это текстовый файл
- `fcidump_filename=None`

**Что происходит:**
```
1. Обнаружен ./FCIDUMP (текст)
2. mode игнорируется (ram/disk не важно)
3. gecco.x запускается напрямую
4. ./FCIDUMP остается на месте
```

**Вывод:**
```
[MODE] auto-detected existing ./FCIDUMP (text); using as-is (mode ignored)
[RUN ] PID=12345 CMD='gecco.x job.inp' OUT='job.out' (stderr=console)
[DONE] gecco.x exit code 0 at 2025-10-19 18:00:00
```

---

### Сценарий 2: Текстовый файл с произвольным именем

**Команда (RAM mode):**
```python
runner.run("job.inp", mode="ram", fcidump_filename="integrals_data")
```

**Условия:**
- `integrals_data` существует
- Это текстовый файл (определено по сигнатуре)
- `fcidump_filename="integrals_data"`
- `mode="ram"`

**Что происходит:**
```
1. Обнаружен integrals_data (текст)
2. Проверка: ./FCIDUMP не существует ✓
3. Создается СИМЛИНК: ./FCIDUMP -> integrals_data
4. gecco.x запускается
5. Симлинк удаляется, integrals_data остается
```

**Вывод:**
```
[MODE] ram; creating symlink ./FCIDUMP -> integrals_data
[RUN ] PID=12345 CMD='gecco.x job.inp' OUT='job.out' (stderr=console)
[DONE] gecco.x exit code 0 at 2025-10-19 18:00:00
[CLEAN] removed symlink ./FCIDUMP at 2025-10-19 18:00:00
```

---

**Команда (DISK mode):**
```python
runner.run("job.inp", mode="disk", fcidump_filename="integrals_data")
```

**Условия:**
- `integrals_data` существует
- Это текстовый файл
- `fcidump_filename="integrals_data"`
- `mode="disk"`

**Что происходит:**
```
1. Обнаружен integrals_data (текст)
2. Проверка: ./FCIDUMP не существует ✓
3. Создается симлинк: integrals_data -> ./FCIDUMP
4. gecco.x запускается
5. ./FCIDUMP удаляется, integrals_data остается
```

**Вывод:**
```
[MODE] disk; copying integrals_data -> ./FCIDUMP
[RUN ] PID=12345 CMD='gecco.x job.inp' OUT='job.out' (stderr=console)
[DONE] gecco.x exit code 0 at 2025-10-19 18:00:00
[CLEAN] removed ./FCIDUMP at 2025-10-19 18:00:00
```

---

### Сценарий 3: Бинарный файл, RAM mode

**Команда:**
```python
runner.run("job.inp", mode="ram", grace=30.0)
```

**Условия:**
- `FCIDUMP.bin` существует
- `fcidump_filename=None`
- `mode="ram"`

**Что происходит:**
```
1. Обнаружен FCIDUMP.bin
2. Распаковка в /dev/shm/FCIDUMP_abc123.txt
3. Создается симлинк: ./FCIDUMP → /dev/shm/FCIDUMP_abc123.txt
4. gecco.x запускается
5. [Опционально] Мониторинг с grace period
6. После завершения удаляются:
   - симлинк ./FCIDUMP
   - файл /dev/shm/FCIDUMP_abc123.txt
```

**Вывод:**
```
[MODE] ram; materializing FCIDUMP at /dev/shm/FCIDUMP_abc123.txt (RAM) and symlinking as ./FCIDUMP
[BUILD] Header: norb=10 nelec=4 ms2=0 records=5000
[BUILD] Text FCIDUMP ready at /dev/shm/FCIDUMP_abc123.txt (size=250000 bytes, dev:ino=0:12345)
[RAM ] ready at 2025-10-19 18:00:00; size=250000 bytes; dev:ino=0:12345; link=./FCIDUMP; non_empty_lines=5000
[RUN ] PID=12345 CMD='gecco.x job.inp' OUT='job.out' (stderr=console)
[MON ] enabled; grace=30.0s interval=2.0s
[DONE] gecco.x exit code 0 at 2025-10-19 18:05:00
[CLEAN] unlinked ./FCIDUMP at 2025-10-19 18:05:00
[CLEAN] removed /dev/shm/FCIDUMP_abc123.txt at 2025-10-19 18:05:00 (lifetime 300.00s)
```

---

### Сценарий 4: Сжатый файл, disk mode

**Команда:**
```python
runner.run("job.inp", mode="disk", fcidump_filename="data.bin.zst")
```

**Условия:**
- `data.bin.zst` существует
- Это .bin.zst файл (определено по сигнатуре)
- `mode="disk"`
- `./FCIDUMP` НЕ существует

**Что происходит:**
```
1. Обнаружен data.bin.zst (zst формат)
2. Проверка: ./FCIDUMP не существует ✓
3. Распаковка на диск: ./FCIDUMP
4. gecco.x запускается
5. После завершения ./FCIDUMP удаляется
```

**Вывод:**
```
[MODE] disk; building ./FCIDUMP on disk
[BUILD] Header: norb=10 nelec=4 ms2=0 records=5000
[BUILD] Text FCIDUMP ready at ./FCIDUMP (size=250000 bytes, dev:ino=2049:67890)
[RUN ] PID=12345 CMD='gecco.x job.inp' OUT='job.out' (stderr=console)
[DONE] gecco.x exit code 0 at 2025-10-19 18:05:00
[CLEAN] removed ./FCIDUMP at 2025-10-19 18:05:00
```

---

### Сценарий 5: disk mode, но FCIDUMP уже существует

**Команда:**
```python
runner.run("job.inp", mode="disk")
```

**Условия:**
- `FCIDUMP.bin` существует (нужно распаковать)
- `./FCIDUMP` УЖЕ существует на диске
- `mode="disk"`

**Что происходит:**
```
1. Обнаружен FCIDUMP.bin
2. Проверка: ./FCIDUMP существует ✗
3. Ошибка: FileExistsError
```

**Вывод:**
```
FileExistsError: mode='disk': 'FCIDUMP' already exists in CWD; refusing to overwrite
```

---

## Ключевые правила

### 1. Когда mode игнорируется
- ✅ Найден текстовый FCIDUMP и `fcidump_filename=None`

### 2. Когда mode работает
- ✅ Указан `fcidump_filename` (для любого формата, включая текст!)
- ✅ Найден .bin файл
- ✅ Найден .bin.zst файл

### 3. Когда файл удаляется
- ✅ mode="ram": симлинк (для текстовых с fcidump_filename) или симлинк + файл в RAM (для bin/zst)
- ✅ mode="disk": копия ./FCIDUMP (для текстовых с fcidump_filename) или распакованный ./FCIDUMP (для bin/zst)
- ❌ Текстовый FCIDUMP без fcidump_filename не удаляется

### 4. Проверки существования
- ✅ mode="disk": ./FCIDUMP не должен существовать (для всех случаев кроме fcidump_filename=None)
- ✅ mode="ram": ./FCIDUMP не должен существовать (для текстовых с fcidump_filename)
- ✅ mode="ram": ./FCIDUMP не должен существовать (для bin/zst)

### 5. Обработка текстовых файлов с fcidump_filename
- ✅ mode="ram": создается **симлинк** (быстро, без копирования)
- ✅ mode="disk": создается **симлинк** (быстро, без копирования)
- ⚡ Текстовые файлы **никогда** не копируются - только симлинк!

## Автоматические действия

1. **Определение формата** - всегда по сигнатуре файла
2. **Удаление info файлов** - `FCIDUMP_info.txt` всегда удаляется
3. **Конвертация в текст** - всегда создается ./FCIDUMP в текстовом виде
4. **Cleanup** - автоматическое удаление временных файлов

## Примеры ошибок

### Ошибка 1: FCIDUMP уже существует (disk mode)
```python
runner.run("job.inp", mode="disk")  # ./FCIDUMP exists
# FileExistsError: mode='disk': 'FCIDUMP' already exists in CWD
```

### Ошибка 2: Файл не найден
```python
runner.run("job.inp", mode="ram", fcidump_filename="missing_file")
# FileNotFoundError: FCIDUMP file not found: missing_file
```

### Ошибка 3: Неверный mode
```python
runner.run("job.inp", mode="none")
# ValueError: mode must be one of: 'ram', 'disk'
```
