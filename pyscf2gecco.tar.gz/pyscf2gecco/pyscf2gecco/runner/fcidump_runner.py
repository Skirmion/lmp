"""
GeCCo runner with RAM/disk FCIDUMP modes and FCIDUMP v5-aware decoder.

This module provides FCIDUMPRunner class that executes GeCCo quantum chemistry
calculations with intelligent FCIDUMP file handling. It supports multiple
FCIDUMP formats and execution modes optimized for different use cases.

Main Features
-------------
- Automatic FCIDUMP format detection (text, binary .bin, compressed .bin.zst)
- RAM-based execution for fast I/O with optional memory monitoring
- Disk-based execution for memory-constrained environments
- Transparent decompression and format conversion
- Process monitoring with automatic resource cleanup

Execution Modes
---------------
mode='ram':
    Expands FCIDUMP into a RAM-backed text file (/dev/shm if available,
    otherwise system temp directory) and creates a symlink as './FCIDUMP'.
    Optional grace period monitoring: when grace is set (seconds), monitors
    /proc/<pid>/fd and automatically deletes the RAM file and symlink as soon
    as FCIDUMP has remained closed continuously for at least 'grace' seconds.
    If grace is None (default), no monitoring occurs and cleanup happens on exit.

mode='disk':
    Expands FCIDUMP into './FCIDUMP' in the current working directory.
    Raises FileExistsError if './FCIDUMP' already exists (prevents overwrites).
    After GeCCo process terminates, automatically deletes the generated file.

Format Support
--------------
- Text FCIDUMP: Uses directly (creates symlink to avoid copying)
- Binary .bin (v5): Decoded using Cython/OpenMP codec (or pure Python fallback)
- Compressed .bin.zst: Decompressed then decoded to text format

File Resolution Priority (when fcidump_filename not specified):
    1. FCIDUMP (text)
    2. FCIDUMP.bin (binary v5)
    3. FCIDUMP.bin.zst (compressed binary v5)

When fcidump_filename is specified, uses that file directly with automatic
format detection by file signature.

Process I/O Handling
--------------------
- Stdout: Redirected to '<stem>.out' file
- Stderr: Passed to console (preserves Fortran runtime messages and status)

Performance Characteristics
---------------------------
Binary decoding uses FCIDUMP v5 codec with Cython/OpenMP acceleration when
available, providing efficient parallel decompression and format conversion.
RAM mode minimizes disk I/O for improved performance on systems with fast
memory but slow storage.

Example Usage
-------------
    >>> from pyscf2gecco.runner import FCIDUMPRunner
    >>> 
    >>> # Basic usage with RAM mode
    >>> runner = FCIDUMPRunner(gecco_bin="gecco.x", verbose=True)
    >>> exit_code = runner.run("job.inp", mode="ram")
    >>> 
    >>> # With grace period for early cleanup
    >>> exit_code = runner.run(
    ...     "job.inp", 
    ...     mode="ram",
    ...     grace=600.0,  # Delete after 10 min of being closed
    ...     interval=5.0   # Check every 5 seconds
    ... )
    >>> 
    >>> # Disk mode for memory-constrained systems
    >>> exit_code = runner.run("job.inp", mode="disk")
    >>> 
    >>> # Custom FCIDUMP filename
    >>> exit_code = runner.run(
    ...     "job.inp",
    ...     mode="ram",
    ...     fcidump_filename="my_integrals.bin.zst"
    ... )
"""

from __future__ import annotations

import datetime
import json
import os
import shutil
import struct
import subprocess
import tempfile
import time
import uuid
from typing import Dict, List, Optional, Tuple

import sys

from ..archiver.archiver_core import read_meta_from_zst, restore_loose_fcidump, _detect_fcidump_format
try:
    from ..archiver.fcidump_codec import bin_to_text_parallel, read_meta_from_bin
except ImportError:
    # Fallback for direct script execution
    import sys
    import os
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'archiver'))
    from fcidump_codec import bin_to_text_parallel, read_meta_from_bin

try:
    from ..fc_gen.fmt import header_lines, _line  # FCIDUMP text emitters
except ImportError:
    # Fallback
    import sys
    import os
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'fc_gen'))
    from fmt import header_lines, _line


class FCIDUMPRunner:
    """
    Execute GeCCo quantum chemistry calculations with intelligent FCIDUMP handling.

    FCIDUMPRunner provides flexible execution modes for GeCCo calculations,
    automatically handling FCIDUMP file format conversions and optimizing
    resource usage based on the selected execution mode.

    The runner supports transparent handling of text, binary (.bin), and
    compressed (.bin.zst) FCIDUMP formats, with automatic format detection
    and conversion. It can execute in RAM mode for performance or disk mode
    for memory-constrained environments.

    Parameters
    ----------
    gecco_bin : str, optional
        Path to the gecco.x executable binary. If not provided or set to
        'gecco.x', the executable will be resolved via system PATH.
        Default: 'gecco.x'
    verbose : bool, optional
        Enable detailed lifecycle logging. When True, prints comprehensive
        information about file operations, process status, and resource
        cleanup. When False, only essential information and errors are shown.
        Default: False

    Attributes
    ----------
    gecco_bin : str
        Path to the GeCCo executable
    verbose : bool
        Verbosity flag for logging

    Examples
    --------
    Basic usage with automatic file detection:

        >>> runner = FCIDUMPRunner()
        >>> exit_code = runner.run("calculation.inp", mode="ram")

    Custom GeCCo binary with verbose logging:

        >>> runner = FCIDUMPRunner(
        ...     gecco_bin="/opt/gecco/bin/gecco.x",
        ...     verbose=True
        ... )
        >>> exit_code = runner.run("job.inp", mode="disk")

    RAM mode with grace period monitoring:

        >>> runner = FCIDUMPRunner(verbose=True)
        >>> exit_code = runner.run(
        ...     gecco_inp="large_job.inp",
        ...     mode="ram",
        ...     grace=300.0,  # Auto-cleanup after 5 min closed
        ...     interval=2.0  # Check every 2 seconds
        ... )

    Notes
    -----
    - The runner creates temporary files and symlinks which are automatically
      cleaned up after execution
    - In RAM mode, /dev/shm is preferred when available for optimal performance
    - Binary format conversion uses parallel decoding when Cython extensions
      are available
    - Process monitoring (grace period) requires /proc filesystem (Linux only)

    See Also
    --------
    run : Main execution method
    """

    def __init__(self, gecco_bin: str = "gecco.x", verbose: bool = False) -> None:
        self.gecco_bin = gecco_bin
        self.verbose = verbose

    # ------------------------------------------------------------------ #
    # Public API
    # ------------------------------------------------------------------ #

    def run(
        self,
        gecco_inp: str,
        mode: str = "ram",
        fcidump_filename: Optional[str] = None,
        out_name: Optional[str] = None,
        grace: Optional[float] = None,
        interval: float = 2.0,
        chunk_records: int = 500_000,
    ) -> int:
        """
        Execute gecco.x with automatic FCIDUMP format handling and mode selection.

        This method orchestrates the complete GeCCo execution workflow: resolves
        and prepares the FCIDUMP file (converting format if needed), sets up the
        execution environment based on the selected mode, launches GeCCo, and
        performs cleanup after completion.

        Parameters
        ----------
        gecco_inp : str
            Path to the GeCCo input file (e.g., 'job.inp', 'calculation.inp').
            Must exist in the current working directory or be an absolute path.
        mode : {'ram', 'disk'}, optional
            Execution mode that determines FCIDUMP handling strategy:
            
            - 'ram': Creates FCIDUMP in RAM-backed filesystem (/dev/shm or temp)
              and symlinks as './FCIDUMP'. Optimal for fast I/O and large files.
              Automatically cleaned up after execution.
            
            - 'disk': Creates './FCIDUMP' directly in current working directory.
              Suitable for memory-constrained systems. Will raise FileExistsError
              if './FCIDUMP' already exists to prevent data loss.
            
            Default: 'ram'
        fcidump_filename : str, optional
            Custom FCIDUMP filename to use instead of auto-detection. When
            specified, this exact file will be used and its format will be
            detected automatically by file signature. Supports:
            - Text FCIDUMP files (any name)
            - Binary .bin files (FCIDUMP v5 format)
            - Compressed .bin.zst files
            
            If None (default), auto-detection tries in order:
            1. FCIDUMP (text)
            2. FCIDUMP.bin (binary)
            3. FCIDUMP.bin.zst (compressed)
            
            Default: None
        out_name : str, optional
            Destination file for GeCCo stdout. If None, defaults to
            '<input_stem>.out' (e.g., 'job.inp' -> 'job.out').
            Stderr remains directed to console to preserve Fortran runtime
            messages and status output.
            Default: None
        grace : float, optional
            Grace period in seconds for automatic FCIDUMP cleanup in RAM mode.
            When set, enables /proc-based monitoring that tracks file descriptor
            usage. The RAM file and symlink are automatically deleted as soon as
            FCIDUMP has remained closed continuously for at least this duration.
            
            Useful for large calculations where FCIDUMP is read early and kept
            closed for extended periods, allowing early memory reclamation.
            
            Only effective in 'ram' mode. Requires Linux /proc filesystem.
            If None (default), no monitoring occurs and cleanup happens only
            after GeCCo terminates.
            Default: None
        interval : float, optional
            Polling interval in seconds for grace period monitoring. Only used
            when grace is not None. Determines how frequently /proc/<pid>/fd is
            checked for file descriptor status. Smaller values provide faster
            response but higher CPU overhead.
            Default: 2.0
        chunk_records : int, optional
            Legacy parameter kept for backward compatibility. No longer used by
            the FCIDUMP v5 decoder which handles chunking automatically.
            Default: 500000

        Returns
        -------
        int
            GeCCo exit code. Returns 0 on successful completion, non-zero on
            error. The exit code is the raw return value from gecco.x process.

        Raises
        ------
        FileNotFoundError
            - If gecco_inp does not exist
            - If no valid FCIDUMP source file is found
            - If specified fcidump_filename does not exist
        FileExistsError
            - If mode='disk' and './FCIDUMP' already exists in CWD
            - If mode='ram' and './FCIDUMP' symlink already exists
        ValueError
            - If mode is not 'ram' or 'disk'
            - If FCIDUMP format cannot be determined
        RuntimeError
            - If binary decompression or format conversion fails
            - If symlink creation fails in RAM mode

        Notes
        -----
        File Lifecycle:
            1. Source FCIDUMP is identified and format detected
            2. If needed, FCIDUMP is converted to text format
            3. In RAM mode: File created in /dev/shm, symlink as ./FCIDUMP
            4. In disk mode: File created directly as ./FCIDUMP
            5. GeCCo process is launched with output redirection
            6. Monitoring thread started if grace is set (RAM mode only)
            7. After completion or grace timeout: automatic cleanup
        
        Performance Considerations:
            - RAM mode: Faster I/O, requires sufficient RAM for FCIDUMP
            - Disk mode: Lower memory usage, may be I/O bound
            - Binary/compressed formats: Parallel decompression when available
            - Grace monitoring: Minimal CPU overhead (~0.1% per check)
        
        Thread Safety:
            Not thread-safe. Each FCIDUMPRunner instance should be used by
            a single thread. For concurrent calculations, create separate
            runner instances in separate working directories.

        Examples
        --------
        Simple execution with auto-detection:

            >>> runner = FCIDUMPRunner()
            >>> rc = runner.run("calculation.inp")
            >>> if rc == 0:
            ...     print("Success")

        RAM mode with early cleanup for long calculation:

            >>> runner = FCIDUMPRunner(verbose=True)
            >>> rc = runner.run(
            ...     gecco_inp="large_system.inp",
            ...     mode="ram",
            ...     grace=600.0,  # Cleanup after 10 min closed
            ...     interval=5.0
            ... )

        Disk mode with custom FCIDUMP file:

            >>> runner = FCIDUMPRunner()
            >>> rc = runner.run(
            ...     gecco_inp="job.inp",
            ...     mode="disk",
            ...     fcidump_filename="archived_integrals.bin.zst",
            ...     out_name="calculation_output.log"
            ... )

        See Also
        --------
        FCIDUMPRunner : Class documentation with more examples
        """
        if not os.path.isfile(gecco_inp):
            raise FileNotFoundError(f"Input not found: {gecco_inp}")

        stem = os.path.splitext(os.path.basename(gecco_inp))[0]
        out_path = out_name or f"{stem}.out"

        if mode not in {"disk", "ram"}:
            raise ValueError("mode must be one of: 'ram', 'disk'")

        source_kind, source_path = self._resolve_source(fcidump_filename)

        # Если найден текстовый FCIDUMP и не указан конкретный fcidump_filename
        # то mode игнорируется - просто используем существующий файл
        if source_kind == "text" and fcidump_filename is None:
            self._log("[MODE] auto-detected existing ./FCIDUMP (text); using as-is (mode ignored)")
            proc = self._run_gecco_redirect(gecco_inp, out_path)
            rc = proc.wait()
            if rc != 0:
                print(f"[gecco] non-zero exit ({rc})", file=sys.stderr)
            else:
                self._log(f"[DONE] gecco.x exit code 0 at {self._ts()}")
            return rc

        # Если указан fcidump_filename с текстовым файлом
        # то mode РАБОТАЕТ - копируем/линкуем в ./FCIDUMP
        if source_kind == "text" and fcidump_filename is not None:
            # Проверка: если mode=disk и ./FCIDUMP существует - ошибка
            if mode == "disk" and os.path.lexists("FCIDUMP"):
                raise FileExistsError(
                    f"mode='disk': './FCIDUMP' already exists in CWD"
                )
            
            # Проверка: если mode=ram и ./FCIDUMP существует - ошибка
            if mode == "ram" and os.path.lexists("FCIDUMP"):
                raise FileExistsError(
                    f"mode='ram': './FCIDUMP' already exists in CWD"
                )
            
            # Теперь обрабатываем в зависимости от mode
            return self._run_text_fcidump(
                gecco_inp,
                out_path,
                source_path,
                mode,
            )

        if mode == "disk":
            return self._run_mode_disk(
                gecco_inp,
                out_path,
                source_path,
                source_kind,
                chunk_records,
            )

        return self._run_mode_ram(
            gecco_inp,
            out_path,
            source_path,
            source_kind,
            grace,
            interval,
            chunk_records,
        )

    # ------------------------------------------------------------------ #
    # Logging / filesystem / /proc helpers
    # ------------------------------------------------------------------ #

    def _log(self, msg: str) -> None:
        """Print a log line if verbose=True."""
        if self.verbose:
            print(msg, flush=True)

    @staticmethod
    def _ts(t: Optional[float] = None) -> str:
        """Return a human-readable timestamp."""
        return datetime.datetime.fromtimestamp(t or time.time()).strftime(
            "%Y-%m-%d %H:%M:%S"
        )

    @staticmethod
    def _pick_ram_dir() -> str:
        """Prefer /dev/shm; fallback to system temp dir."""
        if os.path.isdir("/dev/shm") and os.access("/dev/shm", os.W_OK):
            return "/dev/shm"
        return tempfile.gettempdir()

    @staticmethod
    def _file_id(path: str) -> Tuple[int, int]:
        """Return (dev, ino) for a path."""
        st = os.stat(path, follow_symlinks=True)
        return st.st_dev, st.st_ino

    @staticmethod
    def _list_fds(pid: int) -> List[str]:
        """List /proc/<pid>/fd entries; return [] if inaccessible."""
        try:
            base = f"/proc/{pid}/fd"
            return [os.path.join(base, name) for name in os.listdir(base)]
        except Exception:
            return []

    @staticmethod
    def _fd_points_to(fd_path: str, target_id: Tuple[int, int]) -> bool:
        """Check if a /proc/.../fd entry points to a given (dev, ino)."""
        try:
            st = os.stat(fd_path, follow_symlinks=True)
            return (st.st_dev, st.st_ino) == target_id
        except Exception:
            return False

    def _resolve_source(self, fcidump_filename: Optional[str] = None) -> Tuple[str, str]:
        """
        Return ('text'|'bin'|'zst', path) for the FCIDUMP source.
        
        If fcidump_filename is provided:
          - Uses that specific file (format auto-detected by signature)
        If fcidump_filename is None:
          - Tries FCIDUMP (text), then FCIDUMP.bin, then FCIDUMP.bin.zst
        """
        if fcidump_filename:
            # Используем указанный файл, определяем формат по сигнатуре
            file_path = os.path.abspath(fcidump_filename)
            if not os.path.isfile(file_path):
                raise FileNotFoundError(f"FCIDUMP file not found: {fcidump_filename}")
            
            # Определяем формат по сигнатуре (импортировано выше)
            detected_format = _detect_fcidump_format(file_path)
            
            if detected_format == "txt":
                return "text", file_path
            elif detected_format == "bin":
                return "bin", file_path
            elif detected_format == "zst":
                return "zst", file_path
            else:
                raise ValueError(f"Cannot determine format of file: {fcidump_filename}")
        
        # Стандартная логика: FCIDUMP -> FCIDUMP.bin -> FCIDUMP.bin.zst
        text_path = os.path.abspath("FCIDUMP")
        if os.path.isfile(text_path):
            return "text", text_path

        bin_path = os.path.abspath("FCIDUMP.bin")
        if os.path.isfile(bin_path):
            return "bin", bin_path

        zst_path = os.path.abspath("FCIDUMP.bin.zst")
        if os.path.isfile(zst_path):
            return "zst", zst_path

        raise FileNotFoundError(
            "FCIDUMP source not found (checked FCIDUMP, FCIDUMP.bin, FCIDUMP.bin.zst)"
        )

    def _produce_text_fcidump(
        self,
        source_kind: str,
        source_path: str,
        *,
        target_txt: str,
        chunk_records: int,
        mode: str,
    ) -> Dict:
        """
        Produce text FCIDUMP at target_txt from source (bin or zst).
        Always creates FCIDUMP in text format without *_info.txt file.
        """
        if source_kind == "bin":
            return self._expand_bin_to_text(
                source_path, target_txt, chunk_records=chunk_records
            )
        if source_kind == "zst":
            # Используем обновленный API restore_loose_fcidump
            meta = read_meta_from_zst(source_path)
            auto = meta.get("auto") if isinstance(meta, dict) else {}
            norb = int(auto.get("norb", 0))
            nelec = int(auto.get("nelec", 0))
            ms2 = int(auto.get("ms2", 0))
            record_hint = int(auto.get("records", -1))
            self._log(
                f"[BUILD] Header: norb={norb} nelec={nelec} ms2={ms2} "
                f"records={record_hint}"
            )
            
            # Временно распаковываем в целевое место
            dirpath = os.path.dirname(target_txt) or "."
            basename = os.path.basename(source_path)
            
            # Копируем .zst файл во временное место если нужно
            if dirpath != os.path.dirname(source_path):
                import shutil
                temp_zst = os.path.join(dirpath, ".temp_" + basename)
                shutil.copy2(source_path, temp_zst)
                source_to_use = temp_zst
                cleanup_temp = True
            else:
                source_to_use = source_path
                cleanup_temp = False
            
            try:
                # Используем restore_loose_fcidump с обновленным API
                _, _, ok, message = restore_loose_fcidump(
                    dirpath=dirpath,
                    to_text=True,
                    fc_workers=None,
                    zstd_dthreads=0,
                    fcidump_filename=os.path.basename(source_to_use).replace(".bin.zst", "")
                )
                
                if not ok:
                    raise RuntimeError(f"restore_loose_fcidump failed: {message}")
                
                # Переименовываем результат в целевое имя если нужно
                restored_name = os.path.basename(source_to_use).replace(".bin.zst", "") + ".output"
                restored_path = os.path.join(dirpath, restored_name)
                
                if restored_path != target_txt and os.path.exists(restored_path):
                    os.rename(restored_path, target_txt)
                elif not os.path.exists(target_txt):
                    # Возможно файл уже с правильным именем
                    pass
                
                # Удаляем _info.txt если был создан
                info_file = os.path.join(dirpath, os.path.basename(source_to_use).replace(".bin.zst", "") + "_info.txt")
                if os.path.exists(info_file):
                    try:
                        os.remove(info_file)
                    except:
                        pass
                
            finally:
                if cleanup_temp and os.path.exists(source_to_use):
                    try:
                        os.remove(source_to_use)
                    except:
                        pass
            
            if not os.path.exists(target_txt):
                raise RuntimeError(f"Failed to create text FCIDUMP at {target_txt}")
            
            size = os.path.getsize(target_txt)
            self._log(
                f"[BUILD] Text FCIDUMP ready at {target_txt} "
                f"(size={size} bytes, dev:ino={self._file_id(target_txt)})"
            )

            return {
                "norb": norb,
                "nelec": nelec,
                "ms2": ms2,
                "non_empty_lines": record_hint if record_hint >= 0 else 0,
            }
        raise ValueError(f"Unsupported FCIDUMP source kind: {source_kind}")

    # ------------------------------------------------------------------ #
    # FCIDUMP v5 metadata helpers
    # ------------------------------------------------------------------ #

    @staticmethod
    def _format_orbsym(orbsym: object) -> str:
        """Format ORBSYM data from metadata into CSV compatible string."""
        if isinstance(orbsym, (list, tuple)):
            values: List[str] = []
            for item in orbsym:
                try:
                    values.append(str(int(item)))
                except (TypeError, ValueError):
                    continue
            return ",".join(values)
        if isinstance(orbsym, str):
            text = orbsym.strip()
            return text.rstrip(",")
        if orbsym is None:
            return ""
        try:
            return str(int(orbsym))
        except (TypeError, ValueError):
            return str(orbsym)

    def _extract_meta(self, bin_path: str) -> Dict[str, object]:
        """Read FCIDUMP v5 metadata and normalize core fields."""
        meta = read_meta_from_bin(bin_path)
        auto = meta.get("auto") if isinstance(meta, dict) else None
        if not isinstance(auto, dict):
            auto = {}

        def _to_int(value: object, default: int = 0) -> int:
            try:
                return int(value)
            except (TypeError, ValueError):
                return default

        norb = _to_int(auto.get("norb"))
        nelec = _to_int(auto.get("nelec"))
        ms2 = _to_int(auto.get("ms2"))
        records = _to_int(auto.get("records"), default=-1)
        orbsym_csv = self._format_orbsym(auto.get("orbsym"))

        return {
            "norb": norb,
            "nelec": nelec,
            "ms2": ms2,
            "orbsym_csv": orbsym_csv,
            "records": records,
        }

    # ------------------------------------------------------------------ #
    # Expansion: FCIDUMP.bin -> text (v5 decoder pathway)
    # ------------------------------------------------------------------ #

    def _expand_bin_to_text(
        self,
        bin_path: str,
        txt_path: str,
        *,
        chunk_records: int = 500_000,
    ) -> Dict:
        """
        Expand FCIDUMP.bin (v5) to a text FCIDUMP at 'txt_path'.

        Notes
        -----
        - Uses the v5 decoder provided by fcidump_codec (Cython/OpenMP when
          available).
        - Header metadata comes from the binary payload; we no longer support
          legacy FCIDUMP.bin versions (<v5).
        - The 'chunk_records' parameter is kept for API compatibility but is
          ignored by the v5 decoder.

        Returns
        -------
        dict
            Minimal stats: {'norb', 'nelec', 'ms2', 'non_empty_lines'}.
        """
        _ = chunk_records  # kept for signature compatibility

        record_count = -1
        stats = self._extract_meta(bin_path)
        norb = stats["norb"]
        nelec = stats["nelec"]
        ms2 = stats["ms2"]
        orbsym_csv = stats["orbsym_csv"]
        record_hint = stats.get("records", -1)
        self._log(
            f"[BUILD] Header: norb={norb} nelec={nelec} ms2={ms2} "
            f"records={record_hint}"
        )

        tmp_txt = f"{txt_path}.tmp_{uuid.uuid4().hex}"
        try:
            raw_count = bin_to_text_parallel(bin_path, tmp_txt)
            try:
                record_count = int(raw_count)
            except (TypeError, ValueError):
                record_count = -1
        except Exception:
            if os.path.exists(tmp_txt):
                os.remove(tmp_txt)
            raise

        header_present = False
        try:
            with open(tmp_txt, "rb") as src:
                first_line = src.readline()
                header_present = first_line.startswith(b" &FCI ")
                src.seek(0)
                if not header_present:
                    with open(txt_path, "wb") as dst:
                        for line in header_lines(norb, nelec, ms2, orbsym_csv):
                            dst.write(line.encode("utf-8"))
                        shutil.copyfileobj(src, dst, length=1 << 20)
            if header_present:
                os.replace(tmp_txt, txt_path)
            else:
                os.remove(tmp_txt)
        except Exception:
            if os.path.exists(tmp_txt):
                try:
                    os.remove(tmp_txt)
                except FileNotFoundError:
                    pass
            raise
        size = os.path.getsize(txt_path)
        self._log(
            f"[BUILD] Text FCIDUMP ready at {txt_path} "
            f"(size={size} bytes, dev:ino={self._file_id(txt_path)})"
        )
        non_empty = record_count if record_count >= 0 else (record_hint if record_hint >= 0 else 0)

        return {
            "norb": norb,
            "nelec": nelec,
            "ms2": ms2,
            "non_empty_lines": non_empty,
        }


    # ------------------------------------------------------------------ #
    # Launch GeCCo (stdout -> file, stderr -> console)
    # ------------------------------------------------------------------ #

    def _run_gecco_redirect(self, gecco_inp: str, out_path: str) -> subprocess.Popen:
        """
        Launch gecco.x like 'gecco.x job.inp > job.out':
        stdout goes to 'out_path'; stderr stays on the console.
        """
        fout = open(out_path, "w", encoding="utf-8")
        proc = subprocess.Popen(
            [self.gecco_bin, gecco_inp], stdout=fout, stderr=None, text=True
        )
        self._log(
            f"[RUN ] PID={proc.pid} CMD='{self.gecco_bin} {gecco_inp}' "
            f"OUT='{out_path}' (stderr=console)"
        )
        return proc

    # ------------------------------------------------------------------ #
    # Modes
    # ------------------------------------------------------------------ #

    def _run_text_fcidump(
        self,
        gecco_inp: str,
        out_path: str,
        source_path: str,
        mode: str,
    ) -> int:
        """
        Обработка текстового FCIDUMP файла с произвольным именем.
        
        Для текстовых файлов всегда создается симлинк (независимо от mode),
        чтобы избежать лишнего копирования.
        """
        self._log(f"[MODE] {mode}; creating symlink ./FCIDUMP -> {source_path}")
        try:
            os.symlink(source_path, "FCIDUMP")
            proc = self._run_gecco_redirect(gecco_inp, out_path)
            rc = proc.wait()
        finally:
            try:
                os.remove("FCIDUMP")
                self._log(f"[CLEAN] removed symlink ./FCIDUMP at {self._ts()}")
            except FileNotFoundError:
                pass
        
        if rc != 0:
            print(f"[gecco] non-zero exit ({rc})", file=sys.stderr)
        else:
            self._log(f"[DONE] gecco.x exit code 0 at {self._ts()}")
        return rc

    def _run_mode_disk(
        self,
        gecco_inp: str,
        out_path: str,
        source_path: str,
        source_kind: str,
        chunk_records: int,
    ) -> int:
        """
        Expand FCIDUMP (text/.bin/.bin.zst) into './FCIDUMP' on disk;
        refuse to overwrite an existing 'FCIDUMP';
        delete the generated file after gecco.x ends.
        """
        if os.path.lexists("FCIDUMP"):
            raise FileExistsError(
                "mode='disk': 'FCIDUMP' already exists in CWD; refusing to overwrite"
            )

        self._log("[MODE] disk; building ./FCIDUMP on disk")
        self._produce_text_fcidump(
            source_kind,
            source_path,
            target_txt="FCIDUMP",
            chunk_records=chunk_records,
            mode="disk",
        )

        try:
            proc = self._run_gecco_redirect(gecco_inp, out_path)
            rc = proc.wait()
        finally:
            try:
                os.remove("FCIDUMP")
                self._log(f"[CLEAN] removed ./FCIDUMP at {self._ts()}")
            except FileNotFoundError:
                pass
            # Удаляем _info.txt если был создан
            try:
                if os.path.exists("FCIDUMP_info.txt"):
                    os.remove("FCIDUMP_info.txt")
            except:
                pass

        if rc != 0:
            print(f"[gecco] non-zero exit ({rc})", file=sys.stderr)
        else:
            self._log(f"[DONE] gecco.x exit code 0 at {self._ts()}")
        return rc

    def _run_mode_ram(
        self,
        gecco_inp: str,
        out_path: str,
        source_path: str,
        source_kind: str,
        grace: Optional[float],
        interval: float,
        chunk_records: int,
    ) -> int:
        """
        Expand FCIDUMP (text/.bin/.bin.zst) into a RAM-backed text file
        and symlink './FCIDUMP'.
        If 'grace' is set, monitor /proc/<pid>/fd and delete link+file early
        once FCIDUMP remains closed for >= grace seconds. Final cleanup runs
        regardless.
        """
        ram_dir = self._pick_ram_dir()
        tag = uuid.uuid4().hex[:8]
        txt_path = os.path.join(ram_dir, f"FCIDUMP_{tag}.txt")
        link_path = os.path.abspath("FCIDUMP")

        if os.path.lexists(link_path):
            raise FileExistsError(
                "mode='ram': './FCIDUMP' already exists in CWD; "
                "remove it first or choose mode='disk'."
            )

        self._log(
            f"[MODE] ram; materializing FCIDUMP at {txt_path} (RAM) and symlinking as ./FCIDUMP"
        )
        stats = self._produce_text_fcidump(
            source_kind,
            source_path,
            target_txt=txt_path,
            chunk_records=chunk_records,
            mode="ram",
        )

        try:
            os.symlink(txt_path, link_path)
        except OSError as exc:
            try:
                os.remove(txt_path)
            except FileNotFoundError:
                pass
            raise exc

        created_at = time.time()
        size = os.path.getsize(txt_path)
        dev, ino = self._file_id(txt_path)
        self._log(
            f"[RAM ] ready at {self._ts(created_at)}; "
            f"size={size} bytes; dev:ino={dev}:{ino}; link={link_path}; "
            f"non_empty_lines={stats['non_empty_lines']}"
        )

        proc = self._run_gecco_redirect(gecco_inp, out_path)

        try:
            if grace is not None:
                self._log(
                    f"[MON ] enabled; grace={grace:.1f}s interval={interval:.1f}s"
                )
                self._monitor_and_delete_when_closed(
                    pid=proc.pid,
                    txt_path=txt_path,
                    link_path=link_path,
                    grace=grace,
                    interval=interval,
                )

            rc = proc.wait()
            if rc != 0:
                print(f"[gecco] non-zero exit ({rc})", file=sys.stderr)
            else:
                self._log(f"[DONE] gecco.x exit code 0 at {self._ts()}")
            return rc

        finally:
            # Final cleanup (in case not already removed by monitor)
            if os.path.islink(link_path):
                try:
                    os.remove(link_path)
                    self._log(f"[CLEAN] unlinked {link_path} at {self._ts()}")
                except FileNotFoundError:
                    pass
            if os.path.exists(txt_path):
                try:
                    os.remove(txt_path)
                    lived = time.time() - created_at
                    self._log(
                        f"[CLEAN] removed {txt_path} at {self._ts()} "
                        f"(lifetime {lived:.2f}s)"
                    )
                except FileNotFoundError:
                    pass

    # ------------------------------------------------------------------ #
    # /proc-based monitoring for bin_ram (only when 'grace' is set)
    # ------------------------------------------------------------------ #

    def _monitor_and_delete_when_closed(
        self,
        pid: int,
        txt_path: str,
        link_path: str,
        grace: float,
        interval: float,
    ) -> None:
        """
        Poll /proc/<pid>/fd every 'interval' seconds. When no FDs point to
        'txt_path' continuously for at least 'grace' seconds, delete both the
        symlink and the RAM file immediately, then return.
        """
        target = self._file_id(txt_path)
        first_closed: Optional[float] = None
        link_deleted = False
        file_deleted = False

        self._log(f"[MON ] target dev:ino={target}; start={self._ts()}")

        while True:
            # Is the process still alive?
            if not os.path.exists(f"/proc/{pid}"):
                self._log(f"[MON ] process {pid} ended at {self._ts()}")
                return

            # Any FD currently points to our file?
            any_open = False
            for fd_path in self._list_fds(pid):
                if self._fd_points_to(fd_path, target):
                    any_open = True
                    break

            now = time.time()
            if any_open:
                if first_closed is not None:
                    self._log(
                        f"[MON ] re-open detected after {now - first_closed:.1f}s closed"
                    )
                first_closed = None
            else:
                if first_closed is None:
                    first_closed = now
                    self._log(
                        f"[MON ] all FDs closed at {self._ts(first_closed)}; "
                        f"grace countdown {grace:.1f}s"
                    )
                elif (now - first_closed) >= grace:
                    # Delete symlink and RAM file if still present
                    if not link_deleted and os.path.islink(link_path):
                        try:
                            os.remove(link_path)
                            link_deleted = True
                            self._log(f"[DEL ] unlinked {link_path} at {self._ts()}")
                        except FileNotFoundError:
                            link_deleted = True
                    if not file_deleted and os.path.exists(txt_path):
                        try:
                            os.remove(txt_path)
                            file_deleted = True
                            self._log(f"[DEL ] removed  {txt_path} at {self._ts()}")
                        except FileNotFoundError:
                            file_deleted = True
                    return

            time.sleep(interval)
