# Уточнение логики FCIDUMPRunner

## Ответы на ваши вопросы

### Вопрос 1: Если задан fcidump_filename и есть текстовый FCIDUMP + mode=disk, то ошибка?

**Ответ:** ✅ ДА, выводится ошибка!

Если:
- `fcidump_filename="my_file"` (указан)
- `my_file` - текстовый файл
- `./FCIDUMP` уже существует
- `mode="disk"`

То: `FileExistsError: mode='disk': './FCIDUMP' already exists in CWD`

**Это правильно**, потому что mode="disk" всегда проверяет, что ./FCIDUMP не существует.

---

### Вопрос 2: Если fcidump_filename задан для текстового файла, то mode работает?

**Ответ:** ✅ ДА, но для текстовых файлов **всегда симлинк** (независимо от mode)!

#### mode="ram" (текстовый файл):
- Проверка: ./FCIDUMP не существует
- Создается **СИМЛИНК**: `./FCIDUMP -> my_file`
- gecco.x запускается
- Симлинк удаляется, `my_file` остается

#### mode="disk" (текстовый файл):
- Проверка: ./FCIDUMP не существует
- Создается **СИМЛИНК**: `./FCIDUMP -> my_file` (НЕ копия!)
- gecco.x запускается
- Симлинк удаляется, `my_file` остается

**Важно:** Для текстовых файлов **ВСЕГДА** создается симлинк (не копия), чтобы избежать лишнего копирования больших файлов.

---

## Полная таблица истинности

| fcidump_filename | Найден файл | Формат | mode | ./FCIDUMP существует? | Что происходит |
|------------------|-------------|--------|------|-----------------------|----------------|
| **None** | FCIDUMP | текст | любой | Да (это он и есть) | mode игнорируется, используется как есть |
| **None** | FCIDUMP.bin | bin | ram | Нет | Распаковка в RAM, симлинк |
| **None** | FCIDUMP.bin | bin | disk | Нет | Распаковка на диск |
| **None** | FCIDUMP.bin | bin | disk | **ДА** | **❌ Ошибка** |
| **"my_file"** | my_file | текст | ram | Нет | **Симлинк** ./FCIDUMP → my_file |
| **"my_file"** | my_file | текст | ram | **ДА** | **❌ Ошибка** |
| **"my_file"** | my_file | текст | disk | Нет | **Симлинк** ./FCIDUMP → my_file |
| **"my_file"** | my_file | текст | disk | **ДА** | **❌ Ошибка** |
| **"my_file"** | my_file | bin | ram | Нет | Распаковка в RAM, симлинк |
| **"my_file"** | my_file | bin | disk | Нет | Распаковка на диск |
| **"my_file"** | my_file | bin | disk | **ДА** | **❌ Ошибка** |

---

## Примеры с пояснениями

### Пример 1: Текстовый FCIDUMP уже есть
```python
# ./FCIDUMP существует (текст)
runner.run("job.inp", mode="ram")
runner.run("job.inp", mode="disk")
```
✅ **Работает**: mode игнорируется, ./FCIDUMP используется как есть

---

### Пример 2a: Текстовый файл с именем, RAM mode
```python
# my_integrals существует (текст)
# ./FCIDUMP НЕ существует
runner.run("job.inp", mode="ram", fcidump_filename="my_integrals")
```
✅ **Работает**:
1. Создается **симлинк**: `./FCIDUMP -> my_integrals`
2. gecco.x работает с симлинком
3. Симлинк удаляется, `my_integrals` остается

---

### Пример 2b: Текстовый файл с именем, DISK mode
```python
# my_integrals существует (текст)
# ./FCIDUMP НЕ существует
runner.run("job.inp", mode="disk", fcidump_filename="my_integrals")
```
✅ **Работает**:
1. **Копируется** файл: `my_integrals -> ./FCIDUMP`
2. gecco.x работает с копией
3. ./FCIDUMP удаляется, `my_integrals` остается

---

### Пример 3: Ошибка - FCIDUMP уже существует
```python
# my_integrals существует (текст)
# ./FCIDUMP СУЩЕСТВУЕТ (!)
runner.run("job.inp", mode="disk", fcidump_filename="my_integrals")
```
❌ **Ошибка**: `FileExistsError: mode='disk': './FCIDUMP' already exists in CWD`

---

### Пример 4: Бинарный файл с именем
```python
# data.bin существует
# ./FCIDUMP НЕ существует
runner.run("job.inp", mode="disk", fcidump_filename="data.bin")
```
✅ **Работает**:
1. Распаковка: `data.bin -> ./FCIDUMP` (текст)
2. gecco.x работает
3. ./FCIDUMP удаляется

---

## Ключевые отличия

### Без fcidump_filename (стандартное поведение):
- Ищет FCIDUMP, FCIDUMP.bin, FCIDUMP.bin.zst
- Если FCIDUMP (текст) найден → mode игнорируется
- Если .bin/.bin.zst найдены → mode работает

### С fcidump_filename (пользовательское поведение):
- Использует указанный файл
- **mode ВСЕГДА работает** (даже для текстовых!)
- Для текстовых:
  - ram: симлинк (быстро)
  - disk: копия (медленнее, но безопаснее)
- Для bin/zst: стандартная распаковка

---

## Почему для текстовых файлов mode работает?

**Причина 1: Консистентность**
- Пользователь явно указал `fcidump_filename` → хочет контролировать поведение
- mode дает возможность выбрать: симлинк (ram) или копия (disk)

**Причина 2: Безопасность**
- mode="disk" создает изолированную копию
- Исходный файл не затрагивается
- Полезно для параллельных расчетов

**Причина 3: Единообразие**
- Для bin/zst файлов mode работает
- Для текстовых с fcidump_filename mode тоже работает
- Проще для понимания и использования
