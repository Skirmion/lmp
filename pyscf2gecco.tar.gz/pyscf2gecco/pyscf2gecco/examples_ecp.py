#!/usr/bin/env python3
"""
Examples demonstrating ECP module usage after pip installation.

This file shows comprehensive usage of all functions available for loading
and working with GRECP/QED pseudopotentials in libgrpp format.
"""

from pyscf2gecco import ecp
from pyscf import gto, scf
import os


def example_basic_loading():
    """
    Example 1: Basic pseudopotential loading.
    
    Demonstrates:
    - Loading a pseudopotential by name
    - Getting the raw pseudopotential text
    - Using the load function
    """
    print("=" * 70)
    print("Example 1: Basic pseudopotential loading")
    print("=" * 70)
    
    # Load uranium pseudopotential (64 electrons in core)
    pseudo_text = ecp.load_pseudopotential("U64")
    
    print(f"Loaded U64 pseudopotential")
    print(f"Content length: {len(pseudo_text)} characters")
    print("\nFirst few lines:")
    print('\n'.join(pseudo_text.split('\n')[:5]))
    print("✓ Pseudopotential loaded successfully\n")


def example_with_pyscf():
    """
    Example 2: Using pseudopotential in PySCF calculation.
    
    Demonstrates:
    - Loading pseudopotential for calculation
    - Integrating with libgrpp
    - Basic workflow
    """
    print("=" * 70)
    print("Example 2: PySCF calculation with pseudopotential")
    print("=" * 70)
    
    # Load pseudopotential
    u64_pseudo = ecp.load_pseudopotential("U64")
    
    print(f"Loaded U64 pseudopotential")
    print(f"Length: {len(u64_pseudo)} characters")
    
    # The pseudopotential can be used with libgrpp for PySCF:
    # from libgrpp.libgrpp import libgrpp4pyscf
    # parsed_ecp = libgrpp4pyscf.parse_grpp(u64_pseudo)
    # mol = gto.M(atom='U 0 0 0', basis='...', ecp=parsed_ecp)
    
    print("✓ Pseudopotential ready for libgrpp integration\n")
    print("Note: Actual PySCF calculation requires libgrpp installation")
    print("      and proper basis set for the element.\n")


def example_help_function():
    """
    Example 3: Getting help on available pseudopotentials.
    
    Demonstrates:
    - Using help_pseudopotential function
    - Discovering available pseudopotentials
    - Getting information on specific element
    """
    print("=" * 70)
    print("Example 3: Pseudopotential help system")
    print("=" * 70)
    
    # Get help for all available pseudopotentials
    print("All available pseudopotentials:")
    ecp.help_pseudopotential()
    
    # Get header information for specific pseudopotential
    print("\nHeader information for U64:")
    ecp.help_pseudopotential("U64")
    
    print("\n✓ Help information displayed\n")


def example_diagnostics():
    """
    Example 4: Running pseudopotential diagnostics.
    
    Demonstrates:
    - Using diagnose_pseudopotentials function
    - Checking pseudopotential file validity
    - Identifying issues in pseudopotential data
    """
    print("=" * 70)
    print("Example 4: Pseudopotential diagnostics")
    print("=" * 70)
    
    # Run diagnostics on specific uranium pseudopotentials
    print("Running diagnostics on specific U pseudopotentials...")
    ecp.diagnose_pseudopotentials(codes={"U64", "U32", "U04"})
    
    print("\n✓ Diagnostics completed\n")


def example_format_normalization():
    """
    Example 5: Ensuring full GRPP format.
    
    Demonstrates:
    - Using ensure_full_grpp_format function
    - Normalizing pseudopotential format
    - Handling different input formats
    """
    print("=" * 70)
    print("Example 5: Format normalization")
    print("=" * 70)
    
    # Load pseudopotential
    pseudo_text = ecp.load_pseudopotential("U64")
    
    # Ensure it's in full GRPP format
    normalized = ecp.ensure_full_grpp_format(pseudo_text)
    
    print("Pseudopotential normalized to full GRPP format")
    print(f"Normalized length: {len(normalized)} characters")
    print("✓ Format normalization completed\n")


def example_alias_function():
    """
    Example 6: Using load alias.
    
    Demonstrates:
    - Using the shorter 'load' alias
    - Same functionality as load_pseudopotential
    """
    print("=" * 70)
    print("Example 6: Using load alias")
    print("=" * 70)
    
    # Use shorter alias
    pseudo = ecp.load("U64")
    
    print(f"Loaded using ecp.load() alias")
    print(f"Content length: {len(pseudo)} characters")
    print("✓ Alias function works identically\n")


def example_multiple_elements():
    """
    Example 7: Loading pseudopotentials for multiple elements.
    
    Demonstrates:
    - Loading different pseudopotentials
    - Working with various elements
    - Comparing different core sizes
    """
    print("=" * 70)
    print("Example 7: Multiple element pseudopotentials")
    print("=" * 70)
    
    # Load pseudopotentials for different elements
    elements = ["U64", "Th30", "Pu34"]
    
    for elem in elements:
        try:
            pseudo = ecp.load_pseudopotential(elem)
            print(f"✓ Loaded {elem}: {len(pseudo)} characters")
        except Exception as e:
            print(f"✗ Failed to load {elem}: {e}")
    
    print("\n✓ Multiple pseudopotentials loaded\n")


def example_error_handling():
    """
    Example 8: Error handling for missing pseudopotentials.
    
    Demonstrates:
    - Handling non-existent pseudopotentials
    - Proper error checking
    - Graceful failure
    """
    print("=" * 70)
    print("Example 8: Error handling")
    print("=" * 70)
    
    # Try to load non-existent pseudopotential
    try:
        pseudo = ecp.load_pseudopotential("NonExistent99")
        print("Loaded successfully")
    except FileNotFoundError as e:
        print(f"Expected error caught: File not found")
        print(f"Error message: {e}")
    except Exception as e:
        print(f"Other error: {e}")
    
    print("✓ Error handling demonstrated\n")


def example_custom_directory():
    """
    Example 9: Loading from custom directory.
    
    Demonstrates:
    - Specifying custom pseudopotential directory
    - Using local pseudopotential files
    - Organizing pseudopotential library
    """
    print("=" * 70)
    print("Example 9: Custom directory loading")
    print("=" * 70)
    
    # This is a conceptual example
    # In practice, you would set up a custom directory
    print("Note: Custom directory support depends on implementation")
    print("Typically done by modifying search paths or providing path parameter")
    
    # Example structure:
    # pseudo = ecp.load_pseudopotential("U64", basedir="/path/to/pseudos")
    
    print("✓ Concept demonstrated\n")


def example_complete_workflow():
    """
    Example 10: Complete workflow with pseudopotential.
    
    Demonstrates:
    - Full workflow from loading to calculation
    - Integration with PySCF
    - Best practices
    """
    print("=" * 70)
    print("Example 10: Complete workflow")
    print("=" * 70)
    
    # Step 1: Get help to find available pseudopotentials
    print("Step 1: Check available pseudopotentials")
    ecp.help_pseudopotential()  # List all available
    
    # Step 2: Load the desired pseudopotential
    print("\nStep 2: Load pseudopotential")
    pseudo = ecp.load_pseudopotential("U64")
    print(f"Loaded U64 pseudopotential")
    
    # Step 3: Ensure proper format
    print("\nStep 3: Normalize format")
    pseudo_normalized = ecp.ensure_full_grpp_format(pseudo)
    print("Format normalized")
    
    # Step 4: Run diagnostics
    print("\nStep 4: Run diagnostics")
    ecp.diagnose_pseudopotentials(codes={"U64"})
    
    # Step 5: Save to file (if needed for PySCF)
    print("\nStep 5: Save for PySCF")
    with open('U64_final.libgrpp', 'w') as f:
        f.write(pseudo_normalized)
    print("Saved to U64_final.libgrpp")
    
    # Cleanup
    if os.path.exists('U64_final.libgrpp'):
        os.remove('U64_final.libgrpp')
    
    print("\n✓ Complete workflow finished\n")


if __name__ == '__main__':
    print("\n")
    print("=" * 70)
    print("ECP Module Examples - Complete Usage Guide")
    print("=" * 70)
    print("\n")
    
    # Run all examples
    example_basic_loading()
    example_with_pyscf()
    example_help_function()
    example_diagnostics()
    example_format_normalization()
    example_alias_function()
    example_multiple_elements()
    example_error_handling()
    example_custom_directory()
    example_complete_workflow()
    
    print("=" * 70)
    print("All ECP module examples completed successfully!")
    print("=" * 70)
