"""
Utilities for GRECP/QED pseudopotentials loading and PySCF diagnostics.

This module provides functions for loading and validating pseudopotential files
in libgrpp format. It automatically handles basis set selection and provides
diagnostic tools to verify that pseudopotentials can be successfully used with PySCF.

Features
--------
* **PySCF built-in basis sets only** - no external basis files required.
* Per-element preferred basis set lists (PER_ELEMENT_BASES dictionary).
* Automatic basis set fallback when preferred sets are unavailable.
* Comprehensive diagnostics with status codes:
    - OK: basis found, atom built successfully
    - OK [basis-missing]: synthetic minimal basis used (no built-in available)
    - OK [spin-flipped]: spin had to be flipped to avoid electron number error
    - FAIL-LOAD / FAIL-BUILD: file loading or molecular build failed
"""

from __future__ import annotations
import os, sys, re, argparse, textwrap, importlib
from typing import Dict, Optional, Tuple

from pyscf import gto

# ═══════════════════════════════════════════════════════════════
# 1.  Предпочтительные базисы для элементов (только PySCF built-in)
#    Добавляйте/меняйте при необходимости.
# =================================================================
PER_ELEMENT_BASES: Dict[str, list[str]] = {
    # s-, p-блок
    "H" : ["aug-cc-pvdz", "ccpvdz", "6-31g*"],
    "He": ["aug-cc-pvdz", "ccpvdz"],
    "Li": ["ccpvdz", "def2-svp"],
    "Be": ["ccpvdz", "def2-svp"],
    "B" : ["ccpvdz", "def2-svp"],
    "C" : ["ccpvdz", "def2-svp", "6-31g*"],
    "N" : ["aug-cc-pvdz", "ccpvdz"],
    "O" : ["aug-cc-pvdz", "ccpvdz"],
    "F" : ["aug-cc-pvdz", "ccpvdz"],
    "Ne": ["aug-cc-pvdz", "ccpvdz"],
    # 3-й период
    "Na": ["def2-svp", "ccpvdz"],
    "Mg": ["def2-svp", "ccpvdz"],
    "Al": ["def2-svp", "ccpvdz"],
    "Si": ["def2-svp", "ccpvdz"],
    "P" : ["def2-svp", "ccpvdz"],
    "S" : ["aug-cc-pvdz", "ccpvdz"],
    "Cl": ["aug-cc-pvdz", "ccpvdz"],
    "Ar": ["aug-cc-pvdz", "ccpvdz"],
    # 1-й ряд d-металлов (пример)
    "Sc": ["def2-svp", "ccpvdz"],
    "Ti": ["def2-svp", "ccpvdz"],
    "V" : ["def2-svp", "ccpvdz"],
    "Cr": ["def2-svp", "ccpvdz"],
    "Mn": ["def2-svp", "ccpvdz"],
    "Fe": ["def2-svp", "ccpvdz"],
    "Co": ["def2-svp", "ccpvdz"],
    "Ni": ["def2-svp", "ccpvdz"],
    "Cu": ["def2-svp", "ccpvdz"],
    "Zn": ["def2-svp", "ccpvdz"],
    # -------- актиниды (ECP + компактные BFD) --------
    "Ac": ["bfd-vdz", "lanl2dz"],
    "Th": ["bfd-vdz", "bfd-vtz", "lanl2dz"],
    "Pa": ["bfd-vdz", "bfd-vtz", "lanl2dz"],
    "U":  ["bfd-vdz", "bfd-vtz", "lanl2dz"],
    "Np": ["bfd-vdz", "bfd-vtz", "lanl2dz"],
    "Pu": ["bfd-vdz", "bfd-vtz", "lanl2dz"],
    "Am": ["bfd-vdz", "bfd-vtz", "lanl2dz"],
    "Cm": ["bfd-vdz", "bfd-vtz", "lanl2dz"],
    "Bk": ["bfd-vdz", "bfd-vtz", "lanl2dz"],
    "Cf": ["bfd-vdz", "bfd-vtz", "lanl2dz"],
    "Es": ["bfd-vdz", "bfd-vtz", "lanl2dz"],
    "Fm": ["bfd-vdz", "bfd-vtz", "lanl2dz"],
    "Md": ["bfd-vdz", "bfd-vtz", "lanl2dz"],
    "No": ["bfd-vdz", "bfd-vtz", "lanl2dz"],
    "Lr": ["bfd-vdz", "bfd-vtz", "lanl2dz"],

    # -------- лантаниды (def2 полностью встроены) ----
    "La": ["def2-svp", "def2-tzvp", "lanl2dz"],
    "Ce": ["def2-svp", "def2-tzvp", "lanl2dz"],
    "Pr": ["def2-svp", "def2-tzvp", "lanl2dz"],
    "Nd": ["def2-svp", "def2-tzvp", "lanl2dz"],
    "Pm": ["def2-svp", "def2-tzvp", "lanl2dz"],
    "Sm": ["def2-svp", "def2-tzvp", "lanl2dz"],
    "Eu": ["def2-svp", "def2-tzvp", "lanl2dz"],
    "Gd": ["def2-svp", "def2-tzvp", "lanl2dz"],
    "Tb": ["def2-svp", "def2-tzvp", "lanl2dz"],
    "Dy": ["def2-svp", "def2-tzvp", "lanl2dz"],
    "Ho": ["def2-svp", "def2-tzvp", "lanl2dz"],
    "Er": ["def2-svp", "def2-tzvp", "lanl2dz"],
    "Tm": ["def2-svp", "def2-tzvp", "lanl2dz"],
    "Yb": ["def2-svp", "def2-tzvp", "lanl2dz"],
    "Lu": ["def2-svp", "def2-tzvp", "lanl2dz"],

    # -------- тяжёлый p-, d-блок до Rn --------
    "Hg": ["def2-svp", "def2-tzvp", "lanl2dz"],
    "Tl": ["def2-svp", "def2-tzvp", "lanl2dz"],
    "Bi": ["def2-svp", "def2-tzvp", "lanl2dz"],
    "Po": ["def2-svp", "def2-tzvp", "lanl2dz"],
    "Rn": ["def2-svp", "def2-tzvp", "lanl2dz"],

    # -------- Z > 86: только ЭЯП-семейства --------
    # (def2 уже не определён; LANL2DZ спасает)
    "Fr": ["lanl2dz"], "Ra": ["lanl2dz"],
    "Db": ["lanl2dz"], "Sg": ["lanl2dz"],
    "Bh": ["lanl2dz"], "Hs": ["lanl2dz"],
    "Mt": ["lanl2dz"], "Ds": ["lanl2dz"],
    "Rg": ["lanl2dz"], "Cn": ["lanl2dz"],
    "Nh": ["lanl2dz"], "Fl": ["lanl2dz"],
    "Mc": ["lanl2dz"], "Lv": ["lanl2dz"],
    "Ts": ["lanl2dz"], "Og": ["lanl2dz"],

    # -------- исправление «обычных» элементов --------
    "Al": ["def2-svp", "ccpvdz"],
    "C":  ["ccpvdz", "def2-svp"],
    "O":  ["aug-cc-pvdz", "ccpvdz"],

}

# Резервный порядок, если элемент не в словаре
FALLBACK_BASES = ["ccpvdz", "def2-svp", "dzvp", "svp"]

# кеш: {elem: выбранный_базис_или_None}
_basis_cache: Dict[str, Optional[str]] = {}

_DUMMY_BASIS_MAX_L = 5


def _make_dummy_basis(elem: str, max_l: int = _DUMMY_BASIS_MAX_L) -> dict[str, list[list[float]]]:
    """
    Generate a synthetic minimal basis set when no built-in basis is available.
    
    Parameters
    ----------
    elem : str
        Chemical element symbol.
    max_l : int, optional
        Maximum angular momentum quantum number for shells (default: 5).
    
    Returns
    -------
    dict
        Basis set dictionary in PySCF format: {element: [[L, [exponent, coeff]], ...]}.
    """
    shells: list[list[float]] = []
    for L in range(max_l + 1):
        exponent = max(0.1, 2.0 ** (-(L)))
        shells.append([L, [exponent, 1.0]])
    return {elem: shells}


def _pick_basis(elem: str) -> Optional[str]:
    """
    Select the first available built-in basis set for the given element.
    
    This function searches through the element's preferred basis sets
    (defined in PER_ELEMENT_BASES) and fallback options, returning
    the first one that PySCF can load successfully.
    
    Parameters
    ----------
    elem : str
        Chemical element symbol (e.g., 'H', 'C', 'Fe').
    
    Returns
    -------
    str or None
        Name of the first available basis set, or None if none are available.
        
    Notes
    -----
    Results are cached to avoid repeated PySCF basis load attempts.
    """
    if elem in _basis_cache:
        return _basis_cache[elem]

    for name in PER_ELEMENT_BASES.get(elem, []) + FALLBACK_BASES:
        try:
            gto.basis.load(name, elem)
            _basis_cache[elem] = name
            return name
        except RuntimeError:
            continue
    _basis_cache[elem] = None
    return None

# ═══════════════════════════════════════════════════════════════
# 2.  Базовые I/O функции (load, help)
# =================================================================
def load_pseudopotential(
    code: str,
    directory: str = None,
    ext: str = ".inp",
    normalize: bool = True,
    debug: bool | str = False,
    debug_path: str = "used_pseudo"
) -> str:
    """
    Load and return the content of a pseudopotential file.
    
    Reads a pseudopotential file from ``<directory>/<code><ext>`` and optionally
    normalizes it to ensure compatibility with libgrpp format requirements.
    
    Parameters
    ----------
    code : str
        Pseudopotential identifier (filename without extension).
    directory : str, optional
        Directory containing pseudopotential files. If None, uses the default
        pseudos directory from the installed package.
    ext : str, default=".inp"
        File extension for pseudopotential files.
    normalize : bool, default=True
        If True, automatically pads incomplete data lines with zeros to match
        the full libgrpp format. Pseudopotentials often have truncated lines,
        and libgrpp expects all columns (AREP, ESOP, outer core) to be present.
    debug : bool or str, default=False
        Enable writing the processed pseudopotential to a file for inspection.
        If True, uses `debug_path` as the filename. If a string, uses that
        string as the output path.
    debug_path : str, default="used_pseudo"
        Default path for debug output when `debug=True`.
    
    Returns
    -------
    str
        Content of the pseudopotential file (normalized if requested).
    
    Raises
    ------
    FileNotFoundError
        If the pseudopotential file does not exist.
    
    Examples
    --------
    >>> pseudo_text = load_pseudopotential("U64")
    >>> # Use with libgrpp
    >>> from libgrpp.libgrpp import libgrpp4pyscf
    >>> ecp = libgrpp4pyscf.parse_grpp(pseudo_text)
    """
    if directory is None:
        # Use package's default pseudos directory
        directory = os.path.join(os.path.dirname(__file__), "pseudos")
    
    path = os.path.join(directory, f"{code}{ext}")
    if not os.path.isfile(path):
        raise FileNotFoundError(path)
    with open(path, encoding="utf-8") as fh:
        text = fh.read()
    if normalize:
        text = ensure_full_grpp_format(text)
        text = _normalize_header(text)

    if isinstance(debug, str):
        debug_target = debug
    elif debug:
        debug_target = debug_path
    else:
        debug_target = None

    if debug_target:
        debug_target = os.fspath(debug_target)
        parent = os.path.dirname(debug_target)
        if parent:
            os.makedirs(parent, exist_ok=True)
        with open(debug_target, "w", encoding="utf-8") as dbg:
            dbg.write(text)
    return text


load = load_pseudopotential


_FORTRAN_FLOAT_RE = re.compile(r'^[-+]?(?:\d+(?:\.\d*)?|\.\d+)[Dd][-+]?\d+$', re.IGNORECASE)


def ensure_full_grpp_format(text: str) -> str:
    """
    Pad truncated data lines with '0.0' to match full GRPP format.
    
    Many pseudopotential files contain incomplete lines (missing AREP, ESOP,
    or outer core columns). This function automatically extends such lines
    with zeros so they conform to the complete libgrpp format specification.
    
    Additionally converts Fortran D-notation (e.g., '1.23d-4') to E-notation
    ('1.23E-4') for better compatibility.
    
    Parameters
    ----------
    text : str
        Raw pseudopotential file content.
    
    Returns
    -------
    str
        Normalized pseudopotential content with complete data lines.
    
    Notes
    -----
    The function analyzes the metadata header (4th non-empty line) to determine
    the expected number of basis and AREP blocks, then ensures each data line
    has the correct number of columns.
    """
    lines = text.splitlines()
    if not lines:
        return text

    rows = [ln.split() for ln in lines]

    for row in rows:
        for idx, tok in enumerate(row):
            if _FORTRAN_FLOAT_RE.match(tok):
                row[idx] = tok.replace('d', 'E').replace('D', 'E')

    if rows and rows[0]:
        rows[0][0] = rows[0][0].replace('_', '')

    nonempty = [i for i, row in enumerate(rows) if row]
    if len(nonempty) < 4:
        return "\n".join(" ".join(row) if row else " " for row in rows)

    meta_idx = nonempty[3]
    meta = rows[meta_idx]

    def _safe_int(token: str) -> Optional[int]:
        try:
            return int(token)
        except (TypeError, ValueError):
            try:
                return int(float(token))
            except (TypeError, ValueError):
                return None

    def _pad(row: list[str], needed: int) -> list[str]:
        if len(row) < needed:
            row.extend("0.0" for _ in range(needed - len(row)))
        return row

    def _next_idx(idx: int) -> int:
        idx += 1
        while idx < len(rows) and not rows[idx]:
            idx += 1
        return idx

    try:
        num_basis_blocks = int(float(meta[2]))
        num_arep_blocks = int(float(meta[-3]))
    except (IndexError, ValueError):
        return "\n".join(" ".join(row) if row else " " for row in rows)

    idx = _next_idx(meta_idx)

    for _ in range(num_basis_blocks):
        if idx >= len(rows):
            break
        header = rows[idx]
        _pad(header, 2)
        num_primitives = _safe_int(header[0]) or 0
        num_contracted = _safe_int(header[1])
        if num_contracted is None:
            lookahead = _next_idx(idx)
            if lookahead < len(rows):
                num_contracted = max(0, len(rows[lookahead]) - 1)
            else:
                num_contracted = 0
            header[1] = str(num_contracted)
        else:
            header[1] = str(num_contracted)
        header[0] = str(num_primitives)
        rows[idx] = header
        idx = _next_idx(idx)

        for _ in range(num_primitives):
            if idx >= len(rows):
                break
            _pad(rows[idx], 1 + max(num_contracted or 0, 0))
            idx = _next_idx(idx)

    for _ in range(num_arep_blocks):
        if idx >= len(rows):
            break
        header = rows[idx]
        _pad(header, 2)
        num_primitives = _safe_int(header[0]) or 0
        num_outer = _safe_int(header[1]) or 0
        header[0] = str(num_primitives)
        header[1] = str(num_outer)
        rows[idx] = header
        idx = _next_idx(idx)
        required = 1 + 3 + max(num_outer, 0)

        for _ in range(num_primitives):
            if idx >= len(rows):
                break
            _pad(rows[idx], required)
            idx = _next_idx(idx)

    return "\n".join(" ".join(row) if row else " " for row in rows)

def help_pseudopotential(
    code: str | None = None,
    directory: str = None,
    ext: str = ".inp"
) -> None:
    """
    Display information about available pseudopotentials.
    
    Without arguments, lists all pseudopotential files in the directory.
    With a code argument, prints the header section of that specific file
    (up to the 'Pseudospinors' line).
    
    Parameters
    ----------
    code : str, optional
        Pseudopotential identifier. If None, lists all available files.
    directory : str, optional
        Directory containing pseudopotential files. If None, uses the default
        pseudos directory from the installed package.
    ext : str, default=".inp"
        File extension for pseudopotential files.
    
    Examples
    --------
    >>> help_pseudopotential()  # List all available pseudopotentials
    ECP-files: U64 Th32 Pu32 ...
    
    >>> help_pseudopotential("U64")  # Show header for U64
    --- Header U64.inp ---
    U64 64-electron GRECP/QED
    ...
    """
    if directory is None:
        directory = os.path.join(os.path.dirname(__file__), "pseudos")
    
    if code is None:
        files = sorted(f[:-len(ext)] for f in os.listdir(directory)
                       if f.endswith(ext))
        if files:
            print("ECP-files:", " ".join(files))
        else:
            print(f"No {ext} files in {directory}")
        return

    path = os.path.join(directory, f"{code}{ext}")
    if not os.path.isfile(path):
        print(f"File not found: {path}")
        return

    stop = re.compile(r'^\s*Pseudospinors\s+from')
    print(f"--- Header {code}{ext} ---")
    with open(path, encoding="utf-8") as fh:
        for ln in fh:
            print(ln.rstrip())
            if stop.match(ln):
                break

# ═══════════════════════════════════════════════════════════════
# 3.  Утилиты парсинга шапки
# =================================================================
_RX_NE    = re.compile(r'(\d+)\s*e-')
_RX_FOR   = re.compile(r'\bfor\s+(?:the\s+)?([A-Z][a-z]?)', re.I)
_RX_FIRST = re.compile(r'^([A-Za-z]{1,2})')

def _normalize_header(text: str) -> str:
    """Первый токен «X_06» → «X06», регистр фиксируется («po24» → «Po24»)."""
    lines = text.splitlines()
    if not lines:
        return text
    parts = lines[0].split()
    if parts:
        tok = parts[0].replace('_', '')
        m = _RX_FIRST.match(tok)
        if m:
            cap = m.group(1).capitalize()
            parts[0] = cap + tok[len(cap):]
            lines[0] = ' '.join(parts)
    return '\n'.join(lines)

def _header_info(text: str, code: str) -> Tuple[str, Optional[int]]:
    head = "\n".join(text.splitlines()[:10])
    m_ne = _RX_NE.search(head)
    ne   = int(m_ne.group(1)) if m_ne else None
    m_for = _RX_FOR.search(head)
    if m_for:
        elem = m_for.group(1).capitalize()
    else:
        first = head.split()[0]
        m = _RX_FIRST.match(first) or _RX_FIRST.match(code)
        elem = m.group(1).capitalize()
    return elem, ne

# ═══════════════════════════════════════════════════════════════
# 4.  Диагностика
# =================================================================
def diagnose_pseudopotentials(
    directory: str = None,
    ext: str = ".inp",
    codes: Optional[set[str]] = None
) -> None:
    """
    Run comprehensive diagnostics on pseudopotential files.
    
    For each pseudopotential file, this function attempts to:
    1. Load and normalize the file
    2. Extract element and electron count from header
    3. Find or create a suitable basis set
    4. Parse the pseudopotential with libgrpp
    5. Build a PySCF molecule to verify compatibility
    
    Results are categorized as OK (with optional flags) or FAIL with
    error descriptions.
    
    Parameters
    ----------
    directory : str, optional
        Directory containing pseudopotential files. If None, uses the default
        pseudos directory from the installed package.
    ext : str, default=".inp"
        File extension for pseudopotential files.
    codes : set of str, optional
        If provided, only diagnose pseudopotentials with these codes.
        Case-insensitive matching.
    
    Status Codes
    ------------
    OK : Pseudopotential loaded and molecule built successfully
    OK [basis-missing] : Synthetic basis used (no built-in available)
    OK [spin-flipped] : Required spin adjustment to match electron count
    FAIL-LOAD : File could not be loaded
    FAIL-PARSE : Pseudopotential parsing failed
    FAIL-BUILD : Molecule build failed
    
    Examples
    --------
    >>> diagnose_pseudopotentials()  # Check all files
    ✓ OK  (12)
      U64: U (64 e⁻); Pu32: Pu (32 e⁻); ...
    ✗ FAIL (2)
      Xx99: Xx (99 e⁻): BUILD: Electron number mismatch
    
    >>> diagnose_pseudopotentials(codes={"U64", "Th32"})  # Check specific files
    """
    # Import libgrpp only when this function is called
    try:
        _libgrpp_core = importlib.import_module('libgrpp.libgrpp.libgrpp')
        sys.modules['libgrpp'] = _libgrpp_core
        from libgrpp.libgrpp import libgrpp4pyscf
        libgrpp4pyscf.libgrpp = _libgrpp_core
    except ImportError as e:
        print(f"Error: libgrpp is not installed. Install it to use diagnostics.")
        print(f"Details: {e}")
        return
    
    if directory is None:
        directory = os.path.join(os.path.dirname(__file__), "pseudos")
    
    files = sorted(f for f in os.listdir(directory) if f.endswith(ext))
    if not files:
        print(f"No {ext} files in {directory}")
        return

    codes_lower = {c.lower() for c in codes} if codes else None

    ok, fail = [], {}
    for fn in files:
        code = fn[:-len(ext)]
        if codes_lower and code.lower() not in codes_lower:
            continue
        path = os.path.join(directory, fn)
        # LOAD
        try:
            txt = load_pseudopotential(code, directory, ext)
        except Exception as e:
            fail[code] = f"LOAD: {e}"
            continue

        # HEADER
        elem, ne = _header_info(txt, code)
        spin = (ne % 2) if ne is not None else 0
        label = f"{elem} ({ne or '?'} e⁻)"
        fail_label = f"{code}: {label}"

        # BASIS
        basis_name = _pick_basis(elem)
        if basis_name is None:
            basis_arg = _make_dummy_basis(elem)
            tag = "[basis-missing]"
        else:
            basis_arg = basis_name
            tag = ""

        # ECP (parser or raw text)
        try:
            ecp_val = libgrpp4pyscf.parse_grpp(txt)
        except Exception as e:
            fail[fail_label] = "PARSE: " + str(e).splitlines()[0][:120]
            continue

        # BUILD
        mol = libgrpp4pyscf.GRPPMole()
        try:
            mol.build(atom=f"{elem} 0 0 0",
                      unit='A',
                      basis=basis_arg,
                      spin=spin,
                      ecp={elem: ecp_val})
            prefix = f"{code}: {label}"
            ok.append(prefix + (" " + tag if tag else ""))
        except RuntimeError as e:
            if "Electron number" in str(e) and "spin" in str(e):
                try:
                    mol.build(atom=f"{elem} 0 0 0",
                              basis=basis_arg,
                              unit='A',
                              spin=1 - spin,
                              ecp={elem: ecp_val})
                    suffix = " ".join(part for part in ("[spin-flipped]", tag) if part)
                    ok.append(f"{code}: {label} {suffix}".rstrip())
                except Exception as e2:
                    fail[fail_label] = "BUILD: " + str(e2).splitlines()[0][:120]
            else:
                fail[fail_label] = "BUILD: " + str(e).splitlines()[0][:120]
        except Exception as e:
            fail[fail_label] = "BUILD: " + str(e).splitlines()[0][:120]

    # REPORT
    print(f"\n✓ OK  ({len(ok)})")
    if ok:
        print(textwrap.fill("; ".join(ok), width=100, subsequent_indent="  "))
    print(f"\n✗ FAIL ({len(fail)})")
    for k, v in fail.items():
        print(f"  {k}: {v}")
