"""
ECP module for loading and diagnosing GRECP/QED pseudopotentials.

This module provides utilities for working with pseudopotential files in
libgrpp format, including automatic basis set selection and comprehensive
diagnostics.

Functions:
    load_pseudopotential: Load a pseudopotential file with optional normalization
    help_pseudopotential: Display information about available pseudopotentials
    diagnose_pseudopotentials: Run diagnostics on pseudopotential files
    ensure_full_grpp_format: Normalize pseudopotential data format
"""

from .load_ecp import (
    load_pseudopotential,
    load,  # Alias for load_pseudopotential
    help_pseudopotential,
    diagnose_pseudopotentials,
    ensure_full_grpp_format,
)

__all__ = [
    "load_pseudopotential",
    "load",
    "help_pseudopotential",
    "diagnose_pseudopotentials",
    "ensure_full_grpp_format",
]
