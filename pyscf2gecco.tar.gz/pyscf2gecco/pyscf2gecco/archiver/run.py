from pyscf2gecco.archiver import GeCCoArchiver

import os
os.environ["OMP_NUM_THREADS"] = "16"
os.environ["OMP_PROC_BIND"] = "spread"
os.environ["OMP_PLACES"] = "cores"


arc = GeCCoArchiver(
    archive_name="",   # тег архива/метаданных
    num_workers=16,           # параллелизм (по умолчанию = все доступные ядра)
    verbose=True,             # печать прогресса/итогов
    # patterns/keywords ЗАМЕНЯЮТ дефолты (иначе используйте None)
    patterns=[
        "target_list", "RESULTS", "WARNINGS",
        "log_from_py_python_start.py", "log_from_py_setting_up_python_interface.py",
    ],
    keywords=[".fml", ".da", ".statistics", ".tgt_list"],
    xz_memlimit_percent=97,    # разрешить xz занять больше RAM
    xz_block_size=32*1024*1024 # уменьшить блок до 32 MiB, снизив RAM на поток
)
import time, os
start_time = time.time()

# пример: сжатие всех проектов на глубине 0..4
arc.compress_fcidump(root=".", depth_min=0, depth_max=1, to_zstd=True, filename = "sdsds.t.ds")
# arc.compress_all(
#     root=".",
#     depth_min=0,
#     depth_max=10,
#     user_meta={"1": "krya\nblablalba", "2": "utochka"},
# )

# arc.compress_all(
#     root=".",
#     depth_min=0,
#     depth_max=10,
#     user_meta={"1": "krya\nblablalba", "2": "utochka"},
# )
arc.show_meta(root=".", depth_min=0, depth_max=0)
#arc.decompress_fcidump(root="./", depth_min=0, depth_max=1, to_text=True, zstd_dthreads=os.cpu_count())
# # # # пример: распаковка FCIDUMP из fc-only и проектных архивов (последние перепакуются без FCIDUMP.bin)
# arc.compress_fcidump(root=".", depth_min=0, depth_max=10, zstd_level=1, zstd_threads=os.cpu_count(), to_zstd = True)

# arc.show_meta(root=".", depth_min=0, depth_max=10)
# time.sleep(10)
# arc.compress_all(
#     root=".",
#     depth_min=0,
#     depth_max=10,
#     user_meta={"1": "krya\nblablalba", "2": "utochka"},
# )



# #arc.compress_fcidump(root=".", depth_min=0, depth_max=10, zstd_level=1, zstd_threads=os.cpu_count(), to_zstd = True)

# arc.decompress_fcidump(root=".", depth_min=0, depth_max=10, to_text=False, zstd_dthreads=os.cpu_count())

# # # # # пример: полноценная распаковка проектов
#arc.decompress_all(root=".", depth_min=0, depth_max=10)
# arc.decompress_fcidump(root=".", depth_min=0, depth_max=10, to_text=True, zstd_dthreads=os.cpu_count())

#arc.list_archives(root=".", depth_min=0, depth_max=10)
print("время на выполнение: ", time.time() - start_time)

