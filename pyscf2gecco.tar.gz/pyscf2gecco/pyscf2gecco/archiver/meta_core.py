# meta_core.py
# -*- coding: utf-8 -*-
"""
META/TRAIL и константы бинарного формата v4 для FCIDUMP.bin.

Формат файла:
  [MAGIC='FCDB'][u32 VER=4]
  [u32 NORB][u32 NELEC][i32 MS2]
  [u32 N_ORBSYM][N_ORBSYM * u32 ORBSYM]
  [u64 BODY_LEN][BODY]                      # поток рекордов
  [META_MAGIC='FCMETA'][u32 META_LEN][META_JSON (utf-8)]
  [TRAIL_MAGIC='FCTRAIL'][u32 CRC32_ALL_BEFORE]  # CRC32 IEEE 802.3

Хеши: только BLAKE3. Поле в META:
  "hashes": { "fc_text_blake3": "<hex64>" }
"""

import io
import json
import struct
import time
import zlib
from typing import Dict, List

from blake3 import blake3  # pip install blake3

MAGIC = b"FCDB"
VER = 4
META_MAGIC = b"FCMETA"
TRAIL_MAGIC = b"FCTRAIL"

_u32 = struct.Struct("<I")
_i32 = struct.Struct("<i")
_u64 = struct.Struct("<Q")


def b3_hex(data: bytes) -> str:
    return blake3(data).hexdigest()


def build_header(norb: int, nelec: int, ms2: int, orbsym: List[int]) -> bytes:
    out = io.BytesIO()
    out.write(MAGIC)
    out.write(_u32.pack(VER))
    out.write(_u32.pack(norb))
    out.write(_u32.pack(nelec))
    out.write(_i32.pack(ms2))
    out.write(_u32.pack(len(orbsym)))
    for x in orbsym:
        out.write(_u32.pack(int(x)))
    return out.getvalue()


def build_meta(auto: Dict, user: Dict) -> bytes:
    meta = {"auto": auto, "user": user or {}}
    payload = json.dumps(meta, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    return META_MAGIC + _u32.pack(len(payload)) + payload


def build_trail(crc32_val: int) -> bytes:
    return TRAIL_MAGIC + _u32.pack(crc32_val & 0xFFFFFFFF)


def parse_meta(raw: bytes) -> Dict:
    if not raw.startswith(META_MAGIC):
        raise ValueError("META header not found")
    meta_len = _u32.unpack_from(raw, len(META_MAGIC))[0]
    payload = raw[len(META_MAGIC) + 4 : len(META_MAGIC) + 4 + meta_len]
    return json.loads(payload.decode("utf-8"))


def now_meta(version: str, norb: int, nelec: int, ms2: int, orbsym: List[int], body_bytes: bytes) -> Dict:
    return {
        "created_utc": int(time.time()),
        "archiver_version": version,
        "hashes": {"fc_text_blake3": b3_hex(body_bytes)},
        "fcidump": {"norb": norb, "nelec": nelec, "ms2": ms2, "orbsym": list(map(int, orbsym))},
    }


def crc32_all(parts: List[bytes]) -> int:
    z = 0
    for p in parts:
        z = zlib.crc32(p, z)
    return z & 0xFFFFFFFF
