# archiver_core.py
# -*- coding: utf-8 -*-
from __future__ import annotations

import os
import io
import json
import tarfile
import shutil
import tempfile
import subprocess
import lzma
import struct
import copy
import glob
import re
import math
import blake3
from contextlib import contextmanager
from datetime import datetime, timezone
import stat as _stat
import errno
import time
from typing import Callable, Dict, Iterable, List, Optional, Tuple

# --- внешние Cython-модули ---
from .fcidump_codec import (
    text_to_bin_compact_stream,   # txt -> path (может быть FIFO), считает BLAKE3 внутри .bin
    bin_to_text_parallel,         # .bin -> FCIDUMP (формат выравнивания строго совместим)
    verify_b3_of_bin,             # проверка целостности .bin по BLAKE3 (внутренний заголовок)
    read_meta_from_bin,
)

# zstd-кодек (на базе libzstd). Должен быть собран.
try:
    from .zstd_codec import (
        compress_zstd_file as _zstd_compress_file,     # (src_path, dst_path, level, threads, chunk)
        decompress_zstd_file as _zstd_decompress_file, # (src_path, dst_path, threads)
        blake3_of_decompressed,                        # (src_path, threads) -> hex
    )
    _HAVE_ZSTD = True
except Exception:
    _HAVE_ZSTD = False
    _zstd_compress_file = _zstd_decompress_file = None  # type: ignore
    blake3_of_decompressed = None  # type: ignore


# ---------------- утилиты диска/файлов ----------------

def _size(p: str) -> int:
    try:
        return os.path.getsize(p)
    except Exception:
        return 0

def _size_mb(nbytes: int) -> float:
    return float(nbytes) / (1024.0 * 1024.0)

def _safe_remove(p: str) -> None:
    try:
        if p and os.path.exists(p):
            os.remove(p)
    except Exception:
        pass

def _is_regular_file(path: str) -> bool:
    try:
        st = os.lstat(path)
        return _stat.S_ISREG(st.st_mode)
    except FileNotFoundError:
        return False


def _size_reg(path: str) -> int:
    return _size(path) if _is_regular_file(path) else 0


_ARCHIVE_META_NAME = "ARCHIVE_META.json"
_ARCHIVE_SIGNATURE = "GECCO_ARCHIVE_v1"

_FCIDUMP_DATA_BASENAMES = {
    "FCIDUMP",
    "FCIDUMP.bin",
    "FCIDUMP.bin.zst",
}
_FCIDUMP_META_BASENAMES = {
    _ARCHIVE_META_NAME,
    "FCIDUMP_info.txt",
    "FCIDUMP.bin.zst.meta.json",
    "FCIDUMP.bin.meta.json",
}
_FCIDUMP_HASH_KEY = "fc_hash"
_FCIDUMP_SIG_DIGITS = 15
_FCIDUMP_ULP_GUARD = 2


# --------- детерминированный tar.xz ---------


def _read_json_safely(path: str) -> Optional[Dict]:
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return None


def _normalize_int(value: object) -> Optional[int]:
    if isinstance(value, bool):
        return int(value)
    if isinstance(value, (int, float)):
        return int(value)
    if isinstance(value, str):
        try:
            return int(float(value))
        except Exception:
            return None
    return None


def _fcidump_meta_update(meta_path: str, *, created_ts: Optional[int] = None, **updates: object) -> None:
    data = _read_json_safely(meta_path) or {}
    current = _normalize_int(data.get("created_utc"))
    if created_ts is None:
        created_ts = current
    else:
        created_ts = _normalize_int(created_ts)
    if created_ts is None:
        created_ts = int(time.time())
    data["created_utc"] = int(created_ts)
    for key, value in updates.items():
        if value is None:
            continue
        data[key] = value
    try:
        with open(meta_path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2, sort_keys=True)
    except Exception:
        pass


_FCIDUMP_MAGIC = b"FCD5"
_HDR_STRUCT = struct.Struct("<I")
_PACK_INDICES = struct.Struct(">iiii")


def _auto_user_meta() -> Dict:
    info: Dict = {}
    try:
        user = os.environ.get("FCIDUMP_USER") or os.environ.get("USER")
        if user:
            info["generated_by"] = user
    except Exception:
        pass
    try:
        now_utc = datetime.now(timezone.utc)
        info.setdefault("generated_iso", now_utc.isoformat(timespec="seconds"))
        info.setdefault("generated_utc", int(now_utc.timestamp()))
    except Exception:
        pass
    return info


def _threads_or_cpu(value: Optional[int]) -> int:
    cpu_total = max(1, os.cpu_count() or 1)
    if value is None or value <= 0:
        return cpu_total
    return int(max(1, value))


def _detect_fcidump_format(filepath: str) -> Optional[str]:
    """
    Определить формат файла FCIDUMP по его содержимому.
    Возвращает: 'bin' для .bin, 'zst' для .bin.zst, 'txt' для текстового, None если не удалось определить.
    """
    if not _is_regular_file(filepath):
        return None
    
    try:
        with open(filepath, "rb") as f:
            # Читаем первые 4 байта для проверки магических сигнатур
            magic = f.read(4)
            
            # Проверка на FCIDUMP.bin (FCD5)
            if magic == _FCIDUMP_MAGIC:
                return "bin"
            
            # Проверка на zstd (магическая сигнатура: 0x28, 0xB5, 0x2F, 0xFD)
            if len(magic) >= 4 and magic[0:4] == b'\x28\xB5\x2F\xFD':
                return "zst"
            
            # Если не бинарный формат, пробуем как текст
            # Проверяем начало файла на текстовые признаки FCIDUMP
            f.seek(0)
            try:
                first_bytes = f.read(1024)
                text = first_bytes.decode('utf-8', errors='strict')
                # Ищем признаки текстового FCIDUMP (&FCI, &END, числа и т.д.)
                if '&' in text or 'NORB' in text.upper() or 'NELEC' in text.upper():
                    return "txt"
            except UnicodeDecodeError:
                pass
            
    except Exception:
        pass
    
    return None


def _merge_user_meta_dict(base: Optional[Dict], patch: Optional[Dict]) -> Dict:
    result: Dict = {}
    if isinstance(base, dict):
        for key, val in base.items():
            if isinstance(val, dict):
                result[key] = _merge_user_meta_dict(val, None)
            else:
                result[key] = val
    if isinstance(patch, dict):
        for key, val in patch.items():
            if isinstance(val, dict) and isinstance(result.get(key), dict):
                result[key] = _merge_user_meta_dict(result.get(key), val)
            else:
                result[key] = val
    return result


def _rewrite_bin_meta(bin_path: str, modifier: Callable[[Dict], bool]) -> bool:
    if not _is_regular_file(bin_path):
        return False
    try:
        with open(bin_path, "rb") as src:
            if src.read(4) != _FCIDUMP_MAGIC:
                return False
            hdr_len_bytes = src.read(4)
            if len(hdr_len_bytes) != 4:
                return False
            (hdr_len,) = _HDR_STRUCT.unpack(hdr_len_bytes)
            hdr = src.read(hdr_len)
            body = src.read()
    except Exception:
        return False

    try:
        meta = json.loads(hdr.decode("utf-8"))
    except Exception:
        return False

    changed = modifier(meta)
    if not changed:
        return False

    new_hdr = json.dumps(meta, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    tmp_path = bin_path + ".tmp_meta"
    try:
        with open(tmp_path, "wb") as out:
            out.write(_FCIDUMP_MAGIC)
            out.write(_HDR_STRUCT.pack(len(new_hdr)))
            out.write(new_hdr)
            out.write(body)
        os.replace(tmp_path, bin_path)
    except Exception:
        _safe_remove(tmp_path)
        return False
    finally:
        _safe_remove(tmp_path)
    return True


def _update_bin_user_meta(bin_path: str, patch: Optional[Dict]) -> bool:
    if not patch or not isinstance(patch, dict):
        return False

    def modifier(meta: Dict) -> bool:
        raw_user = meta.get("user")
        if isinstance(raw_user, dict):
            base = raw_user
        elif raw_user is None:
            base = {}
        else:
            base = {"_previous": raw_user}

        if not patch:
            return False
        merged = _merge_user_meta_dict(base, patch)
        if merged == base:
            return False
        meta["user"] = merged
        return True

    return _rewrite_bin_meta(bin_path, modifier)


def _update_auto_meta(bin_path: str, patch: Optional[Dict]) -> bool:
    if not patch or not isinstance(patch, dict):
        return False

    patch_copy = copy.deepcopy(patch)

    def modifier(meta: Dict) -> bool:
        auto = meta.get("auto")
        changed = False
        if not isinstance(auto, dict):
            auto = {}
            meta["auto"] = auto
            changed = True
        created_keys = {
            "created_utc",
            "created",
            "created_iso",
            "time_utc",
            "time",
            "generated_by",
            "generated_iso",
            "generated_utc",
        }
        for key, value in patch_copy.items():
            if key in auto and key in created_keys:
                continue
            if key in auto and auto[key] == value:
                continue
            auto[key] = value
            changed = True
        return changed

    return _rewrite_bin_meta(bin_path, modifier)


def _restore_auto_meta(bin_path: str, data: Optional[Dict]) -> bool:
    if not data or not isinstance(data, dict):
        return False
    auto_copy = copy.deepcopy(data)

    def modifier(meta: Dict) -> bool:
        if not isinstance(auto_copy, dict):
            return False
        auto = meta.get("auto")
        changed = False
        if not isinstance(auto, dict):
            meta["auto"] = copy.deepcopy(auto_copy)
            return True
        for key, value in auto_copy.items():
            if auto.get(key) != value:
                auto[key] = value
                changed = True
        return changed

    return _rewrite_bin_meta(bin_path, modifier)


def _det_tarinfo(name: str, st: os.stat_result) -> tarfile.TarInfo:
    ti = tarfile.TarInfo(name=name)
    ti.type = tarfile.REGTYPE
    ti.size = st.st_size
    ti.mode = 0o644
    ti.uid = 0; ti.gid = 0
    ti.uname = "root"; ti.gname = "root"
    ti.mtime = 0
    return ti

def _write_txz(
    dirpath: str,
    archive_name: str,
    files: List[str],
    *,
    xz_threads: int = 0,
    xz_memlimit_percent: Optional[int] = None,
    xz_block_size: Optional[int] = None,
) -> str:
    """
    Создаёт project_archive_{archive_name}.tar.xz в dirpath из списка абсолютных путей files.
    В архив не попадут нерегулярные файлы (FIFO/сокеты/директории/симлинки).
    """
    tar_path = os.path.join(dirpath, f"project_archive_{archive_name}.tar.xz")

    rel_files: List[str] = []
    for p in files:
        if _is_regular_file(p):
            rel_files.append(os.path.relpath(p, dirpath))

    # если нечего класть — создаём пустой tar и сжимаем
    if not rel_files:
        tmpdir = tempfile.mkdtemp(prefix=".txz_", dir=dirpath or ".")
        tar_tmp = os.path.join(tmpdir, "payload.tar")
        try:
            with tarfile.open(tar_tmp, mode="w") as tf:
                pass
            try:
                cmd = ["xz", "-c", "-7", "-T", str(xz_threads if xz_threads > 0 else 0), tar_tmp]
                if xz_memlimit_percent is not None:
                    cmd.append(f"--memlimit-compress={int(xz_memlimit_percent)}%")
                if xz_block_size is not None and xz_block_size > 0:
                    cmd.append(f"--block-size={int(xz_block_size)}")
                with open(tar_path, "wb") as fout:
                    subprocess.run(cmd, check=True, stdout=fout, stderr=subprocess.PIPE, env={})
            except FileNotFoundError:
                with open(tar_tmp, "rb") as fin, lzma.open(tar_path, "wb", preset=7) as fout:
                    shutil.copyfileobj(fin, fout)
        finally:
            _safe_remove(tar_tmp)
            shutil.rmtree(tmpdir, ignore_errors=True)
        return tar_path

    # путь 1: внешние tar|xz
    try:
        listfile = tempfile.NamedTemporaryFile("w", delete=False, dir=dirpath, encoding="utf-8")
        try:
            for rp in sorted(rel_files):
                listfile.write(rp + "\n")
        finally:
            listfile.close()

        tar_cmd = [
            "tar",
            "-C", dirpath,
            "--sort=name",
            "--mtime=@0",
            "--owner=0",
            "--group=0",
            "--numeric-owner",
            "-c",
            "-T", listfile.name
        ]
        threads = (xz_threads if xz_threads > 0 else max(1, (os.cpu_count() or 1) // 2))
        xz_cmd = ["xz", "-7", "-T", str(threads), "-c"]
        if xz_memlimit_percent is not None:
            xz_cmd.append(f"--memlimit-compress={int(xz_memlimit_percent)}%")
        if xz_block_size is not None and xz_block_size > 0:
            xz_cmd.append(f"--block-size={int(xz_block_size)}")

        with open(tar_path, "wb") as fout:
            p_tar = subprocess.Popen(tar_cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, close_fds=True, env={})
            try:
                p_xz = subprocess.Popen(xz_cmd, stdin=p_tar.stdout, stdout=fout, stderr=subprocess.PIPE, close_fds=True, env={})
                if p_tar.stdout is not None:
                    p_tar.stdout.close()
                _, err_xz  = p_xz.communicate()
                _, err_tar = p_tar.communicate()
                if p_xz.returncode != 0:
                    raise RuntimeError(f"xz failed: {err_xz.decode('utf-8','ignore')}")
                if p_tar.returncode != 0:
                    raise RuntimeError(f"tar failed: {err_tar.decode('utf-8','ignore')}")
            finally:
                try: p_tar.kill()
                except Exception: pass

        _safe_remove(listfile.name)
        return tar_path

    except FileNotFoundError:
        # путь 2: чистый Python tarfile + lzma
        tmpdir = tempfile.mkdtemp(prefix=".txz_", dir=dirpath or ".")
        tar_tmp = os.path.join(tmpdir, "payload.tar")
        try:
            with tarfile.open(tar_tmp, mode="w") as tf:
                for rp in sorted(rel_files):
                    full = os.path.join(dirpath, rp)
                    if not _is_regular_file(full):
                        continue
                    st = os.stat(full)
                    with open(full, "rb") as fo:
                        tf.addfile(_det_tarinfo(os.path.basename(rp), st), fileobj=fo)
            try:
                cmd = ["xz", "-c", "-7", "-T", str(threads), tar_tmp]
                if xz_memlimit_percent is not None:
                    cmd.append(f"--memlimit-compress={int(xz_memlimit_percent)}%")
                if xz_block_size is not None and xz_block_size > 0:
                    cmd.append(f"--block-size={int(xz_block_size)}")
                with open(tar_path, "wb") as fout:
                    subprocess.run(cmd, check=True, stdout=fout, stderr=subprocess.PIPE, env={})
            except Exception:
                with open(tar_tmp, "rb") as fin, lzma.open(tar_path, "wb", preset=7) as fout:
                    shutil.copyfileobj(fin, fout)
        finally:
            _safe_remove(tar_tmp)
            shutil.rmtree(tmpdir, ignore_errors=True)
        return tar_path


def _extract_txz_to_tmp(tar_path: str) -> Tuple[str, List[str]]:
    """Распаковать tar.xz в временный каталог, вернуть (tmp_dir, [полные пути])."""
    td = tempfile.mkdtemp(prefix=".unpack_", dir=os.path.dirname(tar_path) or ".")
    files: List[str] = []
    with tarfile.open(tar_path, mode="r:xz") as tf:
        for m in tf.getmembers():
            if m.isreg():
                tf.extract(m, path=td, set_attrs=False, numeric_owner=False)
                files.append(os.path.join(td, m.name))
    return td, files


def _archive_name_from_path(tar_path: str) -> str:
    name = os.path.basename(tar_path)
    if name.startswith("project_archive_") and name.endswith(".tar.xz"):
        return name[len("project_archive_"):-len(".tar.xz")]
    if name.endswith(".tar.xz"):
        return name[:-len(".tar.xz")]
    return name


def _archive_has_fcidump(tar_path: str) -> bool:
    try:
        with tarfile.open(tar_path, mode="r:xz") as tf:
            for m in tf.getmembers():
                if not m.isreg():
                    continue
                base = os.path.basename(m.name)
                if base in {"FCIDUMP.bin", "FCIDUMP.bin.zst"}:
                    return True
    except Exception:
        return False
    return False


def _append_files_to_archive(tar_path: str, fc_files: List[str]) -> Tuple[bool, int]:
    if not fc_files:
        return False, 0
    prev_size = _size_reg(tar_path)
    fc_sizes = sum(_size_reg(p) for p in fc_files)
    try:
        td, extracted = _extract_txz_to_tmp(tar_path)
    except Exception:
        return False, 0
    try:
        present: Dict[str, str] = {}
        meta_on_disk: Optional[str] = None
        for path in extracted:
            base = os.path.basename(path)
            present[base] = path
            if base == _ARCHIVE_META_NAME:
                meta_on_disk = path
        for src in fc_files:
            if not _is_regular_file(src):
                continue
            base = os.path.basename(src)
            dst = os.path.join(td, base)
            _safe_remove(dst)
            shutil.copy2(src, dst)
            present[base] = dst
        if meta_on_disk and _is_regular_file(meta_on_disk):
            try:
                meta_payload = _read_json_safely(meta_on_disk) or {}
                if isinstance(meta_payload, dict):
                    files_map = meta_payload.setdefault("files", {}) if isinstance(meta_payload.get("files"), dict) else {}
                    if not isinstance(files_map, dict):
                        files_map = {}
                        meta_payload["files"] = files_map
                    meta_payload.setdefault("signature", _ARCHIVE_SIGNATURE)
                    meta_payload["with_fcidump"] = True
                    for src in fc_files:
                        if not _is_regular_file(src):
                            continue
                        base = os.path.basename(src)
                        try:
                            entry = files_map.get(base)
                            if not isinstance(entry, dict):
                                entry = {}
                                files_map[base] = entry
                            if base in _FCIDUMP_DATA_BASENAMES:
                                entry.pop("b3", None)
                                entry[_FCIDUMP_HASH_KEY] = hash_fcidump(
                                    src,
                                    sig_digits=_FCIDUMP_SIG_DIGITS,
                                    ulp_guard=_FCIDUMP_ULP_GUARD,
                                )
                            else:
                                entry["b3"] = _blake3_of_file(src)
                        except Exception:
                            pass
                    with open(meta_on_disk, "w", encoding="utf-8") as mf:
                        json.dump(meta_payload, mf, ensure_ascii=False, indent=2)
            except Exception:
                pass

        file_list = list({os.path.realpath(p): p for p in present.values()}.values())
        archive_name = _archive_name_from_path(tar_path)
        new_archive = _write_txz(td, archive_name, file_list)
        shutil.move(new_archive, tar_path)
        new_size = _size_reg(tar_path)
        saved = (prev_size + fc_sizes) - new_size
        return True, saved
    except Exception:
        return False, 0
    finally:
        shutil.rmtree(td, ignore_errors=True)


def _remove_files_from_archive(tar_path: str, remove_names: List[str]) -> Tuple[bool, int]:
    """Rewrite tar.xz without files whose basename is in remove_names.
    Returns (changed, saved_bytes_positive_if_freed)."""
    remove_set = set(remove_names)
    prev_size = _size_reg(tar_path)
    try:
        td, extracted = _extract_txz_to_tmp(tar_path)
    except Exception:
        return False, 0
    try:
        keep: List[str] = []
        meta_on_disk: Optional[str] = None
        removed_actual: List[str] = []
        removed_hash: Dict[str, str] = {}
        for path in extracted:
            base = os.path.basename(path)
            if base in remove_set:
                if base in _FCIDUMP_DATA_BASENAMES:
                    try:
                        removed_hash[base] = hash_fcidump(
                            path,
                            sig_digits=_FCIDUMP_SIG_DIGITS,
                            ulp_guard=_FCIDUMP_ULP_GUARD,
                        )
                    except Exception:
                        pass
                removed_actual.append(base)
                continue
            if base == _ARCHIVE_META_NAME:
                meta_on_disk = path
            keep.append(path)
        # If nothing to remove, bail out
        if len(keep) == len(extracted):
            return False, 0
        if meta_on_disk and _is_regular_file(meta_on_disk):
            try:
                meta_payload = _read_json_safely(meta_on_disk) or {}
                files_map = meta_payload.get("files") if isinstance(meta_payload.get("files"), dict) else None
                if isinstance(files_map, dict):
                    for name in removed_actual:
                        if not name.startswith("FCIDUMP"):
                            files_map.pop(name, None)
                        else:
                            entry = files_map.get(name)
                            if not isinstance(entry, dict):
                                entry = {}
                                files_map[name] = entry
                            hash_value = removed_hash.get(name) or entry.get(_FCIDUMP_HASH_KEY)
                            if hash_value:
                                entry[_FCIDUMP_HASH_KEY] = hash_value
                            else:
                                entry.pop(_FCIDUMP_HASH_KEY, None)
                if any(name.startswith("FCIDUMP") for name in removed_actual):
                    meta_payload["with_fcidump"] = False
                with open(meta_on_disk, "w", encoding="utf-8") as mf:
                    json.dump(meta_payload, mf, ensure_ascii=False, indent=2)
            except Exception:
                pass
        archive_name = _archive_name_from_path(tar_path)
        new_archive = _write_txz(td, archive_name, keep)
        shutil.move(new_archive, tar_path)
        new_size = _size_reg(tar_path)
        saved = max(0, prev_size - new_size)
        return True, saved
    except Exception:
        return False, 0
    finally:
        shutil.rmtree(td, ignore_errors=True)


def _next_archive_filename(dirpath: str, tag: str, existing: List[str]) -> str:
    base = f"project_archive_{tag}"
    used: set[int] = set()
    for path in existing:
        name = os.path.basename(path)
        if not name.startswith(base) or not name.endswith(".tar.xz"):
            continue
        suffix = name[len(base):-len(".tar.xz")]
        if not suffix:
            used.add(0)
        elif suffix.startswith("_"):
            try:
                idx = int(suffix[1:])
                used.add(idx)
            except ValueError:
                continue
    idx = 0
    if 0 not in used:
        return f"{base}.tar.xz"
    idx = 1
    while idx in used:
        idx += 1
    return f"{base}_{idx}.tar.xz"


# ------------- межпроцессная блокировка каталога -------------

try:
    import fcntl
    _HAVE_FCNTL = True
except Exception:
    _HAVE_FCNTL = False

class _DirLock:
    """Эксклюзивная блокировка каталога через flock."""
    def __init__(self, dirpath: str, timeout: float = 300.0, poll: float = 0.05):
        self.dirpath = os.path.abspath(dirpath or ".")
        self.lock_path = os.path.join(self.dirpath, ".FCIDUMP.encode.lock")
        self.timeout = float(timeout)
        self.poll = float(poll)
        self.fd: Optional[int] = None

    def acquire(self) -> bool:
        self.fd = os.open(self.lock_path, os.O_CREAT | os.O_RDWR, 0o600)
        if not _HAVE_FCNTL:
            return True
        end = time.monotonic() + self.timeout
        while True:
            try:
                fcntl.flock(self.fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
                return True
            except OSError as e:
                if e.errno in (errno.EAGAIN, errno.EACCES):
                    if time.monotonic() >= end:
                        return False
                    time.sleep(self.poll)
                    continue
                raise

    def release(self) -> None:
        try:
            if self.fd is not None and _HAVE_FCNTL:
                fcntl.flock(self.fd, fcntl.LOCK_UN)
        except Exception:
            pass
        try:
            if self.fd is not None:
                os.close(self.fd)
        finally:
            self.fd = None

    def __enter__(self):
        ok = self.acquire()
        return ok
    def __exit__(self, exc_type, exc, tb):
        self.release()


# ---------------- TEE: TXT -> (BIN stream) -> BLAKE3 + ZSTD ----------------

def _writer_txt_to_fifo(path_txt: str, path_fifo: str, fc_threads: int) -> None:
    """Генерация бинарного потока FCIDUMP.bin напрямую в именованный FIFO с явным OMP."""
    if fc_threads and fc_threads > 0:
        os.environ["OMP_NUM_THREADS"] = str(int(fc_threads))
        os.environ.setdefault("OMP_PROC_BIND", "spread")
        os.environ.setdefault("OMP_PLACES", "cores")
    text_to_bin_compact_stream(path_txt, path_fifo)

def _zstd_reader_fifo_to_zst(path_fifo: str, path_out: str, lvl: int, th: int, ch: int) -> None:
    """Zstd-воркер: читает из именованного FIFO и пишет .zst."""
    _zstd_compress_file(path_fifo, path_out, level=lvl, threads=th, chunk=ch)

def _encode_txt_to_zst_streamhash(
    txt: str,
    zst: str,
    *,
    level: int,
    threads: int,
    chunk: int = 32 << 20,
    fc_threads: int = 0,
) -> str:
    """
    Быстрый путь (многопоточный): если fc_threads>1, кодируем в .tmp.bin (OpenMP внутри),
    затем считаем BLAKE3(.tmp.bin) многопоточно и сжимаем в Zstd с threads потоками.
    Медленный стримовый путь (FIFO) сохраняем только для fc_threads<=1.
    Возвращает hex BLAKE3 бинарного потока.
    """
    if not _HAVE_ZSTD:
        raise RuntimeError("zstd not available (install libzstd-dev and rebuild)")

    # --- быстрый параллельный путь через tmp.bin ---
    if fc_threads and fc_threads > 1:
        # 1) параллельно текст -> tmp.bin
        dirpath = os.path.abspath(os.path.dirname(zst) or ".")
        tmp_bin = os.path.join(dirpath, ".FCIDUMP.encode.tmp.bin")
        try:
            # Настроим OpenMP для кодека
            os.environ["OMP_NUM_THREADS"] = str(int(fc_threads))
            os.environ.setdefault("OMP_PROC_BIND", "spread")
            os.environ.setdefault("OMP_PLACES", "cores")

            # ВАЖНО: эта функция должна быть реализована так, чтобы использовать OpenMP/prange
            # и произвольную запись в файл (не FIFO).
            text_to_bin_compact_stream(txt, tmp_bin)

            # 2) BLAKE3 — многопоточно, без распаковки
            b3_bin = _blake3_of_file(tmp_bin, chunk=chunk)

            # 3) Zstd — многопоточно
            _zstd_compress_file(tmp_bin, zst, level=int(level), threads=int(threads), chunk=int(chunk))

            # 4) (опц.) самопроверка «по дешёвке» — BLAKE3(decompressed) vs b3_bin
            #    чтобы не писать на диск: lib zstd читает .zst и даёт нам поток на лету.
            if blake3_of_decompressed is None:
                raise RuntimeError("RAM-verify not available")
            b3_dec = blake3_of_decompressed(zst, threads=max(1, int(threads)))
            if b3_dec.lower() != b3_bin.lower():
                _safe_remove(zst)
                raise RuntimeError("post-verify mismatch (BLAKE3)")

            return b3_bin  # это BLAKE3 бинарного потока
        finally:
            _safe_remove(tmp_bin)

    # --- стримовый путь через FIFO (оставлен для совместимости и fc_threads<=1) ---
    import multiprocessing as mp, blake3, random
    dirpath = os.path.abspath(os.path.dirname(zst) or ".")
    uid = f"{os.getpid()}_{int(time.time()*1000)}_{random.getrandbits(32):08x}"
    fifo_src  = os.path.join(dirpath, f".FCIDUMP.bin.{uid}.pipe")
    fifo_zstd = os.path.join(dirpath, f".FCIDUMP.zstd.{uid}.pipe")

    for p in (fifo_src, fifo_zstd):
        try:
            st = os.lstat(p)
            if _stat.S_ISFIFO(st.st_mode):
                os.remove(p)
        except FileNotFoundError:
            pass
    os.mkfifo(fifo_src,  0o600)
    os.mkfifo(fifo_zstd, 0o600)

    ctx = mp.get_context("fork")
    p_writer = ctx.Process(target=_writer_txt_to_fifo,      args=(txt, fifo_src, int(fc_threads)), daemon=True)
    p_zstd   = ctx.Process(target=_zstd_reader_fifo_to_zst, args=(fifo_zstd, os.path.abspath(zst), int(level), int(threads), int(chunk)), daemon=True)

    p_zstd.start()
    p_writer.start()

    # BLAKE3 считаем на лету (здесь — один поток; это дешевле, чем писать на диск)
    h = blake3.blake3(max_threads=max(1, int(threads)))
    bsize = int(chunk)
    fd_in = fd_out = -1
    try:
        fd_in  = os.open(fifo_src,  os.O_RDONLY)
        fd_out = os.open(fifo_zstd, os.O_WRONLY)
        while True:
            data = os.read(fd_in, bsize)
            if not data:
                break
            h.update(data)
            off = 0
            while off < len(data):
                w = os.write(fd_out, data[off:])
                if w <= 0:
                    raise RuntimeError("short write into zstd FIFO")
                off += w
    except Exception:
        try:
            if p_writer.is_alive(): p_writer.terminate()
        except Exception: pass
        try:
            if p_zstd.is_alive():   p_zstd.terminate()
        except Exception: pass
        _safe_remove(zst)
        raise
    finally:
        for fd in (fd_in, fd_out):
            try:
                if fd >= 0: os.close(fd)
            except Exception: pass
        for p in (fifo_src, fifo_zstd):
            try: os.remove(p)
            except Exception: pass
        for proc in (p_writer, p_zstd):
            proc.join(timeout=30.0)
            if proc.is_alive():
                try: proc.terminate()
                except Exception: pass
                proc.join(timeout=5.0)

    if p_writer.exitcode != 0:
        _safe_remove(zst); raise RuntimeError("BIN writer failed")
    if p_zstd.exitcode != 0:
        _safe_remove(zst); raise RuntimeError("zstd worker failed")

    return h.hexdigest()


# ---------------- BLAKE3 полезняшка ----------------

def _blake3_of_file(path: str, chunk: int = 8 << 20) -> str:
    import blake3
    max_thr = max(1, os.cpu_count() or 1)
    h = blake3.blake3(max_threads=max_thr)
    with open(path, "rb") as f:
        while True:
            b = f.read(chunk)
            if not b:
                break
            h.update(b)
    return h.hexdigest()


@contextmanager
def _fcidump_text_reader(source: object) -> Iterable[str]:
    if isinstance(source, (bytes, bytearray, memoryview)):
        text = bytes(source).decode("utf-8", errors="ignore")
        yield io.StringIO(text)
        return

    path = os.fspath(source)
    tmp_dir: Optional[str] = None
    fh: Optional[io.TextIOBase] = None
    try:
        if path.endswith(".zst"):
            if not _HAVE_ZSTD:
                raise RuntimeError("zstd not available")
            tmp_dir = tempfile.mkdtemp(prefix=".fc_hash_", dir=os.path.dirname(path) or ".")
            tmp_bin = os.path.join(tmp_dir, "FCIDUMP.bin")
            tmp_txt = os.path.join(tmp_dir, "FCIDUMP.txt")
            _zstd_decompress_file(path, tmp_bin, threads=0)
            bin_to_text_parallel(tmp_bin, tmp_txt)
            fh = open(tmp_txt, "r", encoding="utf-8", errors="ignore")
        elif path.endswith(".bin"):
            tmp_dir = tempfile.mkdtemp(prefix=".fc_hash_", dir=os.path.dirname(path) or ".")
            tmp_txt = os.path.join(tmp_dir, "FCIDUMP.txt")
            bin_to_text_parallel(path, tmp_txt)
            fh = open(tmp_txt, "r", encoding="utf-8", errors="ignore")
        else:
            fh = open(path, "r", encoding="utf-8", errors="ignore")
        yield fh
    finally:
        if fh is not None and not fh.closed:
            fh.close()
        if tmp_dir is not None:
            shutil.rmtree(tmp_dir, ignore_errors=True)


def _fcidump_normalize_header(header_lines: List[str]) -> str:
    if not header_lines:
        return "&FCI\n/"

    prefix = "FCI"
    header_blob = " ".join(line.strip() for line in header_lines if line.strip() and line.strip() != "/")
    match = re.search(r"&\s*([A-Za-z0-9_]+)", header_blob)
    if match:
        prefix = match.group(1).upper()

    kv_pairs: Dict[str, str] = {}
    for line in header_lines:
        stripped = line.strip()
        if not stripped or stripped == "/" or stripped.startswith("!"):
            continue
        stripped = re.sub(r"&\s*[A-Za-z0-9_]+", "", stripped)
        for key, value in re.findall(r"([A-Za-z0-9_()+\-]+)\s*=([^,]+)", stripped):
            cleaned = ",".join(part.strip() for part in value.strip().split(",") if part.strip())
            kv_pairs[key.upper()] = cleaned

    parts = [f"&{prefix}"]
    for key in sorted(kv_pairs):
        parts.append(f"{key}={kv_pairs[key]}")
    parts.append("/")
    return "\n".join(parts)


def _fcidump_parse_stream(fh: Iterable[str]) -> Tuple[List[str], List[Tuple[int, int, int, int, float]]]:
    header_lines: List[str] = []
    records: List[Tuple[int, int, int, int, float]] = []
    in_header = True
    for raw in fh:
        line = raw.rstrip("\n")
        stripped = line.strip()
        if in_header:
            if not stripped and not header_lines:
                continue
            header_lines.append(line)
            if stripped == "/":
                in_header = False
            continue
        if not stripped:
            continue
        parts = stripped.split()
        if not parts:
            continue
        value_token_raw = parts[0]
        value_token = value_token_raw.replace('D', 'E').replace('d', 'e')
        try:
            value = float(value_token)
        except ValueError:
            if value_token.lower() in {"nan", "+nan", "-nan"}:
                value = float('nan')
            elif value_token.lower() in {"inf", "+inf"}:
                value = float('inf')
            elif value_token.lower() == "-inf":
                value = float('-inf')
            else:
                value = float(value_token)
        idx_tokens = parts[1:]
        indices: List[int] = []
        for tok in idx_tokens:
            try:
                indices.append(int(tok))
            except ValueError:
                indices.append(0)
        while len(indices) < 4:
            indices.append(0)
        indices = indices[:4]
        records.append((indices[0], indices[1], indices[2], indices[3], value))
    return header_lines, records


def _scientific_repr(value: float, digits: int) -> str:
    frac = max(0, digits - 1)
    if value == 0.0:
        return f"+0.{ '0' * frac }E+00"
    sign = '-' if math.copysign(1.0, value) < 0 else '+'
    abs_val = abs(value)
    formatted = format(abs_val, f".{frac}E")
    mantissa, exp = formatted.split('E')
    return f"{sign}{mantissa}E{exp}"


def _stable_sig_repr(value: float, *, sig_digits: int, ulp_guard: int) -> str:
    if math.isnan(value):
        return "NaN"
    if math.isinf(value):
        return "+Inf" if value > 0 else "-Inf"
    if value == 0.0:
        return _scientific_repr(0.0, sig_digits)

    def rep(val: float, digits: int) -> str:
        return _scientific_repr(val, digits)

    base = float(value)
    if ulp_guard > 0:
        plus_vals: List[float] = []
        minus_vals: List[float] = []
        v_plus = base
        v_minus = base
        for _ in range(ulp_guard):
            v_plus = math.nextafter(v_plus, math.inf)
            v_minus = math.nextafter(v_minus, -math.inf)
            plus_vals.append(v_plus)
            minus_vals.append(v_minus)
    else:
        plus_vals = []
        minus_vals = []

    for digits in range(sig_digits, 1, -1):
        reference = rep(base, digits)
        ok = True
        if ulp_guard > 0:
            for plus_val, minus_val in zip(plus_vals, minus_vals):
                if not math.isfinite(plus_val) or not math.isfinite(minus_val):
                    ok = False
                    break
                if rep(plus_val, digits) != reference or rep(minus_val, digits) != reference:
                    ok = False
                    break
        if ok:
            return reference
    return rep(base, max(2, min(sig_digits, 2)))


def hash_fcidump(path_or_bytes: object, *, sig_digits: int = _FCIDUMP_SIG_DIGITS, ulp_guard: int = _FCIDUMP_ULP_GUARD) -> str:
    if sig_digits < 2:
        raise ValueError("sig_digits must be >= 2")
    if ulp_guard < 0:
        raise ValueError("ulp_guard must be >= 0")

    with _fcidump_text_reader(path_or_bytes) as reader:
        header_lines, records = _fcidump_parse_stream(reader)

    header_text = _fcidump_normalize_header(header_lines)
    records.sort()

    hasher = blake3.blake3()
    hasher.update(b"FCIDUMP.v2.stable-decimal")
    hasher.update(header_text.encode("utf-8"))
    hasher.update(b"\n")
    for i, j, k, l, value in records:
        hasher.update(_PACK_INDICES.pack(int(i), int(j), int(k), int(l)))
        value_repr = _stable_sig_repr(value, sig_digits=sig_digits, ulp_guard=ulp_guard)
        hasher.update(value_repr.encode("utf-8"))
        hasher.update(b"\n")
    return hasher.hexdigest()


def _hash_fcidump_from_archive(
    tar_path: str,
    base_name: str,
    *,
    sig_digits: int = _FCIDUMP_SIG_DIGITS,
    ulp_guard: int = _FCIDUMP_ULP_GUARD,
) -> Optional[str]:
    if not _is_regular_file(tar_path):
        return None
    try:
        with tarfile.open(tar_path, mode="r:xz") as tf:
            for member in tf.getmembers():
                if not member.isreg():
                    continue
                if os.path.basename(member.name) != base_name:
                    continue
                tmp_dir = tempfile.mkdtemp(prefix=".fc_hash_arch_", dir=os.path.dirname(tar_path) or ".")
                try:
                    tf.extract(member, path=tmp_dir, set_attrs=False, numeric_owner=False)
                    tmp_path = os.path.join(tmp_dir, member.name)
                    return hash_fcidump(tmp_path, sig_digits=sig_digits, ulp_guard=ulp_guard)
                finally:
                    shutil.rmtree(tmp_dir, ignore_errors=True)
    except Exception:
        return None
    return None


def _cleanup_fcidump_artifacts(dirpath: str, *, keep: Optional[Iterable[str]] = None) -> None:
    skip = {os.path.normpath(p) for p in (keep or [])}
    targets = _FCIDUMP_DATA_BASENAMES | {"FCIDUMP_info.txt"}
    for base in targets:
        path = os.path.join(dirpath, base)
        if os.path.normpath(path) in skip:
            continue
        _safe_remove(path)


def _emit_user_info_txt(bin_path: str, dirpath: str, fcidump_filename: Optional[str] = None) -> None:
    """Сохранить краткую информацию о FCIDUMP в текстовом виде.
    
    Args:
        bin_path: путь к .bin файлу
        dirpath: директория для сохранения info файла
        fcidump_filename: базовое имя FCIDUMP (если None, используется стандартное FCIDUMP_info.txt)
    """
    try:
        meta = read_meta_from_bin(bin_path) or {}
        user = meta.get("user", {})
        auto = meta.get("auto", {})
        if not user and not auto:
            return
        
        # Определяем имя info файла
        if fcidump_filename:
            out = os.path.join(dirpath, f"{fcidump_filename}_info.txt")
        else:
            out = os.path.join(dirpath, "FCIDUMP_info.txt")
        
        lines: List[str] = []
        lines.append("# FCIDUMP info")
        if auto:
            generated = auto.get("generated_by")
            if generated is not None:
                lines.append(f"auto.generated_by={generated}")
            created = auto.get("created_utc")
            if created is not None:
                lines.append(f"auto.created_utc={created}")
                try:
                    created_iso = auto.get("created_iso")
                    if not created_iso:
                        created_iso = datetime.fromtimestamp(int(created), tz=timezone.utc).isoformat(timespec="seconds")
                        if created_iso.endswith("+00:00"):
                            created_iso = created_iso[:-6] + "Z"
                    lines.append(f"auto.created_iso={created_iso}")
                except Exception:
                    pass
            fci = auto.get("fcidump", {}) if isinstance(auto.get("fcidump"), dict) else {}
            lines.append(f"auto.version={auto.get('version')}")
            norb = fci.get("norb", auto.get("norb"))
            nelec = fci.get("nelec", auto.get("nelec"))
            ms2 = fci.get("ms2", auto.get("ms2"))
            if norb is not None:
                lines.append(f"auto.fcidump.NORB={norb}")
            if nelec is not None:
                lines.append(f"auto.fcidump.NELEC={nelec}")
            if ms2 is not None:
                lines.append(f"auto.fcidump.MS2={ms2}")
        if user:
            lines.append("")
            lines.append("# user meta (JSON):")
            try:
                lines.append(json.dumps(user, ensure_ascii=False, indent=2, sort_keys=True))
            except Exception:
                lines.append(str(user))
        with open(out, "w", encoding="utf-8") as f:
            f.write("\n".join(lines) + "\n")
    except Exception:
        pass


# ---------------- FCIDUMP: encode / archive ----------------


def _parse_auto_value(text: str) -> object:
    value = text.strip()
    if not value:
        return ""
    try:
        return int(value)
    except Exception:
        pass
    try:
        return float(value)
    except Exception:
        pass
    return value


def _read_auto_user_from_info(info_path: str) -> Tuple[Optional[Dict], Optional[Dict]]:
    try:
        with open(info_path, "r", encoding="utf-8") as fh:
            lines = [line.rstrip("\n") for line in fh]
    except Exception:
        return None, None

    auto: Dict[str, object] = {}
    user_lines: List[str] = []
    capture_user = False
    for raw in lines:
        stripped = raw.strip()
        if capture_user:
            user_lines.append(raw)
            continue
        if not stripped:
            continue
        if stripped.startswith("#"):
            if stripped.lower().startswith("# user meta"):
                capture_user = True
            continue
        if stripped.startswith("auto.") and "=" in stripped:
            key, val = stripped.split("=", 1)
            key = key[5:]
            auto[key] = _parse_auto_value(val)

    user_meta: Optional[Dict] = None
    if user_lines:
        try:
            user_meta_obj = json.loads("\n".join(user_lines))
            if isinstance(user_meta_obj, dict):
                user_meta = user_meta_obj
        except Exception:
            user_meta = None

    return (auto or None), user_meta

def _list_dir_only(dirpath: str,
                   include_patterns: Iterable[str] | None,
                   include_keywords: Iterable[str] | None,
                   *,
                   with_fcidump: bool = True) -> List[str]:
    """Вернуть список полных путей к регулярным файлам текущего каталога."""
    pats = set(include_patterns or [])
    kws = [k for k in (include_keywords or []) if k]
    out: List[str] = []
    seen: set[str] = set()

    if with_fcidump:
        for base in (
            "FCIDUMP.bin.zst",
            "FCIDUMP.bin",
        ):
            p = os.path.join(dirpath, base)
            if _is_regular_file(p):
                norm = os.path.normpath(p)
                if norm not in seen:
                    out.append(p)
                    seen.add(norm)

    skip_fc = {
        "FCIDUMP.bin.zst",
        "FCIDUMP.bin",
        "FCIDUMP",
        "FCIDUMP_info.txt",
    }

    try:
        for base in os.listdir(dirpath):
            full = os.path.join(dirpath, base)
            norm = os.path.normpath(full)
            if not _is_regular_file(full):
                continue
            if base.startswith("project_archive_") and base.endswith(".tar.xz"):
                continue
            if base == _ARCHIVE_META_NAME:
                continue
            if not with_fcidump and base in skip_fc:
                continue
            if norm in seen:
                continue
            if base in pats or any(kw in base for kw in kws):
                out.append(norm)
                seen.add(norm)
    except FileNotFoundError:
        pass
    return out


def compress_fcidump_dir(
    *,
    dirpath: str,
    tag: str,
    compress: str = "zstd",          # "zstd" | "none"
    zstd_level: int = 1,
    zstd_threads: Optional[int] = None,
    fc_workers: Optional[int] = None,
    user_meta: Optional[Dict] = None,
    fcidump_filename: Optional[str] = None,
) -> Tuple[str, int, bool, str]:
    """Ensure FCIDUMP artifacts in ``dirpath`` follow requested state.
    
    Args:
        fcidump_filename: Optional custom filename (with any extension). If None, uses "FCIDUMP".
                  Format is auto-detected by file signature, not by extension.
    """
    dirpath = os.path.abspath(dirpath or ".")
    saved = 0
    if user_meta is not None and not isinstance(user_meta, dict):
        raise TypeError("user_meta must be a dict or None")
    auto_patch = _auto_user_meta() or None
    extra_meta = copy.deepcopy(user_meta) if user_meta is not None else None
    if isinstance(extra_meta, dict) and not extra_meta:
        extra_meta = None

    zstd_threads_res = _threads_or_cpu(zstd_threads)
    
    # Определяем базовое имя файла
    base_name = fcidump_filename if fcidump_filename is not None else "FCIDUMP"

    with _DirLock(dirpath, timeout=300.0) as got:
        if not got:
            return dirpath, 0, False, "encode busy (timeout)"

        # Пути к файлам - используем base_name или стандартные имена
        txt_path = os.path.join(dirpath, base_name)
        bin_path = os.path.join(dirpath, f"{base_name}.bin" if fcidump_filename else "FCIDUMP.bin")
        zst_path = os.path.join(dirpath, f"{base_name}.bin.zst" if fcidump_filename else "FCIDUMP.bin.zst")
        info_path = os.path.join(dirpath, "FCIDUMP_info.txt")
        
        # Если указан fcidump_filename, проверяем, какой формат у файла по сигнатуре
        if fcidump_filename is not None and _is_regular_file(txt_path):
            detected_format = _detect_fcidump_format(txt_path)
            if detected_format == "bin":
                # Файл на самом деле bin, переназначаем пути
                bin_path = txt_path
                txt_path = os.path.join(dirpath, f"{base_name}.txt.tmp")
                have_txt = False
                have_bin = True
                have_zst = False
            elif detected_format == "zst":
                # Файл на самом деле zst, переназначаем пути
                zst_path = txt_path
                txt_path = os.path.join(dirpath, f"{base_name}.txt.tmp")
                have_txt = False
                have_bin = False
                have_zst = True
            else:
                # Файл текстовый
                have_txt = True
                have_bin = _is_regular_file(bin_path)
                have_zst = _is_regular_file(zst_path)
        else:
            # Стандартное поведение
            have_txt = _is_regular_file(txt_path)
            have_bin = _is_regular_file(bin_path)
            have_zst = _is_regular_file(zst_path)
        
        txt_mtime = os.path.getmtime(txt_path) if have_txt and _is_regular_file(txt_path) else None
        zst_mtime = os.path.getmtime(zst_path) if have_zst and _is_regular_file(zst_path) else None
        created_new_bin = False

        original_auto: Optional[Dict] = None
        original_user: Optional[Dict] = None
        if have_bin:
            try:
                existing_meta = read_meta_from_bin(bin_path) or {}
                if isinstance(existing_meta.get("auto"), dict):
                    original_auto = copy.deepcopy(existing_meta.get("auto"))
                if isinstance(existing_meta.get("user"), dict):
                    original_user = copy.deepcopy(existing_meta.get("user"))
            except Exception:
                pass
        elif have_zst:
            try:
                existing_meta = read_meta_from_zst(zst_path) or {}
                if isinstance(existing_meta.get("auto"), dict):
                    original_auto = copy.deepcopy(existing_meta.get("auto"))
                if isinstance(existing_meta.get("user"), dict):
                    original_user = copy.deepcopy(existing_meta.get("user"))
            except Exception:
                pass
        if (original_auto is None or original_user is None) and _is_regular_file(info_path):
            info_auto, info_user = _read_auto_user_from_info(info_path)
            if original_auto is None and info_auto:
                original_auto = info_auto
            if original_user is None and info_user:
                original_user = info_user

        if original_auto is not None:
            auto_patch = None

        if have_txt:
            # Check if FCIDUMP is actually already a v5 binary file
            is_already_binary = False
            try:
                with open(txt_path, "rb") as f:
                    magic = f.read(4)
                    if magic == _FCIDUMP_MAGIC:
                        # It's already a v5 binary file, just rename it
                        is_already_binary = True
            except Exception:
                pass
            
            if is_already_binary:
                # File is already binary, just rename it to .bin
                try:
                    ok, vmsg = verify_b3_of_bin(txt_path)
                    if not ok:
                        raise RuntimeError(vmsg)
                    os.rename(txt_path, bin_path)
                    have_txt = False
                    have_bin = True
                    if have_zst:
                        _safe_remove(zst_path)
                        have_zst = False
                    created_new_bin = True
                    if original_auto is None:
                        try:
                            ts_src = int(txt_mtime) if txt_mtime is not None else int(time.time())
                            iso = datetime.fromtimestamp(ts_src, tz=timezone.utc).isoformat(timespec="seconds")
                            if iso.endswith("+00:00"):
                                iso = iso[:-6] + "Z"
                            _update_auto_meta(bin_path, {"created_utc": ts_src, "created_iso": iso})
                        except Exception:
                            pass
                except Exception as exc:
                    _safe_remove(bin_path)
                    return dirpath, 0, False, f"binary rename failed: {exc}"
            else:
                # It's a text file, encode it normally
                try:
                    meta_payload = copy.deepcopy(extra_meta) if extra_meta is not None else None
                    _nrec, _meta = text_to_bin_compact_stream(
                        txt_path,
                        bin_path,
                        user_meta=meta_payload,
                    )
                    ok, vmsg = verify_b3_of_bin(bin_path)
                    if not ok:
                        raise RuntimeError(vmsg)
                    s_txt = _size(txt_path)
                    s_bin = _size(bin_path)
                    _safe_remove(txt_path)
                    saved += max(0, s_txt - s_bin)
                    have_txt = False
                    have_bin = True
                    if have_zst:
                        _safe_remove(zst_path)
                        have_zst = False
                    created_new_bin = True
                    if original_auto is None:
                        try:
                            ts_src = int(txt_mtime) if txt_mtime is not None else int(time.time())
                            iso = datetime.fromtimestamp(ts_src, tz=timezone.utc).isoformat(timespec="seconds")
                            if iso.endswith("+00:00"):
                                iso = iso[:-6] + "Z"
                            _update_auto_meta(bin_path, {"created_utc": ts_src, "created_iso": iso})
                        except Exception:
                            pass
                except Exception as exc:
                    _safe_remove(bin_path)
                    return dirpath, 0, False, f"encode failed: {exc}"

        if have_zst and (extra_meta or auto_patch or compress != "zstd") and not have_bin:
            tmp_bin = os.path.join(dirpath, ".FCIDUMP.tmp.bin")
            try:
                _zstd_decompress_file(zst_path, tmp_bin, threads=zstd_threads_res)
                ok, vmsg = verify_b3_of_bin(tmp_bin)
                if not ok:
                    raise RuntimeError(vmsg)
                os.replace(tmp_bin, bin_path)
                _safe_remove(zst_path)
                have_bin = True
                have_zst = False
                created_new_bin = True
                if original_auto is None:
                    try:
                        ts_src = int(zst_mtime) if zst_mtime is not None else int(time.time())
                        iso = datetime.fromtimestamp(ts_src, tz=timezone.utc).isoformat(timespec="seconds")
                        if iso.endswith("+00:00"):
                            iso = iso[:-6] + "Z"
                        _update_auto_meta(bin_path, {"created_utc": ts_src, "created_iso": iso})
                    except Exception:
                        pass
            except Exception as exc:
                _safe_remove(tmp_bin)
                return dirpath, 0, False, f"zst decode error: {exc}"

        if have_bin:
            if created_new_bin:
                if original_auto:
                    _restore_auto_meta(bin_path, original_auto)
                else:
                    # set created_* from source file mtime if absent
                    try:
                        src = txt_path if _is_regular_file(txt_path) else (zst_path if _is_regular_file(zst_path) else bin_path)
                        ts_src = int(os.path.getmtime(src))
                        iso = datetime.fromtimestamp(ts_src, tz=timezone.utc).isoformat(timespec="seconds")
                        if iso.endswith("+00:00"):
                            iso = iso[:-6] + "Z"
                        _update_auto_meta(bin_path, {"created_utc": ts_src, "created_iso": iso})
                    except Exception:
                        pass
                if original_user:
                    _update_bin_user_meta(bin_path, original_user)
            else:
                # preserve existing auto; if missing, derive from file mtime
                if original_auto is None:
                    try:
                        src = bin_path
                        ts_src = int(os.path.getmtime(src))
                        iso = datetime.fromtimestamp(ts_src, tz=timezone.utc).isoformat(timespec="seconds")
                        if iso.endswith("+00:00"):
                            iso = iso[:-6] + "Z"
                        _update_auto_meta(bin_path, {"created_utc": ts_src, "created_iso": iso})
                    except Exception:
                        pass
            if extra_meta:
                _update_bin_user_meta(bin_path, extra_meta)
                extra_meta = None
            _emit_user_info_txt(bin_path, dirpath, fcidump_filename)

        if compress == "zstd":
            if have_bin:
                if not _HAVE_ZSTD:
                    return dirpath, 0, False, "zstd not available (install libzstd-dev and rebuild)"
                try:
                    _zstd_compress_file(bin_path, zst_path, level=int(zstd_level), threads=zstd_threads_res)
                    ok, _msg = verify_b3_of_bin(bin_path)
                    if not ok:
                        raise RuntimeError("verify BIN failed")
                    b3_bin = _blake3_of_file(bin_path)
                    if blake3_of_decompressed is None:
                        raise RuntimeError("RAM-verify not available")
                    b3_dec = blake3_of_decompressed(zst_path, threads=0)
                    if b3_bin.lower() != b3_dec.lower():
                        raise RuntimeError("post-verify mismatch (BLAKE3)")
                    s_bin = _size(bin_path)
                    s_zst = _size(zst_path)
                    _safe_remove(bin_path)
                    _safe_remove(info_path)
                    saved += max(0, s_bin - s_zst)
                    return dirpath, saved, True, "zstd from bin"
                except Exception as exc:
                    _safe_remove(zst_path)
                    return dirpath, 0, False, f"zstd failed: {exc}"
            if have_zst:
                _safe_remove(info_path)
                return dirpath, saved, True, "noop"
            return dirpath, saved, True, "nothing to encode"

        # compress == "none"
        if have_bin:
            return dirpath, saved, True, "encoded (.bin)"
        if have_zst:
            return dirpath, saved, True, "noop"
        return dirpath, 0, False, "nothing to encode"


def compress_project_dir(
    *,
    dirpath: str,
    tag: str,
    fc_workers: Optional[int] = None,
    xz_threads: Optional[int] = None,
    description: Optional[str] = "text→bin ensured",
    include_patterns: Optional[Iterable[str]] = None,
    include_keywords: Optional[Iterable[str]] = None,
    comment: Optional[str] = None,
    user_meta: Optional[Dict] = None,
    xz_memlimit_percent: Optional[int] = None,
    xz_block_size: Optional[int] = None,
    with_fcidump: bool = True,
    fcidump_filename: Optional[str] = None,
) -> Tuple[str, int, bool, str]:
    """Упаковать каталог в project_archive_{tag}.tar.xz."""
    dirpath = os.path.abspath(dirpath or ".")

    # предварительная бинаризация/сжатие FCIDUMP, если требуется
    if with_fcidump:
        _, _, ok, msg = compress_fcidump_dir(
            dirpath=dirpath,
            tag=tag,
            compress="zstd",
            zstd_level=1,
            zstd_threads=None,
            fc_workers=fc_workers,
            user_meta=user_meta,
            fcidump_filename=fcidump_filename,
        )
        if not ok and str(msg).strip().lower() != "nothing to encode":
            return dirpath, 0, False, f"pre-encode failed: {msg}"

    files = _list_dir_only(
        dirpath,
        include_patterns,
        include_keywords,
        with_fcidump=with_fcidump,
    )
    if not files:
        return dirpath, 0, False, "nothing to archive"

    base_prefix = f"project_archive_{tag}"
    existing_archives: List[str] = []
    for path in glob.glob(os.path.join(dirpath, f"{base_prefix}*.tar.xz")):
        name = os.path.basename(path)
        if not name.startswith(base_prefix) or not name.endswith(".tar.xz"):
            continue
        suffix = name[len(base_prefix):-len(".tar.xz")]
        if suffix and not re.fullmatch(r"_\d+", suffix):
            continue
        existing_archives.append(path)
    existing_archives.sort(key=os.path.getmtime)
    
    # Определяем приоритет файлов FCIDUMP (с учетом custom filename)
    if fcidump_filename:
        fc_priority = [
            f"{fcidump_filename}.bin.zst",
            f"{fcidump_filename}.bin",
            fcidump_filename,
        ]
        fc_bases = set(fc_priority) | {f"{fcidump_filename}_info.txt", "FCIDUMP_info.txt"}
    else:
        fc_priority = ["FCIDUMP.bin.zst", "FCIDUMP.bin", "FCIDUMP"]
        fc_bases = set(fc_priority) | {"FCIDUMP_info.txt"}
    
    payload_bases = {os.path.basename(p) for p in files}
    only_fc_payload = bool(payload_bases) and all(base in fc_bases for base in payload_bases)

    if only_fc_payload and existing_archives:
        variants = {os.path.basename(p): p for p in files if os.path.basename(p) in fc_priority}
        if len(variants) > 1:
            print(f"[info] compress_all: multiple FCIDUMP variants detected {list(variants.keys())}, preferring highest priority")
        selected_path: Optional[str] = None
        selected_name: Optional[str] = None
        for name in fc_priority:
            path = variants.get(name)
            if path:
                selected_name = name
                selected_path = path
                break
        if selected_path is None:
            print("[info] compress_all: FCIDUMP variants present but none selected (unexpected)")
            files = []
        else:
            target_arch = max(existing_archives, key=os.path.getmtime)
            outer_meta, _, _ = read_archive_meta_brief(target_arch)
            files_meta = outer_meta.get("files") if isinstance(outer_meta, dict) else None
            expected_entry = files_meta.get(selected_name) if isinstance(files_meta, dict) else None
            expected_name = selected_name
            if isinstance(files_meta, dict):
                if not isinstance(expected_entry, dict) or _FCIDUMP_HASH_KEY not in expected_entry:
                    for alt_name in fc_priority:
                        alt_entry = files_meta.get(alt_name)
                        if isinstance(alt_entry, dict) and alt_entry.get(_FCIDUMP_HASH_KEY):
                            expected_entry = alt_entry
                            expected_name = alt_name
                            break
            try:
                current_hash = hash_fcidump(
                    selected_path,
                    sig_digits=_FCIDUMP_SIG_DIGITS,
                    ulp_guard=_FCIDUMP_ULP_GUARD,
                )
            except Exception as exc:
                print(f"[warn] compress_all: unable to hash {selected_name}: {exc}")
                return dirpath, 0, True, "FCIDUMP kept on disk (hash mismatch)"
            current_hash_norm = current_hash.lower()

            expected_hash_meta = None
            if isinstance(expected_entry, dict):
                raw_hash = expected_entry.get(_FCIDUMP_HASH_KEY)
                if raw_hash:
                    expected_hash_meta = str(raw_hash).lower()

            archive_hash = _hash_fcidump_from_archive(
                target_arch,
                expected_name,
                sig_digits=_FCIDUMP_SIG_DIGITS,
                ulp_guard=_FCIDUMP_ULP_GUARD,
            )
            archive_hash_norm = archive_hash.lower() if archive_hash else None

            if archive_hash_norm is None and isinstance(files_meta, dict):
                for alt_name in fc_priority:
                    entry = files_meta.get(alt_name)
                    if isinstance(entry, dict) and entry.get(_FCIDUMP_HASH_KEY):
                        archive_hash = _hash_fcidump_from_archive(
                            target_arch,
                            alt_name,
                            sig_digits=_FCIDUMP_SIG_DIGITS,
                            ulp_guard=_FCIDUMP_ULP_GUARD,
                        )
                        if archive_hash:
                            archive_hash_norm = archive_hash.lower()
                            expected_name = alt_name
                        break

            if archive_hash_norm is not None:
                if archive_hash_norm != current_hash_norm:
                    print(f"[warn] compress_all: FCIDUMP {selected_name} hash mismatch or absent in archive, leaving on disk")
                    return dirpath, 0, True, "FCIDUMP kept on disk (hash mismatch)"
            else:
                if expected_hash_meta and expected_hash_meta == current_hash_norm:
                    pass
                elif not _archive_has_fcidump(target_arch):
                    print(f"[info] compress_all: FCIDUMP payload absent in archive, updating metadata")
                else:
                    print(f"[warn] compress_all: FCIDUMP {selected_name} hash mismatch or absent in archive, leaving on disk")
                    return dirpath, 0, True, "FCIDUMP kept on disk (hash mismatch)"

            success, saved = _append_files_to_archive(target_arch, [selected_path])
            if not success:
                return dirpath, 0, False, "failed to append FCIDUMP"
            _safe_remove(selected_path)
            _cleanup_fcidump_artifacts(dirpath)
            return dirpath, saved, True, f"FCIDUMP appended to {os.path.basename(target_arch)}"

    archive_filename = _next_archive_filename(dirpath, tag, existing_archives)
    arch_path = os.path.join(dirpath, archive_filename)
    archive_name_for_write = _archive_name_from_path(arch_path)
    if _is_regular_file(arch_path):
        _safe_remove(arch_path)

    meta_tmp = None
    if only_fc_payload:
        # keep only highest-priority variant
        for name in fc_priority:
            candidate = os.path.join(dirpath, name)
            if _is_regular_file(candidate):
                files = [candidate]
                break
    files_for_archive = list(files)
    try:
        meta_tmp = os.path.join(dirpath, _ARCHIVE_META_NAME)
        payload: Dict[str, object] = {
            "signature": _ARCHIVE_SIGNATURE,
            "tag": tag,
            "created_utc": int(time.time()),
            "with_fcidump": bool(with_fcidump),
        }
        if comment:
            payload["comment"] = comment

        # attach per-file hashes at the end
        files_meta: Dict[str, Dict[str, str]] = {}
        for p in files:
            base = os.path.basename(p)
            try:
                entry: Dict[str, str] = {}
                if base in _FCIDUMP_DATA_BASENAMES:
                    entry[_FCIDUMP_HASH_KEY] = hash_fcidump(
                        p,
                        sig_digits=_FCIDUMP_SIG_DIGITS,
                        ulp_guard=_FCIDUMP_ULP_GUARD,
                    )
                else:
                    entry["b3"] = _blake3_of_file(p)
                if entry:
                    files_meta[base] = entry
            except Exception:
                continue
        if files_meta:
            payload["files"] = files_meta

        with open(meta_tmp, "w", encoding="utf-8") as mf:
            json.dump(payload, mf, ensure_ascii=False, indent=2)
        files_for_archive.append(meta_tmp)

        total_src = sum((_size(p) for p in files_for_archive), 0)
        try:
            out_path = _write_txz(
                dirpath,
                archive_name_for_write,
                files_for_archive,
                xz_threads=_threads_or_cpu(xz_threads),
                xz_memlimit_percent=xz_memlimit_percent,
                xz_block_size=xz_block_size,
            )
        except Exception as exc:
            return dirpath, 0, False, f"archive failed: {exc}"

        # After creating archive, remove originals
        for p in files_for_archive:
            _safe_remove(p)

        if only_fc_payload:
            _cleanup_fcidump_artifacts(dirpath)

        saved = max(0, total_src - _size(out_path))
        return dirpath, saved, True, f"files={len(files)} archived"
    finally:
        if meta_tmp is not None:
            _safe_remove(meta_tmp)


# ---------------- распаковка архива / только FCIDUMP ----------------
def decompress_project_archive(
    *,
    tar_path: str,
    to_text: bool = True,
    zstd_dthreads: int = 0,
    fc_workers: Optional[int] = None,
    fcidump_filename: Optional[str] = None,
) -> Tuple[str, int, bool, str]:
    """Полная распаковка project_archive_*.tar.xz в тот же каталог.
    
    Args:
        fcidump_filename: If provided, FCIDUMP files will be extracted with this base name.
    """
    if not _is_regular_file(tar_path):
        return os.path.dirname(tar_path) or ".", 0, False, "archive not found"

    outer_meta, _, _ = read_archive_meta_brief(tar_path)
    if not isinstance(outer_meta, dict) or outer_meta.get("signature") != _ARCHIVE_SIGNATURE:
        return os.path.dirname(tar_path) or ".", 0, False, "archive signature mismatch"
    expected_hashes = outer_meta.get("files") if isinstance(outer_meta.get("files"), dict) else {}

    dirpath = os.path.dirname(tar_path) or "."
    
    # Определяем имена файлов с учетом fcidump_filename
    if fcidump_filename:
        binp = os.path.join(dirpath, f"{fcidump_filename}.bin")
        zst = os.path.join(dirpath, f"{fcidump_filename}.bin.zst")
        txt_path = os.path.join(dirpath, fcidump_filename)
    else:
        binp = os.path.join(dirpath, "FCIDUMP.bin")
        zst = os.path.join(dirpath, "FCIDUMP.bin.zst")
        txt_path = os.path.join(dirpath, "FCIDUMP")
    
    info_path = os.path.join(dirpath, "FCIDUMP_info.txt")
    meta_path = os.path.join(dirpath, _ARCHIVE_META_NAME)

    prev_sizes: Dict[str, int] = {}
    for p in (tar_path, binp, zst, txt_path, info_path, meta_path):
        prev_sizes[p] = _size_reg(p)

    try:
        td, files = _extract_txz_to_tmp(tar_path)
    except Exception as exc:
        return dirpath, 0, False, f"extract failed: {exc}"

    try:
        # hash check before moving files
        for src in files:
            base = os.path.basename(src)
            entry = expected_hashes.get(base) if isinstance(expected_hashes, dict) else None
            if base in _FCIDUMP_DATA_BASENAMES:
                if isinstance(entry, dict):
                    expected_hash = entry.get(_FCIDUMP_HASH_KEY)
                    if expected_hash:
                        actual_hash = hash_fcidump(
                            src,
                            sig_digits=_FCIDUMP_SIG_DIGITS,
                            ulp_guard=_FCIDUMP_ULP_GUARD,
                        )
                        if not actual_hash or actual_hash.lower() != str(expected_hash).lower():
                            raise RuntimeError(f"hash mismatch for {base}")
                continue
            if isinstance(entry, dict):
                expected_b3 = entry.get("b3")
                if expected_b3:
                    actual_b3 = _blake3_of_file(src)
                    if actual_b3.lower() != str(expected_b3).lower():
                        raise RuntimeError(f"hash mismatch for {base}")

        for src in files:
            base = os.path.basename(src)
            
            # Если указан fcidump_filename, переименовываем FCIDUMP файлы
            if fcidump_filename and base in ("FCIDUMP.bin", "FCIDUMP.bin.zst", "FCIDUMP"):
                if base == "FCIDUMP.bin":
                    dst = os.path.join(dirpath, f"{fcidump_filename}.bin")
                elif base == "FCIDUMP.bin.zst":
                    dst = os.path.join(dirpath, f"{fcidump_filename}.bin.zst")
                elif base == "FCIDUMP":
                    dst = os.path.join(dirpath, fcidump_filename)
                else:
                    dst = os.path.join(dirpath, base)
            else:
                dst = os.path.join(dirpath, base)
            
            prev_sizes.setdefault(dst, _size_reg(dst))
            _safe_remove(dst)
            shutil.move(src, dst)
    except Exception as exc:
        shutil.rmtree(td, ignore_errors=True)
        return dirpath, 0, False, f"integrity check failed: {exc}"
    finally:
        shutil.rmtree(td, ignore_errors=True)

    threads = _threads_or_cpu(zstd_dthreads)
    fc_threads = _threads_or_cpu(fc_workers)

    if to_text:
        if _is_regular_file(zst) and not _is_regular_file(binp):
            tmp_bin = os.path.join(dirpath, ".FCIDUMP.tmp.bin")
            try:
                _zstd_decompress_file(zst, tmp_bin, threads=threads)
                ok, vmsg = verify_b3_of_bin(tmp_bin)
                if not ok:
                    raise RuntimeError(f"verify failed: {vmsg}")
                if fc_threads and fc_threads > 0:
                    os.environ["OMP_NUM_THREADS"] = str(int(fc_threads))
                    os.environ.setdefault("OMP_PROC_BIND", "spread")
                    os.environ.setdefault("OMP_PLACES", "cores")
                bin_to_text_parallel(tmp_bin, txt_path)
                _emit_user_info_txt(tmp_bin, dirpath, fcidump_filename)
                _safe_remove(tmp_bin)
                _safe_remove(zst)
                _safe_remove(binp)
            except Exception as exc:
                _safe_remove(tmp_bin)
                for p in (txt_path, binp, zst):
                    _safe_remove(p)
                return dirpath, 0, False, f"zst decode error: {exc}"

        elif _is_regular_file(binp):
            ok, vmsg = verify_b3_of_bin(binp)
            if not ok:
                _safe_remove(txt_path)
                return dirpath, 0, False, f"verify failed: {vmsg}"
            if fc_threads and fc_threads > 0:
                os.environ["OMP_NUM_THREADS"] = str(int(fc_threads))
                os.environ.setdefault("OMP_PROC_BIND", "spread")
                os.environ.setdefault("OMP_PLACES", "cores")
            try:
                bin_to_text_parallel(binp, txt_path)
            except Exception as exc:
                _safe_remove(txt_path)
                return dirpath, 0, False, f"decode error: {exc}"
            _emit_user_info_txt(binp, dirpath, fcidump_filename)
            _safe_remove(binp)

    if _is_regular_file(meta_path):
        _safe_remove(meta_path)

    _safe_remove(tar_path)

    delta_total = 0
    for path, prev in prev_sizes.items():
        delta_total += _size_reg(path) - prev

    return dirpath, delta_total, True, "extracted"

def decompress_archive_fcidump_only(
    *,
    tar_path: str,
    to_text: bool = True,
    fc_workers: Optional[int] = None,
    remove_archive: bool = True,
    zstd_dthreads: int = 0,
) -> Tuple[str, int, bool, str]:
    """Извлечь FCIDUMP.bin(.zst) из архива и вернуть изменение занимаемого места."""
    if not _is_regular_file(tar_path):
        return os.path.dirname(tar_path) or ".", 0, False, "archive not found"

    outer_meta, inner_meta, _ = read_archive_meta_brief(tar_path)
    if not isinstance(outer_meta, dict) or outer_meta.get("signature") != _ARCHIVE_SIGNATURE:
        return os.path.dirname(tar_path) or ".", 0, False, "archive signature mismatch"
    expected_hashes = outer_meta.get("files") if isinstance(outer_meta.get("files"), dict) else {}

    dirpath = os.path.dirname(tar_path) or "."
    binp = os.path.join(dirpath, "FCIDUMP.bin")
    zst = os.path.join(dirpath, "FCIDUMP.bin.zst")
    txt_path = os.path.join(dirpath, "FCIDUMP")
    info_path = os.path.join(dirpath, "FCIDUMP_info.txt")

    prev_sizes: Dict[str, int] = {}
    for p in (tar_path, binp, zst, txt_path, info_path):
        prev_sizes[p] = _size_reg(p)

    td = tempfile.mkdtemp(prefix=".unpack_fc_", dir=dirpath or ".")
    wanted = {"FCIDUMP.bin", "FCIDUMP.bin.zst"}
    extracted: List[str] = []
    archive_has_other_payload = False
    try:
        with tarfile.open(tar_path, mode="r:xz") as tf:
            for m in tf.getmembers():
                if not m.isreg():
                    continue
                base = os.path.basename(m.name)
                if base in wanted:
                    tf.extract(m, path=td, set_attrs=False, numeric_owner=False)
                    extracted.append(os.path.join(td, m.name))
                elif base in _FCIDUMP_META_BASENAMES:
                    continue
                else:
                    archive_has_other_payload = True
    except Exception as exc:
        shutil.rmtree(td, ignore_errors=True)
        return dirpath, 0, False, f"extract failed: {exc}"

    try:
        for src in extracted:
            base = os.path.basename(src)
            entry = expected_hashes.get(base) if isinstance(expected_hashes, dict) else None
            if base in _FCIDUMP_DATA_BASENAMES:
                if isinstance(entry, dict):
                    expected_hash = entry.get(_FCIDUMP_HASH_KEY)
                    if expected_hash:
                        actual_hash = hash_fcidump(
                            src,
                            sig_digits=_FCIDUMP_SIG_DIGITS,
                            ulp_guard=_FCIDUMP_ULP_GUARD,
                        )
                        if not actual_hash or actual_hash.lower() != str(expected_hash).lower():
                            raise RuntimeError(f"hash mismatch for {base}")
                continue
            if isinstance(entry, dict):
                expected_b3 = entry.get("b3")
                if expected_b3:
                    actual_b3 = _blake3_of_file(src)
                    if actual_b3.lower() != str(expected_b3).lower():
                        raise RuntimeError(f"hash mismatch for {base}")

        for src in extracted:
            base = os.path.basename(src)
            dst = os.path.join(dirpath, base)
            if _is_regular_file(dst):
                print(f"[warn] decompress_fcidump: {base} already exists, skipping")
                continue
            prev_sizes.setdefault(dst, _size_reg(dst))
            _safe_remove(dst)
            shutil.move(src, dst)
            if base in {"FCIDUMP.bin", "FCIDUMP.bin.zst"}:
                prev_sizes[dst] = 0
    except Exception as exc:
        shutil.rmtree(td, ignore_errors=True)
        return dirpath, 0, False, f"integrity check failed: {exc}"
    finally:
        shutil.rmtree(td, ignore_errors=True)

    threads = _threads_or_cpu(zstd_dthreads)
    fc_threads = _threads_or_cpu(fc_workers)

    if to_text:
        if _is_regular_file(zst) and not _is_regular_file(binp):
            tmp_bin = os.path.join(dirpath, ".FCIDUMP.tmp.bin")
            try:
                _zstd_decompress_file(zst, tmp_bin, threads=threads)
                ok, vmsg = verify_b3_of_bin(tmp_bin)
                if not ok:
                    raise RuntimeError(f"verify failed: {vmsg}")
                if fc_threads and fc_threads > 0:
                    os.environ["OMP_NUM_THREADS"] = str(int(fc_threads))
                    os.environ.setdefault("OMP_PROC_BIND", "spread")
                    os.environ.setdefault("OMP_PLACES", "cores")
                bin_to_text_parallel(tmp_bin, txt_path)
                _emit_user_info_txt(tmp_bin, dirpath, fcidump_filename)
                _safe_remove(tmp_bin)
                _safe_remove(zst)
                _safe_remove(binp)
            except Exception as exc:
                _safe_remove(tmp_bin)
                for p in (txt_path, binp, zst):
                    _safe_remove(p)
                return dirpath, 0, False, f"zst decode error: {exc}"

        elif _is_regular_file(binp):
            ok, vmsg = verify_b3_of_bin(binp)
            if not ok:
                _safe_remove(txt_path)
                return dirpath, 0, False, f"verify failed: {vmsg}"
            if fc_threads and fc_threads > 0:
                os.environ["OMP_NUM_THREADS"] = str(int(fc_threads))
                os.environ.setdefault("OMP_PROC_BIND", "spread")
                os.environ.setdefault("OMP_PLACES", "cores")
            try:
                bin_to_text_parallel(binp, txt_path)
            except Exception as exc:
                _safe_remove(txt_path)
                return dirpath, 0, False, f"decode error: {exc}"
            _emit_user_info_txt(binp, dirpath, fcidump_filename)
            _safe_remove(binp)

    if remove_archive:
        if not archive_has_other_payload:
            _safe_remove(tar_path)
        else:
            # rewrite archive without FCIDUMP payload and any info/meta artifacts
            _remove_files_from_archive(
                tar_path,
                [
                    "FCIDUMP.bin",
                    "FCIDUMP.bin.zst",
                    "FCIDUMP_info.txt",
                    "FCIDUMP.bin.zst.meta.json",
                    "FCIDUMP.bin.meta.json",
                ],
            )

    delta_total = 0
    for path, prev in prev_sizes.items():
        delta_total += _size_reg(path) - prev

    return dirpath, delta_total, True, "fcidump extracted"

# ---------------- восстановление из «рассыпанных» .zst/.bin ----------------

def restore_loose_fcidump(
    *,
    dirpath: str,
    to_text: bool = True,
    fc_workers: Optional[int] = None,
    zstd_dthreads: int = 0,
    fcidump_filename: Optional[str] = None,
) -> Tuple[str, int, bool, str]:
    """Восстановить FCIDUMP из локальных FCIDUMP.bin / FCIDUMP.bin.zst в ТЕКУЩЕМ каталоге.
    
    Args:
        fcidump_filename: Optional custom filename (with any extension). If None, uses "FCIDUMP".
                  Format is auto-detected by file signature, not by extension.
    """
    dirpath = os.path.abspath(dirpath or ".")
    
    # Определяем базовое имя файла
    base_name = fcidump_filename if fcidump_filename is not None else "FCIDUMP"
    
    p_txt  = os.path.join(dirpath, base_name)
    p_bin  = os.path.join(dirpath, f"{base_name}.bin" if fcidump_filename else "FCIDUMP.bin")
    p_zst  = os.path.join(dirpath, f"{base_name}.bin.zst" if fcidump_filename else "FCIDUMP.bin.zst")
    
    # Если указан fcidump_filename, проверяем формат по сигнатуре
    if fcidump_filename is not None and _is_regular_file(p_txt):
        detected_format = _detect_fcidump_format(p_txt)
        if detected_format == "bin":
            # Файл на самом деле bin
            p_bin = p_txt
            p_txt = os.path.join(dirpath, f"{base_name}.output")
            has_bin = True
            has_zst = False
        elif detected_format == "zst":
            # Файл на самом деле zst
            p_zst = p_txt
            p_txt = os.path.join(dirpath, f"{base_name}.output")
            has_bin = False
            has_zst = True
        else:
            # Файл уже текстовый, ничего делать не надо
            return dirpath, 0, True, "already text format"
    else:
        has_zst = _is_regular_file(p_zst)
        has_bin = _is_regular_file(p_bin)

    if not has_zst and not has_bin:
        return dirpath, 0, False, "nothing to restore"

    threads = _threads_or_cpu(zstd_dthreads)
    fc_threads = _threads_or_cpu(fc_workers)

    if has_zst:
        if not _HAVE_ZSTD:
            return dirpath, 0, False, "zstd not available (install libzstd-dev and rebuild)"
        tmp_bin = os.path.join(dirpath, ".FCIDUMP.tmp.bin")
        try:
            _zstd_decompress_file(p_zst, tmp_bin, threads=threads)
            ok, vmsg = verify_b3_of_bin(tmp_bin)
            if not ok:
                raise RuntimeError(f"verify failed: {vmsg}")

            if to_text:
                if fc_threads and fc_threads > 0:
                    os.environ["OMP_NUM_THREADS"] = str(int(fc_threads))
                    os.environ.setdefault("OMP_PROC_BIND", "spread")
                    os.environ.setdefault("OMP_PLACES", "cores")
                bin_to_text_parallel(tmp_bin, p_txt)
                _emit_user_info_txt(tmp_bin, dirpath, fcidump_filename)  # Создаём FCIDUMP_info.txt
                s_txt = _size(p_txt); s_zst = _size(p_zst)
                delta = max(0, s_txt - s_zst)
                _safe_remove(tmp_bin); _safe_remove(p_zst)
                _safe_remove(p_bin)
                return dirpath, delta, True, "restored from zst→txt"
            else:
                os.replace(tmp_bin, p_bin)
                s_bin = _size(p_bin); s_zst = _size(p_zst)
                delta = max(0, s_bin - s_zst)
                _safe_remove(p_zst)
                return dirpath, delta, True, "restored from zst→bin"
        except Exception as e:
            _safe_remove(tmp_bin)
            return dirpath, 0, False, f"zst decode error: {e}"

    ok, vmsg = verify_b3_of_bin(p_bin)
    if not ok:
        return dirpath, 0, False, f"verify failed: {vmsg}"
    if to_text:
        try:
            if fc_threads and fc_threads > 0:
                os.environ["OMP_NUM_THREADS"] = str(int(fc_threads))
                os.environ.setdefault("OMP_PROC_BIND", "spread")
                os.environ.setdefault("OMP_PLACES", "cores")
            bin_to_text_parallel(p_bin, p_txt)
            _emit_user_info_txt(p_bin, dirpath, fcidump_filename)  # Создаём FCIDUMP_info.txt
            s_txt = _size(p_txt); s_bin = _size(p_bin)
            delta = max(0, s_txt - s_bin)
            _safe_remove(p_bin)
            return dirpath, delta, True, "restored from bin→txt"
        except Exception as e:
            return dirpath, 0, False, f"decode error: {e}"
    else:
        return dirpath, 0, True, "noop (.bin present)"


# ---------------- метаданные из архива ----------------

def read_meta_from_zst(zst_path: str) -> Optional[Dict]:
    """Прочитать заголовок FCIDUMP.bin из .zst."""
    if not _is_regular_file(zst_path):
        return None
    tmp_dir = tempfile.mkdtemp(prefix=".fc_meta_", dir=os.path.dirname(zst_path) or ".")
    tmp_bin = os.path.join(tmp_dir, "meta_tmp.bin")
    try:
        _zstd_decompress_file(zst_path, tmp_bin, threads=0)
        meta = read_meta_from_bin(tmp_bin) or {}
        sidecar = _read_json_safely(f"{zst_path}.meta.json") or {}
        created = _normalize_int(sidecar.get("created_utc"))
        if created is not None:
            auto = meta.setdefault("auto", {})
            if "created_utc" not in auto:
                auto["created_utc"] = int(created)
        return meta
    except Exception:
        return None
    finally:
        _safe_remove(tmp_bin)
        shutil.rmtree(tmp_dir, ignore_errors=True)



def read_archive_meta_brief(tar_path: str) -> Tuple[Optional[Dict], Optional[Dict], Optional[Dict]]:
    """Вернуть (archive_meta, inner_fcidump_meta, fcidump_sidecar_meta) из project_archive."""
    if not _is_regular_file(tar_path):
        return None, None, None

    outer: Optional[Dict] = None
    inner: Optional[Dict] = None
    sidecar: Optional[Dict] = None

    try:
        with tarfile.open(tar_path, mode="r:xz") as tf:
            meta_member = None
            zst_member = None
            sidecar_member = None

            for m in tf.getmembers():
                if not m.isreg():
                    continue
                base = os.path.basename(m.name)
                if base == _ARCHIVE_META_NAME and meta_member is None:
                    meta_member = m
                elif base == "FCIDUMP.bin.zst" and zst_member is None:
                    zst_member = m
                elif base == "FCIDUMP.bin.zst.meta.json" and sidecar_member is None:
                    sidecar_member = m
                if meta_member and zst_member and sidecar_member:
                    break

            if meta_member is not None:
                try:
                    fh = tf.extractfile(meta_member)
                    if fh is not None:
                        with io.TextIOWrapper(fh, encoding="utf-8") as reader:
                            outer = json.load(reader)
                except Exception:
                    outer = None

            if zst_member is not None:
                td = tempfile.mkdtemp(prefix=".probe_zst_", dir=os.path.dirname(tar_path) or ".")
                try:
                    tf.extract(zst_member, path=td, set_attrs=False, numeric_owner=False)
                    zst_path = os.path.join(td, zst_member.name)
                    inner = read_meta_from_zst(zst_path)
                    if sidecar_member is not None:
                        try:
                            tf.extract(sidecar_member, path=td, set_attrs=False, numeric_owner=False)
                            meta_path = os.path.join(td, sidecar_member.name)
                            sidecar = _read_json_safely(meta_path)
                            created = _normalize_int((sidecar or {}).get("created_utc"))
                            if created is not None and isinstance(inner, dict):
                                auto = inner.setdefault("auto", {})
                                auto.setdefault("created_utc", int(created))
                        except Exception:
                            sidecar = None
                finally:
                    shutil.rmtree(td, ignore_errors=True)
    except Exception:
        pass

    return outer, inner, sidecar
