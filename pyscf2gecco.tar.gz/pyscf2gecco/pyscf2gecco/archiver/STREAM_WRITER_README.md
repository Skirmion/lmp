# FCIDumpTextStreamWriter - Потоковая запись FCIDUMP v5

## Описание проблемы и решение

### Проблема
После создания FCIDUMP файла с помощью `stream_writer.py`, при попытке использовать функции архиватора (например, `decompress_fcidump`) возникала ошибка:
```
ERR encode failed: FCIDUMP header parse error (missing NORB/NELEC/MS2)
```

### Причина
Ошибка возникала из-за того, что:
1. `stream_writer.py` создает валидный бинарный файл в формате v5 (с магической подписью `FCD5`)
2. Если файл называется "FCIDUMP" (без расширения), архиватор думает что это **текстовый** файл
3. Архиватор пытается закодировать его снова, используя `text_to_bin_compact_stream()`
4. Эта функция ожидает текстовый формат с заголовком вида `&FCI NORB=... NELEC=...`, но получает бинарный файл
5. Возникает ошибка парсинга заголовка

### Решение
Проблема была исправлена в `archiver_core.py`. Теперь перед попыткой кодирования файла "FCIDUMP", система проверяет магическую подпись файла. Если файл уже содержит подпись `FCD5` (v5 binary format), он просто переименовывается в "FCIDUMP.bin" без повторного кодирования.

## Использование

### Базовый пример

```python
from stream_writer import FCIDumpTextStreamWriter

# Создаем writer с параметрами FCIDUMP
writer = FCIDumpTextStreamWriter(
    "output.bin",  # или "FCIDUMP", или "FCIDUMP.bin"
    norb=44,
    nelec=12,
    ms2=2,
    orbsym=[1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4],
)

# Добавляем данные порциями (могут быть в любом порядке)
# text_offset - смещение в байтах от начала тела FCIDUMP (после заголовка)
# chunk_bytes - текстовые данные в формате FCIDUMP (значение и 4 индекса)
chunk = b"""  1.234567890  1  0  0  0
  0.987654321  2  0  0  0
"""
writer.write_text_partition(0, chunk)

# Финализируем файл
meta = writer.finalize(user_meta={"author": "user", "comment": "test"})
print(f"Создан файл с {meta['auto']['records']} записями")
```

### Полный цикл с архиватором

```python
from stream_writer import FCIDumpTextStreamWriter
from archiver_core import compress_project_dir, decompress_archive_fcidump_only

# 1. Создаем FCIDUMP
writer = FCIDumpTextStreamWriter(
    "FCIDUMP",  # Можно использовать "FCIDUMP", "FCIDUMP.bin" или другое имя
    norb=4, nelec=2, ms2=0, orbsym=[1,1,2,2],
)
writer.write_text_partition(0, b"  1.23  1  0  0  0\n")
writer.finalize()

# 2. Сжимаем в архив
compress_project_dir(
    dirpath=".",
    tag="my_project",
    with_fcidump=True,
)
# Создается файл: project_archive_my_project.tar.xz

# 3. Распаковываем FCIDUMP из архива
decompress_archive_fcidump_only(
    tar_path="project_archive_my_project.tar.xz",
    to_text=True,  # Получим текстовый FCIDUMP
    remove_archive=False,
)
# Восстанавливается файл: FCIDUMP (текстовый формат)
```

## Совместимость с именами файлов

| Имя файла | Поведение архиватора |
|-----------|---------------------|
| `FCIDUMP` | ✅ Автоматически определяется как v5 binary, корректно обрабатывается |
| `FCIDUMP.bin` | ✅ Сразу распознается как бинарный файл |
| `FCIDUMP.bin.zst` | ✅ Распознается как сжатый бинарный файл |
| `custom_name.bin` | ✅ Работает, но может потребовать явного указания пути |

## Формат файла

Созданный файл имеет формат FCIDUMP v5:

```
[MAGIC 'FCD5' (4 bytes)]
[HDR_LEN uint32]
[HDR_JSON bytes (UTF-8)]
[BODY bytes (compressed blocks)]
```

Где HDR_JSON содержит:
```json
{
  "auto": {
    "version": 5,
    "norb": int,
    "nelec": int,
    "ms2": int,
    "orbsym": [int, ...],
    "records": int,
    "body_len": int,
    "hashes": {"blake3_body_hex": "..."}
  },
  "user": {...}  // ваши метаданные
}
```

## Проверка корректности

После создания файла можно проверить его корректность:

```python
from fcidump_codec import verify_b3_of_bin, read_meta_from_bin

# Проверка хеша
ok, msg = verify_b3_of_bin("FCIDUMP.bin")
print(f"Verification: {ok}, {msg}")

# Чтение метаданных
meta = read_meta_from_bin("FCIDUMP.bin")
print(f"NORB: {meta['auto']['norb']}")
print(f"Records: {meta['auto']['records']}")
print(f"User meta: {meta['user']}")
```

## Известные ограничения

1. Порции данных должны покрывать все байты тела без пропусков
2. Порции не должны перекрываться
3. Финализация вызовет исключение, если есть пропущенные данные
4. Формат v5 не имеет обратной совместимости с v4

## Исправления

**2025-01-11**: Добавлена автоматическая проверка магической подписи в `archiver_core.py::compress_fcidump_dir()`. Теперь файлы, созданные `stream_writer.py` и названные "FCIDUMP", корректно распознаются как v5 binary и не проходят повторное кодирование.
