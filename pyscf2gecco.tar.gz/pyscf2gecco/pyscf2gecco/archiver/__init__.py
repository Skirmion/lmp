"""
archiver - FCIDUMP compression and archiving utilities.

This module provides tools for compressing, archiving, and managing FCIDUMP files
for GECCO quantum chemistry software.
"""

from .gecco_archiver import GeCCoArchiver

__all__ = ["GeCCoArchiver"]
