import math
import unittest

from archiver_core import hash_fcidump


def _fcidump_text(values):
    lines = ["&FCI NORB=1,NELEC=1,MS2=1", "/"]
    for idx, (val, i, j, k, l) in enumerate(values, 1):
        lines.append(f" {val:.17E}   {i}   {j}   {k}   {l}")
    lines.append(" 0.0000000000000000E+00   0   0   0   0")
    return "\n".join(lines) + "\n"


class StableDecimalHashTests(unittest.TestCase):
    def _hash_text(self, values, **kwargs):
        text = _fcidump_text(values)
        return hash_fcidump(text.encode("utf-8"), **kwargs)

    def test_midpoint_triplet(self):
        vals = [
            (0.9999999999999999, 1, 1, 1, 1),
            (1.0, 1, 1, 1, 1),
            (1.0000000000000002, 1, 1, 1, 1),
        ]
        hashes = {self._hash_text([v]) for v in vals}
        self.assertEqual(len(hashes), 1)

    def test_nextafter_half(self):
        base = 0.5
        down = math.nextafter(base, -math.inf)
        h_base = self._hash_text([(base, 1, 1, 1, 1)])
        h_down = self._hash_text([(down, 1, 1, 1, 1)])
        self.assertEqual(h_base, h_down)

    def test_within_guard_ulps(self):
        base_values = [
            (0.123456789012345, 1, 1, 1, 1),
            (-0.987654321098765, 2, 1, 1, 1),
            (math.pi, 1, 2, 3, 4),
        ]
        perturbed = []
        for idx, (val, i, j, k, l) in enumerate(base_values):
            direction = math.inf if (idx % 2 == 0) else -math.inf
            steps = (idx % 2) + 1  # 1 or 2 ULPs
            v = val
            for _ in range(steps):
                v = math.nextafter(v, direction)
            perturbed.append((v, i, j, k, l))

        h_base = self._hash_text(base_values)
        h_perturbed = self._hash_text(perturbed)
        self.assertEqual(h_base, h_perturbed)

    def test_special_values(self):
        pos_zero = self._hash_text([(0.0, 1, 1, 1, 1)])
        neg_zero = self._hash_text([(-0.0, 1, 1, 1, 1)])
        self.assertEqual(pos_zero, neg_zero)

        nan_payloads = [
            (float('nan'), 1, 2, 3, 4),
            (math.copysign(float('nan'), -1.0), 1, 2, 3, 4),
        ]
        hashes = {self._hash_text([v]) for v in nan_payloads}
        self.assertEqual(len(hashes), 1)

        pos_inf_a = self._hash_text([(float('inf'), 1, 1, 1, 1)])
        pos_inf_b = self._hash_text([(float('inf'), 1, 1, 1, 1)])
        neg_inf = self._hash_text([(-float('inf'), 1, 1, 1, 1)])
        self.assertEqual(pos_inf_a, pos_inf_b)
        self.assertNotEqual(pos_inf_a, neg_inf)

    def test_order_invariance(self):
        values = [
            (0.5, 2, 3, 4, 5),
            (0.25, 1, 2, 3, 4),
            (0.125, 5, 4, 3, 2),
        ]
        shuffled = list(reversed(values))
        h1 = self._hash_text(values)
        h2 = self._hash_text(shuffled)
        self.assertEqual(h1, h2)


if __name__ == "__main__":
    unittest.main()
