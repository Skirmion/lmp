import os
import tempfile
import unittest

from fcidump_codec import read_meta_from_bin, text_to_bin_compact_stream

from stream_writer import FCIDumpTextStreamWriter


def _fcidump_text() -> str:
    header = (
        "&FCI NORB= 2,NELEC= 2,MS2= 0,\n"
        " ORBSYM= 1,1,\n /\n"
    )
    body_lines = [
        " 5.0000000000000000E-01   1   1   1   1\n",
        " 2.5000000000000000E-01   1   2   1   2\n",
        "-1.0000000000000000E-01   2   1   2   1\n",
        " 0.0000000000000000E+00   0   0   0   0\n",
    ]
    return header + "".join(body_lines)


class StreamWriterTests(unittest.TestCase):
    def test_matches_reference_encoder(self) -> None:
        text = _fcidump_text()
        body = text.split("/\n", 1)[1]  # body starts after terminator
        body_bytes = body.encode("ascii")
        split = body_bytes.find(b"\n", body_bytes.find(b"\n") + 1) + 1
        chunk_a = body_bytes[:split]
        chunk_b = body_bytes[split:]

        with tempfile.TemporaryDirectory() as td:
            txt_path = os.path.join(td, "FCIDUMP")
            ref_path = os.path.join(td, "FCIDUMP.bin.ref")
            out_path = os.path.join(td, "FCIDUMP.bin")

            with open(txt_path, "w", encoding="ascii") as fh:
                fh.write(text)

            text_to_bin_compact_stream(txt_path, ref_path)

            writer = FCIDumpTextStreamWriter(out_path, norb=2, nelec=2, ms2=0, orbsym=[1, 1])
            writer.write_text_partition(len(chunk_a), chunk_b)  # out of order on purpose
            writer.write_text_partition(0, chunk_a)
            meta = writer.finalize(user_meta={"source": "test"})

            with open(out_path, "rb") as built, open(ref_path, "rb") as ref:
                built.seek(4)  # skip magic
                ref.seek(4)
                built_hdr = int.from_bytes(built.read(4), "little")
                ref_hdr = int.from_bytes(ref.read(4), "little")
                built.read(built_hdr)
                ref.read(ref_hdr)
                self.assertEqual(built.read(), ref.read())

            read_back = read_meta_from_bin(out_path)
            self.assertEqual(meta, read_back)
            self.assertEqual(meta["auto"]["records"], 4)
            self.assertEqual(meta["user"], {"source": "test"})


if __name__ == "__main__":
    unittest.main()
