#!/usr/bin/env python3
"""
Examples of using the archiver system with fcidump_filename parameter.

All examples demonstrate how to work with custom FCIDUMP file names.
"""

# Example 1: Basic compression with custom filename
def example_basic_custom_name():
    """Compress FCIDUMP file with custom name"""
    from pyscf2gecco.archiver import GeCCoArchiver
    
    # Create archiver
    archiver = GeCCoArchiver(archive_name="test", num_workers=1)
    
    # Compress file named "my_data" (not "FCIDUMP")
    archiver.compress_fcidump(
        root=".",
        to_zstd=True,
        fcidump_filename="my_data"  # Custom filename
    )
    # Result: my_data → my_data.bin → my_data.bin.zst
    

# Example 2: Archive project with custom FCIDUMP name
def example_archive_custom_fcidump():
    """Create project archive with custom FCIDUMP filename"""
    from pyscf2gecco.archiver import GeCCoArchiver
    
    archiver = GeCCoArchiver(
        archive_name="my_project",
        patterns=["*.log", "*.out"],
        keywords=["result"],
    )
    
    # Archive project where FCIDUMP is named "integrals"
    archiver.compress_all(
        root="./calculations",
        with_fcidump=True,
        fcidump_filename="integrals",  # Custom FCIDUMP name
        comment="Temperature scan experiment"
    )
    

# Example 3: Decompress specific archive with custom FCIDUMP name
def example_decompress_specific():
    """Decompress a specific archive and restore FCIDUMP with custom name"""
    from pyscf2gecco.archiver import GeCCoArchiver
    
    archiver = GeCCoArchiver(archive_name="my_project")
    
    # Decompress specific archive and restore FCIDUMP as "restored_integrals"
    archiver.decompress_all(
        root="./restore",
        to_text=True,
        archive_path="./calculations/project_archive_my_project.tar.xz",  # Specific archive
        fcidump_filename="restored_integrals"  # New name for restored FCIDUMP
    )
    

# Example 4: Restore only FCIDUMP with custom name
def example_restore_fcidump_only():
    """Restore only FCIDUMP files with custom name"""
    from pyscf2gecco.archiver import GeCCoArchiver
    
    archiver = GeCCoArchiver(archive_name="test")
    
    # Restore only FCIDUMP named "my_integrals"
    archiver.decompress_fcidump(
        root="./data",
        to_text=True,
        fcidump_filename="my_integrals",  # Custom name
        remove_archive=False  # Keep archives
    )
    

# Example 5: Complete workflow with custom names
def example_complete_workflow():
    """Complete workflow: create → compress → archive → decompress"""
    from pyscf2gecco.archiver import GeCCoArchiver
    import os
    
    # Step 1: Compress FCIDUMP with custom name
    print("Step 1: Compressing custom FCIDUMP...")
    archiver1 = GeCCoArchiver(archive_name="workflow", num_workers=2)
    archiver1.compress_fcidump(
        root="./data",
        to_zstd=True,
        fcidump_filename="qc_data"  # Custom name
    )
    
    # Step 2: Archive project
    print("Step 2: Creating project archive...")
    archiver2 = GeCCoArchiver(
        archive_name="workflow",
        patterns=["*.log"],
    )
    archiver2.compress_all(
        root="./data",
        with_fcidump=True,
        fcidump_filename="qc_data",  # Same custom name
        comment="Quantum chemistry calculation"
    )
    
    # Step 3: Later, restore from specific archive
    print("Step 3: Restoring from archive...")
    archive_path = "./data/project_archive_workflow.tar.xz"
    if os.path.exists(archive_path):
        archiver3 = GeCCoArchiver(archive_name="workflow")
        archiver3.decompress_all(
            root="./restore",
            to_text=True,
            archive_path=archive_path,
            fcidump_filename="analysis_data"  # Rename on restore
        )
        print("Restored as 'analysis_data'")
    

# Example 6: Auto-format detection
def example_auto_detection():
    """Demonstrate automatic format detection by file signature"""
    from pyscf2gecco.archiver import GeCCoArchiver
    
    archiver = GeCCoArchiver(archive_name="test")
    
    # File "data" has no extension, but system detects format automatically
    # It could be .txt, .bin, or .bin.zst - format detected by signature:
    # - FCD5 (4 bytes) → .bin format
    # - 0x28B52FFD → .bin.zst format
    # - Text content → .txt format
    
    archiver.compress_fcidump(
        root=".",
        fcidump_filename="data"  # No extension - auto-detected!
    )
    

# Example 7: Using with standard archiver functions
def example_with_core_functions():
    """Use core functions directly with fcidump_filename"""
    from pyscf2gecco.archiver.archiver_core import (
        compress_fcidump_dir,
        compress_project_dir,
        decompress_project_archive,
        restore_loose_fcidump
    )
    
    # Compress FCIDUMP
    dirpath, saved, ok, msg = compress_fcidump_dir(
        dirpath="./work",
        tag="test",
        compress="zstd",
        fcidump_filename="custom_data"  # Custom name
    )
    print(f"Compressed: {msg}, saved {saved} bytes")
    
    # Archive project
    _, _, ok, msg = compress_project_dir(
        dirpath="./work",
        tag="my_proj",
        with_fcidump=True,
        fcidump_filename="custom_data"  # Same custom name
    )
    print(f"Archived: {msg}")
    
    # Restore loose FCIDUMP
    _, delta, ok, msg = restore_loose_fcidump(
        dirpath="./work",
        to_text=True,
        fcidump_filename="custom_data"  # Custom name
    )
    print(f"Restored: {msg}")
    

# Example 8: Metadata and verification
def example_metadata():
    """Show metadata from files with custom names"""
    from pyscf2gecco.archiver import GeCCoArchiver
    
    archiver = GeCCoArchiver(archive_name="project")
    
    # Show metadata for all FCIDUMP files (any name)
    archiver.show_meta(
        root=".",
        show_user=True,
        list_archives=True
    )
    # System automatically finds and shows info for all FCIDUMP files
    # regardless of their names
    

if __name__ == "__main__":
    print("Archiver Examples with fcidump_filename parameter")
    print("=" * 70)
    print("\nAll examples use uniform 'fcidump_filename' parameter:")
    print("  • compress_fcidump(fcidump_filename=...)")
    print("  • compress_all(fcidump_filename=...)")
    print("  • decompress_all(fcidump_filename=..., archive_path=...)")
    print("  • decompress_fcidump(fcidump_filename=...)")
    print("\nRun individual functions to see examples:")
    print("  example_basic_custom_name()")
    print("  example_archive_custom_fcidump()")
    print("  example_decompress_specific()")
    print("  example_restore_fcidump_only()")
    print("  example_complete_workflow()")
    print("  example_auto_detection()")
    print("  example_with_core_functions()")
    print("  example_metadata()")

