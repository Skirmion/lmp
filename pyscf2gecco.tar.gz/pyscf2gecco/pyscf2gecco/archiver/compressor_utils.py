# compressor_utils.py
import os, tarfile, lzma, subprocess, tempfile
from typing import Iterable, Tuple, Dict

def _norm_tarinfo(ti: tarfile.TarInfo) -> tarfile.TarInfo:
    ti.uid = ti.gid = 0
    ti.uname = ti.gname = ""
    ti.mtime = 0
    ti.pax_headers = {}
    return ti

def _snapshot(paths):
    snap = {}
    for p in paths:
        st = os.stat(p, follow_symlinks=False)
        snap[p] = (st.st_ino, st.st_size, getattr(st, "st_mtime_ns", int(st.st_mtime * 1e9)))
    return snap

def _write_tar_stream_strict(pairs, out_fp, snapshot: Dict[str, tuple]) -> int:
    added = 0
    with tarfile.open(fileobj=out_fp, mode="w|") as tf:
        for arcname, real in pairs:
            ino, sz, mt = snapshot[real]
            st1 = os.stat(real, follow_symlinks=False)
            mt1 = getattr(st1, "st_mtime_ns", int(st1.st_mtime * 1e9))
            if (st1.st_ino, st1.st_size, mt1) != (ino, sz, mt):
                raise RuntimeError(f"changed during pack: {real}")
            with open(real, "rb") as f:
                st2 = os.fstat(f.fileno())
                mt2 = getattr(st2, "st_mtime_ns", int(st2.st_mtime * 1e9))
                if (st2.st_ino, st2.st_size, mt2) != (ino, sz, mt):
                    raise RuntimeError(f"changed after open: {real}")
                ti = tf.gettarinfo(real, arcname=arcname)
                if ti is None:
                    raise RuntimeError(f"cannot tarinfo: {real}")
                _norm_tarinfo(ti)
                tf.addfile(ti, f)
                added += 1
    return added

def make_deterministic_txz_strict(
    dst_path: str,
    file_iter,
    *,
    use_external_xz: bool = True,
    xz_threads: int = 0,
    xz_memlimit_percent: int = 97,
    xz_block_size: int = 32 * 1024 * 1024,
) -> int:
    pairs = list(file_iter)
    if not pairs:
        return 0
    srcs = [real for _, real in pairs]
    snap = _snapshot(srcs)
    tmpdir = os.path.dirname(os.path.abspath(dst_path)) or "."
    fd, tmp = tempfile.mkstemp(prefix=".tmp_project_", suffix=".tar.xz", dir=tmpdir)
    os.close(fd)
    try:
        if use_external_xz:
            cmd = [
                "xz",
                f"-T{xz_threads}",
                f"--memlimit-compress={xz_memlimit_percent}%",
                f"--block-size={xz_block_size}",
                "-zc",
            ]
            try:
                with open(tmp, "wb") as fout:
                    p = subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=fout)
                    assert p.stdin is not None
                    try:
                        added = _write_tar_stream_strict(pairs, p.stdin, snap)
                    except Exception:
                        p.stdin.close()
                        p.terminate()
                        p.wait(timeout=5)
                        raise
                    p.stdin.close()
                    rc = p.wait()
                    if rc != 0:
                        raise RuntimeError(f"xz returned {rc}")
            except FileNotFoundError:
                use_external_xz = False
            else:
                os.replace(tmp, dst_path)
                return added
        with lzma.open(tmp, "wb", preset=6) as xzf:
            added = _write_tar_stream_strict(pairs, xzf, snap)
        os.replace(tmp, dst_path)
        return added
    except Exception:
        try: os.remove(tmp)
        except OSError: pass
        raise

# Backward-compat wrapper (старое имя, если ещё где-то импортируется)
def make_deterministic_txz(
    dst_path: str,
    file_iter,
    *,
    use_external_xz: bool = True,
    xz_threads: int = 0,
    xz_memlimit_percent: int = 97,
    xz_block_size: int = 32 * 1024 * 1024,
):
    _ = make_deterministic_txz_strict(
        dst_path, file_iter,
        use_external_xz=use_external_xz,
        xz_threads=xz_threads,
        xz_memlimit_percent=xz_memlimit_percent,
        xz_block_size=xz_block_size,
    )
    return None
