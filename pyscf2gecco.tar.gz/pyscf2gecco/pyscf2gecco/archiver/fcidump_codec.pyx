# fcidump_codec.pyx
# -*- coding: utf-8 -*-
# FCIDUMP v5 (no backward compatibility)
# Значения = float64, индексы = delta-coded signed varint (LEB128+zigzag).
# Кодирование/декодирование блоками с OpenMP. Формат текста: ведущий 0
# у мантиссы (0.dddddE±xx), индексы — поля шириной 4, без лишнего пробела
# перед первым индексом.

from __future__ import annotations
# cython: boundscheck=False, wraparound=False, initializedcheck=False, nonecheck=False, cdivision=True, language_level=3

import os, json, mmap, tempfile, shutil, re
cimport cython
from cython.parallel cimport prange

from libc.stdlib  cimport malloc, free, realloc, strtod, strtol
from libc.string  cimport memcpy
from libc.stdint  cimport uint8_t, uint32_t, int32_t
from libc.stddef  cimport size_t
from libc.stdio   cimport snprintf

from cpython.buffer cimport Py_buffer, PyObject_GetBuffer, PyBuffer_Release, PyBUF_SIMPLE

from blake3 import blake3

# ---- OpenMP ---------------------------------------------------------------
cdef extern from "omp.h":
    void omp_set_num_threads(int) nogil

@cython.cfunc
cdef void _ensure_omp_threads(int workers=0):
    """
    Под GIL читаем переменные окружения и выставляем число потоков в OMP.
    Вызывать ДО 'with nogil'.
    """
    if workers is not None and workers > 0:
        omp_set_num_threads(workers)
        return
    env = os.environ.get("OMP_NUM_THREADS")
    if env:
        try:
            v = int(env)
            if v > 0:
                omp_set_num_threads(v)
        except Exception:
            pass

# ---- константы ------------------------------------------------------------
cdef bytes  MAGIC      = b"FCD5"
cdef int    BLOCK_RECS = 262144

# ---- varint helpers -------------------------------------------------------
@cython.cfunc
@cython.inline
cdef uint32_t _zz_encode(int32_t x) nogil:
    return <uint32_t>((x << 1) ^ (x >> 31))

@cython.cfunc
@cython.inline
cdef int32_t _zz_decode(uint32_t u) nogil:
    return <int32_t>((u >> 1) ^ (-(<int32_t>(u & 1))))

@cython.cfunc
@cython.inline
cdef uint8_t* _enc_uvar(uint8_t* outp, uint32_t u) nogil:
    while u >= 0x80:
        outp[0] = <uint8_t>((u & 0x7F) | 0x80); outp += 1
        u >>= 7
    outp[0] = <uint8_t>u
    return outp + 1

@cython.cfunc
@cython.inline
cdef uint8_t* _enc_svar(uint8_t* outp, int32_t x) nogil:
    return _enc_uvar(outp, _zz_encode(x))

@cython.cfunc
@cython.inline
cdef uint32_t _dec_uvar(const uint8_t* buf, size_t buflen, size_t* pos) nogil:
    cdef size_t i = pos[0]
    cdef uint32_t v = 0
    cdef int shift = 0
    cdef uint8_t b
    while True:
        b = buf[i]; i += 1
        v |= (<uint32_t>(b & 0x7F)) << shift
        if (b & 0x80) == 0:
            break
        shift += 7
    pos[0] = i
    return v

@cython.cfunc
@cython.inline
cdef int32_t _dec_svar(const uint8_t* buf, size_t buflen, size_t* pos) nogil:
    return _zz_decode(_dec_uvar(buf, buflen, pos))

# ---- утилиты --------------------------------------------------------------
@cython.cfunc
@cython.inline
cdef int _is_space(unsigned char c) nogil:
    return c == 32 or (c >= 9 and c <= 13)

@cython.cfunc
cdef int _find_body_off(const uint8_t* data, size_t n) nogil:
    """Найти позицию после '/\\n' (конец шапки)."""
    cdef size_t i = 0
    while i + 1 < n:
        if data[i] == 47 and data[i+1] == 10:  # "/\n"
            return <int>(i + 2)
        i += 1
    return -1

@cython.cfunc
cdef int _collect_lines(const uint8_t* data, size_t n, size_t start_off,
                        size_t** starts_out, size_t** lens_out) nogil:
    """
    Собрать все непустые строки (после трима лидирующих пробелов) —
    вернуть массивы starts/lens. Память под массивы — malloc().
    """
    cdef size_t i = start_off, s, e, p
    cdef size_t cnt = 0
    # pass1 — считаем
    while i < n:
        s = i
        while i < n and data[i] != 10: i += 1
        e = i
        p = s
        while p < e and _is_space(data[p]): p += 1
        if p < e: cnt += 1
        if i < n: i += 1

    if cnt == 0:
        starts_out[0] = <size_t*>0
        lens_out[0]   = <size_t*>0
        return 0

    cdef size_t* starts = <size_t*>malloc(cnt * sizeof(size_t))
    cdef size_t* lens   = <size_t*>malloc(cnt * sizeof(size_t))
    if starts == <size_t*>0 or lens == <size_t*>0:
        if starts != <size_t*>0: free(starts)
        if lens   != <size_t*>0: free(lens)
        return -1

    # pass2 — заполняем
    i = start_off
    cdef size_t idx = 0
    while i < n:
        s = i
        while i < n and data[i] != 10: i += 1
        e = i
        p = s
        while p < e and _is_space(data[p]): p += 1
        if p < e:
            starts[idx] = s
            lens[idx]   = e - s
            idx += 1
        if i < n: i += 1

    starts_out[0] = starts
    lens_out[0]   = lens
    return <int>idx

@cython.cfunc
cdef int _parse_line(const uint8_t* src, size_t len,
                     double* val, int32_t* ii, int32_t* jj, int32_t* kk, int32_t* ll,
                     uint8_t** scratch, size_t* scratch_cap) nogil:
    """
    Копируем строку в NUL-терминированный буфер и парсим:
    <float> <i> <j> <k> <l>
    """
    cdef size_t need = len + 1
    cdef char* p
    cdef char* b
    cdef long t

    if scratch[0] == <uint8_t*>0 or scratch_cap[0] < need:
        if scratch[0] != <uint8_t*>0:
            free(scratch[0])
        scratch[0] = <uint8_t*>malloc(need)
        if scratch[0] == <uint8_t*>0:
            scratch_cap[0] = 0
            return -1
        scratch_cap[0] = need

    memcpy(scratch[0], src, len)
    scratch[0][len] = 0
    p = <char*>scratch[0]

    # float
    while p[0] == 32 or (p[0] >= 9 and p[0] <= 13): p += 1
    val[0] = strtod(p, &b)
    if b == p: return -1
    p = b

    # i
    while p[0] == 32 or (p[0] >= 9 and p[0] <= 13): p += 1
    t = strtol(p, &b, 10)
    if b == p: return -1
    ii[0] = <int32_t>t; p = b

    # j
    while p[0] == 32 or (p[0] >= 9 and p[0] <= 13): p += 1
    t = strtol(p, &b, 10)
    if b == p: return -1
    jj[0] = <int32_t>t; p = b

    # k
    while p[0] == 32 or (p[0] >= 9 and p[0] <= 13): p += 1
    t = strtol(p, &b, 10)
    if b == p: return -1
    kk[0] = <int32_t>t; p = b

    # l
    while p[0] == 32 or (p[0] >= 9 and p[0] <= 13): p += 1
    t = strtol(p, &b, 10)
    if b == p: return -1
    ll[0] = <int32_t>t

    return 0

# ---- форматтеры вывода ----------------------------------------------------
@cython.cfunc
@cython.inline
cdef size_t _write_int4(char* dst, int32_t v) nogil:
    """
    Быстрое форматирование индекса шириной 4, правое выравнивание пробелами.
    Предполагаем v >= 0 и v <= 9999 (как в FCIDUMP).
    """
    cdef int x = <int>v
    if x >= 1000:
        dst[0] = <char>(48 + (x // 1000) % 10)
        dst[1] = <char>(48 + (x // 100)  % 10)
        dst[2] = <char>(48 + (x // 10)   % 10)
        dst[3] = <char>(48 +  x          % 10)
    elif x >= 100:
        dst[0] = ' '
        dst[1] = <char>(48 + (x // 100)  % 10)
        dst[2] = <char>(48 + (x // 10)   % 10)
        dst[3] = <char>(48 +  x          % 10)
    elif x >= 10:
        dst[0] = ' '; dst[1] = ' '
        dst[2] = <char>(48 + (x // 10)   % 10)
        dst[3] = <char>(48 +  x          % 10)
    else:
        dst[0] = ' '; dst[1] = ' '; dst[2] = ' '
        dst[3] = <char>(48 + x)
    return 4

@cython.cfunc
cdef size_t _fmt_val_zeroE(char* dst, double val) nogil:
    """
    Формат: " {sign}0.ddddddddddddddddE±xx" (16 после точки).
    """
    cdef char tmp[64]
    cdef int m = snprintf(tmp, 64, "% .16E", val)
    if m <= 0:
        return <size_t>snprintf(dst, 64, " % .16E", val)

    cdef char signch = tmp[0]
    cdef char first  = tmp[1]
    cdef int i, iE = -1
    for i in range(m):
        if tmp[i] == 'E': iE = i; break
    if iE < 0:
        return <size_t>snprintf(dst, 64, " % .16E", val)

    cdef int dec_len = iE - 3
    if dec_len < 0: dec_len = 0

    cdef bint allzero = (first == '0')
    if allzero:
        for i in range(dec_len):
            if tmp[3 + i] != '0': allzero = False; break

    # экспонента
    cdef int expv = 0
    cdef int j = iE + 2
    while j < m and tmp[j] >= '0' and tmp[j] <= '9':
        expv = expv * 10 + ((<int>tmp[j]) - 48)
        j += 1
    if tmp[iE + 1] == '-': expv = -expv

    cdef int newexp = expv if allzero else (expv + 1)

    # " {sign}0."
    dst[0] = ' '; dst[1] = signch; dst[2] = '0'; dst[3] = '.'; dst[4] = first
    cdef int w = 5
    cdef int need = 15
    cdef int cp = dec_len if dec_len < need else need
    for i in range(cp): dst[w + i] = tmp[3 + i]
    w += cp
    for i in range(need - cp): dst[w + i] = '0'
    w += (need - cp)

    # 'E±xx'
    dst[w] = 'E'; w += 1
    if newexp >= 0:
        dst[w] = '+'; w += 1; j = newexp
    else:
        dst[w] = '-'; w += 1; j = -newexp

    if j >= 100:
        dst[w+0] = <char>(48 + (j // 100) % 10)
        dst[w+1] = <char>(48 + (j // 10)  % 10)
        dst[w+2] = <char>(48 +  j         % 10)
        w += 3
    else:
        dst[w+0] = <char>(48 + (j // 10)  % 10)
        dst[w+1] = <char>(48 +  j         % 10)
        w += 2

    return <size_t>w

@cython.cfunc
cdef size_t _write_line(char* dst, double val, int32_t i, int32_t j, int32_t k, int32_t l) nogil:
    """
    [value_zeroE][i:4][j:4][k:4][l:4]['\n']
    """
    cdef size_t n = _fmt_val_zeroE(dst, val)
    n += _write_int4(&dst[n], i)
    n += _write_int4(&dst[n], j)
    n += _write_int4(&dst[n], k)
    n += _write_int4(&dst[n], l)
    dst[n] = '\n'; n += 1
    return n

# ---- кодирование одного блока --------------------------------------------
@cython.cfunc
cdef int _encode_block(const uint8_t* data, size_t* starts, size_t* lens,
                       size_t i0, size_t i1,
                       uint8_t** out_buf, size_t* out_len) nogil:
    cdef size_t n = i1 - i0
    cdef size_t cap
    cdef uint8_t* buf = <uint8_t*>0
    cdef uint8_t* w
    cdef uint8_t* scratch = <uint8_t*>0
    cdef size_t   scratch_cap = 0

    cdef double  val
    cdef int32_t ii, jj, kk, ll
    cdef uint32_t base_i, base_j, base_k, base_l
    cdef int32_t  pi, pj, pk, pl
    cdef size_t   idx

    if n == 0:
        out_buf[0] = <uint8_t*>0
        out_len[0] = 0
        return 0

    cap = 20 + n * (8 + 4*5)
    buf = <uint8_t*>malloc(cap)
    if buf == <uint8_t*>0:
        return -1
    w = buf

    if _parse_line(data + starts[i0], lens[i0], &val, &ii, &jj, &kk, &ll, &scratch, &scratch_cap) != 0:
        if scratch != <uint8_t*>0: free(scratch)
        free(buf)
        return -1

    base_i = <uint32_t>ii; base_j = <uint32_t>jj; base_k = <uint32_t>kk; base_l = <uint32_t>ll

    # заголовок блока
    w[0] = <uint8_t>(n & 0xFF); w[1] = <uint8_t>((n >> 8) & 0xFF); w[2] = <uint8_t>((n >> 16) & 0xFF); w[3] = <uint8_t>((n >> 24) & 0xFF); w += 4
    w[0] = <uint8_t>(base_i & 0xFF); w[1] = <uint8_t>((base_i >> 8) & 0xFF); w[2] = <uint8_t>((base_i >> 16) & 0xFF); w[3] = <uint8_t>((base_i >> 24) & 0xFF); w += 4
    w[0] = <uint8_t>(base_j & 0xFF); w[1] = <uint8_t>((base_j >> 8) & 0xFF); w[2] = <uint8_t>((base_j >> 16) & 0xFF); w[3] = <uint8_t>((base_j >> 24) & 0xFF); w += 4
    w[0] = <uint8_t>(base_k & 0xFF); w[1] = <uint8_t>((base_k >> 8) & 0xFF); w[2] = <uint8_t>((base_k >> 16) & 0xFF); w[3] = <uint8_t>((base_k >> 24) & 0xFF); w += 4
    w[0] = <uint8_t>(base_l & 0xFF); w[1] = <uint8_t>((base_l >> 8) & 0xFF); w[2] = <uint8_t>((base_l >> 16) & 0xFF); w[3] = <uint8_t>((base_l >> 24) & 0xFF); w += 4

    (<double*>w)[0] = val; w += sizeof(double)
    w = _enc_svar(w, 0); w = _enc_svar(w, 0); w = _enc_svar(w, 0); w = _enc_svar(w, 0)
    pi = ii; pj = jj; pk = kk; pl = ll

    for idx in range(i0 + 1, i1):
        if _parse_line(data + starts[idx], lens[idx], &val, &ii, &jj, &kk, &ll, &scratch, &scratch_cap) != 0:
            if scratch != <uint8_t*>0: free(scratch)
            free(buf)
            return -1
        (<double*>w)[0] = val; w += sizeof(double)
        w = _enc_svar(w, ii - pi)
        w = _enc_svar(w, jj - pj)
        w = _enc_svar(w, kk - pk)
        w = _enc_svar(w, ll - pl)
        pi = ii; pj = jj; pk = kk; pl = ll

    if scratch != <uint8_t*>0: free(scratch)
    out_buf[0] = buf
    out_len[0] = <size_t>(w - buf)
    return 0

# маленький враппер, чтобы не объявлять локальные переменные внутри prange
@cython.cfunc
cdef int _encode_block_by_index(const uint8_t* d, size_t* st, size_t* ln,
                                int bi, int block_recs, int nlines,
                                uint8_t** ob, size_t* ol) nogil:
    cdef size_t s = <size_t>(bi * block_recs)
    cdef size_t e = <size_t>((bi + 1) * block_recs)
    if e > <size_t>nlines: e = <size_t>nlines
    return _encode_block(d, st, ln, s, e, ob, ol)

# ---- Public: text -> bin --------------------------------------------------
@cython.binding(True)
def text_to_bin_compact_stream(str src_txt, str dst_bin, user_meta=None, int block_recs=BLOCK_RECS):
    """
    Кодирование FCIDUMP-текста в v5-бинарь.
    Возвращает (nrecords, meta).
    """
    cdef Py_buffer view
    cdef const uint8_t* data
    cdef size_t n
    cdef int body_off

    # mmap исходный текст
    with open(src_txt, "rb") as f:
        mm = mmap.mmap(f.fileno(), 0, access=mmap.ACCESS_READ)
    if PyObject_GetBuffer(mm, &view, PyBUF_SIMPLE) != 0:
        mm.close()
        raise MemoryError("PyObject_GetBuffer failed")
    data = <const uint8_t*>view.buf
    n    = <size_t>view.len

    with nogil:
        body_off = _find_body_off(data, n)
    if body_off < 0:
        PyBuffer_Release(&view); mm.close()
        raise ValueError("FCIDUMP header parse error (no '/\\n')")

    # шапка ASCII
    mm.seek(0)
    header = mm.read(body_off).decode("ascii", "ignore")

    # парсим NORB/NELEC/MS2/ORBSYM
    mNOR = re.search(r"NORB\s*=\s*([+-]?\d+)", header)
    mELE = re.search(r"NELEC\s*=\s*([+-]?\d+)", header)
    mMS  = re.search(r"MS2\s*=\s*([+-]?\d+)", header)
    if not (mNOR and mELE and mMS):
        PyBuffer_Release(&view); mm.close()
        raise ValueError("FCIDUMP header parse error (missing NORB/NELEC/MS2)")
    norb  = int(mNOR.group(1))
    nelec = int(mELE.group(1))
    ms2   = int(mMS.group(1))

    mSYM = re.search(r"ORBSYM\s*=\s*([0-9,\s]+)", header, re.S)
    orbsym = [int(x) for x in re.findall(r"\d+", mSYM.group(1))] if mSYM else []

    # собираем строки тела
    cdef size_t* starts = <size_t*>0
    cdef size_t* lens   = <size_t*>0
    cdef int nlines
    with nogil:
        nlines = _collect_lines(data, n, <size_t>body_off, &starts, &lens)
    if nlines < 0:
        PyBuffer_Release(&view); mm.close()
        raise MemoryError("collect_lines failed")

    # число блоков
    cdef int block_recs_local = block_recs if block_recs > 0 else BLOCK_RECS
    cdef int nb = (nlines + block_recs_local - 1) // block_recs_local
    if nb <= 0: nb = 0

    # буферы блоков
    cdef uint8_t** blk_bufs = <uint8_t**>malloc((nb if nb>0 else 1) * sizeof(uint8_t*))
    cdef size_t*   blk_lens = <size_t*>  malloc((nb if nb>0 else 1) * sizeof(size_t))
    if blk_bufs == <uint8_t**>0 or blk_lens == <size_t*>0:
        if blk_bufs != <uint8_t**>0: free(blk_bufs)
        if blk_lens != <size_t*>0: free(blk_lens)
        if starts   != <size_t*>0: free(starts)
        if lens     != <size_t*>0: free(lens)
        PyBuffer_Release(&view); mm.close()
        raise MemoryError("alloc blocks meta")
    cdef int b
    for b in range(nb):
        blk_bufs[b] = <uint8_t*>0; blk_lens[b] = 0

    # параллельное кодирование блоков
    _ensure_omp_threads(0)
    with nogil:
        for b in prange(nb, schedule='static'):
            if _encode_block_by_index(data, starts, lens,
                                      b, block_recs_local, nlines,
                                      &blk_bufs[b], &blk_lens[b]) != 0:
                blk_bufs[b] = <uint8_t*>0
                blk_lens[b] = 0

    # проверка, что все блоки ок
    for b in range(nb):
        if blk_bufs[b] == <uint8_t*>0 and blk_lens[b] == 0:
            # освобождение всего и ошибка
            for b in range(nb):
                if blk_bufs[b] != <uint8_t*>0: free(blk_bufs[b])
            free(blk_bufs); free(blk_lens)
            free(starts); free(lens)
            PyBuffer_Release(&view); mm.close()
            raise ValueError("encode failed in a block")

    # считаем blake3 на лету и одновременно пишем тело во временный файл
    tmpdir = tempfile.mkdtemp(prefix=".fcd5_", dir=os.path.dirname(dst_bin) or ".")
    tmp_body = os.path.join(tmpdir, "body.bin")
    h = blake3()

    cdef size_t total_body = 0
    with open(tmp_body, "wb", buffering=1<<20) as bw:
        for b in range(nb):
            if blk_lens[b]:
                bw.write((<uint8_t[:blk_lens[b]]> blk_bufs[b]))
                h.update((<uint8_t[:blk_lens[b]]> blk_bufs[b]))
                total_body += blk_lens[b]

    # число записей
    cdef Py_ssize_t nrec = 0
    cdef uint32_t bn
    for b in range(nb):
        bn = (<uint32_t*>blk_bufs[b])[0]
        nrec += bn

    # освобождаем блоковые буферы и индексы строк
    for b in range(nb):
        if blk_bufs[b] != <uint8_t*>0: free(blk_bufs[b])
    free(blk_bufs); free(blk_lens)
    free(starts); free(lens)
    PyBuffer_Release(&view); mm.close()

    # собираем метаданные
    b3hex = h.hexdigest()
    auto = {
        "version": 5,
        "norb": int(norb), "nelec": int(nelec), "ms2": int(ms2),
        "orbsym": [int(x) for x in orbsym],
        "records": int(nrec),
        "body_len": int(total_body),
        "hashes": {"blake3_body_hex": b3hex},
    }
    meta = {"auto": auto, "user": dict(user_meta or {})}
    hdr_json = json.dumps(meta, ensure_ascii=False, separators=(",", ":")).encode("utf-8")

    # финальная запись
    with open(dst_bin, "wb") as out:
        out.write(MAGIC)
        out.write((len(hdr_json)).to_bytes(4, "little"))
        out.write(hdr_json)
        with open(tmp_body, "rb") as rb:
            for chunk in iter(lambda: rb.read(1<<20), b""):
                out.write(chunk)

    try:
        shutil.rmtree(tmpdir, ignore_errors=True)
    except Exception:
        pass

    return int(nrec), meta

# ---- чтение/проверка меты -------------------------------------------------
@cython.binding(True)
def read_meta_from_bin(str path):
    with open(path, "rb") as f:
        if f.read(4) != MAGIC:
            raise ValueError("Invalid FCIDUMP v5 magic")
        hdr_len = int.from_bytes(f.read(4), "little")
        hdr = f.read(hdr_len)
    return json.loads(hdr.decode("utf-8"))

@cython.binding(True)
def verify_b3_of_bin(str path):
    try:
        with open(path, "rb") as f:
            if f.read(4) != MAGIC:
                return False, "invalid magic"
            hdr_len = int.from_bytes(f.read(4), "little")
            f.seek(4 + 4 + hdr_len, os.SEEK_SET)
            h = blake3()
            for chunk in iter(lambda: f.read(1<<20), b""):
                h.update(chunk)
            got = h.hexdigest()
        meta = read_meta_from_bin(path)
        want = meta.get("auto", {}).get("hashes", {}).get("blake3_body_hex", "")
        return (got == want), (("BLAKE3 OK " + got) if got == want else f"BLAKE3 mismatch: got {got}, want {want}")
    except Exception as e:
        return False, f"verify error: {e}"

# ---- декодирование одного блока в текст -----------------------------------
@cython.cfunc
cdef void _decode_block_to_text(const uint8_t* buf, size_t buflen,
                                size_t blk_off,
                                char** out_buf, size_t* out_len) nogil:
    """
    Декодирует один блок из тела бинаря в freshly-allocated текстовый буфер.
    """
    cdef size_t p = blk_off
    cdef uint32_t n
    cdef uint32_t i0, j0, k0, l0
    cdef int32_t  pi, pj, pk, pl
    cdef double   val
    cdef int32_t  di, dj, dk, dl
    cdef Py_ssize_t r
    cdef size_t cap, wrote
    cdef char* wbuf
    cdef char* wp

    n  = (<uint32_t*>(<const uint8_t*>buf + p))[0]; p += 4
    i0 = (<uint32_t*>(<const uint8_t*>buf + p))[0]; p += 4
    j0 = (<uint32_t*>(<const uint8_t*>buf + p))[0]; p += 4
    k0 = (<uint32_t*>(<const uint8_t*>buf + p))[0]; p += 4
    l0 = (<uint32_t*>(<const uint8_t*>buf + p))[0]; p += 4

    cap = <size_t>(n) * 64 + 32
    wbuf = <char*>malloc(cap)
    if wbuf == <char*>0:
        out_buf[0] = <char*>0; out_len[0] = 0
        return
    wp = wbuf

    pi = <int32_t>i0; pj = <int32_t>j0; pk = <int32_t>k0; pl = <int32_t>l0
    for r in range(n):
        val = (<double*>(<const uint8_t*>buf + p))[0]; p += sizeof(double)
        di = _dec_svar(buf, buflen, &p)
        dj = _dec_svar(buf, buflen, &p)
        dk = _dec_svar(buf, buflen, &p)
        dl = _dec_svar(buf, buflen, &p)
        pi += di; pj += dj; pk += dk; pl += dl
        wrote = _write_line(wp, val, pi, pj, pk, pl)
        wp += wrote

    out_buf[0] = wbuf
    out_len[0] = <size_t>(wp - wbuf)

# ---- Public: bin -> text ---------------------------------------------------
@cython.binding(True)
def bin_to_text_parallel(str src_bin, str dst_txt):
    """
    Быстрая распаковка v5 в FCIDUMP-текст с параллельной декодировкой блоков.
    Возвращает число записей (берётся из метаданных).
    """
    # метаданные для шапки
    meta = read_meta_from_bin(src_bin)
    auto = meta.get("auto", {})
    cdef int  norb  = int(auto.get("norb", 0))
    cdef int  nelec = int(auto.get("nelec", 0))
    cdef int  ms2   = int(auto.get("ms2", 0))
    orbsym = list(auto.get("orbsym", []))
    orbsym_csv = ",".join(str(int(x)) for x in orbsym) if orbsym else ""

    # позиция тела
    cdef size_t body_off
    with open(src_bin, "rb") as f:
        if f.read(4) != MAGIC:
            raise ValueError("Invalid FCIDUMP v5 magic")
        hdr_len = int.from_bytes(f.read(4), "little")
        body_off = <size_t>(4 + 4 + hdr_len)

    # mmap всего файла
    with open(src_bin, "rb") as f:
        mm = mmap.mmap(f.fileno(), 0, access=mmap.ACCESS_READ)
    cdef Py_buffer view
    if PyObject_GetBuffer(mm, &view, PyBUF_SIMPLE) != 0:
        mm.close()
        raise MemoryError("PyObject_GetBuffer failed")
    cdef const uint8_t* buf = <const uint8_t*>view.buf
    cdef size_t buflen = <size_t>view.len

    # предварительный проход: собрать смещения блоков
    cdef size_t pos = body_off
    cdef size_t cap_blk = 1024
    cdef size_t* blk_offs = <size_t*>malloc(cap_blk * sizeof(size_t))
    if blk_offs == <size_t*>0:
        PyBuffer_Release(&view); mm.close()
        raise MemoryError("alloc blk_offs")

    cdef size_t nblk = 0
    cdef uint32_t nrec_loc
    cdef size_t p
    cdef uint32_t i0, j0, k0, l0
    cdef double dummy_val
    cdef size_t newcap
    cdef int r
    while pos + 20 <= buflen:
        if nblk == cap_blk:
            newcap = cap_blk * 2
            blk_offs = <size_t*>realloc(blk_offs, newcap * sizeof(size_t))
            if blk_offs == <size_t*>0:
                PyBuffer_Release(&view); mm.close()
                raise MemoryError("realloc blk_offs")
            cap_blk = newcap
        blk_offs[nblk] = pos
        nblk += 1

        # прочитать заголовок блока
        nrec_loc = (<uint32_t*>(<const uint8_t*>buf + pos))[0]; pos += 4
        i0 = (<uint32_t*>(<const uint8_t*>buf + pos))[0]; pos += 4
        j0 = (<uint32_t*>(<const uint8_t*>buf + pos))[0]; pos += 4
        k0 = (<uint32_t*>(<const uint8_t*>buf + pos))[0]; pos += 4
        l0 = (<uint32_t*>(<const uint8_t*>buf + pos))[0]; pos += 4

        # пропускаем записи (double + 4 varint)
        p = pos
        for r in range(nrec_loc):
            dummy_val = (<double*>(<const uint8_t*>buf + p))[0]; p += sizeof(double)
            _dec_uvar(buf, buflen, &p)
            _dec_uvar(buf, buflen, &p)
            _dec_uvar(buf, buflen, &p)
            _dec_uvar(buf, buflen, &p)
        pos = p

    # готовим выходные буферы на блок
    cdef char** out_bufs = <char**>malloc((nblk if nblk>0 else 1) * sizeof(char*))
    cdef size_t* out_lens = <size_t*>malloc((nblk if nblk>0 else 1) * sizeof(size_t))
    if out_bufs == <char**>0 or out_lens == <size_t*>0:
        if out_bufs != <char**>0: free(out_bufs)
        if out_lens != <size_t*>0: free(out_lens)
        free(blk_offs)
        PyBuffer_Release(&view); mm.close()
        raise MemoryError("alloc out arrays")
    cdef size_t i
    for i in range(nblk):
        out_bufs[i] = <char*>0; out_lens[i] = 0

    # параллельная декодировка по блокам
    _ensure_omp_threads(0)
    with nogil:
        for i in prange(nblk, schedule='static'):
            _decode_block_to_text(buf, buflen, blk_offs[i], &out_bufs[i], &out_lens[i])

    # шапка FCIDUMP
    header1 = f" &FCI NORB= {norb},NELEC= {nelec},MS2= {ms2},\n".encode("ascii")
    header2 = f"  ORBSYM={orbsym_csv},\n  ISYM=1,\n /\n".encode("ascii")

    # запись файла
    cdef Py_ssize_t total = 0
    with open(dst_txt, "wb", buffering=1<<20) as out:
        out.write(header1); out.write(header2)
        for i in range(nblk):
            if out_lens[i]:
                out.write((<char[:out_lens[i]]> out_bufs[i]))
                total += 1
            if out_bufs[i] != <char*>0: free(out_bufs[i])

    free(out_bufs); free(out_lens)
    free(blk_offs)
    PyBuffer_Release(&view); mm.close()

    return int(meta.get("auto", {}).get("records", -1))
