# setup.py
# -*- coding: utf-8 -*-
from __future__ import annotations

import os
import sys
import platform
from setuptools import setup, Extension
from Cython.Build import cythonize

PLAT = sys.platform
MACHINE = platform.machine().lower()

def is_windows():
    return PLAT.startswith("win")

def is_macos():
    return PLAT == "darwin"

def is_linux():
    return PLAT.startswith("linux")

# -------- общие флаги компиляции ----------
common_macros = [
    ("NDEBUG", None),
]
common_cflags = [
    "-O3",
    "-fno-strict-aliasing",
    "-fvisibility=hidden",
]
common_ldflags = []

# OpenMP для разных платформ
omp_cflags = []
omp_ldflags = []
if is_windows():
    # MSVC
    omp_cflags += ["/openmp"]
    # для MSVC отдельные ldflags обычно не нужны
elif is_macos():
    # Clang на macOS: требуется libomp из brew (brew install libomp)
    omp_cflags += ["-Xpreprocessor", "-fopenmp"]
    omp_ldflags += ["-lomp"]
else:
    # GCC/Clang на Linux
    omp_cflags += ["-fopenmp"]
    omp_ldflags += ["-fopenmp"]

# zstd: нужна системная libzstd (sudo apt install libzstd-dev на Debian/Ubuntu)
zstd_include_dirs = []
zstd_libs = ["zstd"]
zstd_extra_cflags = []
zstd_extra_ldflags = []
if is_linux():
    zstd_extra_ldflags += ["-pthread"]

# -------- расширения --------
exts = []

# FCIDUMP кодек — обязательно с OpenMP
exts.append(
    Extension(
        name="fcidump_codec",
        sources=["fcidump_codec.pyx"],
        define_macros=common_macros,
        extra_compile_args=common_cflags + omp_cflags,
        extra_link_args=common_ldflags + omp_ldflags,
        include_dirs=[],
        libraries=[],
    )
)

# Zstd кодек — линковка с libzstd (+ pthread на Linux)
exts.append(
    Extension(
        name="zstd_codec",
        sources=["zstd_codec.pyx"],
        define_macros=common_macros,
        extra_compile_args=common_cflags + zstd_extra_cflags,
        extra_link_args=common_ldflags + zstd_extra_ldflags,
        include_dirs=zstd_include_dirs,
        libraries=zstd_libs,
    )
)

# Если у тебя остаётся ctoken_codec.pyx – он тоже может выиграть от OpenMP.
if os.path.exists("ctoken_codec.pyx"):
    exts.append(
        Extension(
            name="ctoken_codec",
            sources=["ctoken_codec.pyx"],
            define_macros=common_macros,
            extra_compile_args=common_cflags + omp_cflags,
            extra_link_args=common_ldflags + omp_ldflags,
            include_dirs=[],
            libraries=[],
        )
    )

setup(
    name="gecco-archiver",
    version="0.1.0",
    ext_modules=cythonize(
        exts,
        language_level="3",
        annotate=False,
        compiler_directives={
            "boundscheck": False,
            "wraparound": False,
            "cdivision": True,
            "initializedcheck": False,
            "nonecheck": False,
        },
    ),
)
