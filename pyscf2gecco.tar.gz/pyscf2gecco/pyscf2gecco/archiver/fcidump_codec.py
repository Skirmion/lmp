# fcidump_codec.py (v5)
# -*- coding: utf-8 -*-
"""
FCIDUMP binary codec — version 5 (no backward compatibility).

Format overview (all little-endian):
  [MAGIC 'FCD5' (4 bytes)]
  [HDR_LEN u32]
  [HDR_JSON bytes of length HDR_LEN, UTF-8]
  [BODY bytes]

HDR_JSON (dict) contains:
  {
    "auto": {
      "version": 5,
      "norb": int, "nelec": int, "ms2": int,
      "orbsym": [int,...],
      "records": int,
      "body_len": int,
      "hashes": {"blake3_body_hex": "..." }
    },
    "user": {...}   # optional passthrough from API
  }

BODY is a sequence of blocks; each block:
  [n u32] [i0 u32] [j0 u32] [k0 u32] [l0 u32]
  then repeated n times:
    [value f64] [Δi varint] [Δj varint] [Δk varint] [Δl varint]
where Δ are signed deltas relative to previous record within the block
(first record has Δ=0, as previous = base indices).

Varint encoding: unsigned LEB128 of zigzag-encoded signed 32-bit value.
"""

from __future__ import annotations

import io
import os
import re
import json
import mmap
import struct
from typing import Tuple, List, Dict, Iterable

try:
    from blake3 import blake3
except Exception as e:
    raise RuntimeError("BLAKE3 module is required for FCIDUMP v5") from e

from ..fc_gen.fmt import _line as fmt_line, _fmt as fmt_number

MAGIC = b"FCD5"
HDR_STRUCT = struct.Struct("<I")
U32 = struct.Struct("<I")
F64 = struct.Struct("<d")

BLOCK_RECS = 65536  # размер блока по записям (под OpenMP распараллеливание в будущем)

# ---------------- varint helpers ----------------

def _zigzag_encode(x: int) -> int:
    return (x << 1) ^ (x >> 31)

def _zigzag_decode(u: int) -> int:
    return (u >> 1) ^ -(u & 1)

def _uleb128_encode(u: int) -> bytes:
    out = bytearray()
    while True:
        b = u & 0x7F
        u >>= 7
        if u:
            out.append(b | 0x80)
        else:
            out.append(b)
            break
    return bytes(out)

def _uleb128_decode_from(buf: memoryview, pos: int) -> Tuple[int, int]:
    v = 0
    shift = 0
    i = pos
    while True:
        b = buf[i]
        i += 1
        v |= (b & 0x7F) << shift
        if (b & 0x80) == 0:
            break
        shift += 7
    return v, i

def _svarint_encode(x: int) -> bytes:
    return _uleb128_encode(_zigzag_encode(int(x)))

def _svarint_decode_from(buf: memoryview, pos: int) -> Tuple[int, int]:
    u, p = _uleb128_decode_from(buf, pos)
    return _zigzag_decode(u), p

# ---------------- text header parsing ----------------

import re
_re_int = re.compile(r"([+-]?\d+)")
_re_orbsym = re.compile(r"ORBSYM\s*=\s*([^,/\n]+)")

def _parse_header_text(mm: mmap.mmap) -> Tuple[int,int,int,List[int], int]:
    """
    Returns norb, nelec, ms2, orbsym_list, body_offset
    """
    mm.seek(0)
    text = mm.read(1<<20)  # первый мегабайт с запасом для заголовка
    s = text.decode("ascii", errors="ignore")

    # конец заголовка по '/', варианты с пробелом тоже встречаются
    end = s.find("\n /\n")
    if end == -1:
        end = s.find("\n/\n")
        if end == -1:
            end = s.find("\n/")
            if end == -1:
                raise ValueError("FCIDUMP header parse error (no terminator '/')")

    header = s[:end]
    ints = _re_int.findall(header)
    if len(ints) < 3:
        raise ValueError("FCIDUMP header parse error (NORB/NELEC/MS2)")
    norb, nelec, ms2 = map(int, ints[:3])

    m = _re_orbsym.search(header)
    if m:
        nums = [int(x.strip()) for x in m.group(1).replace(",", " ").split()]
    else:
        nums = []

    # оффсет тела: по байтовому поиску "/\n"
    mm.seek(0)
    b = mm.read(1<<20)
    pat = b"/\n"
    off = b.find(pat)
    if off == -1:
        raise ValueError("FCIDUMP header parse error (slash bytes)")
    body_off = off + len(pat)
    return norb, nelec, ms2, nums, body_off

# ---------------- text record iterator ----------------

def _iter_records(mm: mmap.mmap, start: int) -> Iterable[Tuple[float,int,int,int,int]]:
    mm.seek(start)
    while True:
        line = mm.readline()
        if not line:
            break
        if not line.strip():
            continue
        # ожидаем: значение, затем 4 индекса
        try:
            parts = line.split()
            if len(parts) < 5:
                continue
            token = parts[0].decode("ascii")
            i = int(parts[-4]); j = int(parts[-3]); k = int(parts[-2]); l = int(parts[-1])
            val = float(token.replace("d", "e").replace("D", "E"))
        except Exception:
            continue
        yield (val, i, j, k, l)

# ---------------- encoder / decoder ----------------

def text_to_bin_compact_stream(src_txt: str, dst_bin: str, user_meta: Dict | None = None, block_recs: int = BLOCK_RECS) -> Tuple[int, Dict]:
    """
    Encode FCIDUMP text file into v5 binary format.
    Returns (records_count, meta_dict)
    """
    user_meta = user_meta or {}
    nrec = 0

    with open(src_txt, "rb") as f:
        mm = mmap.mmap(f.fileno(), 0, access=mmap.ACCESS_READ)
        try:
            norb, nelec, ms2, orbsym, body_off = _parse_header_text(mm)

            # тело пишем во временный файл и одновременно считаем BLAKE3
            import tempfile, shutil
            td = tempfile.mkdtemp(prefix=".v5_", dir=os.path.dirname(dst_bin) or ".")
            tmp_body = os.path.join(td, "body.tmp")
            h = blake3()
            with open(tmp_body, "wb") as bw:
                prev_i = prev_j = prev_k = prev_l = None
                base_i = base_j = base_k = base_l = 0
                count_in_block = 0
                block_buf = bytearray()

                def _flush_block():
                    nonlocal block_buf, count_in_block, base_i, base_j, base_k, base_l
                    if count_in_block == 0:
                        return
                    out = bytearray()
                    out += U32.pack(count_in_block)
                    out += U32.pack(base_i); out += U32.pack(base_j)
                    out += U32.pack(base_k); out += U32.pack(base_l)
                    out += block_buf
                    bw.write(out)
                    h.update(out)
                    block_buf.clear()
                    count_in_block = 0

                for val, i, j, k, l in _iter_records(mm, body_off):
                    if count_in_block == 0:
                        base_i, base_j, base_k, base_l = i, j, k, l
                        prev_i, prev_j, prev_k, prev_l = i, j, k, l
                        # первая запись блока: Δ=0
                        block_buf += F64.pack(float(val))
                        block_buf += _svarint_encode(0)
                        block_buf += _svarint_encode(0)
                        block_buf += _svarint_encode(0)
                        block_buf += _svarint_encode(0)
                        count_in_block = 1
                        nrec += 1
                        continue

                    di = i - prev_i; dj = j - prev_j; dk = k - prev_k; dl = l - prev_l
                    block_buf += F64.pack(float(val))
                    block_buf += _svarint_encode(di)
                    block_buf += _svarint_encode(dj)
                    block_buf += _svarint_encode(dk)
                    block_buf += _svarint_encode(dl)
                    prev_i, prev_j, prev_k, prev_l = i, j, k, l
                    count_in_block += 1
                    nrec += 1

                    if count_in_block >= block_recs:
                        _flush_block()

                _flush_block()

            body_len = os.path.getsize(tmp_body)
            b3 = h.hexdigest()

            auto = {
                "version": 5,
                "norb": norb, "nelec": nelec, "ms2": ms2,
                "orbsym": orbsym,
                "records": nrec,
                "body_len": body_len,
                "hashes": {"blake3_body_hex": b3},
            }
            meta = {"auto": auto, "user": user_meta}

            hdr_json = json.dumps(meta, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
            with open(dst_bin, "wb") as out:
                out.write(MAGIC)
                out.write(HDR_STRUCT.pack(len(hdr_json)))
                out.write(hdr_json)
                with open(tmp_body, "rb") as rb:
                    for chunk in iter(lambda: rb.read(1<<20), b""):
                        out.write(chunk)

            try:
                shutil.rmtree(td, ignore_errors=True)
            except Exception:
                pass

            return nrec, meta
        finally:
            mm.close()

def _read_header_and_body_offset(fp: io.BufferedReader) -> Tuple[Dict, int]:
    head = fp.read(4)
    if head != MAGIC:
        raise ValueError("Invalid FCIDUMP v5 magic")
    hdr_len_bytes = fp.read(4)
    if len(hdr_len_bytes) != 4:
        raise ValueError("Corrupt header")
    (hdr_len,) = HDR_STRUCT.unpack(hdr_len_bytes)
    hdr = fp.read(hdr_len)
    if len(hdr) != hdr_len:
        raise ValueError("Short header")
    meta = json.loads(hdr.decode("utf-8"))
    body_off = 4 + 4 + hdr_len
    return meta, body_off

def read_meta_from_bin(path: str) -> Dict:
    with open(path, "rb") as f:
        meta, _ = _read_header_and_body_offset(f)
    return meta

def bin_to_text_parallel(src_bin: str, dst_txt: str) -> int:
    """
    Decode v5 binary into canonical text (width/format handled by fmt.py)
    Returns number of records written.
    """
    with open(src_bin, "rb") as f:
        meta, body_off = _read_header_and_body_offset(f)
        total = 0
        mm = mmap.mmap(f.fileno(), 0, access=mmap.ACCESS_READ)
        try:
            buf = memoryview(mm)[body_off:]
            pos = 0
            buflen = len(buf)
            with open(dst_txt, "wb") as out:
                while pos < buflen:
                    if buflen - pos < 20:
                        break
                    n, = U32.unpack_from(buf, pos); pos += 4
                    i0, = U32.unpack_from(buf, pos); pos += 4
                    j0, = U32.unpack_from(buf, pos); pos += 4
                    k0, = U32.unpack_from(buf, pos); pos += 4
                    l0, = U32.unpack_from(buf, pos); pos += 4
                    pi, pj, pk, pl = i0, j0, k0, l0
                    for _ in range(n):
                        val, = F64.unpack_from(buf, pos); pos += 8
                        di, pos = _svarint_decode_from(buf, pos)
                        dj, pos = _svarint_decode_from(buf, pos)
                        dk, pos = _svarint_decode_from(buf, pos)
                        dl, pos = _svarint_decode_from(buf, pos)
                        pi += di; pj += dj; pk += dk; pl += dl
                        out.write(fmt_line(val, pi, pj, pk, pl))
                        total += 1
            return total
        finally:
            mm.close()

# --- helper for archiver_core: verify BLAKE3 of BODY ---
def verify_b3_of_bin(path: str) -> Tuple[bool, str]:
    try:
        with open(path, "rb") as f:
            meta, body_off = _read_header_and_body_offset(f)
            h = blake3()
            # читаем ТОЛЬКО тело
            f.seek(body_off, os.SEEK_SET)
            for chunk in iter(lambda: f.read(1<<20), b""):
                h.update(chunk)
            got = h.hexdigest()
            want = meta.get("auto", {}).get("hashes", {}).get("blake3_body_hex", "")
            if got == want:
                return True, f"BLAKE3 OK {got}"
            else:
                return False, f"BLAKE3 mismatch: got {got}, want {want}"
    except Exception as e:
        return False, f"verify error: {e}"
