# Fix Summary: stream_writer.py Integration with Archiver

## Problem

When using `stream_writer.py` to create FCIDUMP files, attempting to use archiver functions like `decompress_fcidump` resulted in an error:

```
ERR encode failed: FCIDUMP header parse error (missing NORB/NELEC/MS2)
```

## Root Cause

The issue occurred because:

1. `stream_writer.py` creates valid v5 binary FCIDUMP files (with `FCD5` magic signature)
2. When the file was named "FCIDUMP" (without extension), the archiver assumed it was a text file
3. `compress_fcidump_dir()` tried to re-encode it using `text_to_bin_compact_stream()`
4. This function expects text format with ASCII header (`&FCI NORB=... NELEC=...`), but received binary v5 format
5. Parser failed looking for text header markers

## Solution

Modified `archiver_core.py` in the `compress_fcidump_dir()` function (lines 1299-1367):

**Before:**
- Directly attempted to encode any file named "FCIDUMP" as text

**After:**
- Added magic signature check before encoding
- If file starts with `b'FCD5'`, it's recognized as v5 binary format
- Binary files are simply renamed to "FCIDUMP.bin" without re-encoding
- Text files continue to be encoded normally

## Changes Made

### File: `archiver_core.py`

```python
# Added check for v5 binary format
if have_txt:
    # Check if FCIDUMP is actually already a v5 binary file
    is_already_binary = False
    try:
        with open(txt_path, "rb") as f:
            magic = f.read(4)
            if magic == _FCIDUMP_MAGIC:  # b'FCD5'
                is_already_binary = True
    except Exception:
        pass
    
    if is_already_binary:
        # File is already binary, just rename it
        # ... validation and rename logic ...
    else:
        # It's a text file, encode it normally
        # ... existing encoding logic ...
```

### File: `stream_writer.py`

Updated documentation to clarify filename compatibility:
- Files can be named "FCIDUMP", "FCIDUMP.bin", or any other name
- All names work seamlessly with the archiver
- Automatic v5 format detection ensures correct handling

## Testing

Comprehensive tests verify:
- ✅ v5 binary files created by stream_writer are detected correctly
- ✅ No double-encoding occurs
- ✅ Full compress/archive/decompress cycle works
- ✅ Data integrity is preserved (BLAKE3 verification)
- ✅ Both "FCIDUMP" and "FCIDUMP.bin" filenames work correctly

## Usage Example

```python
from stream_writer import FCIDumpTextStreamWriter
from archiver_core import compress_project_dir, decompress_archive_fcidump_only

# 1. Create FCIDUMP using stream_writer
writer = FCIDumpTextStreamWriter(
    "FCIDUMP",  # Any name works now!
    norb=44, nelec=12, ms2=2,
    orbsym=[1,1,1,1,2,2,2,2],
)
writer.write_text_partition(0, data_chunk)
writer.finalize(user_meta={"author": "user"})

# 2. Archive it (now works correctly!)
compress_project_dir(
    dirpath=".",
    tag="my_project",
    with_fcidump=True,
)

# 3. Decompress from archive
decompress_archive_fcidump_only(
    tar_path="project_archive_my_project.tar.xz",
    to_text=True,
)
```

## Additional Documentation

- `STREAM_WRITER_README.md` - Complete usage guide
- Updated docstring in `stream_writer.py`

## Date

2025-01-11
