# gecco_archiver.py
# -*- coding: utf-8 -*-
"""
High-level user API: GeCCoArchiver.

- compress_fcidump: бинаризация/сжатие FCIDUMP (с поддержкой Zstd-потока) по дереву.
- compress_all: упаковывает проект в project_archive_{tag}.tar.xz (каждый каталог отдельно).
- decompress_all / decompress_fcidump: распаковка с проверками и корректным учётом диска.
- show_meta / list_archives: инвентарь метаданных.

Инварианты:
- Публичные методы/сигнатуры сохранены (новые параметры имеют дефолты).
- Все новые файлы удаляются при ошибках; исходники не трогаем.
"""

from __future__ import annotations

import os
import glob
import stat
import copy
import json
import re
from typing import Dict, Iterable, List, Optional, Tuple
from collections import defaultdict
from datetime import datetime

from concurrent.futures import ProcessPoolExecutor, as_completed
import multiprocessing as mp

# ---- ядро операций ----
from .archiver_core import (
    compress_fcidump_dir,
    compress_project_dir,
    decompress_project_archive,
    decompress_archive_fcidump_only,
    _list_dir_only,
    read_archive_meta_brief,
    read_meta_from_zst,
    restore_loose_fcidump,
)

_ARCHIVE_META_NAME = "ARCHIVE_META.json"

# try импорт Cython-функций (может отсутствовать)
try:
    from fcidump_codec import read_meta_from_bin, bin_to_text_parallel  # noqa: F401
    _HAVE_FCID = True
except Exception:
    _HAVE_FCID = False

# ---------------- utils ----------------

def _canon(path: str) -> str:
    return os.path.realpath(os.path.abspath(path))

def _rel_depth(root_abs: str, path: str) -> int:
    rel = os.path.relpath(path, root_abs)
    if rel == ".":
        return 0
    return len([p for p in rel.split(os.sep) if p])

def _iter_dirs(root_abs: str, depth_min: int, depth_max: int) -> List[str]:
    out: List[str] = []
    for cur, dirs, files in os.walk(root_abs):
        d = _rel_depth(root_abs, cur)
        if d < depth_min or d > depth_max:
            if d >= depth_max:
                dirs[:] = []
            continue
        out.append(_canon(cur))
    out.sort()
    seen: set[str] = set()
    uniq: List[str] = []
    for p in out:
        if p not in seen:
            uniq.append(p)
            seen.add(p)
    return uniq

def _match_archives_in_dir(dirpath: str, tag: str) -> List[str]:
    base = f"project_archive_{tag}"
    pat = os.path.join(dirpath, f"{base}*.tar.xz")
    out: List[str] = []
    for path in glob.glob(pat):
        name = os.path.basename(path)
        if not name.startswith(base) or not name.endswith(".tar.xz"):
            continue
        suffix = name[len(base):-len(".tar.xz")]
        if suffix and not re.fullmatch(r"_\d+", suffix):
            continue
        out.append(path)
    out.sort()
    return out

def _pick_latest(paths: List[str]) -> Optional[str]:
    return max(paths, key=os.path.getmtime) if paths else None

def _has_fcidump_any(dirpath: str, fcidump_filename: Optional[str] = None) -> bool:
    """Проверить наличие FCIDUMP файлов в директории"""
    if fcidump_filename:
        # Проверяем custom имя файла
        for ext in ("", ".bin", ".bin.zst"):
            p = os.path.join(dirpath, f"{fcidump_filename}{ext}" if ext else fcidump_filename)
            try:
                st = os.lstat(p)
                if stat.S_ISREG(st.st_mode):
                    return True
            except FileNotFoundError:
                pass
    else:
        # Проверяем стандартные имена
        for name in ("FCIDUMP", "FCIDUMP.bin", "FCIDUMP.bin.zst"):
            p = os.path.join(dirpath, name)
            try:
                st = os.lstat(p)
                if stat.S_ISREG(st.st_mode):
                    return True
            except FileNotFoundError:
                pass
    return False

def _size_mb(nbytes: int) -> float:
    return float(nbytes) / (1024.0 * 1024.0)

def _fmt_ts(ts: Optional[int]) -> str:
    if ts in (None, '', '?'):
        return '?'
    try:
        return datetime.fromtimestamp(int(ts)).isoformat(timespec='seconds')
    except (ValueError, OSError, TypeError):
        return str(ts)


def _threads_or_cpu(value: Optional[int]) -> int:
    cpu_total = max(1, os.cpu_count() or 1)
    if value is None or value <= 0:
        return cpu_total
    return int(max(1, value))

# ---------------- pickle-safe workers ----------------

def _worker_compress_fcidump(args: Dict) -> Tuple[str, int, bool, str]:
    return compress_fcidump_dir(**args)

def _worker_compress_project(args: Dict) -> Tuple[str, int, bool, str]:
    return compress_project_dir(**args)

def _worker_decompress_project(ap: str, to_text: bool, zstd_dthreads: int, fc_workers: int, fcidump_filename: Optional[str] = None) -> Tuple[str, int, bool, str]:
    return decompress_project_archive(
        tar_path=ap,
        to_text=to_text,
        zstd_dthreads=zstd_dthreads,
        fc_workers=fc_workers,
        fcidump_filename=fcidump_filename,
    )

def _worker_decompress_fc_only(
    ap: str, to_text: bool, fc_workers: int, remove_archive: bool, zstd_dthreads: int
) -> Tuple[str, int, bool, str]:
    return decompress_archive_fcidump_only(
        tar_path=ap,
        to_text=to_text,
        fc_workers=fc_workers,
        remove_archive=remove_archive,
        zstd_dthreads=zstd_dthreads,
    )

def _worker_restore_loose_fc(dirpath: str, to_text: bool, fc_workers: int, zstd_dthreads: int, fcidump_filename: Optional[str] = None) -> Tuple[str, int, bool, str]:
    return restore_loose_fcidump(
        dirpath=dirpath,
        to_text=to_text,
        fc_workers=fc_workers,
        zstd_dthreads=zstd_dthreads,
        fcidump_filename=fcidump_filename,
    )

# ---------------- main API ----------------

class GeCCoArchiver:
    """
    High-level API for folder tree operations.
    
    Provides methods for compressing and decompressing FCIDUMP files and project archives.
    
    Parameters
    ----------
    archive_name : Optional[str], default='default'
        Name/tag for the archive. Used to name archive files as 
        'project_archive_{archive_name}.tar.xz'. If None, uses 'default'.
    num_workers : Optional[int], default=CPU count
        Number of parallel workers for directory processing.
        If None or <= 0, uses all available CPU cores.
    verbose : bool, default=True
        Enable verbose output during operations.
    patterns : Optional[List[str]], default=None
        File patterns to include in project archives.
    keywords : Optional[List[str]], default=None
        Keywords for filtering.
    xz_threads : Optional[int], default=CPU count
        Number of threads for XZ compression. If None or <= 0, uses CPU count.
    fcidump_workers_map : Optional[List[Tuple[float, int]]], default=None
        Size-based mapping for FCIDUMP worker threads.
        List of (size_in_mb, num_threads) tuples.
    xz_memlimit_percent : Optional[int], default=None
        Memory limit percent for XZ decompression.
    xz_block_size : Optional[int], default=None
        Block size for XZ compression.
    """

    def __init__(
        self,
        archive_name: Optional[str] = None,
        num_workers: Optional[int] = None,
        verbose: bool = True,
        patterns: Optional[List[str]] = None,
        keywords: Optional[List[str]] = None,
        xz_threads: Optional[int] = None,
        fcidump_workers_map: Optional[List[Tuple[float, int]]] = None,
        xz_memlimit_percent: Optional[int] = None,
        xz_block_size: Optional[int] = None,
    ) -> None:
        self.archive_name = archive_name if archive_name is not None else "default"
        cpu_total = max(1, os.cpu_count() or 1)
        if num_workers is None or num_workers <= 0:
            self.num_workers = cpu_total
        else:
            self.num_workers = int(max(1, num_workers))
        self.verbose = bool(verbose)
        self.patterns = list(patterns or [])
        self.keywords = list(keywords or [])
        self.xz_threads = int(xz_threads) if xz_threads and xz_threads > 0 else cpu_total

        # карта выбора потоков для FCIDUMP
        self.fcidump_workers_map: List[Tuple[int, int]] = []
        if fcidump_workers_map:
            self.fcidump_workers_map = [
                (int(max(0, sz)), int(max(1, th))) for sz, th in fcidump_workers_map
            ]
            self.fcidump_workers_map.sort(key=lambda t: t[0])
        else:
            self.fcidump_workers_map = [(0, cpu_total)]
        self.xz_memlimit_percent = xz_memlimit_percent
        self.xz_block_size = xz_block_size

        # Пул процессов на fork (без spawn)
        self._mp_ctx = mp.get_context("fork")

    def _choose_fc_workers(self, size_bytes: int) -> int:
        th = 1
        for sz, n in self.fcidump_workers_map:
            if size_bytes >= sz:
                th = n
            else:
                break
        return max(1, int(th))

    # ---------- COMPRESS: только FCIDUMP ----------

    def compress_fcidump(
        self,
        *,
        root: str = ".",
        depth_min: int = 0,
        depth_max: int = 10,
        to_zstd: bool = True,
        zstd_level: int = 1,
        zstd_threads: Optional[int] = None,
        user_meta: Optional[Dict] = None,
        fcidump_filename: Optional[str] = None,
    ) -> None:
        tag = self.archive_name
        root_abs = _canon(root)
        dirs = _iter_dirs(root_abs, depth_min, depth_max)

        tasks: List[Tuple[str, int]] = []
        for d in dirs:
            if _has_fcidump_any(d, fcidump_filename):
                size = 0
                # Определяем имена файлов для проверки размера
                if fcidump_filename:
                    check_names = [fcidump_filename, f"{fcidump_filename}.bin"]
                else:
                    check_names = ["FCIDUMP", "FCIDUMP.bin"]
                
                for fn in check_names:
                    p = os.path.join(d, fn)
                    try:
                        size = max(size, os.path.getsize(p))
                    except Exception:
                        pass
                fcw = self._choose_fc_workers(size)
                tasks.append((d, fcw))

        print(f"[info] starting FCIDUMP→bin compression: {len(tasks)} dirs (silent-skip others)")
        if not tasks:
            print("[summary] FCIDUMP→bin Δdisk total = 0.00 MB nochange")
            return

        threads = _threads_or_cpu(zstd_threads)
        args_list: List[Dict] = []
        meta_payload = copy.deepcopy(user_meta) if user_meta is not None else None
        for d, fcw in tasks:
            args_list.append(
                dict(
                    dirpath=d,
                    tag=tag,
                    compress=("zstd" if to_zstd else "none"),
                    zstd_level=int(zstd_level),
                    zstd_threads=threads,
                    fc_workers=int(max(1, fcw)),
                    user_meta=meta_payload,
                    fcidump_filename=fcidump_filename,
                )
            )

        total = 0.0
        with ProcessPoolExecutor(max_workers=self.num_workers, mp_context=self._mp_ctx) as pool:
            futs = [pool.submit(_worker_compress_fcidump, a) for a in args_list]
            for i, fut in enumerate(as_completed(futs), 1):
                dirpath, saved, ok, msg = fut.result()
                rel = os.path.relpath(dirpath, root_abs)
                if ok:
                    mb = _size_mb(saved)
                    total += max(0.0, mb)
                    print(f"[{i}/{len(tasks)}] {rel}: OK {msg}; Δdisk={mb:.2f} MB freed")
                else:
                    if str(msg).strip().lower().startswith("nothing to encode"):
                        print(f"[{i}/{len(tasks)}] {rel}: OK nothing to encode; Δdisk=0.00 MB nochange")
                    else:
                        print(f"[{i}/{len(tasks)}] {rel}: ERR {msg}; Δdisk=0.00 MB nochange")

        print(f"[summary] FCIDUMP→bin Δdisk total = {total:.2f} MB freed")

    # ---------- COMPRESS: проект целиком ----------

    def _dir_has_archive_payload(self, dirpath: str, *, with_fcidump: bool) -> bool:
        """
        Дешёвый и точный предфильтр, синхронизированный с логикой archiver_core._list_dir_only:
        - true, если в каталоге есть FCIDUMP (текст) ИЛИ FCIDUMP.bin(.zst/.meta);
        - ИЛИ есть хотя бы один обычный файл, чьё имя:
              * входит в self.patterns (точное совпадение имени), ИЛИ
              * содержит любой из self.keywords как подстроку;
        - игнорируем project_archive_*.tar.xz и не регулярные файлы.
        """
        try:
            if with_fcidump:
                for name in ("FCIDUMP", "FCIDUMP.bin", "FCIDUMP.bin.zst", "FCIDUMP_info.txt"):
                    p = os.path.join(dirpath, name)
                    try:
                        st = os.lstat(p)
                        if stat.S_ISREG(st.st_mode):
                            return True
                    except FileNotFoundError:
                        pass

            pats = set(self.patterns or [])
            kws  = [k for k in (self.keywords or []) if k]

            # если шаблонов/ключей нет — других файлов (кроме FCIDUMP*) не берём
            if not pats and not kws:
                return False

            for base in os.listdir(dirpath):
                # пропускаем уже собранные архивы
                if base.startswith("project_archive_") and base.endswith(".tar.xz"):
                    continue
                p = os.path.join(dirpath, base)
                try:
                    st = os.lstat(p)
                except FileNotFoundError:
                    continue
                if not stat.S_ISREG(st.st_mode):
                    continue
                if base == _ARCHIVE_META_NAME:
                    continue
                if not with_fcidump and base in {"FCIDUMP", "FCIDUMP.bin", "FCIDUMP.bin.zst", "FCIDUMP_info.txt"}:
                    continue
                if base in pats:
                    return True
                if kws and any(kw in base for kw in kws):
                    return True
            return False
        except Exception:
            return False

    def compress_all(
        self,
        *,
        root: str = ".",
        depth_min: int = 0,
        depth_max: int = 10,
        xz_threads: Optional[int] = None,
        xz_memlimit_percent: Optional[int] = None,
        xz_block_size: Optional[int] = None,
        with_fcidump: bool = True,
        comment: Optional[str] = None,
        user_meta: Optional[Dict] = None,
        fcidump_filename: Optional[str] = None,
    ) -> None:
        """
        Архивирует проектные папки независимо, не залезая в родительские/дочерние уровни («архив в архиве» не делаем).
        Прогресс [k/N] ведётся ТОЛЬКО по реально архивируемым папкам (по нашему предфильтру).
        """
        root_abs = os.path.abspath(root)

        # 1) собираем все кандидаты по глубине
        all_dirs: list[str] = []
        for dirpath, dirnames, filenames in os.walk(root_abs):
            rel = os.path.relpath(dirpath, root_abs)
            d = 0 if rel == "." else rel.count(os.sep) + 1
            if d < depth_min or d > depth_max:
                continue
            all_dirs.append(dirpath)

        # 2) точный фильтр: оставляем ТОЛЬКО те, что реально что-то дадут в архив
        candidates = [d for d in all_dirs if self._dir_has_archive_payload(d, with_fcidump=with_fcidump)]
        N = len(candidates)
        print(
            f"[info] starting project compression (text→bin ensured, with_fcidump={'yes' if with_fcidump else 'no'}): {N} dirs"
        )
        if N == 0:
            print("[summary] project compression Δdisk total = 0.00 MB nochange")
            return

        # 3) формируем задачи под актуальную сигнатуру archiver_core.compress_project_dir
        args_list: List[Dict] = []
        configured_xz_threads = xz_threads if xz_threads is not None else self.xz_threads
        resolved_xz_threads = _threads_or_cpu(configured_xz_threads)
        for d in candidates:
            args_list.append(
                dict(
                    dirpath=d,
                    tag=self.archive_name,
                    fc_workers=self._choose_fc_workers(0),
                    xz_threads=resolved_xz_threads,
                    description="text→bin ensured",
                    include_patterns=self.patterns,
                    include_keywords=self.keywords,
                    comment=comment,
                    user_meta=copy.deepcopy(user_meta) if user_meta is not None else None,
                    xz_memlimit_percent=xz_memlimit_percent,
                    xz_block_size=xz_block_size,
                    with_fcidump=bool(with_fcidump),
                    fcidump_filename=fcidump_filename,
                )
            )

        total_saved_mb = 0.0
        with ProcessPoolExecutor(max_workers=self.num_workers, mp_context=self._mp_ctx) as pool:
            futs = [pool.submit(_worker_compress_project, a) for a in args_list]
            for i, fut in enumerate(as_completed(futs), 1):
                dirpath, saved_bytes, ok, msg = fut.result()
                rel = os.path.relpath(dirpath, root_abs)
                mb = _size_mb(saved_bytes)
                if ok:
                    total_saved_mb += max(0.0, mb)
                    print(f"[{i}/{N}] {rel}: OK {msg}; Δdisk={mb:.2f} MB freed")
                else:
                    # такое может случиться лишь при гонке (файлы исчезли между фильтром и задачей)
                    print(f"[{i}/{N}] {rel}: ERR {msg}; Δdisk=0.00 MB nochange")

        print(f"[summary] project compression Δdisk total = {total_saved_mb:.2f} MB freed")

    def clear(
        self,
        *,
        root: str = ".",
        depth_min: int = 0,
        depth_max: int = 10,
        with_fcidump: bool = False,
    ) -> None:
        """Удалить набор файлов по тем же правилам, что и compress_all."""
        root_abs = _canon(root)
        dirs = _iter_dirs(root_abs, depth_min, depth_max)

        targets: List[Tuple[str, List[str]]] = []
        for d in dirs:
            files = _list_dir_only(
                d,
                self.patterns,
                self.keywords,
                with_fcidump=with_fcidump,
            )
            meta_path = os.path.join(d, _ARCHIVE_META_NAME)
            if os.path.isfile(meta_path):
                files = list(files) + [meta_path]
            if files:
                targets.append((d, list(files)))

        print(f"[info] starting clear (with_fcidump={'yes' if with_fcidump else 'no'}): {len(targets)} dirs")
        if not targets:
            print("[summary] clear Δdisk total = 0.00 MB nochange")
            return

        total_mb = 0.0
        total_removed = 0
        total_errors = 0

        for idx, (dirpath, files) in enumerate(targets, 1):
            freed_bytes = 0
            removed_here = 0
            errors_here: List[str] = []
            for path in files:
                try:
                    size = os.path.getsize(path)
                except Exception:
                    size = 0
                try:
                    os.remove(path)
                    removed_here += 1
                    freed_bytes += max(0, size)
                except FileNotFoundError:
                    continue
                except Exception as exc:
                    errors_here.append(f"{os.path.basename(path)}: {exc}")
            rel = os.path.relpath(dirpath, root_abs)
            freed_mb = _size_mb(freed_bytes)
            total_removed += removed_here
            total_mb += max(0.0, freed_mb)
            total_errors += len(errors_here)
            if removed_here or errors_here:
                print(f"[clr {idx}/{len(targets)}] {rel}: removed={removed_here}, Δdisk={freed_mb:.2f} MB freed")
                for err in errors_here:
                    print(f"    ERR {err}")

        summary = f"[summary] clear Δdisk total = {total_mb:.2f} MB freed"
        details: List[str] = []
        details.append(f"removed={total_removed}")
        if total_errors:
            details.append(f"errors={total_errors}")
        if details:
            summary += f" ({', '.join(details)})"
        print(summary)

    # ---------- DECOMPRESS: проект целиком ----------

    def decompress_all(
        self,
        *,
        root: str = ".",
        depth_min: int = 0,
        depth_max: int = 10,
        to_text: bool = False,
        zstd_dthreads: int = 0,
        archive_path: Optional[str] = None,
        fcidump_filename: Optional[str] = None,
    ) -> None:
        tag = self.archive_name
        root_abs = _canon(root)

        # Если указан конкретный архив, используем его
        if archive_path:
            archs = [os.path.abspath(archive_path)] if os.path.isfile(archive_path) else []
        else:
            dirs = _iter_dirs(root_abs, depth_min, depth_max)
            archs: List[str] = []
            for d in dirs:
                latest = _pick_latest(_match_archives_in_dir(d, tag))
                if latest:
                    archs.append(latest)

        print(f"[info] starting decompression (to_text={to_text}) — {len(archs)} archives")
        if not archs:
            print("[summary] decompression Δdisk total = 0.00 MB nochange")
            return

        total = 0.0
        threads = _threads_or_cpu(zstd_dthreads)
        with ProcessPoolExecutor(max_workers=self.num_workers, mp_context=self._mp_ctx) as pool:
            futs = [
                pool.submit(
                    _worker_decompress_project,
                    ap,
                    to_text,
                    threads,
                    self._choose_fc_workers(0),
                    fcidump_filename,
                )
                for ap in archs
            ]
            for i, fut in enumerate(as_completed(futs), 1):
                dirpath, delta, ok, msg = fut.result()
                rel = os.path.relpath(dirpath, root_abs)
                if ok:
                    mb = _size_mb(delta)
                    total += max(0.0, mb)
                    sense = "used" if mb >= 0 else "freed"
                    print(f"[arc {i}/{len(archs)}] {rel}: OK {msg}; Δdisk={abs(mb):.2f} MB {sense}")
                else:
                    print(f"[arc {i}/{len(archs)}] {rel}: ERR {msg}; Δdisk=0.00 MB nochange")
        print(f"[summary] decompression Δdisk total = {abs(total):.2f} MB {'used' if total>=0 else 'freed'}")

    # ---------- DECOMPRESS: только FCIDUMP ----------

    def decompress_fcidump(
        self,
        *,
        root: str = ".",
        depth_min: int = 0,
        depth_max: int = 10,
        to_text: bool = True,
        remove_archive: bool = True,
        zstd_dthreads: int = 0,
        fcidump_filename: Optional[str] = None,
    ) -> None:
        tag = self.archive_name
        root_abs = _canon(root)
        dirs = _iter_dirs(root_abs, depth_min, depth_max)

        # собрать архивы
        archs: List[str] = []
        for d in dirs:
            archs.extend(_match_archives_in_dir(d, tag))

        # собрать «рассыпанные» FCIDUMP.bin(.zst) - с учетом custom filename
        bins: List[str] = []
        zsts: List[str] = []
        for d in dirs:
            if fcidump_filename:
                p_bin = os.path.join(d, f"{fcidump_filename}.bin")
                p_zst = os.path.join(d, f"{fcidump_filename}.bin.zst")
            else:
                p_bin = os.path.join(d, "FCIDUMP.bin")
                p_zst = os.path.join(d, "FCIDUMP.bin.zst")
            if os.path.isfile(p_bin):
                bins.append(p_bin)
            if os.path.isfile(p_zst):
                zsts.append(p_zst)

        print(f"[info] starting FCIDUMP restore (to_text={to_text}) — {len(bins)} .bin and {len(zsts)} .zst")
        total = 0.0

        # сначала архивы — только FCIDUMP
        if archs:
            threads = _threads_or_cpu(zstd_dthreads)
            with ProcessPoolExecutor(max_workers=self.num_workers, mp_context=self._mp_ctx) as pool:
                futs = [
                    pool.submit(
                        _worker_decompress_fc_only,
                        ap,
                        to_text,
                        self._choose_fc_workers(0),
                        remove_archive,
                        threads,
                    )
                    for ap in archs
                ]
                for i, fut in enumerate(as_completed(futs), 1):
                    dirpath, delta, ok, msg = fut.result()
                    rel = os.path.relpath(dirpath, root_abs)
                    if ok:
                        mb = _size_mb(delta)
                        total += max(0.0, mb)
                        sense = "used" if mb >= 0 else "freed"
                        print(f"[arc {i}/{len(archs)}] {rel}: OK {msg}; Δdisk={abs(mb):.2f} MB {sense}")
                    else:
                        print(f"[arc {i}/{len(archs)}] {rel}: ERR {msg}; Δdisk=0.00 MB nochange")

        # затем «рассыпанные» — по одному каталогу
        loose_dirs: List[str] = []
        seen_dirs: set[str] = set()
        for p in zsts + bins:
            d = _canon(os.path.dirname(p))
            if d not in seen_dirs:
                seen_dirs.add(d)
                loose_dirs.append(d)

        restore_threads = _threads_or_cpu(zstd_dthreads)
        for i, d in enumerate(loose_dirs, 1):
            rel = os.path.relpath(d, root_abs)
            try:
                dirpath, delta, ok, msg = _worker_restore_loose_fc(
                    d, to_text, self._choose_fc_workers(0), restore_threads, fcidump_filename
                )
                if ok:
                    mb = _size_mb(delta); total += max(0.0, mb)
                    sense = "used" if mb >= 0 else "freed"
                    print(f"[bin {i}/{len(loose_dirs)}] {rel}: OK {msg}; Δdisk={abs(mb):.2f} MB {sense}")
                else:
                    print(f"[bin {i}/{len(loose_dirs)}] {rel}: ERR {msg}; Δdisk=0.00 MB nochange")
            except Exception as exc:  # noqa: BLE001
                print(f"[bin {i}/{len(loose_dirs)}] {rel}: ERR {exc}; Δdisk=0.00 MB nochange")

        print(f"[summary] FCIDUMP restore Δdisk total = {total:.2f} MB used")

    # ---------- META/Inventory ----------


    def show_meta(
        self,
        *,
        root: str = ".",
        depth_min: int = 0,
        depth_max: int = 10,
        show_user: bool = True,
        list_archives: bool = True,
    ) -> None:
        tag = self.archive_name
        root_abs = _canon(root)
        dirs = _iter_dirs(root_abs, depth_min, depth_max)

        loose_fc: List[Tuple[str, str]] = []  # (path, kind)
        for d in dirs:
            bin_path = os.path.join(d, "FCIDUMP.bin")
            zst_path = os.path.join(d, "FCIDUMP.bin.zst")
            txt_path = os.path.join(d, "FCIDUMP")
            if os.path.isfile(bin_path):
                loose_fc.append((bin_path, "bin"))
                continue
            if os.path.isfile(zst_path):
                loose_fc.append((zst_path, "zst"))
                continue
            if os.path.isfile(txt_path):
                loose_fc.append((txt_path, "txt"))

        loose_count = len(loose_fc)
        print(
            f">>> show_meta: loose={loose_count}, depth={depth_min}..{depth_max}, "
            f"show_user={'yes' if show_user else 'no'}, list_archives={'yes' if list_archives else 'no'}"
        )

        total_fc = loose_count


        def _auto_summary(
            meta: Optional[Dict],
            *,
            fallback_path: Optional[str] = None,
            fallback_ts: Optional[object] = None,
        ) -> Optional[str]:
            if not isinstance(meta, dict):
                return None
            auto = meta.get("auto")
            if not isinstance(auto, dict):
                return None
            fc = auto.get("fcidump")
            if not isinstance(fc, dict):
                fc = {}
        
            def pick(key: str):
                val = fc.get(key)
                if val is not None:
                    return val
                return auto.get(key)

            fields: List[str] = []

            generated_by = pick("generated_by")
            if generated_by is not None:
                fields.append(f"generated_by={generated_by}")

            def pick_ts(container: Dict) -> Optional[object]:
                if not isinstance(container, dict):
                    return None
                for key in ("created_utc", "time_utc", "created_ts", "created", "time"):
                    val = container.get(key)
                    if val not in (None, ""):
                        return val
                return None
        
            created_raw = pick_ts(fc) or pick_ts(auto)
            if created_raw is None and fallback_ts is not None:
                created_raw = fallback_ts
            if created_raw is None and fallback_path:
                try:
                    created_raw = os.path.getmtime(fallback_path)
                except OSError:
                    created_raw = None
            if created_raw is not None:
                fields.append(f"created={_fmt_ts(created_raw)}")
            else:
                fields.append("created=?")
            norb = pick("norb")
            if norb is not None:
                fields.append(f"NORB={norb}")
            nelec = pick("nelec")
            if nelec is not None:
                fields.append(f"NELEC={nelec}")
            ms2 = pick("ms2")
            if ms2 is not None:
                fields.append(f"MS2={ms2}")
            records = pick("records")
            if records is None:
                records = auto.get("records")
            if records is not None:
                fields.append(f"records={records}")
            energy = pick("energy")
            if energy is None:
                energy = auto.get("energy")
            if energy is not None:
                fields.append(f"energy={energy}")
            return ", ".join(fields) if fields else None

        def _coerce_created(value: object) -> Optional[int]:
            if isinstance(value, bool):
                return int(value)
            if isinstance(value, (int, float)):
                return int(value)
            if isinstance(value, str):
                try:
                    return int(float(value))
                except Exception:
                    return None
            return None

        def _sidecar_created_ts(base_path: str) -> Optional[int]:
            meta_path = f"{base_path}.meta.json"
            try:
                with open(meta_path, "r", encoding="utf-8") as fh:
                    payload = json.load(fh)
            except FileNotFoundError:
                return None
            except json.JSONDecodeError:
                return None
            except Exception:
                return None
            return _coerce_created(payload.get("created_utc"))

        def _user_summary(meta: Optional[Dict]) -> Optional[str]:
            if not show_user or not isinstance(meta, dict):
                return None
            user = meta.get("user")
            if user is None or user == {}:
                return None
            def _indent_block(text: str, *, first_level: int = 0) -> str:
                indent_base = "    " * first_level
                lines = text.splitlines()
                return "\n".join(indent_base + "    " + line for line in lines)

            indent_key = "             "  # 13 spaces
            indent_val = indent_key + "   "  # 16 spaces for continuation

            def _format_value_lines(text: str) -> List[str]:
                lines = text.splitlines() or [""]
                first = indent_key + lines[0]
                rest = [indent_val + line for line in lines[1:]]
                return [first, *rest]

            if isinstance(user, dict):
                if not user:
                    return "user: {}"
                out_lines: List[str] = ["user:"]
                for key in sorted(user.keys(), key=lambda x: str(x)):
                    val = user[key]
                    if isinstance(val, dict):
                        rendered = json.dumps(val, ensure_ascii=False, indent=2)
                    elif isinstance(val, (list, tuple, set)):
                        rendered = json.dumps(list(val), ensure_ascii=False)
                    else:
                        rendered = str(val)
                    value_lines = rendered.splitlines() or [""]
                    first_line = f"{key}: {value_lines[0]}".rstrip()
                    out_lines.append(indent_key + first_line)
                    for line in value_lines[1:]:
                        out_lines.append(indent_val + line)
                return "\n".join(out_lines)

            if isinstance(user, (list, tuple, set)):
                rendered = json.dumps(list(user), ensure_ascii=False)
                lines = _format_value_lines(rendered)
                return "user:\n" + "\n".join(lines)

            rendered = str(user)
            lines = rendered.splitlines()
            if not lines:
                return "user:"
            if len(lines) == 1:
                return f"user: {lines[0]}"
            formatted = [indent_key + lines[0]]
            formatted.extend(indent_val + line for line in lines[1:])
            return "user:\n" + "\n".join(formatted)

        for idx, (path, kind) in enumerate(loose_fc, 1):
            rel = os.path.relpath(path, root_abs)
            label = "FCIDUMP.bin" if kind == "bin" else ("FCIDUMP.bin.zst" if kind == "zst" else "FCIDUMP")
            if loose_count:
                prefix = f"[fc {idx}/{loose_count}]"
            else:
                prefix = "[fc]"
            print(f"{prefix} {rel} ({label})")
            meta: Optional[Dict] = None
            if kind == "txt":
                print("    meta: FCIDUMP text only (no binary header)")
                info_path = os.path.join(os.path.dirname(path), "FCIDUMP_info.txt")
                if os.path.isfile(info_path):
                    print(f"    hint: see {os.path.relpath(info_path, root_abs)}")
                continue
            if not _HAVE_FCID:
                print("    meta: fcidump_codec not available")
                continue
            try:
                if kind == "bin":
                    meta = read_meta_from_bin(path)
                elif kind == "zst":
                    meta = read_meta_from_zst(path)
            except Exception as exc:  # noqa: BLE001
                print(f"    meta read error: {exc}")
                continue
            if meta is None:
                print("    meta: <unavailable>")
                continue
            sidecar_created = _sidecar_created_ts(path)
            auto_summary = _auto_summary(meta, fallback_path=path, fallback_ts=sidecar_created)
            if auto_summary:
                print(f"    auto: {auto_summary}")
            else:
                print("    auto: <no fields>")
            user_summary = _user_summary(meta)
            if user_summary:
                print(f"    {user_summary}")

        if not list_archives:
            print(f"total FCIDUMP entries={total_fc}")
            return

        archs: List[str] = []
        for d in dirs:
            archs.extend(_match_archives_in_dir(d, tag))
        archs = sorted(archs, key=os.path.getmtime, reverse=True)

        print(f"archives={len(archs)} (latest first)")
        for i, ap in enumerate(archs, 1):
            rel = os.path.relpath(ap, root_abs)
            try:
                sig, inner, fc_sidecar = read_archive_meta_brief(ap)
            except Exception as exc:  # noqa: BLE001
                print(f"[arc {i}/{len(archs)}] {rel} — ERROR: {exc}")
                continue

            print(f"[arc {i}/{len(archs)}] {rel}")
            sig_created_raw: Optional[int] = None
            if sig:
                for key in ("created_utc", "time_utc", "created_ts", "created", "time"):
                    val = sig.get(key)
                    if val in (None, ""):
                        continue
                    candidate = _coerce_created(val)
                    if candidate is not None:
                        sig_created_raw = candidate
                        break
                details: List[str] = []
                if sig.get("tag"):
                    details.append(f"tag={sig['tag']}")
                if sig_created_raw is not None:
                    details.append(f"created={_fmt_ts(sig_created_raw)}")
                with_fcid = sig.get("with_fcidump")
                if with_fcid is not None:
                    details.append(f"with_fcidump={'yes' if with_fcid else 'no'}")
                for extra_key in ("dir", "description"):
                    if sig.get(extra_key):
                        details.append(f"{extra_key}={sig[extra_key]}")
                if details:
                    print(f"    archive meta: {', '.join(details)}")
                comment = sig.get("comment")
                if comment:
                    print(f"    comment: {comment}")
            else:
                print("    archive meta: <missing>")
            inner_present = inner is not None or (sig and bool(sig.get("with_fcidump")))
            if not inner_present:
                continue

            total_fc += 1
            print("    [fc] archive FCIDUMP.bin.zst")
            if inner is None:
                print("        meta: <unavailable>")
                continue
            sidecar_created = None
            if fc_sidecar:
                sidecar_created = _coerce_created(fc_sidecar.get("created_utc"))
            fallback_created = sidecar_created if sidecar_created is not None else sig_created_raw
            auto_summary = _auto_summary(inner, fallback_path=ap, fallback_ts=fallback_created)
            if auto_summary:
                print(f"        auto: {auto_summary}")
            else:
                print("        auto: <no fields>")
            user_summary = _user_summary(inner)
            if user_summary:
                print(f"        {user_summary}")

        print(f"total FCIDUMP entries={total_fc}")

    def list_archives(
        self,
        *,
        root: str = ".",
        depth_min: int = 0,
        depth_max: int = 10,
    ) -> None:
        tag = self.archive_name
        root_abs = _canon(root)
        dirs = _iter_dirs(root_abs, depth_min, depth_max)
        archs: List[str] = []
        for d in dirs:
            archs.extend(_match_archives_in_dir(d, tag))
        archs = sorted(archs, key=os.path.getmtime, reverse=True)
        print(f"archives={len(archs)}")
        for i, ap in enumerate(archs, 1):
            print(f"[{i}] {os.path.relpath(ap, root_abs)}")
