# zstd_codec.pyx
# cython: language_level=3, boundscheck=False, wraparound=False, cdivision=True
# -*- coding: utf-8 -*-

from libc.stddef  cimport size_t
from cython       cimport NULL
from libc.string  cimport memcpy
from libc.stdlib  cimport malloc, free
from libc.stdio   cimport FILE, fopen, fdopen, fclose, fread, fwrite

cimport cython
from cpython.bytes cimport PyBytes_FromStringAndSize

# ---- zstd API (минимум) ----
cdef extern from "zstd.h":
    ctypedef void* ZSTD_CCtx
    ctypedef void* ZSTD_DCtx

    ctypedef struct ZSTD_inBuffer_s:
        const void* src
        size_t size
        size_t pos
    ctypedef ZSTD_inBuffer_s ZSTD_inBuffer

    ctypedef struct ZSTD_outBuffer_s:
        void* dst
        size_t size
        size_t pos
    ctypedef ZSTD_outBuffer_s ZSTD_outBuffer

    ZSTD_CCtx* ZSTD_createCCtx()
    size_t     ZSTD_freeCCtx(ZSTD_CCtx* cctx)
    ZSTD_DCtx* ZSTD_createDCtx()
    size_t     ZSTD_freeDCtx(ZSTD_DCtx* dctx)

    size_t ZSTD_CCtx_setParameter(ZSTD_CCtx* cctx, int param, int value)
    size_t ZSTD_compressStream2(ZSTD_CCtx* cctx, ZSTD_outBuffer* output, ZSTD_inBuffer* input, int endDirective)
    size_t ZSTD_decompressStream(ZSTD_DCtx* dctx, ZSTD_outBuffer* output, ZSTD_inBuffer* input)
    unsigned ZSTD_isError(size_t code)
    const char* ZSTD_getErrorName(size_t code)

# стабильные ID параметров из zstd.h
cdef int ZSTD_e_continue = 0
cdef int ZSTD_e_end      = 2
cdef int ZSTD_c_compressionLevel = 100
cdef int ZSTD_c_nbWorkers        = 400

@cython.boundscheck(False)
@cython.wraparound(False)
cdef void _compress_stream_FILE(FILE* fin, const char* dst_path,
                                int level, int threads, size_t chunk) except *:
    cdef FILE* fout = NULL
    cdef ZSTD_CCtx* cctx = NULL
    cdef size_t rc = 0

    cdef unsigned char* inbuf  = NULL
    cdef unsigned char* outbuf = NULL

    cdef size_t rd = 0

    cdef ZSTD_inBuffer  ib
    cdef ZSTD_outBuffer ob
    cdef ZSTD_inBuffer  ib2
    cdef ZSTD_outBuffer ob2

    if fin == NULL:
        raise RuntimeError("input stream is NULL")
    fout = fopen(dst_path, "wb")
    if fout == NULL:
        raise RuntimeError("cannot open output")

    cctx = ZSTD_createCCtx()
    if cctx == NULL:
        fclose(fout)
        raise RuntimeError("ZSTD_createCCtx failed")

    rc = ZSTD_CCtx_setParameter(cctx, ZSTD_c_compressionLevel, level)
    if ZSTD_isError(rc):
        ZSTD_freeCCtx(cctx); fclose(fout)
        raise RuntimeError("ZSTD set level failed")
    if threads > 0:
        rc = ZSTD_CCtx_setParameter(cctx, ZSTD_c_nbWorkers, threads)
        if ZSTD_isError(rc):
            # библиотека без MT — мягкая деградация на 1 поток
            threads = 0

    inbuf  = <unsigned char*>malloc(chunk)
    outbuf = <unsigned char*>malloc(chunk * 2 + 65536)
    if inbuf == NULL or outbuf == NULL:
        if inbuf:  free(inbuf)
        if outbuf: free(outbuf)
        ZSTD_freeCCtx(cctx); fclose(fout)
        raise MemoryError()

    try:
        while True:
            rd = fread(inbuf, 1, chunk, fin)
            if rd == 0:
                break

            ib.src  = <const void*>inbuf
            ib.size = rd
            ib.pos  = 0

            while ib.pos < ib.size:
                ob.dst  = <void*>outbuf
                ob.size = chunk * 2 + 65536
                ob.pos  = 0
                rc = ZSTD_compressStream2(cctx, &ob, &ib, ZSTD_e_continue)
                if ZSTD_isError(rc):
                    raise RuntimeError("ZSTD_compressStream2 failed")
                if ob.pos:
                    if fwrite(outbuf, 1, ob.pos, fout) != ob.pos:
                        raise RuntimeError("write failed")

        # finish
        ib2.src  = NULL
        ib2.size = 0
        ib2.pos  = 0
        while True:
            ob2.dst  = <void*>outbuf
            ob2.size = chunk * 2 + 65536
            ob2.pos  = 0
            rc = ZSTD_compressStream2(cctx, &ob2, &ib2, ZSTD_e_end)
            if ZSTD_isError(rc):
                raise RuntimeError("ZSTD endStream failed")
            if ob2.pos:
                if fwrite(outbuf, 1, ob2.pos, fout) != ob2.pos:
                    raise RuntimeError("write failed")
            if rc == 0:
                break

    finally:
        free(inbuf); free(outbuf)
        ZSTD_freeCCtx(cctx)
        fclose(fout)

@cython.boundscheck(False)
@cython.wraparound(False)
cdef void _compress_stream_file(const char* src_path, const char* dst_path,
                                int level, int threads, size_t chunk) except *:
    cdef FILE* fin = fopen(src_path, "rb")
    if fin == NULL:
        raise RuntimeError("cannot open input")
    try:
        _compress_stream_FILE(fin, dst_path, level, threads, chunk)
    finally:
        fclose(fin)

@cython.boundscheck(False)
@cython.wraparound(False)
cdef void _compress_stream_fd(int src_fd, const char* dst_path,
                              int level, int threads, size_t chunk) except *:
    cdef FILE* fin = fdopen(src_fd, "rb")
    if fin == NULL:
        raise RuntimeError("cannot fdopen input")
    try:
        _compress_stream_FILE(fin, dst_path, level, threads, chunk)
    finally:
        try: fclose(fin)
        except Exception: pass

@cython.boundscheck(False)
@cython.wraparound(False)
cdef void _decompress_stream_file_to_hasher(const char* src_path, int threads, size_t chunk,
                                            object py_hasher) except *:
    """Разжать src_path и скармливать блоки в Python-хешер (blake3.blake3())."""
    cdef FILE* fin = fopen(src_path, "rb")
    if fin == NULL:
        raise RuntimeError("cannot open input")

    cdef ZSTD_DCtx* dctx = ZSTD_createDCtx()
    if dctx == NULL:
        fclose(fin)
        raise RuntimeError("ZSTD_createDCtx failed")

    cdef unsigned char* inbuf  = <unsigned char*>malloc(chunk + 65536)
    cdef unsigned char* work   = <unsigned char*>malloc(chunk + 65536)
    if inbuf == NULL or work == NULL:
        if inbuf: free(inbuf)
        if work:  free(work)
        ZSTD_freeDCtx(dctx); fclose(fin)
        raise MemoryError()

    cdef size_t rd = 0
    cdef size_t produced = 0
    cdef ZSTD_inBuffer  ib
    cdef ZSTD_outBuffer ob

    try:
        while True:
            rd = fread(inbuf, 1, chunk, fin)
            if rd == 0:
                break

            ib.src  = <const void*>inbuf
            ib.size = rd
            ib.pos  = 0

            while ib.pos < ib.size:
                ob.dst  = <void*>work
                ob.size = chunk + 65536
                ob.pos  = 0
                produced = ZSTD_decompressStream(dctx, &ob, &ib)
                if ZSTD_isError(produced):
                    raise RuntimeError("ZSTD_decompressStream failed")

                if ob.pos > 0:
                    py_hasher.update( PyBytes_FromStringAndSize(<char*>work, ob.pos) )

    finally:
        free(inbuf); free(work)
        ZSTD_freeDCtx(dctx)
        fclose(fin)

# ---- публичные функции ----

def compress_zstd_file(str src_path, str dst_path, int level=1, int threads=0, size_t chunk=8<<20, bint shuffle=False):
    """Сжать файл src_path -> dst_path (zstd). Параметр shuffle игнорируется."""
    _compress_stream_file(src_path.encode("utf-8"), dst_path.encode("utf-8"),
                          level, threads, chunk)

def compress_zstd_from_fd(int fd, str dst_path, int level=1, int threads=0, size_t chunk=8<<20):
    """Сжать поток fd -> dst_path (zstd). fd будет закрыт при выходе."""
    _compress_stream_fd(fd, dst_path.encode("utf-8"),
                        level, threads, chunk)

def decompress_zstd_file(str src_path, str dst_path, int threads=0, size_t chunk=8<<20, bint shuffle=False):
    """Разжать файл src_path -> dst_path (на диск). Параметр shuffle игнорируется."""
    cdef FILE* fin = fopen(src_path.encode("utf-8"), "rb")
    if fin == NULL:
        raise RuntimeError("cannot open input")
    cdef FILE* fout = fopen(dst_path.encode("utf-8"), "wb")
    if fout == NULL:
        fclose(fin)
        raise RuntimeError("cannot open output")

    cdef ZSTD_DCtx* dctx = ZSTD_createDCtx()
    if dctx == NULL:
        fclose(fin); fclose(fout)
        raise RuntimeError("ZSTD_createDCtx failed")

    cdef size_t chunkN = <size_t>(8<<20) if chunk == 0 else chunk
    cdef unsigned char* inbuf  = <unsigned char*>malloc(chunkN + 65536)
    cdef unsigned char* outbuf = <unsigned char*>malloc(chunkN + 65536)
    if inbuf == NULL or outbuf == NULL:
        if inbuf:  free(inbuf)
        if outbuf: free(outbuf)
        ZSTD_freeDCtx(dctx); fclose(fin); fclose(fout)
        raise MemoryError()

    cdef size_t rd = 0
    cdef size_t produced = 0
    cdef ZSTD_inBuffer  ib
    cdef ZSTD_outBuffer ob

    try:
        while True:
            rd = fread(inbuf, 1, chunkN, fin)
            if rd == 0:
                break
            ib.src = <const void*>inbuf
            ib.size = rd
            ib.pos = 0
            while ib.pos < ib.size:
                ob.dst = <void*>outbuf
                ob.size = chunkN + 65536
                ob.pos = 0
                produced = ZSTD_decompressStream(dctx, &ob, &ib)
                if ZSTD_isError(produced):
                    raise RuntimeError("ZSTD_decompressStream failed")
                if ob.pos:
                    if fwrite(outbuf, 1, ob.pos, fout) != ob.pos:
                        raise RuntimeError("write failed")
    finally:
        free(inbuf); free(outbuf)
        ZSTD_freeDCtx(dctx)
        fclose(fin); fclose(fout)

def blake3_of_decompressed(str src_path, int threads=0, size_t chunk=8<<20):
    """Разжать src_path (zst) в оперативной памяти и вернуть hex BLAKE3 всей разжатой последовательности."""
    import blake3
    h = blake3.blake3()
    _decompress_stream_file_to_hasher(src_path.encode("utf-8"), threads, chunk, h)
    return h.hexdigest()
