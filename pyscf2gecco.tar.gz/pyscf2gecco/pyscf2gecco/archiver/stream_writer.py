from __future__ import annotations

"""Streaming FCIDUMP v5 writer with text-based partitions.

This writer supports dynamic memory allocation and custom file names.

Usage scenario (three-stage workflow)::

    # 1. Initialize writer with custom filename and parameters
    writer = FCIDumpTextStreamWriter(
        dst_path="custom_name.bin",  # Can be any name, e.g., "FCIDUMP.bin"
        norb=norb,
        nelec=nelec,
        ms2=ms2,
        orbsym=orbsym,
        block_recs=262144,  # Optional: records per block
    )

    # 2. Write data blocks - memory is allocated dynamically
    # Split canonical FCIDUMP text body (lines after header) into chunks
    # and feed them in any order together with byte offsets inside the text
    for text_offset, chunk_bytes in tasks:
        writer.write_text_partition(text_offset, chunk_bytes)

    # 3. Finalize the file
    meta = writer.finalize(user_meta={...})

Chunks may arrive out of order; they are buffered until all preceding text
bytes are known. Each chunk is converted to v5 BODY blocks using the same
blocking rule as ``text_to_bin_compact_stream``. Offsets are specified in bytes
of canonical FCIDUMP text (exactly the number of bytes that precede the chunk).

Memory allocation is dynamic - the writer allocates only as much as needed
for the actual data being written, with no fixed pre-allocation.

FILE NAMING:
  - The dst_path parameter accepts any filename you provide.
  - For standard workflow, use "FCIDUMP.bin" which will become "FCIDUMP.bin.zst"
    when compressed by the archiver.
  - The archiver will automatically detect the v5 binary format regardless of name.

The file is fully compatible with all archiver functions (compress_fcidump_dir,
compress_project_dir, decompress_archive_fcidump_only, etc.).
"""

import json
import os
import struct
import tempfile
from typing import Dict, Iterable, List, Optional, Tuple

import numpy as np
from blake3 import blake3

try:  # compiled extension may not expose these symbols explicitly
    from fcidump_codec import MAGIC as V5_MAGIC  # type: ignore[attr-defined]
except (ImportError, AttributeError):
    V5_MAGIC = b"FCD5"

try:
    from fcidump_codec import BLOCK_RECS as _BLOCK_RECS  # type: ignore[attr-defined]
except (ImportError, AttributeError):
    _BLOCK_RECS = 262_144
# КРИТИЧЕСКАЯ ОПТИМИЗАЦИЯ: уменьшаем размер блока для экономии памяти при granularity > 0
# Для потоковой записи достаточно гораздо меньших блоков
DEFAULT_BLOCK_RECS = 4096  # Было 262144, теперь 4096 - экономия ~6 MB памяти

_HAS_PWRITE = hasattr(os, "pwrite")


def _pwrite(fd: int, payload: bytes, offset: int) -> None:
    if _HAS_PWRITE:  # type: ignore[truthy-bool]
        os.pwrite(fd, payload, offset)  # type: ignore[attr-defined]
        return
    current = os.lseek(fd, 0, os.SEEK_CUR)
    try:
        os.lseek(fd, offset, os.SEEK_SET)
        os.write(fd, payload)
    finally:
        os.lseek(fd, current, os.SEEK_SET)


# ---------------------------------------------------------------------------
# Helpers: text parsing and block encoding (mirrors Cython logic)


def _ensure_bytes(chunk: bytes | str) -> bytes:
    if isinstance(chunk, bytes):
        return chunk
    return chunk.encode("utf-8")


def _iter_records_from_text(text: str) -> Iterable[Tuple[float, int, int, int, int]]:
    """Parse FCIDUMP text lines into records. Optimized with early exit and minimal string ops."""
    for raw in text.splitlines():
        if not raw or raw.isspace():
            continue
        parts = raw.split()
        if len(parts) < 5:
            continue
        try:
            # Direct conversion without replace operations if possible
            token = parts[0]
            if 'd' in token or 'D' in token:
                token = token.replace("d", "e").replace("D", "E")
            val = float(token)
            # Use negative indexing directly
            i, j, k, l = int(parts[-4]), int(parts[-3]), int(parts[-2]), int(parts[-1])
        except (ValueError, IndexError):
            continue
        yield (val, i, j, k, l)


def _zigzag_encode(x: int) -> int:
    """ZigZag encoding for signed integers."""
    return (x << 1) ^ (x >> 63) if x < 0 else (x << 1)


def _uleb128_encode(u: int) -> bytes:
    """ULEB128 encoding. Optimized for small integers (most common case)."""
    if u < 128:
        return bytes([u])
    
    buf = bytearray()
    while u:
        b = u & 0x7F
        u >>= 7
        buf.append(b | 0x80 if u else b)
    return bytes(buf)


def _svarint_encode(x: int) -> bytes:
    return _uleb128_encode(_zigzag_encode(int(x)))


def _encode_block(records: List[Tuple[float, int, int, int, int]]) -> bytes:
    """Encode a block of records to binary format. Memory-optimized."""
    n = len(records)
    if n == 0:
        return b""

    # ОПТИМИЗАЦИЯ: используем более компактный буфер
    out = bytearray()
    
    pack_u32 = struct.Struct("<I").pack
    pack_f64 = struct.Struct("<d").pack

    first = records[0]
    val0, i0, j0, k0, l0 = first

    # Write header
    out.extend(pack_u32(n))
    out.extend(pack_u32(int(i0)))
    out.extend(pack_u32(int(j0)))
    out.extend(pack_u32(int(k0)))
    out.extend(pack_u32(int(l0)))
    
    # First record
    out.extend(pack_f64(float(val0)))
    out.extend(_svarint_encode(0) * 4)

    prev_i, prev_j, prev_k, prev_l = i0, j0, k0, l0
    for val, i, j, k, l in records[1:]:
        out.extend(pack_f64(float(val)))
        out.extend(_svarint_encode(int(i) - prev_i))
        out.extend(_svarint_encode(int(j) - prev_j))
        out.extend(_svarint_encode(int(k) - prev_k))
        out.extend(_svarint_encode(int(l) - prev_l))
        prev_i, prev_j, prev_k, prev_l = i, j, k, l

    return bytes(out)


# ---------------------------------------------------------------------------
# Chunk bookkeeping (no dataclass to reduce overhead)

class _PendingChunk:
    __slots__ = ('text', 'text_len')
    
    def __init__(self, text: bytes, text_len: int):
        self.text = text
        self.text_len = text_len


# ---------------------------------------------------------------------------
# Public writer


class FCIDumpTextStreamWriter:
    """Write FCIDUMP v5 binary file from text partitions.

    This writer now supports a three-stage workflow:
    1. __init__ - Initialize writer with parameters and allocate memory
    2. write_text_partition - Write data blocks
    3. finalize - Complete the file and cleanup

    Parameters
    ----------
    dst_bin: str
        Target file path (will be overwritten). Can be any name, e.g., "FCIDUMP.bin",
        "custom_name.bin", etc. The file extension should be ".bin" for binary format.
    norb, nelec, ms2: int
        Header values copied into metadata.
    orbsym: Iterable[int]
        Orbital symmetries.
    isym: int, optional
        Molpro symmetry ID for the wavefunction (default: 1).
    block_recs: int, optional
        Records per block (defaults to 262_144 to match C encoder).
    """

    def __init__(
        self,
        dst_bin: str,
        norb: int,
        nelec: int,
        ms2: int,
        orbsym: Iterable[int],
        *,
        isym: int = 1,
        block_recs: int | None = None,
    ) -> None:
        self.dst = os.fspath(dst_bin)
        self.norb = int(norb)
        self.nelec = int(nelec)
        self.ms2 = int(ms2)
        self.orbsym = [int(x) for x in orbsym]
        self.isym = int(isym)
        self.block_recs = int(block_recs or DEFAULT_BLOCK_RECS)
        if self.block_recs <= 0:
            raise ValueError("block_recs must be positive")

        os.makedirs(os.path.dirname(self.dst) or ".", exist_ok=True)

        # КРИТИЧЕСКАЯ ОПТИМИЗАЦИЯ: Прямая запись в финальный файл БЕЗ временного файла!
        # Резервируем место для заголовка (будем писать в конце)
        self._header_reserve = 65536  # 64 KB для заголовка (с запасом)
        self._fd = os.open(self.dst, os.O_RDWR | os.O_CREAT | os.O_TRUNC, 0o644)
        # Записываем placeholder для заголовка
        os.write(self._fd, b'\x00' * self._header_reserve)
        
        self._body_cursor = 0
        self._next_text_off = 0
        self._pending: Dict[int, _PendingChunk] = {}
        self._block_buffer: List[Tuple[float, int, int, int, int]] = []
        self._hash = blake3()
        self._records = 0
        self._finalized = False
        self._initialized = True
        self._blocks_since_gc = 0  # Счетчик для периодической сборки мусора

    # -- internal ---------------------------------------------------------

    def _emit_block(self) -> None:
        """Emit current block buffer to disk. Memory-optimized with direct write."""
        if not self._block_buffer:
            return
        data = _encode_block(self._block_buffer)
        if not data:
            return
        
        # КРИТИЧЕСКАЯ ОПТИМИЗАЦИЯ: Прямая запись в файл БЕЗ временного файла
        file_offset = self._header_reserve + self._body_cursor
        _pwrite(self._fd, data, file_offset)
        
        self._hash.update(data)
        self._body_cursor += len(data)
        
        # КРИТИЧЕСКАЯ ОПТИМИЗАЦИЯ: очищаем буфер и освобождаем память
        self._block_buffer.clear()
        # Создаём новый список для предотвращения фрагментации памяти
        self._block_buffer = []
        
        # Освобождаем data сразу
        data = None
        del data
        
        # КРИТИЧЕСКАЯ ОПТИМИЗАЦИЯ: более частая сборка мусора
        self._blocks_since_gc += 1
        if self._blocks_since_gc >= 5:  # Уменьшено с 10 до 5 для ещё более частого GC
            import gc
            gc.collect(generation=0)
            self._blocks_since_gc = 0

    def _consume_chunk(self, chunk: _PendingChunk) -> None:
        """Process text chunk and convert to records. Memory-optimized."""
        text_len_bytes = chunk.text_len  # Store before deleting
        text = chunk.text.decode("utf-8", errors="ignore")
        del chunk  # Free memory early
        
        for rec in _iter_records_from_text(text):
            self._block_buffer.append(rec)
            self._records += 1
            if len(self._block_buffer) == self.block_recs:
                self._emit_block()
        
        self._next_text_off += text_len_bytes
        del text  # Explicit deletion to help GC

    def _try_flush_ready(self) -> None:
        """Flush all ready chunks in order. Memory-optimized."""
        while self._next_text_off in self._pending:
            chunk = self._pending.pop(self._next_text_off)
            self._consume_chunk(chunk)
            # Help GC
            del chunk

    # -- public -----------------------------------------------------------
    
    def write_record_direct(self, value: float, i: int, j: int, k: int, l: int) -> None:
        """Directly write a single record without text conversion. Memory-efficient."""
        if self._finalized:
            raise RuntimeError("writer already finalized")
        
        self._block_buffer.append((value, i+1, j+1, k+1, l+1))
        self._records += 1
        if len(self._block_buffer) == self.block_recs:
            self._emit_block()

    def write_text_partition(self, text_offset: int, payload: bytes | str) -> None:
        """Write a text partition at the specified offset. Memory-optimized."""
        if self._finalized:
            raise RuntimeError("writer already finalized")
        text_offset = int(text_offset)
        if text_offset < 0:
            raise ValueError("text_offset must be non-negative")
        if text_offset in self._pending or text_offset < self._next_text_off:
            raise ValueError("overlapping or duplicate text_offset")

        text_bytes = _ensure_bytes(payload)
        self._pending[text_offset] = _PendingChunk(text_bytes, len(text_bytes))
        self._try_flush_ready()

    def finalize(self, *, user_meta: Optional[Dict] = None, remove_empty_lines: int = 0) -> Dict:
        """Finalize the FCIDUMP file and write header.
        
        Parameters
        ----------
        user_meta : dict, optional
            Additional user metadata to include in the file header.
        remove_empty_lines : int, optional
            Not used in this implementation.
        
        Returns
        -------
        dict
            Metadata dictionary with 'auto' and 'user' sections.
        """
        if self._finalized:
            raise RuntimeError("writer already finalized")

        if self._pending:
            missing = min(self._pending.keys())
            raise RuntimeError(f"missing text partition before offset {missing}")

        # Сбросить последний блок если есть
        if self._block_buffer:
            self._emit_block()

        body_hash = self._hash.hexdigest()
        
        # Build metadata
        auto = {
            "version": 5,
            "norb": self.norb,
            "nelec": self.nelec,
            "ms2": self.ms2,
            "isym": self.isym,
            "orbsym": self.orbsym,
            "records": self._records,
            "body_len": self._body_cursor,
            "hashes": {"blake3_body_hex": body_hash},
        }
        meta = {"auto": auto, "user": dict(user_meta or {})}
        hdr_json = json.dumps(meta, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
        
        if len(hdr_json) > self._header_reserve - 8:  # 8 bytes for magic + size
            raise RuntimeError(f"Header JSON ({len(hdr_json)} bytes) too large for reservation ({self._header_reserve - 8} bytes)")
        
        # КРИТИЧЕСКАЯ ОПТИМИЗАЦИЯ: Записываем заголовок в начало файла
        header = V5_MAGIC + struct.pack("<I", len(hdr_json)) + hdr_json
        # Дополняем нулями до header_reserve
        header_padded = header + b'\x00' * (self._header_reserve - len(header))
        _pwrite(self._fd, header_padded, 0)
        
        # Обрезаем файл до нужного размера (header + body)
        final_size = self._header_reserve + self._body_cursor
        os.ftruncate(self._fd, final_size)
        
        os.close(self._fd)
        self._finalized = True
        return meta

    # -- context manager convenience -------------------------------------

    def __enter__(self) -> "FCIDumpTextStreamWriter":
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        if not self._finalized:
            try:
                if hasattr(self, '_fd'):
                    os.close(self._fd)
                # Удаляем неполный файл при ошибке
                if os.path.exists(self.dst):
                    os.remove(self.dst)
            except OSError:
                pass
            self._pending.clear()


__all__ = ["FCIDumpTextStreamWriter"]
