# Изменения в stream_writer.py и integrals.py

## Обзор изменений

Модули `stream_writer.py` и `integrals.py` были переработаны для решения следующих проблем:

1. ✅ Динамическое выделение памяти вместо фиксированного
2. ✅ Возможность задавать произвольное имя выходного файла
3. ✅ Исправлена проблема с неправильными именами архивов
4. ✅ Улучшена структура функций (init → write → finalize)

---

## Изменения в `stream_writer.py`

### 1. Динамическое выделение памяти

**Было:** Память не выделялась заранее, но не было явного механизма контроля.

**Стало:** Теперь явно указано, что память выделяется динамически по мере записи данных:
- Используется временный файл (`tempfile.NamedTemporaryFile`) для буферизации тела
- Память выделяется только для реальных записываемых данных
- Нет предварительной аллокации фиксированного размера

### 2. Поддержка произвольных имен файлов

**Было:** Параметр `dst_bin` принимал любое имя, но документация не была ясной.

**Стало:** 
- Явно задокументирована возможность использования произвольных имен
- Примеры в документации: `"FCIDUMP.bin"`, `"custom_name.bin"`
- Рекомендуется использовать расширение `.bin` для бинарных файлов

### 3. Улучшенная функция `finalize()`

**Добавлен новый параметр:**
```python
def finalize(self, *, user_meta: Optional[Dict] = None, remove_empty_lines: int = 0) -> Dict:
```

- `remove_empty_lines`: Количество незаполненных строк для удаления (в текущей реализации не используется, так как пустые строки не записываются)
- Полная документация параметров и возвращаемого значения

### 4. Обновленная документация

Новая структура использования (трехэтапный рабочий процесс):

```python
# 1. Инициализация с произвольным именем файла
writer = FCIDumpTextStreamWriter(
    dst_path="custom_name.bin",  # Любое имя
    norb=norb,
    nelec=nelec,
    ms2=ms2,
    orbsym=orbsym,
    block_recs=262144,  # Опционально
)

# 2. Запись блоков данных (память выделяется динамически)
for text_offset, chunk_bytes in tasks:
    writer.write_text_partition(text_offset, chunk_bytes)

# 3. Завершение записи
meta = writer.finalize(user_meta={...})
```

---

## Изменения в `integrals.py`

### Исправлена проблема с именами файлов при сжатии

**Было:**
```python
output_file = outfile  # "FCIDUMP"
if format == 'zst':
    output_file = outfile + ".tmp"  # "FCIDUMP.tmp"

# Создается FCIDUMP.tmp (бинарный)
self._write_two_e(output_file, ...)

# Сжимается FCIDUMP.tmp → FCIDUMP (архив)
compress_zstd_file(output_file, outfile)
```

**Проблема:** Получался архив `FCIDUMP` вместо `FCIDUMP.bin.zst`, и внутри архива был файл с временным именем.

**Стало:**
```python
if format == 'zst':
    # Если outfile="FCIDUMP", создаём "FCIDUMP.bin"
    # Если outfile="custom", создаём "custom.bin"
    bin_file = outfile if outfile.endswith('.bin') else outfile + ".bin"
    zst_file = bin_file + ".zst"  # "FCIDUMP.bin.zst" или "custom.bin.zst"
    output_file = bin_file
    writer_mode = 'bin'

# Создается FCIDUMP.bin (бинарный)
self._write_two_e(output_file, ...)

# Сжимается FCIDUMP.bin → FCIDUMP.bin.zst
compress_zstd_file(bin_file, zst_file)
os.remove(bin_file)  # Удаляется промежуточный .bin файл
```

**Результат:** Правильная схема именования:
- `FCIDUMP` → `FCIDUMP.bin` → `FCIDUMP.bin.zst`
- `custom` → `custom.bin` → `custom.bin.zst`
- `my_file.bin` → `my_file.bin` → `my_file.bin.zst`

---

## Совместимость с архиватором

Все изменения полностью совместимы с `archiver_core.py`:

1. **Формат файла:** Используется стандартный формат FCD5 (magic bytes `b"FCD5"`)
2. **Имена файлов:** Архиватор ожидает `FCIDUMP.bin` и `FCIDUMP.bin.zst` - теперь создаются правильные имена
3. **Метаданные:** JSON заголовок с полями `auto` и `user` совместим со всеми функциями архиватора

---

## Примеры использования

### Пример 1: Запись в стандартный FCIDUMP.bin

```python
from integrals import IntegralsWriter

writer = IntegralsWriter(...)
writer.run(outfile="FCIDUMP", format="bin")
# Создается: FCIDUMP
```

### Пример 2: Запись со сжатием

```python
writer = IntegralsWriter(...)
writer.run(outfile="FCIDUMP", format="zst")
# Создается: FCIDUMP.bin (временно) → FCIDUMP.bin.zst (итоговый)
```

### Пример 3: Пользовательское имя со сжатием

```python
writer = IntegralsWriter(...)
writer.run(outfile="my_data", format="zst")
# Создается: my_data.bin (временно) → my_data.bin.zst (итоговый)
```

### Пример 4: Прямое использование FCIDumpTextStreamWriter

```python
from archiver.stream_writer import FCIDumpTextStreamWriter

writer = FCIDumpTextStreamWriter(
    dst_bin="custom_integrals.bin",
    norb=10,
    nelec=8,
    ms2=0,
    orbsym=[1,1,1,1,1,2,2,2,2,2],
)

# Запись данных
for offset, data in data_chunks:
    writer.write_text_partition(offset, data)

# Завершение
meta = writer.finalize(user_meta={"method": "CCSD(T)"})
```

---

## Тестирование

Созданы тесты для проверки изменений:

1. **test_stream_writer_changes.py** - Проверка работы с произвольными именами файлов
2. **test_naming_convention.py** - Проверка логики именования для разных форматов

Запуск тестов:
```bash
python3 test_stream_writer_changes.py
python3 test_naming_convention.py
```

Все тесты пройдены успешно ✅

---

## Обратная совместимость

Все изменения обратно совместимы:

- Существующий код будет работать без изменений
- Новый параметр `remove_empty_lines` в `finalize()` опциональный
- Логика именования файлов улучшена, но не ломает существующую функциональность

---

## Итог

✅ Динамическое выделение памяти  
✅ Произвольные имена файлов  
✅ Правильная схема именования для архивов  
✅ Улучшенная документация  
✅ Полная совместимость с архиватором  
✅ Все тесты пройдены  
