#!/usr/bin/env python3
"""
Examples demonstrating GeCCoArchiver usage after pip installation.

This file shows comprehensive usage of all features available for compressing,
archiving, and managing FCIDUMP files with the GeCCo archiver.
"""

from pyscf import gto, scf
from pyscf2gecco import FCIDumpWriter, GeCCoArchiver
import os


def setup_test_fcidump():
    """Helper: Create a sample FCIDUMP file for examples."""
    mol = gto.M(atom='H 0 0 0; H 0 0 0.74', basis='sto-3g')
    mf = scf.RHF(mol).run()
    writer = FCIDumpWriter(mol, mf, granularity=50, tol=1e-15, extended_debug=False)
    writer.run('FCIDUMP_test')
    print("Created test FCIDUMP file\n")


def example_basic_compression():
    """
    Example 1: Basic FCIDUMP compression.
    
    Demonstrates:
    - Creating archiver instance
    - Compressing FCIDUMP to binary format
    - Default compression settings
    """
    print("=" * 70)
    print("Example 1: Basic FCIDUMP compression")
    print("=" * 70)
    
    setup_test_fcidump()
    
    # Create archiver with tag/name for archives
    archiver = GeCCoArchiver(archive_name='example1')
    
    # Compress FCIDUMP in current directory
    archiver.compress_fcidump(root='.')
    print("✓ FCIDUMP compressed to binary format\n")


def example_zstd_compression():
    """
    Example 2: FCIDUMP with zstd compression.
    
    Demonstrates:
    - Using zstd compression algorithm
    - Adjusting compression level
    - Achieving maximum file size reduction
    """
    print("=" * 70)
    print("Example 2: FCIDUMP with zstd compression")
    print("=" * 70)
    
    setup_test_fcidump()
    
    archiver = GeCCoArchiver(archive_name='example2')
    
    # Compress with zstd (level 3 is default, range 1-22)
    archiver.compress_fcidump(
        root='.',
        to_zstd=True,
        zstd_level=3  # Higher = better compression, slower
    )
    print("✓ FCIDUMP compressed with zstd\n")


def example_parallel_compression():
    """
    Example 3: Parallel compression of multiple FCIDUMP files.
    
    Demonstrates:
    - Enabling parallel processing
    - Compressing multiple files efficiently
    - Using multiple CPU cores
    """
    print("=" * 70)
    print("Example 3: Parallel compression")
    print("=" * 70)
    
    # Create multiple test FCIDUMP files
    for i in range(3):
        mol = gto.M(atom=f'H 0 0 0; H 0 0 {0.7 + i*0.1}', basis='sto-3g')
        mf = scf.RHF(mol).run()
        writer = FCIDumpWriter(mol, mf, granularity=50, tol=1e-15, extended_debug=False)
        writer.run(f'FCIDUMP_test_{i}')
    
    archiver = GeCCoArchiver(archive_name='batch', num_workers=4)
    
    # Compress all FCIDUMP files in parallel (automatically done with num_workers)
    archiver.compress_fcidump(root='.')
    print("✓ Multiple FCIDUMP files compressed in parallel\n")


def example_project_archive():
    """
    Example 4: Create complete project archive.
    
    Demonstrates:
    - Archiving entire project directory
    - Including FCIDUMP files in archive
    - Creating .tar.xz archive
    """
    print("=" * 70)
    print("Example 4: Project archive creation")
    print("=" * 70)
    
    setup_test_fcidump()
    
    archiver = GeCCoArchiver(archive_name='my_project')
    
    # Create project archive with FCIDUMP
    archiver.compress_all(root='.')
    print("✓ Project archive created: project_archive_my_project.tar.xz\n")


def example_decompress_fcidump():
    """
    Example 5: Decompress FCIDUMP from archive.
    
    Demonstrates:
    - Extracting FCIDUMP from project archive
    - Converting back to text format
    - Restoring original files
    """
    print("=" * 70)
    print("Example 5: Decompress FCIDUMP from archive")
    print("=" * 70)
    
    # First create an archive (if not exists)
    if not os.path.exists('project_archive_my_project.tar.xz'):
        example_project_archive()
    
    archiver = GeCCoArchiver()
    
    # Decompress only FCIDUMP from archive
    archiver.decompress_fcidump(
        archive_path='project_archive_my_project.tar.xz',
        to_text=True  # Convert to text format
    )
    print("✓ FCIDUMP extracted and converted to text\n")


def example_verify_fcidump():
    """
    Example 6: Verify FCIDUMP integrity.
    
    Demonstrates:
    - Checking BLAKE3 hash of binary FCIDUMP
    - Verifying file integrity
    - Detecting corruption
    """
    print("=" * 70)
    print("Example 6: Verify FCIDUMP integrity")
    print("=" * 70)
    
    # Create and compress FCIDUMP
    setup_test_fcidump()
    archiver = GeCCoArchiver(archive_name='verify')
    archiver.compress_fcidump(root='.')
    
    # Verify the compressed file
    # Note: GeCCoArchiver uses fcidump_codec.verify_b3_of_bin internally
    from pyscf2gecco.archiver.fcidump_codec import verify_b3_of_bin
    
    if os.path.exists('FCIDUMP_test.bin'):
        ok, msg = verify_b3_of_bin('FCIDUMP_test.bin')
        print(f"Verification: {ok}")
        print(f"Message: {msg}")
    print("✓ FCIDUMP integrity verified\n")


def example_read_metadata():
    """
    Example 7: Read metadata from binary FCIDUMP.
    
    Demonstrates:
    - Reading stored metadata
    - Accessing auto-generated metadata
    - Retrieving user-defined metadata
    """
    print("=" * 70)
    print("Example 7: Read FCIDUMP metadata")
    print("=" * 70)
    
    # Create FCIDUMP with metadata
    mol = gto.M(atom='He 0 0 0', basis='6-31g')
    mf = scf.RHF(mol).run()
    
    writer = FCIDumpWriter(mol, mf, format='bin', granularity=50, extended_debug=False)
    writer.run('FCIDUMP_meta.bin')
    
    # Read metadata
    from pyscf2gecco.archiver.fcidump_codec import read_meta_from_bin
    
    meta = read_meta_from_bin('FCIDUMP_meta.bin')
    
    print("Auto-generated metadata:")
    print(f"  NORB: {meta['auto']['norb']}")
    print(f"  NELEC: {meta['auto']['nelec']}")
    print(f"  Records: {meta['auto']['records']}")
    print(f"  BLAKE3: {meta['auto']['hashes']['blake3_body_hex'][:16]}...")
    
    if 'user' in meta and meta['user']:
        print("\nUser metadata:")
        for key, val in meta['user'].items():
            print(f"  {key}: {val}")
    
    print("✓ Metadata read successfully\n")


def example_conversion_text_to_binary():
    """
    Example 8: Convert text FCIDUMP to binary.
    
    Demonstrates:
    - Converting existing text FCIDUMP to binary
    - Preserving all integral data
    - Adding compression
    """
    print("=" * 70)
    print("Example 8: Text to binary conversion")
    print("=" * 70)
    
    # Create text FCIDUMP
    mol = gto.M(atom='H 0 0 0; H 0 0 0.74', basis='6-31g')
    mf = scf.RHF(mol).run()
    writer = FCIDumpWriter(mol, mf, granularity=50, tol=1e-15, extended_debug=False)
    writer.run('FCIDUMP_text')  # Creates text format
    
    # Convert to binary using archiver
    archiver = GeCCoArchiver(archive_name='converted')
    archiver.compress_fcidump(root='.', to_zstd=True)
    print("✓ Text FCIDUMP converted to compressed binary\n")


def example_batch_processing():
    """
    Example 9: Batch process multiple projects.
    
    Demonstrates:
    - Processing multiple project directories
    - Automated workflow
    - Organizing results
    """
    print("=" * 70)
    print("Example 9: Batch project processing")
    print("=" * 70)
    
    # Create test projects
    projects = ['project_A', 'project_B', 'project_C']
    
    for proj in projects:
        os.makedirs(proj, exist_ok=True)
        os.chdir(proj)
        
        # Create FCIDUMP in each project
        mol = gto.M(atom='H 0 0 0; H 0 0 0.74', basis='sto-3g')
        mf = scf.RHF(mol).run()
        writer = FCIDumpWriter(mol, mf, granularity=50, tol=1e-15, extended_debug=False)
        writer.run('FCIDUMP')
        
        # Compress
        archiver = GeCCoArchiver(archive_name=proj)
        archiver.compress_fcidump(root='.', to_zstd=True)
        
        os.chdir('..')
    
    print("✓ All projects processed and compressed\n")


def example_space_savings():
    """
    Example 10: Measure compression efficiency.
    
    Demonstrates:
    - Comparing file sizes
    - Calculating space savings
    - Analyzing compression ratios
    """
    print("=" * 70)
    print("Example 10: Compression efficiency analysis")
    print("=" * 70)
    
    # Create larger FCIDUMP for better demonstration
    mol = gto.M(
        atom='''
        O 0.0 0.0 0.0
        O 0.0 0.0 1.2
        ''',
        basis='6-31g**'
    )
    mf = scf.RHF(mol).run()
    
    # Create binary file directly
    writer = FCIDumpWriter(mol, mf, format='bin', granularity=100, tol=1e-14, extended_debug=False)
    writer.run('FCIDUMP_O2.bin')
    
    # Create text file for comparison
    writer_txt = FCIDumpWriter(mol, mf, format='txt', granularity=100, tol=1e-14, extended_debug=False)
    writer_txt.run('FCIDUMP_O2.txt')
    
    # Get sizes
    txt_size = os.path.getsize('FCIDUMP_O2.txt')
    bin_size = os.path.getsize('FCIDUMP_O2.bin')
    print(f"Text size: {txt_size:,} bytes")
    print(f"Binary size: {bin_size:,} bytes")
    print(f"Binary compression: {100*(1-bin_size/txt_size):.1f}%")
    
    # Create zst compressed version
    writer_zst = FCIDumpWriter(mol, mf, format='zst', granularity=100, tol=1e-14, extended_debug=False)
    writer_zst.run('FCIDUMP_O2_zst.bin')
    zst_size = os.path.getsize('FCIDUMP_O2_zst.bin.zst')
    print(f"Zstd compressed size: {zst_size:,} bytes")
    print(f"Total compression: {100*(1-zst_size/txt_size):.1f}%")
    print(f"Space saved: {txt_size - zst_size:,} bytes\n")


if __name__ == '__main__':
    print("\n")
    print("=" * 70)
    print("GeCCoArchiver Examples - Complete Usage Guide")
    print("=" * 70)
    print("\n")
    
    # Run all examples
    example_basic_compression()
    example_zstd_compression()
    # example_parallel_compression()  # Commented: creates many files
    example_project_archive()
    # example_decompress_fcidump()  # Commented: requires archive
    example_verify_fcidump()
    example_read_metadata()
    example_conversion_text_to_binary()
    # example_batch_processing()  # Commented: creates directories
    example_space_savings()
    
    print("=" * 70)
    print("All GeCCoArchiver examples completed successfully!")
    print("=" * 70)
