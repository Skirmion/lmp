# Package Structure Summary

## Overview

`pyscf2gecco` is a Python package for converting PySCF molecular integrals to FCIDUMP format optimized for GECCO quantum chemistry software, with compression and archiving capabilities.

## Directory Structure

```
pyscf2gecco/
│
├── __init__.py                    # Package entry point (exports FCIDumpWriter, GeCCoArchiver)
├── setup.py                       # Installation script
├── pyproject.toml                 # Build system configuration
├── MANIFEST.in                    # Package data specification
├── LICENSE                        # MIT License
├── README_PACKAGE.md              # User documentation
├── INSTALL.md                     # Installation guide
├── example.py                     # Usage examples
│
├── fc_gen/                        # FCIDUMP generation module
│   ├── __init__.py               # Exports FCIDumpWriter
│   ├── fc_gen.py                 # Main class: FCIDumpWriter
│   ├── fc_utils.py               # Helper functions and preprocessing
│   ├── fmt.py                    # FCIDUMP formatting utilities
│   ├── integrals_one_e.py        # One-electron integral processing
│   ├── integrals_two_e.py        # Two-electron integral processing
│   └── metadata_utils.py         # Binary metadata handling
│
└── archiver/                      # FCIDUMP compression and archiving
    ├── __init__.py               # Exports GeCCoArchiver
    ├── gecco_archiver.py         # Main class: GeCCoArchiver
    ├── archiver_core.py          # Core compression/decompression
    ├── fcidump_codec.pyx         # Cython: binary codec
    ├── fcidump_codec.py          # Python fallback
    ├── zstd_codec.pyx            # Cython: Zstandard compression
    ├── stream_writer.py          # Streaming FCIDUMP writer
    ├── meta_core.py              # Metadata utilities
    ├── compressor_utils.py       # Compression utilities
    └── setup.py                  # Cython extension build
```

## Main Components

### 1. FCIDumpWriter (fc_gen/fc_gen.py)

High-level class for converting PySCF calculations to FCIDUMP format.

**Key features:**
- Automatic molecular orbital extraction from PySCF methods
- Support for natural orbitals (CASSCF)
- Custom MO coefficient input
- Frozen core approximation
- Additional integral operators
- Multiple output formats: text, binary, compressed
- Memory-efficient block processing

**Dependencies:**
- `fc_utils.py`: Helper functions, MO processing, active space construction
- `integrals_one_e.py`: One-electron integral writing
- `integrals_two_e.py`: Two-electron integral writing
- `metadata_utils.py`: Metadata for binary format
- `fmt.py`: Formatting constants and utilities

### 2. GeCCoArchiver (archiver/gecco_archiver.py)

High-level interface for FCIDUMP compression and project archiving.

**Key features:**
- Binary compression with BLAKE3 checksums
- Zstandard streaming compression
- Parallel processing support
- Project-wide archiving with tar.xz
- Metadata preservation and validation
- Decompression with integrity checks

**Dependencies:**
- `archiver_core.py`: Core compression functions
- `fcidump_codec.pyx`: Fast binary encoding/decoding
- `zstd_codec.pyx`: Zstandard compression bindings
- `meta_core.py`: Metadata handling
- `stream_writer.py`: Streaming FCIDUMP writer

## Module Interfaces

### fc_gen module

```python
from pyscf2gecco import FCIDumpWriter

writer = FCIDumpWriter(
    mol,                    # PySCF Mole object
    method,                 # PySCF method (SCF, CASSCF, etc.)
    granularity=50,         # Block size for integral processing
    tol=1e-15,             # Integral threshold
    natorb=False,          # Use natural orbitals
    frozen_indices=None,    # Frozen orbital indices
    mo_coeff=None,         # Custom MO coefficients
    add_ops=None           # Additional operators
)

writer.run(
    fcidump_name,          # Output filename
    binary=False,          # Binary format
    compress=False,        # Compress with Zstandard
    metadata=None          # Custom metadata dictionary
)
```

### archiver module

```python
from pyscf2gecco import GeCCoArchiver

archiver = GeCCoArchiver()

# Compress FCIDUMP files
archiver.compress_fcidump(
    root_dir,              # Directory to process
    parallel=True,         # Use parallel processing
    depth_min=0,           # Minimum directory depth
    depth_max=10          # Maximum directory depth
)

# Create project archive
archiver.compress_all(
    root_dir,              # Project directory
    tag='v1.0',           # Archive tag
    archive_name=None     # Custom archive name
)

# Extract archive
archiver.decompress_all(
    archive_path,          # Path to archive
    output_dir,           # Output directory
    verbose=True          # Verbose output
)
```

## File Formats

### Text FCIDUMP
Standard FCIDUMP format with header and integral data.

### Binary FCIDUMP (.bin)
Compact binary format with:
- MOLPRO header
- Integral data in binary
- BLAKE3 checksum
- Metadata section

### Compressed FCIDUMP (.zst)
Zstandard compressed binary FCIDUMP with streaming support.

### Project Archive (.tar.xz)
LZMA-compressed tarball containing:
- Compressed FCIDUMP files
- Project metadata
- Directory structure
- Checksums

## Testing

Run example scripts:
```bash
python example.py
```

Check specific functionality:
```bash
cd archiver
python EXAMPLES.py
```

## Development

### Adding new features to FCIDumpWriter:
1. Modify `fc_gen.py` for main logic
2. Add helper functions to `fc_utils.py`
3. Update integral processing in `integrals_one_e.py` or `integrals_two_e.py`
4. Update documentation and examples

### Adding new archiver features:
1. Modify `gecco_archiver.py` for high-level API
2. Add core functions to `archiver_core.py`
3. Update Cython extensions if needed
4. Update documentation

## Notes

- All memory management code is preserved and should not be modified
- Explicit parameter passing is used throughout (no kwargs)
- All public functions have comprehensive English docstrings
- PEP8 formatting is followed
- Thread-safe and memory-efficient implementations
