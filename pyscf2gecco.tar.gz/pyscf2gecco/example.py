"""
Example usage of pyscf2gecco package.

This example demonstrates how to:
1. Create a molecule and run PySCF calculation
2. Generate FCIDUMP file using FCIDumpWriter
3. Compress the FCIDUMP file using GeCCoArchiver
"""

from pyscf import gto, scf
from pyscf2gecco import FCIDumpWriter, GeCCoArchiver


def example_basic_fcidump():
    """Basic FCIDUMP generation from RHF calculation."""
    print("=" * 60)
    print("Example 1: Basic FCIDUMP generation")
    print("=" * 60)
    
    # Create H2 molecule
    mol = gto.M(
        atom='H 0 0 0; H 0 0 0.74',
        basis='sto-3g',
        symmetry=True
    )
    
    # Run RHF calculation
    mf = scf.RHF(mol).run()
    
    # Generate FCIDUMP file
    writer = FCIDumpWriter(
        mol=mol,
        method=mf,
        granularity=50,
        tol=1e-15
    )
    writer.run('FCIDUMP_H2')
    print("FCIDUMP_H2 generated successfully\n")


def example_compressed_fcidump():
    """Generate compressed FCIDUMP file."""
    print("=" * 60)
    print("Example 2: Compressed FCIDUMP generation")
    print("=" * 60)
    
    # Create H2O molecule
    mol = gto.M(
        atom='''
        O  0.0000  0.0000  0.0000
        H  0.7572  0.5865  0.0000
        H -0.7572  0.5865  0.0000
        ''',
        basis='6-31g',
        symmetry=True
    )
    
    # Run RHF calculation
    mf = scf.RHF(mol).run()
    
    # Generate compressed FCIDUMP
    writer = FCIDumpWriter(
        mol=mol,
        method=mf,
        granularity=100,
        tol=1e-14
    )
    writer.run('FCIDUMP_H2O', binary=True, compress=True)
    print("FCIDUMP_H2O.zst generated successfully\n")


def example_frozen_core():
    """FCIDUMP with frozen core approximation."""
    print("=" * 60)
    print("Example 3: FCIDUMP with frozen core")
    print("=" * 60)
    
    # Create CH4 molecule
    mol = gto.M(
        atom='''
        C  0.0000  0.0000  0.0000
        H  0.6276  0.6276  0.6276
        H -0.6276 -0.6276  0.6276
        H -0.6276  0.6276 -0.6276
        H  0.6276 -0.6276 -0.6276
        ''',
        basis='cc-pvdz'
    )
    
    # Run RHF calculation
    mf = scf.RHF(mol).run()
    
    # Freeze core orbitals (1s of C)
    writer = FCIDumpWriter(
        mol=mol,
        method=mf,
        frozen_indices=[0],  # Freeze first orbital
        granularity=50,
        tol=1e-15
    )
    writer.run('FCIDUMP_CH4_frozen')
    print("FCIDUMP_CH4_frozen generated with frozen core\n")


def example_archiver():
    """Compress and archive FCIDUMP files."""
    print("=" * 60)
    print("Example 4: Archiving FCIDUMP files")
    print("=" * 60)
    
    archiver = GeCCoArchiver()
    
    # Compress FCIDUMP files in current directory
    print("Compressing FCIDUMP files...")
    archiver.compress_fcidump('.', parallel=False)
    
    print("\nArchiver operations completed\n")


if __name__ == '__main__':
    # Run examples
    example_basic_fcidump()
    example_compressed_fcidump()
    example_frozen_core()
    example_archiver()
    
    print("=" * 60)
    print("All examples completed successfully!")
    print("=" * 60)
