# Cython Auto-Build Configuration

## Changes Made

### 1. Moved Cython to Main Dependencies

**setup.py:**
```python
install_requires=[
    "numpy>=1.20.0",
    "pyscf>=2.0.0",
    "psutil>=5.8.0",
    "Cython>=0.29.0",  # ← Moved from extras_require
],
```

**pyproject.toml:**
```toml
dependencies = [
    "numpy>=1.20.0",
    "pyscf>=2.0.0",
    "psutil>=5.8.0",
    "Cython>=0.29.0",  # ← Moved from optional-dependencies
]
```

### 2. Fixed Import Path

**pyscf2gecco/archiver/fcidump_codec.py:**
```python
# Before:
from fmt import _line as fmt_line, _fmt as fmt_number

# After:
from ..fc_gen.fmt import _line as fmt_line, _fmt as fmt_number
```

### 3. Removed Symbolic Link

Deleted: `pyscf2gecco/archiver/fmt.py` (symlink)

The `fmt.py` module now resides only in `pyscf2gecco/fc_gen/` and is imported using relative imports.

### 4. Added Graceful Fallback

**setup.py:**
```python
ext_modules = []
try:
    from Cython.Build import cythonize
    extensions = [...]
    ext_modules = cythonize(extensions, language_level="3")
    print("Cython extensions will be compiled for optimal performance.")
except Exception as e:
    print(f"Warning: Cython compilation not available: {e}")
    print("Package will be installed without Cython acceleration.")
    ext_modules = []
```

## Result

✓ Cython compiles **automatically** during `pip install .`
✓ No need for `--install-option` or special flags
✓ Graceful fallback if compilation fails
✓ All modules import correctly
✓ Package ready for PyPI distribution

## Testing

```bash
# Clean install
pip uninstall -y pyscf2gecco
rm -rf build dist *.egg-info
pip install .

# Verify
python3 -c "from pyscf2gecco.archiver import fcidump_codec, zstd_codec; print('✓ OK')"
```

## Installation Commands

```bash
# Standard installation
pip install .

# Development mode
pip install -e .

# From PyPI (when published)
pip install pyscf2gecco
```

All three methods will automatically compile Cython extensions!
