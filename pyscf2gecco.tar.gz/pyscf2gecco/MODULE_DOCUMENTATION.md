# pyscf2gecco Package - Complete Module Structure

## Package Overview

The `pyscf2gecco` package provides comprehensive tools for working with GeCCo quantum chemistry software:

1. **FCIDUMP Generation**: Convert PySCF molecular integrals to FCIDUMP format
2. **File Compression**: Efficient archiving of FCIDUMP files
3. **Pseudopotential Loading**: ECP/GRECP pseudopotential utilities
4. **Input Generation**: Create GeCCo/IC-MRCC calculation input files

## Installation

```bash
# Install from source
pip install -e .

# Or install with archiver support (requires Cython)
pip install -e ".[archiver]"
```

## Package Structure

```
pyscf2gecco/
├── __init__.py                  # Main package interface
├── fc_gen/                      # FCIDUMP generation module
│   ├── __init__.py
│   ├── fc_gen.py               # FCIDumpWriter class (main API)
│   ├── fc_utils.py             # Helper utilities
│   ├── integrals_one_e.py      # One-electron integrals
│   ├── integrals_two_e.py      # Two-electron integrals
│   ├── fmt.py                  # Format utilities
│   └── metadata_utils.py       # Metadata handling
├── archiver/                    # Compression and archiving
│   ├── __init__.py
│   ├── gecco_archiver.py       # GeCCoArchiver class (main API)
│   ├── stream_writer.py        # Streaming I/O
│   ├── fcidump_codec.pyx       # Binary encoding (Cython)
│   └── zstd_codec.pyx          # Compression (Cython)
├── ecp/                         # Pseudopotential module
│   ├── __init__.py
│   ├── load_ecp.py             # ECP loading and diagnostics
│   └── pseudos/                # Pseudopotential database
└── gen_inp/                     # GeCCo input generation
    ├── __init__.py
    ├── gecco_input_writer.py   # GeccoInputBuilder class (main API)
    ├── sym.py                  # Symmetry utilities
    ├── shell_type.py           # Orbital space construction
    ├── memory_utils.py         # Memory estimation
    ├── keyword_patch.py        # Input file patching
    └── templates/              # Input templates
```

## Main API Classes

### 1. FCIDumpWriter

**Purpose**: Convert PySCF calculations to FCIDUMP format.

**Key Parameters**:
- `mol`: PySCF Mole object
- `method`: PySCF SCF/MCSCF object
- `granularity`: Block size for two-electron integrals (default: 50)
- `tol`: Integral threshold (default: 1e-15)
- `frozen_indices`: Orbital indices to freeze
- `mo_coeff`: Custom MO coefficients (optional)
- `natorb`: Use natural orbitals (bool, default: False)
- `add_one_e`: Additional one-electron operators (dict)
- `add_two_e`: Additional two-electron operators (dict)

**Methods**:
- `run(filename, binary=False, compress=False)`: Generate FCIDUMP file

**Example**:
```python
from pyscf import gto, scf
from pyscf2gecco import FCIDumpWriter

mol = gto.M(atom='H 0 0 0; H 0 0 0.74', basis='sto-3g')
mf = scf.RHF(mol).run()

writer = FCIDumpWriter(mol, mf, granularity=50, tol=1e-15)
writer.run('FCIDUMP', binary=True, compress=True)
```

### 2. GeCCoArchiver

**Purpose**: Compress and archive FCIDUMP files.

**Methods**:
- `compress_fcidump(directory, parallel=True)`: Compress FCIDUMP files
- `decompress_fcidump(filename)`: Decompress archived files
- `verify_integrity(filename)`: Check file integrity

**Example**:
```python
from pyscf2gecco import GeCCoArchiver

archiver = GeCCoArchiver()
archiver.compress_fcidump('.', parallel=True)
```

### 3. GeccoInputBuilder

**Purpose**: Generate GeCCo/IC-MRCC input files with automatic symmetry and orbital space detection.

**Key Parameters**:
- `name`: Template name
- `mol`: PySCF Mole object
- `wf`: PySCF wavefunction object
- `group`: Point group (auto-detected if None)
- `core_idx`: Core orbital indices
- `active_idx`: Active orbital indices
- `frozen_idx`: Frozen orbital indices
- `deleted_idx`: Deleted orbital indices
- `mem_gib`: Memory in GiB (auto-detected if None)
- `method_MR_maxexc`: Maximum excitation level
- `calc_solve_maxiter`: Solver max iterations
- `patches`: Additional keyword patches

**Methods**:
- `write()`: Generate and save input file

**Example**:
```python
from pyscf import gto, mcscf
from pyscf2gecco import GeccoInputBuilder

mol = gto.M(atom='O 0 0 0; H 0.75 0.59 0; H -0.75 0.59 0',
            basis='6-31g', symmetry='c2v')
mc = mcscf.CASSCF(mol.RHF().run(), 6, 8).run()

builder = GeccoInputBuilder(
    name='h2o_casscf',
    mol=mol,
    wf=mc,
    group='c2v',
    templates_dir='templates'
)
builder.write()
```

## Submodule: ecp

**Purpose**: Load and validate GRECP/QED pseudopotentials.

**Functions**:
- `load_pseudopotential(code, directory='pseudos', normalize=True)`: Load pseudopotential file
- `help_pseudopotential(code=None)`: Show available pseudopotentials or file header
- `diagnose_pseudopotentials(directory='pseudos', codes=None)`: Run diagnostics
- `ensure_full_grpp_format(text)`: Normalize pseudopotential format

**Example**:
```python
from pyscf2gecco import ecp

# List available pseudopotentials
ecp.help_pseudopotential()

# Load a specific pseudopotential
pseudo_text = ecp.load_pseudopotential("U60", debug=True)

# Run diagnostics
ecp.diagnose_pseudopotentials(codes={"U60", "Th28"})
```

## Submodule: gen_inp

**Purpose**: Utilities for GeCCo input generation.

**Functions**:
- `molpro_irrep(wf, mol)`: Get Molpro irrep ID and label
- `spin_info(wf, mol)`: Extract spin quantum numbers
- `make_orb_lines(nelec, mol, wf, ...)`: Generate orbital space lines
- `guess_mem_words(verbose=True)`: Estimate system RAM
- `apply_patches(lines, patches)`: Apply keyword patches to input

**Example**:
```python
from pyscf2gecco import gen_inp

# Get symmetry information
sym_id, sym_label = gen_inp.molpro_irrep(wf, mol)
ms, mult = gen_inp.spin_info(wf, mol)

# Estimate available memory
mem_words = gen_inp.guess_mem_words()
```

## Advanced Features

### Custom MO Coefficients

```python
# Provide custom MO coefficients
custom_mo = my_orbital_transformation(mf.mo_coeff)
writer = FCIDumpWriter(mol, mf, mo_coeff=custom_mo)
writer.run('FCIDUMP_custom')
```

### Additional Operators

```python
# Add custom one-electron and two-electron operators
import numpy as np

# Additional one-electron operator
add_one_e = {
    'custom_op': np.random.rand(nao, nao)
}

# Additional two-electron operator (full or sparse format)
add_two_e = {
    'custom_eris': {
        (i, j, k, l): value
        for i, j, k, l, value in custom_integrals
    }
}

writer = FCIDumpWriter(
    mol, mf,
    add_one_e=add_one_e,
    add_two_e=add_two_e
)
writer.run('FCIDUMP_custom_ops')
```

### Natural Orbitals

```python
# Use natural orbitals from CASSCF
from pyscf import mcscf

mc = mcscf.CASSCF(mf, ncas, nelecas).run()
writer = FCIDumpWriter(mol, mc, natorb=True)
writer.run('FCIDUMP_natorb')
```

### Flexible Input Patches

```python
# Add custom keywords to GeCCo input
patches = [
    {"block": "method", "path": ["MR"], "param": "maxexc=4"},
    {"block": "calculate", "path": ["solve"], "param": "maxiter=200"},
]

builder = GeccoInputBuilder(
    name='calculation',
    mol=mol,
    wf=wf,
    patches=patches
)
builder.write()
```

## Testing

```bash
# Test package imports
python3 test_import.py

# Run examples
python3 example.py
```

## Requirements

**Core Dependencies**:
- Python >= 3.8
- numpy >= 1.20.0
- pyscf >= 2.0.0
- psutil >= 5.8.0

**Optional Dependencies**:
- Cython >= 0.29.0 (for archiver module)
- libzstd (for compression)
- libgrpp (for ECP module)

## File Formats

### FCIDUMP Format

The package supports three output formats:

1. **Text** (`.fcidump`): Standard text format
2. **Binary** (`.bin`): Compact binary encoding
3. **Compressed** (`.zst`): Zstandard-compressed binary

### Additional Operators Format

Additional operators can be provided as:

```python
# Sparse format (recommended for large systems)
add_ops = {
    'operator_name': {
        (i, j, k, l): value,  # Four-index integral
        ...
    }
}

# Dense format (for small systems)
add_ops = {
    'operator_name': np.array(...)  # Shape (nmo, nmo, nmo, nmo)
}
```

## Performance Tips

1. **Granularity**: Larger values (50-200) for better memory efficiency
2. **Threshold**: Use 1e-15 for high accuracy, 1e-12 for faster generation
3. **Compression**: Reduces file size by 50-90% with minimal overhead
4. **Binary format**: 2-3x faster I/O compared to text format
5. **Parallel archiving**: Significant speedup for multiple files

## License

MIT License - see LICENSE file for details.
