# Параметр filename - Краткая инструкция

## Что добавлено?

В функции `compress_fcidump_dir()` и `restore_loose_fcidump()` добавлен опциональный параметр `filename`, который позволяет работать с файлами FCIDUMP произвольного имени.

## Главная особенность

**Формат файла определяется автоматически по внутренней сигнатуре, а не по расширению!**

Это означает:
- Файл может называться просто `data` без расширения
- На самом деле он может быть `.bin.zst` сжатым файлом
- Система сама определит формат и обработает правильно

## Как использовать?

### Сжатие файла с произвольным именем

```python
from pyscf2gecco.archiver.archiver_core import compress_fcidump_dir

# У вас есть файл "my_fcidump_data" (любое имя, любой формат)
result = compress_fcidump_dir(
    dirpath="/path/to/directory",
    tag="test",
    compress="zstd",
    fcidump_filename="my_fcidump_data"  # ← просто указываем имя файла
)
```

### Распаковка файла с произвольным именем

```python
from pyscf2gecco.archiver.archiver_core import restore_loose_fcidump

# Файл может называться как угодно, формат определится автоматически
result = restore_loose_fcidump(
    dirpath="/path/to/directory",
    to_text=True,
    fcidump_filename="my_compressed_file"  # ← указываем имя файла
)
```

### Старый код работает без изменений!

```python
# Если filename не указан - используются стандартные имена FCIDUMP
result = compress_fcidump_dir(
    dirpath="/path/to/directory",
    tag="test",
    compress="zstd"
    # filename не указан → работает как раньше
)
```

## Автоматическое определение формата

Система проверяет файл по сигнатуре:

| Формат | Сигнатура | Описание |
|--------|-----------|----------|
| `.bin` | `FCD5` (4 байта) | Бинарный формат FCIDUMP |
| `.bin.zst` | `0x28B52FFD` | Сжатый zstd формат |
| `.txt` | Текст с `&FCI`, `NORB` и т.д. | Текстовый FCIDUMP |

**Пример:** Файл называется `data`, но внутри него сигнатура `0x28B52FFD` → система определит, что это `.bin.zst` и обработает соответственно.

## Безопасность

✓ Обратная совместимость на 100%  
✓ Существующий код не затронут  
✓ Добавлена проверка формата  
✓ Все тесты пройдены  

## Подробности

Смотри полную документацию в файле `FILENAME_PARAMETER_README.md`
