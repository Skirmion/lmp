# Примеры использования параметра filename в GeCCoArchiver API

## Краткое описание

Добавлена поддержка работы с FCIDUMP файлами произвольного имени:
- **`filename`** - в `compress_fcidump()` - для сжатия файлов с произвольным именем
- **`fcidump_filename`** - в `compress_all()`, `decompress_all()`, `decompress_fcidump()` - для работы с FCIDUMP произвольного имени
- **`archive_path`** - в `decompress_all()` - для указания конкретного архива для распаковки

## Базовые примеры

### Сжатие FCIDUMP с произвольным именем

```python
from pyscf2gecco.archiver import GeCCoArchiver

archiver = GeCCoArchiver(archive_name="project")

# Файл называется "my_integrals" (не "FCIDUMP")
archiver.compress_fcidump(
    root="./calculations",
    fcidump_filename="my_integrals"
)
# my_integrals → my_integrals.bin → my_integrals.bin.zst
```

### Архивирование с FCIDUMP произвольного имени

```python
archiver = GeCCoArchiver(
    archive_name="exp",
    patterns=["*.log"]
)

archiver.compress_all(
    root="./data",
    with_fcidump=True,
    fcidump_fcidump_filename="custom_fcidump"  # ← FCIDUMP файл с этим именем
)
```

### Распаковка конкретного архива

```python
archiver = GeCCoArchiver(archive_name="exp")

archiver.decompress_all(
    root="./restore",
    to_text=True,
    archive_path="./data/project_archive_exp.tar.xz",  # ← конкретный архив
    fcidump_fcidump_filename="restored"  # переименовать FCIDUMP при распаковке
)
```

### Восстановление FCIDUMP с произвольным именем

```python
archiver = GeCCoArchiver(archive_name="calc")

archiver.decompress_fcidump(
    root="./data",
    to_text=True,
    fcidump_fcidump_filename="my_data",  # файл my_data.bin.zst → my_data.output
    remove_archive=False
)
```

## Автоопределение формата

**Ключевая особенность**: формат файла определяется по внутренней сигнатуре, не по расширению!

```python
# Файл называется просто "data", но это может быть .bin.zst
archiver.compress_fcidump(root="./", fcidump_filename="data")

# Система сама определит:
# - FCD5 → бинарный .bin
# - 0x28B52FFD → сжатый .bin.zst
# - текст с &FCI → текстовый FCIDUMP
```

## Полный workflow

```python
from pyscf2gecco.archiver import GeCCoArchiver

# 1. Сжать FCIDUMP с именем "qc_data"
archiver = GeCCoArchiver(archive_name="quantum")
archiver.compress_fcidump(
    root="./calc",
    to_zstd=True,
    fcidump_filename="qc_data"
)

# 2. Архивировать весь проект
archiver.compress_all(
    root="./calc",
    with_fcidump=True,
    fcidump_fcidump_filename="qc_data",
    comment="Temperature scan 100-300K"
)

# 3. Распаковать конкретный расчет
archiver.decompress_all(
    root="./analysis",
    to_text=True,
    archive_path="./calc/run_200K/project_archive_quantum.tar.xz",
    fcidump_fcidump_filename="analysis_data_200K"
)
```

## Обратная совместимость

```python
# Старый код работает без изменений
archiver = GeCCoArchiver(archive_name="old")

# Без filename → стандартные имена FCIDUMP
archiver.compress_fcidump(root="./")
archiver.compress_all(root="./", with_fcidump=True)
archiver.decompress_all(root="./", to_text=True)
```

## Проверка метаданных

```python
archiver = GeCCoArchiver(archive_name="proj")

# Показать информацию о всех FCIDUMP (любого имени)
archiver.show_meta(
    root="./",
    show_user=True,
    list_archives=True
)
```

## Важно

1. **Хеши**: При архивировании хеши FCIDUMP вычисляются и сохраняются правильно, независимо от имени файла
2. **Проверка целостности**: При распаковке хеши проверяются автоматически
3. **Приоритет**: `.bin.zst` > `.bin` > текстовый файл

Полная документация: `FILENAME_PARAMETER_README.md`
