# PySCF2GeCCo Installation Guide

## Automatic Cython Compilation

The package is configured to **automatically compile Cython extensions** during standard pip installation. No additional flags or steps required!

## Installation

### From Local Directory
```bash
pip install .
```

### From PyPI (when published)
```bash
pip install pyscf2gecco
```

### Development Mode
```bash
pip install -e .
```

## What Gets Compiled

During installation, the following Cython modules are automatically compiled for optimal performance:

- `pyscf2gecco.archiver.fcidump_codec` - Fast FCIDUMP binary encoding/decoding
- `pyscf2gecco.archiver.zstd_codec` - High-performance Zstandard compression

## Requirements

### Runtime Requirements
- Python >= 3.8
- numpy >= 1.20.0
- pyscf >= 2.0.0
- psutil >= 5.8.0
- Cython >= 0.29.0 (automatically installed)

### Build Requirements
The following are automatically handled by pip during installation:
- setuptools >= 45
- wheel
- Cython >= 0.29.0
- numpy >= 1.20.0
- C compiler (gcc, clang, etc.)
- zstd library (for archiver module)

## System Dependencies

### Ubuntu/Debian
```bash
sudo apt-get update
sudo apt-get install gcc libzstd-dev
```

### RHEL/CentOS/Fedora
```bash
sudo yum install gcc libzstd-devel
```

### macOS
```bash
brew install zstd
```

## Verification

After installation, verify that Cython modules are working:

```bash
python3 -c "from pyscf2gecco.archiver import fcidump_codec, zstd_codec; print('✓ Cython modules working')"
```

Or run the comprehensive test:

```python
import pyscf2gecco
from pyscf2gecco import FCIDumpWriter, GeCCoArchiver, GeccoInputBuilder
from pyscf2gecco.archiver import fcidump_codec, zstd_codec
print("✓ All modules imported successfully")
```

## Troubleshooting

### Compilation Fails

If Cython compilation fails during installation, the package will still install but without performance optimizations. Check:

1. **C compiler installed**: `gcc --version` or `clang --version`
2. **zstd library installed**: Check system package manager
3. **Build tools**: `pip install --upgrade setuptools wheel`

### Missing Dependencies

If you see import errors:
```bash
pip install --upgrade numpy pyscf psutil Cython
```

### Permission Issues

Use `--user` flag for local installation:
```bash
pip install --user .
```

## Notes

- Cython is now a **main dependency**, not optional
- Build configuration is in `pyproject.toml` (PEP 517/518 compliant)
- Graceful fallback if compilation fails
- No need for `--install-option` or `--global-option` flags

## Quick Start

After installation:

```python
from pyscf2gecco import FCIDumpWriter
from pyscf import gto, scf

# Your PySCF calculation
mol = gto.M(atom='H 0 0 0; H 0 0 0.74', basis='sto-3g')
mf = scf.RHF(mol).run()

# Generate FCIDUMP
writer = FCIDumpWriter(mf)
writer.write_fcidump()
```

See `examples_*.py` files for more usage examples.
