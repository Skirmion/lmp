# ✅ Логика Runner обновлена (финальная версия)

## Что было исправлено

### ✅ Финальная логика (оптимальная):
```python
# fcidump_filename="my_file" (текстовый)

# mode="ram" или mode="disk"
runner.run("job.inp", mode="ram", fcidump_filename="my_file")
runner.run("job.inp", mode="disk", fcidump_filename="my_file")
# → mode РАБОТАЕТ (проверки выполняются)
# → но для текстовых ВСЕГДА создается СИМЛИНК
# → НЕТ лишнего копирования!
```

## Ответы на вопросы

### ✅ Вопрос 1: Если задан fcidump_filename + mode=disk + ./FCIDUMP существует → ошибка?

**Ответ: ДА!**

```python
# ./FCIDUMP существует
runner.run("job.inp", mode="disk", fcidump_filename="my_file")
# → FileExistsError: mode='disk': './FCIDUMP' already exists in CWD
```

### ✅ Вопрос 2: Если fcidump_filename задан для текстового файла, mode работает?

**Ответ: ДА, mode РАБОТАЕТ (проверки), но для текстовых ВСЕГДА симлинк!**

```python
# mode="ram"
runner.run("job.inp", mode="ram", fcidump_filename="my_file")
# → Проверка: ./FCIDUMP не должен существовать
# → Создается СИМЛИНК: ./FCIDUMP -> my_file

# mode="disk"
runner.run("job.inp", mode="disk", fcidump_filename="my_file")
# → Проверка: ./FCIDUMP не должен существовать
# → Создается СИМЛИНК: ./FCIDUMP -> my_file (НЕ КОПИЯ!)
```

**Преимущество:** Нет лишнего копирования больших текстовых файлов!

## Полная матрица поведения

| fcidump_filename | Файл | mode | Обработка | Cleanup |
|------------------|------|------|-----------|---------|
| None | FCIDUMP (текст) | любой | Используется как есть | Не удаляется |
| None | FCIDUMP.bin | ram | Распаковка в RAM | Удаляется |
| None | FCIDUMP.bin | disk | Распаковка на диск | Удаляется |
| "my_file" | my_file (текст) | ram | **Симлинк** | Удаляется |
| "my_file" | my_file (текст) | disk | **Симлинк** | Удаляется |
| "my_file" | my_file.bin | ram | Распаковка в RAM | Удаляется |
| "my_file" | my_file.bin | disk | Распаковка на диск | Удаляется |

## Ключевые особенности

### ✅ Для текстовых файлов с fcidump_filename:
- **Всегда симлинк** (независимо от mode)
- Нет копирования → экономия времени
- Нет копирования → экономия места
- Проверки существования работают для обоих режимов

### ✅ Для бинарных/сжатых файлов:
- mode="ram": распаковка в /dev/shm + симлинк
- mode="disk": распаковка на диск

## Изменения в коде

### Упрощен метод _run_text_fcidump:
```python
def _run_text_fcidump(self, gecco_inp, out_path, source_path, mode):
    """
    Для текстовых файлов всегда создается симлинк.
    mode влияет только на проверки, но не на способ обработки.
    """
    # Всегда симлинк (независимо от mode)
    os.symlink(source_path, "FCIDUMP")
    # ... запуск gecco.x ...
    # Cleanup симлинка
```

## Примеры

### Пример 1: Текстовый файл, RAM mode
```python
runner = FCIDUMPRunner(verbose=True)
exit_code = runner.run(
    "job.inp",
    mode="ram",
    fcidump_filename="integrals.txt"
)
# Вывод:
# [MODE] ram; creating symlink ./FCIDUMP -> integrals.txt
# [RUN ] PID=12345 CMD='gecco.x job.inp' OUT='job.out'
# [DONE] gecco.x exit code 0
# [CLEAN] removed symlink ./FCIDUMP
```

### Пример 2: Текстовый файл, DISK mode
```python
runner = FCIDUMPRunner(verbose=True)
exit_code = runner.run(
    "job.inp",
    mode="disk",
    fcidump_filename="integrals.txt"
)
# Вывод:
# [MODE] disk; creating symlink ./FCIDUMP -> integrals.txt
# [RUN ] PID=12345 CMD='gecco.x job.inp' OUT='job.out'
# [DONE] gecco.x exit code 0
# [CLEAN] removed symlink ./FCIDUMP
```

**Обратите внимание:** И в ram, и в disk mode создается симлинк!

### Пример 3: Бинарный файл - mode влияет
```python
# mode="ram" - распаковка в RAM
runner.run("job.inp", mode="ram", fcidump_filename="data.bin")

# mode="disk" - распаковка на диск
runner.run("job.inp", mode="disk", fcidump_filename="data.bin")
```

## Преимущества решения

1. **Производительность** - нет копирования текстовых файлов
2. **Экономия места** - не создаются дубликаты
3. **Консистентность** - проверки работают одинаково
4. **Простота** - один путь для текстовых файлов
5. **Гибкость** - mode всё ещё важен для бинарных/сжатых

## Файлы обновлены

- ✅ `pyscf2gecco/runner/fcidump_runner.py` - упрощена логика
- ✅ `pyscf2gecco/runner/BEHAVIOR_SUMMARY.md` - обновлена матрица
- ✅ `pyscf2gecco/runner/README.md` - обновлены примеры
- ✅ `pyscf2gecco/runner/LOGIC_CLARIFICATION.md` - уточнена логика

## Тестирование

✅ Компиляция успешна  
✅ Импорт работает  
✅ Логика оптимизирована  
✅ Документация обновлена  

---

## ✅✅✅ ЛОГИКА ОПТИМИЗИРОВАНА ✅✅✅

**Ключевые моменты:**
1. ✅ fcidump_filename + текстовый → **ВСЕГДА симлинк**
2. ✅ fcidump_filename + бинарный → mode влияет на распаковку
3. ✅ Проверки существования работают для всех случаев
4. ✅ Нет лишнего копирования

**⚡ МАКСИМАЛЬНО ЭФФЕКТИВНО! ⚡**
