# PySCF to GeCCo Converter

A comprehensive Python library for converting PySCF molecular integrals to FCIDUMP format optimized for GeCCo quantum chemistry software, with integrated archiving, testing, and execution management.

## Features

### Core Conversion
- **Multiple output formats**: Plain text, binary, and compressed (zstd)
- **Frozen core approximation**: Efficient treatment of core orbitals
- **Natural orbitals**: Automatic transformation for CASSCF calculations
- **Custom MO coefficients**: Support for user-provided molecular orbitals
- **Additional operators**: Include custom 1e/2e operators (kinetic, spin-orbit, etc.)
- **Memory optimized**: Chunked processing for large systems
- **Symmetry aware**: Automatic orbital sorting and symmetry screening
- **Performance monitoring**: Built-in memory and time profiling

### Archive & Compression
- **Binary FCIDUMP format**: Fast I/O with FCIDUMP v5 codec
- **Zstd compression**: ~99% space reduction with parallel decompression
- **Cython acceleration**: OpenMP-enabled parallel processing
- **Automatic format detection**: By file signature

### Testing & Validation
- **Automated test suites**: Batch execution with parallel processing
- **Energy comparison**: VALUE and REF modes
- **Format support**: Text, binary, compressed FCIDUMPs
- **Detailed reporting**: ASCII tables with pass/fail statistics
- **Error diagnostics**: Comprehensive logging and debugging

### Execution Management
- **RAM mode**: Fast execution with in-memory FCIDUMP
- **Disk mode**: Memory-efficient execution
- **Grace period monitoring**: Automatic cleanup after file closure
- **Format conversion**: Transparent handling of all formats

### Additional Utilities
- **ECP/pseudopotential loading**: GRECP and QED support
- **GeCCo input generation**: Automated input file creation
- **Batch processing**: Parallel execution with resource management

## Installation

```bash
# Basic installation
pip install pyscf2gecco

# With archiver support (Cython acceleration)
pip install pyscf2gecco[archiver]

# Development installation
git clone <repository>
cd pyscf2gecco
pip install -e .[archiver]
```

### Requirements
- Python >= 3.8
- NumPy >= 1.20.0
- PySCF >= 2.0.0
- psutil >= 5.8.0
- (Optional) Cython >= 0.29.0 for archiver acceleration
- (Optional) zstd library for compression

## Quick Start

### Generate FCIDUMP from PySCF

```python
from pyscf import gto, scf, mcscf
from pyscf2gecco import FCIDumpWriter

# Define molecule
mol = gto.M(
    atom='H 0 0 0; H 0 0 0.74',
    basis='cc-pvdz',
    symmetry=True
)

# Run calculation
mf = scf.RHF(mol).run()
mc = mcscf.CASSCF(mf, 2, 2).run()

# Generate FCIDUMP with natural orbitals
writer = FCIDumpWriter(
    mol, mc,
    natorb=True,
    format='bin',
    tol=1e-15,
    granularity=50
)
writer.run('FCIDUMP')
```

### Compress and Archive

```python
from pyscf2gecco import GeCCoArchiver

archiver = GeCCoArchiver()
archiver.compress_fcidump('project_dir')
```

### Run GeCCo Calculation

```python
from pyscf2gecco.runner import FCIDUMPRunner

runner = FCIDUMPRunner(gecco_bin="gecco.x", verbose=True)
exit_code = runner.run(
    "job.inp",
    mode="ram",
    grace=600.0  # Auto-cleanup after 10 min
)
```

### Automated Testing

```python
from pyscf2gecco.auto_test import RunnerConfig, run_all_tests
from pathlib import Path

cfg = RunnerConfig(
    gecco_inputs=Path("gecco_inputs"),
    pyscf_inputs=Path("pyscf_inputs"),
    max_workers=8,
    tolerance=1e-8
)

results, summary = run_all_tests(cfg)
print(summary)  # PASS=15  FAIL=0  ERROR=0  TOTAL=15
```

## Core Modules

### Public API
- **FCIDumpWriter** - Main class for FCIDUMP generation
- **GeCCoArchiver** - Binary compression and archiving
- **GeccoInputBuilder** - GeCCo input file generation
- **FCIDUMPRunner** - GeCCo execution management

### Submodules

#### fc_gen (FCIDUMP Generation)
- `fc_gen.py` - Main FCIDumpWriter class
- `fc_utils.py` - Helper functions and preprocessing
- `integrals_one_e.py` - One-electron integral processing
- `integrals_two_e.py` - Two-electron integral processing
- `fmt.py` - FCIDUMP formatting and constants
- `metadata_utils.py` - Metadata extraction

#### archiver (Compression)
- `gecco_archiver.py` - GeCCoArchiver class
- `archiver_core.py` - Core compression logic
- `fcidump_codec.pyx` - Cython codec (binary format)
- `zstd_codec.pyx` - Cython zstd wrapper

#### ecp (Pseudopotentials)
- `load_ecp.py` - Load and validate GRECP/QED

#### gen_inp (Input Generation)
- `gecco_input_writer.py` - GeccoInputBuilder class

#### runner (Execution)
- `fcidump_runner.py` - FCIDUMPRunner class

#### auto_test (Testing)
- `fcidump_tester.py` - Single test execution
- `run_prepared_tests.py` - Batch test runner

## Advanced Usage

### Frozen Core Approximation

```python
# Freeze first 2 orbitals (typically core orbitals)
writer = FCIDumpWriter(
    mol, method,
    frozen_indices=[0, 1],
    format='txt'
)
writer.run('FCIDUMP')
```

### Custom MO Coefficients

```python
import numpy as np

# Load or define custom MO matrix
mo_custom = np.loadtxt('my_mos.txt')

writer = FCIDumpWriter(
    mol, method,
    mo_coeff=mo_custom,  # Overrides method.mo_coeff
    format='bin'
)
writer.run('FCIDUMP')
```

### Additional Operators

```python
# Include kinetic energy and custom operators
writer = FCIDumpWriter(
    mol, method,
    add_ops=[
        "int1e_kin",              # PySCF 1e integral name
        "int2e_ip1",              # PySCF 2e integral name
        ("my_1e_op", my_matrix),  # Custom 1e operator (n×n)
        ("my_2e_op", my_tensor),  # Custom 2e operator (n×n×n×n)
    ],
    format='zst'  # Compressed output
)
writer.run('FCIDUMP.bin.zst')
```

### Output Formats

```python
# Plain text (Molpro format)
writer = FCIDumpWriter(mol, method, format='txt')
writer.run('FCIDUMP')

# Binary (custom format, faster I/O)
writer = FCIDumpWriter(mol, method, format='bin')
writer.run('FCIDUMP.bin')

# Compressed (binary + zstd compression)
writer = FCIDumpWriter(mol, method, format='zst')
writer.run('FCIDUMP.bin.zst')
```

## Parameters Reference

### FCIDumpWriter Parameters

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `mol` | `pyscf.gto.Mole` | Required | PySCF molecule object |
| `method` | PySCF method | Required | RHF, ROHF, CASSCF, etc. |
| `format` | str | `"bin"` | Output format: "txt", "bin", or "zst" |
| `tol` | float | `1e-20` | Integral threshold |
| `granularity` | int | `0` | Chunking size (0=parallel mode) |
| `extended_debug` | bool | `True` | Enable profiling |
| `verbose` | bool | `False` | Print diagnostic messages |
| `sort_by_symmetry` | bool | `True` | Sort MOs by irrep |
| `natorb` | bool | `True` | Use natural orbitals (CASSCF) |
| `frozen_indices` | Sequence[int] | `()` | Orbitals to freeze (0-based) |
| `add_ops` | Sequence | `None` | Additional operators |
| `mo_coeff` | np.ndarray | `None` | Custom MO coefficients |

## Memory Management

The library implements efficient memory management:
- **Granularity mode** (`granularity>0`): Processes integrals in chunks
- **Parallel mode** (`granularity=0`): Maximum speed, more memory
- **Automatic cleanup**: Explicit `del` and `gc.collect()` after large arrays
- **Streaming**: Sequential writing for large calculations

## Symmetry Handling

- Automatic detection of point group symmetry
- Molpro symmetry labeling (irrep IDs)
- Bitwise symmetry screening for 2e integrals
- Fallback to C1 symmetry if needed

## Output Files

1. **FCIDUMP** - Main integral file (text or binary)
2. **FCIDUMP_info.txt** - Metadata file containing:
   - System parameters (norb, nelec, ms2)
   - Molecular geometry
   - Basis set and ECP definitions
   - Processing parameters
   - Orbital symmetries

## Performance Tips

1. Use `granularity=0` for small systems (faster, more memory)
2. Use `granularity=50-100` for large systems (less memory)
3. Binary format is ~10× faster than text for I/O
4. Compressed format saves ~99% disk space with minimal overhead
5. Enable `extended_debug=False` to reduce profiling overhead

## API Documentation

All public functions include comprehensive docstrings with:
- Parameter descriptions and types
- Return value specifications
- Usage examples
- Implementation notes

Access documentation in Python:
```python
from pyscf2gecco import FCIDumpWriter, FCIDUMPRunner
from pyscf2gecco.auto_test import TestConfig

help(FCIDumpWriter)
help(FCIDUMPRunner)
help(TestConfig)
```

### Example Files
- `examples_fc_gen.py` - FCIDUMP generation examples
- `examples_archiver.py` - Compression and archiving examples
- `examples_ecp.py` - ECP/pseudopotential examples
- `examples_gen_inp.py` - Input generation examples
- `examples_runner.py` - GeCCo execution examples
- `examples_auto_test.py` - Testing framework examples

## Development Status

**Version**: 1.0.0 (October 2025)

**Completed features**:
- ✅ FCIDUMP generation with multiple formats
- ✅ Binary compression with Cython acceleration
- ✅ Automated testing framework
- ✅ GeCCo execution management
- ✅ Pseudopotential utilities
- ✅ Input file generation
- ✅ Comprehensive English documentation
- ✅ PEP8 formatting throughout

**Code optimizations**:
- ✅ Removed "Coeff memory" tracking
- ✅ Eliminated kwargs.get() - explicit parameters
- ✅ Split processing into separate modules
- ✅ Removed small_last flag - uniform distribution
- ✅ Unified formatting module
- ✅ Removed redundant parameters
- ✅ Cleaned up unused files

**Guarantees**:
- ✅ Logic unchanged - all functionality preserved
- ✅ Memory management fully retained
- ✅ All optimizations intact (gc.collect, del, etc.)
- ✅ Public API backward compatible

## Package Structure

```
pyscf2gecco/
├── __init__.py              # Main package interface
├── fc_gen/                  # FCIDUMP generation
│   ├── fc_gen.py           # FCIDumpWriter class
│   ├── fc_utils.py         # Utilities
│   ├── integrals_one_e.py  # 1e integrals
│   ├── integrals_two_e.py  # 2e integrals
│   ├── fmt.py              # Formatting
│   └── metadata_utils.py   # Metadata handling
├── archiver/                # Compression
│   ├── gecco_archiver.py   # GeCCoArchiver class
│   ├── archiver_core.py    # Core logic
│   ├── fcidump_codec.pyx   # Binary codec
│   └── zstd_codec.pyx      # Compression
├── ecp/                     # Pseudopotentials
│   └── load_ecp.py         # ECP utilities
├── gen_inp/                 # Input generation
│   └── gecco_input_writer.py
├── runner/                  # Execution
│   └── fcidump_runner.py   # FCIDUMPRunner
├── auto_test/               # Testing
│   ├── fcidump_tester.py   # Single tests
│   └── run_prepared_tests.py # Batch tests
└── examples_*.py            # Usage examples
```

## License

[Your license here]

## Citation

If you use this software in your research, please cite:
[Citation information]

## Support

For issues, questions, or contributions:
- GitHub Issues: [repository URL]
- Documentation: [docs URL]
- Contact: [email]
