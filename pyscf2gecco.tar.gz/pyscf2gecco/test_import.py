#!/usr/bin/env python3
"""
Test package imports and structure.

This script verifies that the pyscf2gecco package is properly structured
and all modules can be imported successfully.
"""

import sys

# Test main package import
print("Testing pyscf2gecco package...")
print("=" * 60)

try:
    import pyscf2gecco
    print(f"✓ pyscf2gecco package imported successfully")
    print(f"  Version: {pyscf2gecco.__version__}")
    print(f"  Location: {pyscf2gecco.__file__}")
except Exception as e:
    print(f"✗ pyscf2gecco package import failed: {e}")
    import traceback
    traceback.print_exc()
    sys.exit(1)

# Test main classes
print("\nTesting main classes...")
try:
    from pyscf2gecco import FCIDumpWriter
    print(f"✓ FCIDumpWriter imported: {FCIDumpWriter.__name__}")
except Exception as e:
    print(f"✗ FCIDumpWriter import failed: {e}")
    sys.exit(1)

try:
    from pyscf2gecco import GeCCoArchiver
    print(f"✓ GeCCoArchiver imported: {GeCCoArchiver.__name__}")
except Exception as e:
    print(f"✗ GeCCoArchiver import failed: {e}")
    sys.exit(1)

try:
    from pyscf2gecco import GeccoInputBuilder
    print(f"✓ GeccoInputBuilder imported: {GeccoInputBuilder.__name__}")
except Exception as e:
    print(f"✗ GeccoInputBuilder import failed: {e}")
    sys.exit(1)

# Test submodules
print("\nTesting submodules...")
try:
    from pyscf2gecco import ecp
    print(f"✓ ecp submodule imported")
    print(f"  Exports: {ecp.__all__}")
except Exception as e:
    print(f"✗ ecp submodule import failed: {e}")
    sys.exit(1)

try:
    from pyscf2gecco import gen_inp
    print(f"✓ gen_inp submodule imported")
    print(f"  Exports: {gen_inp.__all__}")
except Exception as e:
    print(f"✗ gen_inp submodule import failed: {e}")
    sys.exit(1)

# Test ECP functions
print("\nTesting ECP functions...")
try:
    from pyscf2gecco.ecp import load_pseudopotential, help_pseudopotential, diagnose_pseudopotentials
    print(f"✓ All ECP functions available")
except Exception as e:
    print(f"✗ ECP functions import failed: {e}")
    sys.exit(1)

# Test gen_inp functions
print("\nTesting gen_inp functions...")
try:
    from pyscf2gecco.gen_inp import molpro_irrep, spin_info, make_orb_lines
    print(f"✓ All gen_inp utility functions available")
except Exception as e:
    print(f"✗ gen_inp functions import failed: {e}")
    sys.exit(1)

print("\n" + "=" * 60)
print("All tests passed!")
print("\nPackage is ready to use:")
print("  >>> from pyscf2gecco import FCIDumpWriter, GeCCoArchiver, GeccoInputBuilder")
print("  >>> from pyscf2gecco import ecp, gen_inp")

