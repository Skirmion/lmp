# pyscf2gecco - Quick Start

Convert PySCF molecular integrals to FCIDUMP format for GECCO quantum chemistry software.

## Installation

```bash
cd /path/to/p2g-18
pip install -e .
```

## Basic Usage

```python
from pyscf import gto, scf
from pyscf2gecco import FCIDumpWriter

# Create molecule and run calculation
mol = gto.M(atom='H 0 0 0; H 0 0 0.74', basis='sto-3g')
mf = scf.RHF(mol).run()

# Generate FCIDUMP
writer = FCIDumpWriter(mol, mf, granularity=50, tol=1e-15)
writer.run('FCIDUMP')
```

## Compression

```python
from pyscf2gecco import GeCCoArchiver

archiver = GeCCoArchiver()
archiver.compress_fcidump('project_dir')
```

## Documentation

- **README_PACKAGE.md** - Full documentation
- **INSTALL.md** - Installation guide
- **STRUCTURE.md** - Package structure
- **example.py** - Usage examples
- **test_import.py** - Validation script

## Features

- ✓ Multiple output formats (text, binary, compressed)
- ✓ Natural orbital support (CASSCF)
- ✓ Custom MO coefficients
- ✓ Frozen core approximation
- ✓ Additional operators
- ✓ Memory-efficient processing
- ✓ Parallel compression
- ✓ Archive management

## Test

```bash
python test_import.py  # Validate package
python example.py      # Run examples
```

## Main Classes

### FCIDumpWriter
- `mol`: PySCF Mole object
- `method`: PySCF method (SCF, CASSCF, etc.)
- `granularity`: Block size (default: 50)
- `tol`: Integral threshold (default: 1e-15)
- `natorb`: Use natural orbitals (default: False)
- `frozen_indices`: Frozen orbital indices
- `mo_coeff`: Custom MO coefficients
- `add_ops`: Additional operators

### GeCCoArchiver
- `compress_fcidump()`: Compress FCIDUMP files
- `compress_all()`: Create project archive
- `decompress_all()`: Extract archive
- `show_meta()`: Display metadata
- `list_archives()`: List archives

## Version

1.0.0

## License

MIT
