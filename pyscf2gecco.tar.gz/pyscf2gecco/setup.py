"""
Setup script for pyscf2gecco package.
"""

from setuptools import setup, find_packages, Extension
import numpy as np

# Try to build Cython extensions, but don't fail if not possible
ext_modules = []
try:
    from Cython.Build import cythonize
    
    extensions = [
        Extension(
            "pyscf2gecco.archiver.fcidump_codec",
            ["pyscf2gecco/archiver/fcidump_codec.pyx"],
            include_dirs=[np.get_include()],
            extra_compile_args=["-O3", "-march=native", "-fopenmp"],
            extra_link_args=["-fopenmp"],
        ),
        Extension(
            "pyscf2gecco.archiver.zstd_codec",
            ["pyscf2gecco/archiver/zstd_codec.pyx"],
            libraries=["zstd"],
            extra_compile_args=["-O3"],
        ),
    ]
    ext_modules = cythonize(extensions, language_level="3")
    print("Cython extensions will be compiled for optimal performance.")
except Exception as e:
    print(f"Warning: Cython compilation not available: {e}")
    print("Package will be installed without Cython acceleration.")
    ext_modules = []

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="pyscf2gecco",
    version="1.0.0",
    author="PySCF2GECCO Contributors",
    description="Comprehensive toolkit for PySCF to GeCCo conversion with archiving, testing, and execution management",
    long_description=long_description,
    long_description_content_type="text/markdown",
    packages=find_packages(),
    ext_modules=ext_modules,
    package_data={
        'pyscf2gecco.auto_test': ['gecco_inputs/*', 'pyscf_inputs/*.py'],
        'pyscf2gecco.ecp': ['pseudos/*.inp'],
        'pyscf2gecco.gen_inp': ['templates/*.inp'],
    },
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Science/Research",
        "Topic :: Scientific/Engineering :: Chemistry",
        "Topic :: Scientific/Engineering :: Physics",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "License :: OSI Approved :: MIT License",
        "Operating System :: POSIX :: Linux",
    ],
    python_requires=">=3.8",
    install_requires=[
        "numpy>=1.20.0",
        "pyscf>=2.0.0",
        "psutil>=5.8.0",
        "Cython>=0.29.0",
    ],
    include_package_data=True,
    zip_safe=False,
)
