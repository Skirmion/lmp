import os
import sys
import glob
import shutil
import platform
import subprocess
from pathlib import Path
from setuptools import setup, find_packages, Extension
from setuptools.command.build_ext import build_ext


def readme() -> str:
    p = Path(__file__).with_name("README.md")
    return p.read_text(encoding="utf-8") if p.exists() else ""


class CMakeExtension(Extension):
    """Пустое расширение: сборка делается CMake-ом в кастомной команде."""
    def __init__(self, name: str, cmake_target: str | None = None):
        super().__init__(name, sources=[])
        self.cmake_target = cmake_target  # не обязательно использовать


class CMakeBuild(build_ext):
    """Собираем CMake-проект и кладём .so в build_lib/libgrpp/libgrpp/liblibgrpp.so."""
    def run(self):
        for ext in self.extensions:
            self._build_cmake_and_stage(ext)
        # после того, как положили .so в staging, собираем питоновские модули
        super().run()

    def build_extension(self, ext):
        # Ничего не компилируем через setuptools: бинарник уже собран CMake-ом
        return

    # ---- helpers ----

    def _candidate_sources(self) -> list[Path]:
        """Порядок поиска CMakeLists.txt:
        1) $LIBGRPP_CMAKE_DIR (если задан),
        2) корень проекта,
        3) подкаталог libgrpp/."""
        root = Path(__file__).parent.resolve()
        env = os.environ.get("LIBGRPP_CMAKE_DIR")
        cand: list[Path] = []
        if env:
            cand.append(Path(env))
        cand.extend([root, root / "libgrpp"])
        # только те, где реально есть CMakeLists.txt
        return [c for c in cand if (c / "CMakeLists.txt").exists()]

    def _clean_build_dir(self, build_dir: Path):
        # Чистим, чтобы избежать конфликта генераторов (Ninja vs Makefiles)
        if build_dir.exists():
            shutil.rmtree(build_dir)
        build_dir.mkdir(parents=True, exist_ok=True)

    def _try_configure_and_build(self, src_dir: Path, build_dir: Path) -> bool:
        cfg = os.environ.get("CMAKE_BUILD_TYPE", "Release")
        generator = os.environ.get("CMAKE_GENERATOR")
        cmake_cfg = [
            "cmake",
            "-S", str(src_dir),
            "-B", str(build_dir),
            f"-DCMAKE_BUILD_TYPE={cfg}",
            f"-DPython3_EXECUTABLE={sys.executable}",
        ]
        if generator:
            cmake_cfg += ["-G", generator]

        # Конфигурирование
        r = subprocess.run(cmake_cfg)
        if r.returncode != 0:
            return False

        # Сборка (параллельно)
        jobs = str(os.cpu_count() or 2)
        r = subprocess.run(["cmake", "--build", str(build_dir), "--config", cfg, "--parallel", jobs])
        return r.returncode == 0

    def _find_built_library(self, build_dir: Path) -> Path:
        sysname = platform.system()
        ext = { "Windows": ".dll", "Linux": ".so", "Darwin": ".dylib" }.get(sysname)
        if not ext:
            raise OSError(f"Unsupported platform: {sysname}")

        # Ищем наиболее типичные имена
        patterns = [
            str(build_dir / f"**/liblibgrpp*{ext}"),
            str(build_dir / f"**/libgrpp*{ext}"),
        ]
        for pat in patterns:
            found = glob.glob(pat, recursive=True)
            if found:
                return Path(found[0])
        raise RuntimeError(f"Built library not found under {build_dir}")

    def _stage_into_wheel(self, built_lib: Path):
        # Фиксированное имя, как ожидает импортирующая часть
        sysname = platform.system()
        ext = { "Windows": ".dll", "Linux": ".so", "Darwin": ".dylib" }[sysname]
        dest_name = "liblibgrpp" + ext

        # 1) staging каталога wheel: build_lib/libgrpp/libgrpp/...
        build_py = self.get_finalized_command("build_py")
        stage_dir = Path(build_py.build_lib) / "libgrpp" / "libgrpp"
        stage_dir.mkdir(parents=True, exist_ok=True)
        shutil.copy2(built_lib, stage_dir / dest_name)
        print(f"✅ Copied compiled library into wheel staging: {stage_dir / dest_name}")

        # 2) продублировать в исходники пакета (удобно для editable)
        src_pkg_dir = Path(__file__).parent / "libgrpp" / "libgrpp"
        src_pkg_dir.mkdir(parents=True, exist_ok=True)
        shutil.copy2(built_lib, src_pkg_dir / dest_name)

    # ---- main ----

    def _build_cmake_and_stage(self, ext: CMakeExtension):
        build_temp = Path(self.build_temp).absolute()

        # Перебираем возможные исходные директории, каждый раз с «чистым» build_dir
        candidates = self._candidate_sources()
        if not candidates:
            raise FileNotFoundError(
                "CMakeLists.txt not found. "
                "Set LIBGRPP_CMAKE_DIR or ensure CMakeLists.txt exists in project root or libgrpp/."
            )

        last_err = None
        for src in candidates:
            try:
                self._clean_build_dir(build_temp)
                ok = self._try_configure_and_build(src, build_temp)
                if not ok:
                    raise RuntimeError(f"CMake configure/build failed for {src}")
                built_lib = self._find_built_library(build_temp)
                self._stage_into_wheel(built_lib)
                return  # успех
            except Exception as e:
                print(f"[cmake attempt failed for {src}]: {e}", file=sys.stderr)
                last_err = e
                continue

        # если ни один вариант не собрался
        raise RuntimeError(f"All CMake attempts failed. Last error: {last_err!r}")


ext_modules = [
    CMakeExtension(name="libgrpp", cmake_target="libgrpp"),
]

setup(
    name="libgrpp",
    version="0.0.1",
    author="A. Oleynichenko, M. Losev",
    author_email="alexvoleynichenko@gmail.com, losev.mi@phystech.su",
    description=("libgrpp4pyscf: middleware between libgrpp (C) and PySCF; "
                 "provides relativistic Hamiltonians (Breit, QED) in PySCF workflows."),
    long_description=readme(),
    long_description_content_type="text/markdown",
    url="https://github.com/aoleynichenko/libgrpp",
    packages=find_packages(),
    include_package_data=True,
    zip_safe=False,
    install_requires=["numpy", "scipy", "pyscf"],
    ext_modules=ext_modules,
    cmdclass={"build_ext": CMakeBuild},
    package_data={
        "libgrpp": [
            "libgrpp/liblibgrpp.so",
            "libgrpp/liblibgrpp.dylib",
            "libgrpp/liblibgrpp.dll",
        ]
    },
    keywords=[
        "libgrpp4pyscf", "libgrpp", "PySCF",
        "GRPP", "Quantum Chemistry", "Relativistic Hamiltonians", "Breit", "QED"
    ],
)
